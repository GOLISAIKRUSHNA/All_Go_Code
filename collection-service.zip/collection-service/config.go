package config

import (
	"context"

	"github.com/spf13/viper"
)

var AppConfig *viper.Viper

func InitConfigJson(ctx context.Context) {
	// Initialize a new Viper instance
	AppConfig = viper.New()

	// Additional configuration if needed
	AppConfig.SetConfigName("config")
	AppConfig.AddConfigPath(".")
	AppConfig.SetConfigType("json")

	// Read the configuration file
	if err := AppConfig.ReadInConfig(); err != nil {
		panic("Error reading config file: " + err.Error())
	}
}
