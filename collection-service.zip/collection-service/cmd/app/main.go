package main

import (
	"collection-service/cmd/app/bootstrap"																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																		
	"collection-service/common/logger"
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/middleware"
	route_v1 "collection-service/internal/routes/v1"
	"go.opentelemetry.io/otel/sdk/trace"

	"go.opentelemetry.io/contrib/instrumentation/github.com/gin-gonic/gin/otelgin"

	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
)

var AppConfig *viper.Viper
var traceProvider *trace.TracerProvider

func main() {
	// Creating Background context to receive interruption
	// Create a context that will be cancelled when an interrupt signal is received
	ctx, cancel := context.WithCancel(context.Background())
	// Loading environment variables
	settingEnvironment()

	// Load App Settings
	bootstrap.Boot(ctx)

	// Loading Opentelemetry
	var err error
	traceProvider, err = logger.InitializeTelemetry(ctx)
	if err != nil {
		logger.Fatal(ctx, err, "Telemetry initialization failed", nil)
	}

	// Initializing gin application
	app := gin.New()

	//loading the required base routes
	registerBaseRoutes(app)

	//registering all the required middlewares
	registerMiddlewares(app)

	// Api Registrations
	api := app.Group("/api")
	route_v1.Route(&gin.Context{}, api)

	// Not found route handlers
	app.NoRoute(handlers.NotFoundHandler)

	// Run on PORT 8010
	server := &http.Server{
		Addr:    ":" + viper.GetString("HTTP_SERVER_PORT"),
		Handler: app,
	}

	// Listen for interrupt signals and cancel the context when one is received
	go terminate(ctx, cancel, server)

	if err := server.ListenAndServe(); err != nil {
		log.Printf("Server error: %v\n", err)
		cancel()
	}
}

// Loading Environment Variables
func settingEnvironment() {
	viper.SetConfigFile(".env")
	viper.ReadInConfig()
	viper.AutomaticEnv()
}

// registering middleware
func registerMiddlewares(app *gin.Engine) {
	app.Use(otelgin.Middleware(viper.GetString("SERVICE_NAME")))
	app.Use(middleware.ExceptionHandler()) // Handling all the exceptions occurs
	app.Use(middleware.ApiLogger())
	app.Use(middleware.MandatoryHeaderMiddleware()) //all request and response using request id
}

// registering required base routes like health route and swagger route
func registerBaseRoutes(app *gin.Engine) {
	// HealthCheck Api
	app.GET("/health", func(c *gin.Context) {
		c.String(200, "Success")
	})
}

func terminate(ctx context.Context, cancel context.CancelFunc, server *http.Server) {
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	<-sigCh
	log.Print("Received interrupt signal, shutting down golang boilerplate service...")

	//clearing all clusters /connection and closing server
	clearCluster(ctx, cancel)
	closeServer(server)
}

func clearCluster(ctx context.Context, cancel context.CancelFunc) {
	if err := traceProvider.Shutdown(ctx); err != nil {
		logger.Fatal(ctx, err, "Failed to shutdown Telemetry", nil)
	}
	// cancelling the context
	cancel()

	// Destroying all intialization
	bootstrap.Sleep()
}

func closeServer(server *http.Server) {
	// Server will be closing here
	server.Shutdown(context.Background())
	
}
