package bootstrap

import (
	config "collection-service"
	"collection-service/common/bugtrackingtool"
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/adapter/permify"
	"collection-service/internal/adapter/rabbit_mq"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/app/services/storage/sqlservice"
	"collection-service/internal/utils"
	"collection-service/internal/utils/validators"
	"context"
	"github.com/rabbitmq/amqp091-go"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
)

// global variables so that all function can use this
var writeDB sqlservice.ISqlService
var readDB sqlservice.ISqlService
var redis *cacheservice.BaseCacheService
var rabbitMQ adapter.IMessageBroker
var rmqConnClose chan *amqp091.Error
var rmqClientClose chan *amqp091.Error

func Boot(ctx context.Context) bool {

	// Initializing Logger
	logger.Initialize(ctx)

	// Initializing the bug service tool
	bs := bugtrackingtool.GetNewBugTool()
	bs.Initialize()

	permify.InitPermifyClient(ctx)

	if strings.ToLower(viper.GetString("APP_ENV")) == "production" {
		gin.SetMode(gin.ReleaseMode)
	}

	// Write Database Connection and Migration code starts
	writeDB = sqlservice.GetMysqlClient(ctx, constants.WRITE_DATABASE_TYPE, nil)

	// Write Database Connection and Migration code starts
	readDB = sqlservice.GetMysqlClient(ctx, constants.READ_DATABASE_TYPE, nil)

	// Redis Connection settings
	if viper.GetBool("REDIS_ENABLED") {
		redis = cacheservice.GetNewCacheService(ctx, nil)
		redis.SetContext(ctx).SetExpiration(time.Duration(viper.GetInt64("REDIS_TTL")) * time.Second)

	}

	prefetchCount := viper.GetInt("RABBITMQ_PREFETCH_COUNT")

	// RabbitMQ Connection settings
	if viper.GetBool("RABBITMQ_ENABLE") {
		_, rmqConnClose = rabbit_mq.InitRabbitMQConn(ctx)
		rabbitMQ, rmqClientClose = rabbit_mq.InitRabbitMQClient(ctx, prefetchCount)

	}

	go handleReconnections(ctx)
	// aws initialization
	if viper.GetBool("AWS_ENABLE") {
		awsSession := aws.InitAWSSession(ctx)

		// aws s3 initialization
		if viper.GetBool("AWS_S3_ENABLE") {
			aws.InitS3Client(ctx, awsSession)
		}
	}

	//permify.InitPermifyClient(ctx)

	//Custom Validation Initialization
	validators.InitializeValidatorService()

	//System initial Configuration
	config.InitConfigJson(ctx)
	utils.InitTimeUtil()
	return true
}

func handleReconnections(ctx context.Context) {
	signalChan := make(chan os.Signal, 1)
	signal.Notify(signalChan, os.Interrupt, syscall.SIGTERM)

	// RabbitMQ Connection settings
	prefetchCount := viper.GetInt("RABBITMQ_PREFETCH_COUNT")

	for {
		select {
		case <-signalChan:
			logger.Info(ctx, "SIGTERM signal is received in reconnections, attempting graceful shutdown process!!!", nil)
			return
		case <-ctx.Done():
			logger.Info(ctx, "context is cancelled, attempting reconnections shutdown!!!", nil)
			return
		case <-rmqConnClose:
			logger.Info(ctx, "Connection to RabbitMQ lost. Reconnecting...", nil)
			_, rmqConnClose = rabbit_mq.InitRabbitMQConn(ctx)
			rabbitMQ, rmqClientClose = rabbit_mq.InitRabbitMQClient(ctx, prefetchCount)
		case <-rmqClientClose:
			logger.Info(ctx, "Channel to initial RabbitMQ lost. Reconnecting...", nil)
			rabbitMQ, rmqClientClose = rabbit_mq.InitRabbitMQClient(ctx, viper.GetInt("RABBITMQ_PREFETCH_COUNT"))
		}
	}
}

func Sleep() bool {

	//Closing mysql connections
	writeDB.Close()
	readDB.Close()

	//Closing redis connection
	if viper.GetBool("REDIS_ENABLED") {
		redis.Close()
	}

	//Closing rabbit_mq connection
	if viper.GetBool("RABBITMQ_ENABLE") {
		rabbitMQ.CloseChannel()
		rabbitMQ.CloseConn()
	}

	return true
}
