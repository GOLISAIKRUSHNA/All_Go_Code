package main

import (
	config "collection-service"
	"collection-service/cmd/consumer/handler"
	"collection-service/common/bugtrackingtool"
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/permify"
	"collection-service/internal/adapter/rabbit_mq"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/app/services/storage/sqlservice"
	"collection-service/internal/utils/validators"
	"context"
	"encoding/json"
	"fmt"
	"go.opentelemetry.io/otel/sdk/trace"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/rabbitmq/amqp091-go"

	"github.com/spf13/viper"
)

// These global variables are used to store data globally so that all function can use
// var rabbit_mq rabbit_mq.IMessageBroker
var writeDB sqlservice.ISqlService
var readDB sqlservice.ISqlService
var redis *cacheservice.BaseCacheService

var rabbitMQ adapter.IMessageBroker
var rabbitMQConn *amqp091.Connection
var mainClient *rabbit_mq.RabbitMQClient
var dlClient *rabbit_mq.RabbitMQClient
var rmqConnClose chan *amqp091.Error
var rmqClientClose chan *amqp091.Error
var mainClientClose chan *amqp091.Error
var dlClientClose chan *amqp091.Error

var traceProvider *trace.TracerProvider

func main() {

	// Creating Background context to receive interruption
	// Create a context that will be cancelled when an interrupt signal is received
	ctx, cancelFunc := context.WithCancel(context.Background())

	// Loading Environment Variables
	viper.SetConfigFile(".env")
	viper.ReadInConfig()
	viper.AutomaticEnv()

	// Initializing Logger
	logger.Initialize(ctx)

	// Loading Opentelemetry
	var err error
	traceProvider, err = logger.InitializeTelemetry(ctx)
	if err != nil {
		logger.Fatal(ctx, err, "Telemetry initialization failed", nil)
	}

	permify.InitPermifyClient(ctx)

	// Initializing the bug handler tool
	bs := bugtrackingtool.GetNewBugTool()
	bs.Initialize()
	// Redis Connection settings
	if viper.GetBool("REDIS_ENABLED") {
		redis = cacheservice.GetNewCacheService(ctx, nil)
		redis.SetContext(ctx).SetExpiration(time.Duration(viper.GetInt64("REDIS_TTL")) * time.Second)

	}
	//Custom Validation Initialization
	validators.InitializeValidatorService()

	// Write Database Connection and Migration code starts
	writeDB = sqlservice.GetMysqlClient(ctx, constants.WRITE_DATABASE_TYPE, nil)

	// Write Database Connection and Migration code starts
	readDB = sqlservice.GetMysqlClient(ctx, constants.READ_DATABASE_TYPE, nil)

	// initialize handlers
	collectionServiceHandler := handler.InitCollectionMQServiceHandler(ctx)
	airflowServiceHandler := handler.InitAirflowMQServiceHandler(ctx)
	commonServiceHandler := handler.InitCommonMQServiceHandler(ctx)
	dialerServiceHandler := handler.InitDialerMQServiceHandler(ctx)
	paymentServiceHandler := handler.InitPaymentMQServiceHandler(ctx)
	cronServiceHandler := handler.InitCronMQServiceHandler(ctx)

	// System initial Configuration
	config.InitConfigJson(ctx)
	// Kafka handler initialization

	if !viper.GetBool("RABBITMQ_ENABLE") {
		return
	}

	prefetchCount := viper.GetInt("RABBITMQ_PREFETCH_COUNT")

	rabbitMQConn, rmqConnClose = rabbit_mq.InitRabbitMQConn(ctx)

	//Initiated client for publish
	rabbitMQ, rmqClientClose = rabbit_mq.InitRabbitMQClient(ctx, prefetchCount)

	mainClient, mainClientClose = rabbit_mq.NewRabbitMQClient(ctx, rabbitMQConn, prefetchCount)
	dlClient, dlClientClose = rabbit_mq.NewRabbitMQClient(ctx, rabbitMQConn, prefetchCount)

	go handleReconnections(ctx)
	// initializing main queue
	err = mainClient.DeclareQueue(ctx,
		constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE,
		[]string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY},
		constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE)
	if err != nil {
		panic(err)
	}

	// initializing dead letter queue
	err = dlClient.DeclareQueue(ctx,
		constants.RMQ_COLLECTION_SERVICE_DL_QUEUE,
		[]string{constants.RMQ_COLLECTION_SERVICE_DL_QUEUE_KEY},
		constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE)
	if err != nil {
		panic(err)
	}

	// consuming records from rabbit_mq
	mainMsgBus, err := mainClient.Consume(ctx, constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE, false)
	if err != nil {
		logger.Fatal(ctx, err, logger.CreateLogMsg("Failed to set up queue consumer"), map[string]interface{}{"Queue": constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE})
		panic(err)
	}

	// consuming records from rabbit_mq
	deadMsgBus, err := dlClient.Consume(ctx, constants.RMQ_COLLECTION_SERVICE_DL_QUEUE, false)
	if err != nil {
		logger.Fatal(ctx, err, logger.CreateLogMsg("Failed to set up queue consumer"), map[string]interface{}{"Queue": constants.RMQ_COLLECTION_SERVICE_DL_QUEUE})
		panic(err)
	}

	// make a go routine to handle interruption events from os and trigger a shutdown
	go func() {
		signalChan := make(chan os.Signal, 1)
		signal.Notify(signalChan, os.Interrupt, syscall.SIGTERM)

		// block for signal and wait signal is received
		<-signalChan
		shutdownQueues(ctx)
		shutdownDatabases(ctx)
		shutdownTracing(ctx)

		logger.Info(ctx, "SIGTERM signal is received while handling interruptions, attempting graceful shutdown process!!!", nil)

		cancelFunc()
	}()

	for {
		select {
		case <-ctx.Done():
			startTime := time.Now()
			logger.Info(ctx, "App has initiated a graceful shutdown.", nil)

			logger.Info(ctx, fmt.Sprintf("App has completed the graceful shutdown process. %s", time.Since(startTime)), nil)
			return

		case msg, receivedBeforeClosing := <-mainMsgBus:
			if !receivedBeforeClosing {
				continue
			}

			success := true

			eventCtx := adapter.InjectTraceInfoIntoCtx(&msg, ctx)
			eventCtx = adapter.InjectAppInfoIntoCtx(&msg, eventCtx)

			var data adapter.Message
			err = json.Unmarshal(msg.Body, &data)
			if err != nil {
				logger.Error(eventCtx, err, "invalid body received in events", map[string]interface{}{"body": msg.Body})
				ackMsg(msg)
				continue
			}

			success = consumeEvent(eventCtx, data, collectionServiceHandler, airflowServiceHandler, commonServiceHandler, dialerServiceHandler, paymentServiceHandler, cronServiceHandler)

			ackMsg(msg)

			if !success {
				logger.Info(eventCtx, "failed to process the message in main queue.", nil)
				delayTime := constants.RMQ_DEAD_LETTER_QUEUE_DELAY_MS
				err := dlClient.Publish(
					eventCtx, constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE,
					[]string{constants.RMQ_COLLECTION_SERVICE_DL_QUEUE_KEY},
					msg.Body, &delayTime)

				if err != nil {
					logger.Error(eventCtx, err, "failed to publish events in main queue.", map[string]interface{}{"body": msg.Body})
				}

			}

			logger.Info(eventCtx, "msg received successfully in main queue.", map[string]interface{}{"data": data})

		case msg, receivedBeforeClosing := <-deadMsgBus:
			if !receivedBeforeClosing {
				continue
			}

			success := true

			eventCtx := adapter.InjectTraceInfoIntoCtx(&msg, ctx)
			eventCtx = adapter.InjectAppInfoIntoCtx(&msg, eventCtx)

			var data adapter.Message

			err = json.Unmarshal(msg.Body, &data)
			if err != nil {
				logger.Error(eventCtx, err, "invalid body received in events", map[string]interface{}{"body": msg.Body})

				ackMsg(msg)
				continue
			}

			success = consumeEvent(eventCtx, data, collectionServiceHandler, airflowServiceHandler, commonServiceHandler, dialerServiceHandler, paymentServiceHandler, cronServiceHandler)

			ackMsg(msg)

			if !success {
				logger.Info(eventCtx, "failed to process the message in DL queue.", nil)
				delayTime := constants.RMQ_DEAD_LETTER_QUEUE_DELAY_MS
				err := dlClient.Publish(
					eventCtx, constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE,
					[]string{constants.RMQ_COLLECTION_SERVICE_DL_QUEUE_KEY},
					msg.Body, &delayTime)

				if err != nil {
					logger.Error(eventCtx, err, "failed to publish events in DL queue.", map[string]interface{}{"body": msg.Body})
				}

			}

			logger.Info(eventCtx, "msg received successfully in dl queue.", map[string]interface{}{"data": data})
		}
	}
}

func consumeEvent(ctx context.Context, data adapter.Message,
	collectionServiceHandler *handler.CollectionMQServiceHandler,
	airflowServiceHandler *handler.AirflowMQServiceHandler,
	commonServiceHandler *handler.CommonMQServiceHandler,
	dialerServiceHandler *handler.DialerMQServiceHandler,
	paymentServiceHandler *handler.PaymentMQServiceHandler,
	cronServiceHandler *handler.CronMQServiceHandler,
) bool {
	success := true
	switch data.ServiceName {
	case constants.COLLECTION_SERVICE:
		success = collectionServiceHandler.ConsumeEvent(ctx, data)
	case constants.AIRFLOW_SERVICE:
		success = airflowServiceHandler.ConsumeEvent(ctx, data)
	case constants.COMMON_SERVICE:
		success = commonServiceHandler.ConsumeEvent(ctx, data)
	case constants.DIALER_SERVICE:
		success = dialerServiceHandler.ConsumeEvent(ctx, data)
	case constants.PAYMENT_SERVICE:
		success = paymentServiceHandler.ConsumeEvent(ctx, data)
	case constants.CRON_SERVICE:
		success = cronServiceHandler.ConsumeEvent(ctx, data)

	}
	return success
}

func ackMsg(msg amqp091.Delivery) {
	if err := msg.Ack(false); err != nil {
		fmt.Println("Ack failed for message")
	}
}

func handleReconnections(ctx context.Context) {
	signalChan := make(chan os.Signal, 1)
	signal.Notify(signalChan, os.Interrupt, syscall.SIGTERM)

	// RabbitMQ Connection settings
	prefetchCount := viper.GetInt("RABBITMQ_PREFETCH_COUNT")

	for {
		select {
		case <-signalChan:
			logger.Info(ctx, "SIGTERM signal is received in reconnections, attempting graceful shutdown process!!!", nil)
			return
		case <-ctx.Done():
			logger.Info(ctx, "context is cancelled, attempting reconnections shutdown!!!", nil)
			return
		case <-rmqConnClose:
			logger.Info(ctx, "Connection to RabbitMQ lost. Reconnecting...", nil)
			_, rmqConnClose = rabbit_mq.InitRabbitMQConn(ctx)
			rabbitMQ, rmqClientClose = rabbit_mq.InitRabbitMQClient(ctx, prefetchCount)
			mainClient, mainClientClose = rabbit_mq.NewRabbitMQClient(ctx, rabbitMQConn, prefetchCount)
			dlClient, dlClientClose = rabbit_mq.NewRabbitMQClient(ctx, rabbitMQConn, prefetchCount)
		case <-rmqClientClose:
			logger.Info(ctx, "Channel to initial RabbitMQ lost. Reconnecting...", nil)
			rabbitMQ, rmqClientClose = rabbit_mq.InitRabbitMQClient(ctx, viper.GetInt("RABBITMQ_PREFETCH_COUNT"))
		case <-mainClientClose:
			logger.Info(ctx, "Channel to mainClient RabbitMQ lost. Reconnecting...", nil)
			mainClient, mainClientClose = rabbit_mq.NewRabbitMQClient(ctx, rabbitMQConn, prefetchCount)
		case <-dlClientClose:
			logger.Info(ctx, "Channel to dlClient RabbitMQ lost. Reconnecting...", nil)
			dlClient, dlClientClose = rabbit_mq.NewRabbitMQClient(ctx, rabbitMQConn, prefetchCount)
		}
	}
}

func shutdownQueues(ctx context.Context) {
	mainClient.CloseChannel()
	dlClient.CloseChannel()
	rabbitMQ.CloseChannel()
	rabbitMQ.CloseConn()

}

func shutdownDatabases(ctx context.Context) {
	readDB.Close()
	writeDB.Close()
}

func shutdownTracing(ctx context.Context) {
	if err := traceProvider.Shutdown(ctx); err != nil {
		logger.Fatal(ctx, err, "Failed to shutdown Telemetry", nil)
	}
}
