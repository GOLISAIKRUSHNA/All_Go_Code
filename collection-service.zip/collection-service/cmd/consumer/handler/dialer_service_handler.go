package handler

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/services/attribute_service"
	cacheclear "collection-service/internal/app/services/cache_clear"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/client"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/app/services/ticket"
	"collection-service/internal/app/services/upload"
	"collection-service/internal/app/services/user"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/repositories"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
)

type DialerMQServiceHandler struct {
	cacheEnabled           bool
	uploadService          upload.IuploadService
	caseService            _case.ICaseService
	customerAddressService customer.ICustomerAddressService
	cacheClearService      cacheclear.ICacheClearService
	loanPayment            loan.ILoanPaymentService
	userURLService         user.IUserURLService
	attributeService       attribute_service.IAttributeService
	caseBlockService       _case.CaseBlockService
	ticketService          ticket.ITicketService
	caseFreezeService      _case.ICaseFreezeService
}

func InitDialerMQServiceHandler(ctx context.Context) *DialerMQServiceHandler {
	caseRepo := repositories.InitCaseRepository(ctx)
	caseFreezeRepo := repositories.InitCaseFreezeRepository(ctx)
	clientService := client.InitClientService(ctx)
	service := &DialerMQServiceHandler{
		caseService:       _case.InitCaseService(ctx),
		caseFreezeService: _case.InitCaseFreezeService(ctx, caseRepo, caseFreezeRepo, clientService),
	}

	return service

}

func (u *DialerMQServiceHandler) ConsumeEvent(ctx context.Context, message adapter.Message) (success bool) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeEvent"); span != nil {
		defer span.End()
	}

	// panic recovery handling.
	defer func() {
		if r := recover(); r != nil {
			logger.Error(ctx, nil, "panic from consumer handling", map[string]interface{}{"panic data": r})
		}
	}()

	// temporary value injection in context
	ctx = context.WithValue(ctx, "trace_id", message.TraceID)

	switch message.EventName {
	case "case_attempts":
		return u.consumeCaseAttempts(ctx, message.Payload)
	}

	return true
}

func (u *DialerMQServiceHandler) consumeCaseAttempts(ctx context.Context, payLoad interface{}) bool {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeCaseAttempts"); span != nil {
		defer span.End()
	}

	event := events.CaseAttemptReport{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeDisposition|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeDisposition|Payload unmarshal error", logger.LogFields{})
	}
	//time := time.Now()
	//eventFollowupDate := utils.StringToDateTime(event.FollowupDatetime)
	caseAttr := request.CaseAttributeReq{
		CaseRefNumber:        event.CaseRefNumber,
		TotalCallsAttempted:  event.TotalCallsAttempted,
		TotalCallsConnected:  event.TotalCallsConnected,
		TodaysCallsAttempted: event.TodaysCallsAttempted,
		LastCallConnectedAt:  &event.LastCallConnectedAt,
		TodaysCallsConnected: event.TodaysCallsConnected,
	}
	attrErr := u.caseService.InsertUpdateCaseAttributes(ctx, caseAttr.CaseRefNumber, caseAttr)
	if attrErr != nil {
		logger.Error(ctx, attrErr, "CollectionMQServiceHandler|consumeCaseAttempts|attrErr", logger.LogFields{})
		return false
	}
	freezeRequest := request.DailyCallsLimitFreeze{
		CaseRefNumber: event.CaseRefNumber,
		CreatedBy:     event.AgentRefNumber}
	freezeErr := u.caseFreezeService.DailyCallslimitFreeze(ctx, freezeRequest)
	if freezeErr != nil {
		logger.Error(ctx, freezeErr, "CollectionMQServiceHandler|consumeCaseAttempts|freezeErr", logger.LogFields{})
	}
	return true
}
