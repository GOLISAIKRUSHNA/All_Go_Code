package handler

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/dto/events"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
)

type PaymentMQServiceHandler struct {
	loanPayment loan.ILoanPaymentService
}

func InitPaymentMQServiceHandler(ctx context.Context) *PaymentMQServiceHandler {
	// service initializations
	caseService := _case.InitCaseService(ctx)
	loanService := loan.InitLoanService(ctx, caseService)
	service := &PaymentMQServiceHandler{
		loanPayment: loan.InitLoanPaymentService(ctx, loanService),
	}

	return service

}

func (u *PaymentMQServiceHandler) ConsumeEvent(ctx context.Context, message adapter.Message) (success bool) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeEvent"); span != nil {
		defer span.End()
	}

	// panic recovery handling.
	defer func() {
		if r := recover(); r != nil {
			logger.Error(ctx, nil, "panic from consumer handling", map[string]interface{}{"panic data": r})
		}
	}()

	// temporary value injection in context
	ctx = context.WithValue(ctx, "trace_id", message.TraceID)

	switch message.EventName {
	case "payment_status_update":
		return u.createLoanPayment(ctx, message.Payload)
	}

	return true
}

func (u *PaymentMQServiceHandler) createLoanPayment(ctx context.Context, payLoad interface{}) bool {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.createLoanPayment"); span != nil {
		defer span.End()
	}

	paymentStatusEvent := events.PaymentStatusEvent{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|createLoanPayment|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &paymentStatusEvent); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|createLoanPayment|Payload unmarshal error", logger.LogFields{})
	}
	if paymentStatusEvent.Status != "SUCCESS" {
		logger.Error(ctx, nil, "CollectionMQServiceHandler|createLoanPayment|Payment status is not success", logger.LogFields{})
		return true
	}

	paymentErr := u.loanPayment.HandleLoanPayment(ctx, paymentStatusEvent)
	if paymentErr != nil {
		logger.Error(ctx, paymentErr, "CollectionMQServiceHandler|createLoanPayment|Error while creating loan payment", logger.LogFields{})
		return false
	}

	return true

}
