package handler

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/services/attribute_service"
	cacheclear "collection-service/internal/app/services/cache_clear"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/app/services/ticket"
	"collection-service/internal/app/services/upload"
	"collection-service/internal/app/services/user"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
)

type CommonMQServiceHandler struct {
	cacheEnabled           bool
	uploadService          upload.IuploadService
	caseService            _case.ICaseService
	customerAddressService customer.ICustomerAddressService
	cacheClearService      cacheclear.ICacheClearService
	loanPayment            loan.ILoanPaymentService
	userURLService         user.IUserURLService
	attributeService       attribute_service.IAttributeService
	caseBlockService       _case.CaseBlockService
	ticketService          ticket.ITicketService
}

func InitCommonMQServiceHandler(ctx context.Context) *CommonMQServiceHandler {
	service := &CommonMQServiceHandler{
		caseService: _case.InitCaseService(ctx),
	}

	return service

}

func (u *CommonMQServiceHandler) ConsumeEvent(ctx context.Context, message adapter.Message) (success bool) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeEvent"); span != nil {
		defer span.End()
	}

	// panic recovery handling.
	defer func() {
		if r := recover(); r != nil {
			logger.Error(ctx, nil, "panic from consumer handling", map[string]interface{}{"panic data": r})
		}
	}()

	// temporary value injection in context
	ctx = context.WithValue(ctx, "trace_id", message.TraceID)

	switch message.EventName {
	case "payment_attributes":
		u.consumePaymentAttributes(ctx, message.Payload)
	}

	return true
}

func (u *CommonMQServiceHandler) consumePaymentAttributes(ctx context.Context, payLoad interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumePaymentAttributes"); span != nil {
		defer span.End()
	}

	event := events.CaseAttributeEvent{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumePaymentAttributes|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumePaymentAttributes|Payload unmarshal error", logger.LogFields{})
	}

	caseAttr := request.CaseAttributeReq{
		HavingInprogressPayments:        event.Payment.HavingInprogressPayments,
		HavingMandateInprogressPayments: event.Payment.HavingMandateInprogressPayments,
		CaseRefNumber:                   event.CaseRefNumber,
	}
	attrErr := u.caseService.InsertUpdateCaseAttributes(ctx, event.CaseRefNumber, caseAttr)
	if attrErr != nil {
		panic(attrErr)
	}
}
