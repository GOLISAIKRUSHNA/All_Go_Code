package handler

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	permifyService "collection-service/internal/adapter/permify"
	"collection-service/internal/app/constants"
	eventConstants "collection-service/internal/app/constants/events"
	permifyConstants "collection-service/internal/app/constants/permify"
	"collection-service/internal/app/services/attribute_service"
	cacheclear "collection-service/internal/app/services/cache_clear"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/client"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/app/services/special_offer"
	"collection-service/internal/app/services/ticket"
	"collection-service/internal/app/services/upload"
	"collection-service/internal/app/services/user"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/repositories"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"

	"github.com/spf13/viper"
)

type CollectionMQServiceHandler struct {
	cacheEnabled           bool
	uploadService          upload.IuploadService
	caseService            _case.ICaseService
	customerAddressService customer.ICustomerAddressService
	cacheClearService      cacheclear.ICacheClearService
	loanPayment            loan.ILoanPaymentService
	userURLService         user.IUserURLService
	attributeService       attribute_service.IAttributeService
	caseBlockService       _case.CaseBlockService
	ticketService          ticket.ITicketService
	permifyService         *permifyService.PermifyClient
	caseFreezeService      _case.ICaseFreezeService
}

func InitCollectionMQServiceHandler(ctx context.Context) *CollectionMQServiceHandler {

	// repo initializations
	userUrlRepo := repositories.InitUserURLRepo(ctx)
	loanRepo := repositories.InitLoanRepository(ctx)
	specialOfferRepo := repositories.InitSpecialOfferRepo(ctx)
	specialOfferMasterRepo := repositories.InitSpecialOffersMasterRepo(ctx)
	caseRepo := repositories.InitCaseRepository(ctx)
	caseFreezeRepo := repositories.InitCaseFreezeRepository(ctx)

	// service initializations
	caseService := _case.InitCaseService(ctx)
	loanService := loan.InitLoanService(ctx, caseService)
	specialOfferService := special_offer.InitSpecialOfferService(ctx, specialOfferRepo, specialOfferMasterRepo, loanRepo)
	clientService := client.InitClientService(ctx)

	cacheEnabled := viper.GetBool("REDIS_ENABLED")
	service := &CollectionMQServiceHandler{
		cacheEnabled:           cacheEnabled,
		uploadService:          upload.InitUploadService(ctx, loanService, caseService, specialOfferService),
		caseService:            _case.InitCaseService(ctx),
		customerAddressService: customer.InitCustomerAddressService(ctx),
		cacheClearService:      cacheclear.InitClearCacheService(ctx),
		loanPayment:            loan.InitLoanPaymentService(ctx, loanService),
		userURLService:         user.InitUserURLService(ctx, userUrlRepo, loanRepo, cacheEnabled),
		attributeService:       attribute_service.InitAttributeService(ctx),
		caseBlockService:       *_case.InitCaseBlockService(ctx),
		ticketService:          ticket.InitTicketService(ctx),
		permifyService:         permifyService.GetPermifyClientInstance(ctx),
		caseFreezeService:      _case.InitCaseFreezeService(ctx, caseRepo, caseFreezeRepo, clientService),
	}

	return service

}
func (u *CollectionMQServiceHandler) ConsumeEvent(ctx context.Context, message adapter.Message) (success bool) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeEvent"); span != nil {
		defer span.End()
	}

	// panic recovery handling.
	defer func() {
		if r := recover(); r != nil {
			logger.Error(ctx, nil, "panic from consumer handling", map[string]interface{}{"panic data": r})
		}
	}()

	// temporary value injection in context
	ctx = context.WithValue(ctx, "trace_id", message.TraceID)

	var err error
	switch message.EventName {
	// customer service events
	case "bulk_upload":
		u.processUpload(ctx, message.Payload)

	case "address_created":
		u.consumeAddress(ctx, message.Payload)

	case "loan_created":
		res := transformLoanCreateEventToEventLoanStruct(ctx, message.Payload)
		u.cacheClearService.ClearCacheForLoanCreateEvent(ctx, res)
		u.generateCase(ctx, message.Payload)

	case "loan_updated":
		res := transformLoanUpdateEventToEventLoanStruct(ctx, message.Payload)
		u.cacheClearService.ClearCacheForLoanUpdateEvent(ctx, res)
		u.generateCase(ctx, message.Payload)

	case "disposition_create":
		return u.consumeDisposition(ctx, message.Payload)
	case eventConstants.CASE_CREATED:
		u.consumeCaseCreatedEvent(ctx, message.Payload)
	case "customer_contact_created":
		res := mapPayloadToContactEvent(ctx, message.Payload)
		u.cacheClearService.ClearContactEventCache(ctx, res)
	case "special_offer_created":
		u.consumeSpecialOfferCreatedEvent(ctx, message.Payload)
	//case "ticket_created":
	//u.consumeTicketCreated(c, message.Payload)
	case "case_blocked":
		u.consumeCaseBlocked(ctx, message.Payload)
	case eventConstants.AGENT_CREATED:
		err = u.consumeAgentCreatedEvent(ctx, message.Payload)
	case eventConstants.AGENT_UPDATED:
		err = u.consumeAgentUpdatedEvent(ctx, message.Payload)
	case eventConstants.CLIENT_USER_CREATED:
		err = u.consumeClientUserCreatedEvent(ctx, message.Payload)
	case eventConstants.CLIENT_USER_UPDATED:
		err = u.consumeClientUserUpdatedEvent(ctx, message.Payload)
	case eventConstants.ALLOCATION_CHANGED:
		err = u.consumeAllocationChangedEvent(ctx, message.Payload)
	case eventConstants.CASE_UPDATED:
		err = u.consumeCaseUpdatedEvent(ctx, message.Payload)
	case eventConstants.CASE_WITHDRAWN:
		err = u.consumeCaseWithdrawnEvent(ctx, message.Payload)
	case eventConstants.FREEZE_CASE:
		return u.freezeCase(ctx, message.Payload)
	case eventConstants.UNFREEZE_CASE:
		u.unFreezeCase(ctx, message.Payload)
	}

	if err != nil {
		success = false
	}

	return true
}

func (u *CollectionMQServiceHandler) consumeClientUserCreatedEvent(ctx context.Context, payload interface{}) error {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeClientUserCreatedEvent"); span != nil {
		defer span.End()
	}

	event := events.CreateClientUserEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeClientUserCreatedEvent|Payload marshal error", logger.LogFields{"payload": payload})
	}

	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeClientUserCreatedEvent|Payload unmarshal error", logger.LogFields{"jsonData": jsonData, "payload": payload})
	}

	// create User In Permify
	err = createClientUserInPermify(ctx, u, event)
	if err != nil {
		// TODO: discuss error handling

	}

	return nil
}

func createClientUserInPermify(ctx context.Context, u *CollectionMQServiceHandler, createClientUserEvent events.CreateClientUserEvent) error {
	permifyUserReportingManager := createClientUserEvent.ReportingManagerRefNumber
	if permifyUserReportingManager == "" {
		permifyUserReportingManager = createClientUserEvent.ClientUserRefNumber
	}

	clientUserRelationTuple := []permifyService.RelationTuple{
		{EntityTuple: permifyService.EntityTuple{
			EntityType: "client",
			EntityId:   createClientUserEvent.ClientRefNumber,
		},
			Relation: createClientUserEvent.ClientUserRole.String(),
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: "user",
				SubjectId:   createClientUserEvent.ClientUserRefNumber,
			},
		},

		{
			EntityTuple: permifyService.EntityTuple{
				EntityType: permifyConstants.ENTITY_USER,
				EntityId:   createClientUserEvent.ClientUserRefNumber,
			},
			Relation: permifyConstants.RELATION_MAIN_USER,
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   createClientUserEvent.ClientUserRefNumber,
			},
		},
		{
			EntityTuple: permifyService.EntityTuple{
				EntityType: permifyConstants.ENTITY_USER,
				EntityId:   createClientUserEvent.ClientUserRefNumber,
			},
			Relation: permifyConstants.RELATION_REPORTING_MANAGER,
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   permifyUserReportingManager,
			},
		},
	}

	err := u.permifyService.WriteRelationTuple(ctx, clientUserRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|createClientUserInPermify|WriteRelationTuple error", logger.LogFields{"relation_tuple": clientUserRelationTuple})
		return err
	}

	return nil
}

func (u *CollectionMQServiceHandler) processUpload(ctx context.Context, payLoad interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.processUpload"); span != nil {
		defer span.End()
	}

	processUpload := request.ProcessUploadRequest{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|processUpload|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &processUpload); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|processUpload|Payload unmarshal error", logger.LogFields{})
	}
	processError := u.uploadService.ProcessUpload(ctx, processUpload)
	if processError != nil {
		panic(processError)
	}
}

func (u *CollectionMQServiceHandler) consumeAddress(ctx context.Context, payload interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeAddress"); span != nil {
		defer span.End()
	}

	var address request.Address

	jsonData, err := json.Marshal(payload)

	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeAddress|Payload marshal error", logger.LogFields{"payload": payload})
	}

	if err := json.Unmarshal(jsonData, &address); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeAddress|Payload unmarshal error", logger.LogFields{"jsondata": jsonData, "address": address})
	}

	u.customerAddressService.UpdateCustomerLocation(ctx, address)

}

/*
It consumes loan_created & loan_updated events and update/insert case records
@author Tejas Surve
*/
func (u *CollectionMQServiceHandler) generateCase(ctx context.Context, payLoad interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.generateCase"); span != nil {
		defer span.End()
	}

	generateCase := request.GenerateCase{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|generateCase|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &generateCase); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|generateCase|Payload unmarshal error", logger.LogFields{})
	}
	_, caseErr := u.caseService.GenerateCase(ctx, generateCase)
	if caseErr != nil {
		panic(caseErr)
	}
}

/*
It consumes disposition events & update case attributes values
@author Tejas Surve
*/
func (u *CollectionMQServiceHandler) consumeDisposition(ctx context.Context, payLoad interface{}) bool {
	if span := tracing.TraceSpan(ctx, "MQService.consumeDisposition"); span != nil {
		defer span.End()
	}
	status := true
	event := events.Disposition{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "MQService|consumeDisposition|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "MQService|consumeDisposition|Payload unmarshal error", logger.LogFields{})
	}

	//Update case attributes of cases
	time := time.Now()
	eventFollowupDate := utils.StringToDateTime(event.FollowupDatetime)
	caseAttr := request.CaseAttributeReq{
		CaseRefNumber:               event.CaseRefNumber,
		LastDisposition:             event.Disposition,
		LastDispositionFollowupDate: &eventFollowupDate,
		LastDispositionDatetime:     &time,
		DispositionType:             event.DispositionType,
	}
	attrErr := u.caseService.InsertUpdateCaseAttributes(ctx, caseAttr.CaseRefNumber, caseAttr)
	if attrErr != nil {
		status = false
	}
	//Clear case list cache after
	res := transformDispositionEventToEvenDispositionStruct(ctx, payLoad)
	u.cacheClearService.ClearDispositionCache(ctx, res)

	//Block Case
	blockdata := request.BlockCase{
		CaseRefNumber: event.CaseRefNumber,
		Reason:        event.Disposition,
		CreatedBy:     event.AgentRefNumber,
		Source:        enum.DISPOSITION,
	}
	if blockErr := u.caseBlockService.BlockCase(ctx, blockdata); blockErr != nil {
		logger.Error(ctx, blockErr, "CollectionMQServiceHandler|consumeDisposition|BlockCase error", logger.LogFields{})
		//status = false
	}

	//Handle PPS and PPA disposition for freeze case
	ppsAndppaStatus := u.handlePPSAndPPADisposition(ctx, event)
	if !ppsAndppaStatus {
		logger.Error(ctx, nil, "CollectionMQServiceHandler|consumeDisposition|handlePPSAndPPADisposition error", logger.LogFields{})
		//status = ppsAndppaStatus
	}
	//Handle PTP and CB disposition for freeze case
	ptpCbStatus := u.handlePTPAndCBDisposition(ctx, event)
	if !ptpCbStatus {
		logger.Error(ctx, nil, "CollectionMQServiceHandler|consumeDisposition|handlePTPAndCBDisposition error", logger.LogFields{})
		//status = ptpCbStatus
	}
	return status
}

func (u *CollectionMQServiceHandler) handlePTPAndCBDisposition(ctx context.Context, event events.Disposition) bool {

	if event.Disposition == "PTP" || event.Disposition == "CB" {
		freezeReq := request.DailyCallsLimitFreeze{
			CaseRefNumber: event.CaseRefNumber,
			CreatedBy:     event.AgentRefNumber,
			Reason:        constants.FREEZE_REASON_PTP_CB,
			Action:        enum.FREEZE,
			Disposition:   event.Disposition,
		}
		freezeErr := u.caseFreezeService.DailyCallslimitFreeze(ctx, freezeReq)
		if freezeErr != nil {
			return false
		}
	}
	return true
}
func (u *CollectionMQServiceHandler) handlePPSAndPPADisposition(ctx context.Context, event events.Disposition) bool {
	//Based on disposition freeze & unfreeze case
	status := true

	//PPS freeze on hold for now
	/*if event.Disposition == "PPS" {
		freezeRequest := request.FreezeCase{
			CaseRefNumber: event.CaseRefNumber,
			CreatedBy:     event.AgentRefNumber,
			Reason:        "PPS_FREEZE",
			Action:        enum.FREEZE,
		}
		freezeErr := u.caseFreezeService.FreezeCase(ctx, freezeRequest)
		if freezeErr != nil {
			status = false
		}
	}*/
	if event.Disposition == "PPA" {
		unFreezeRequest := request.UnFreezeCase{
			CaseRefNumber: event.CaseRefNumber,
			CreatedBy:     event.AgentRefNumber,
			Reason:        "PPA_UNFREEZE",
			Action:        enum.UNFREEZE,
		}
		unfreezeErr := u.caseFreezeService.UnFreezeCase(ctx, unFreezeRequest)
		if unfreezeErr != nil {
			status = false
		}
	}
	return status
}

/*
It consumes payment event
@author Tejas Surve
*/
func (u *CollectionMQServiceHandler) createLoanPayment(ctx context.Context, payLoad interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.createLoanPayment"); span != nil {
		defer span.End()
	}

	paymentStatusEvent := events.PaymentStatusEvent{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|createLoanPayment|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &paymentStatusEvent); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|createLoanPayment|Payload unmarshal error", logger.LogFields{})
	}
	paymentErr := u.loanPayment.HandleLoanPayment(ctx, paymentStatusEvent)
	if paymentErr != nil {
		panic(paymentErr)
	}

}

func transformLoanUpdateEventToEventLoanStruct(ctx context.Context, payload interface{}) events.LoanEvent {
	loanEvent := events.LoanEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|transformGenerateCaseEventToGenerateCaseStruct|Payload marshal error", logger.LogFields{"payload": payload})
	}
	if err := json.Unmarshal(jsonData, &loanEvent); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|transformGenerateCaseEventToGenerateCaseStruct|Payload unmarshal error", logger.LogFields{"payload": payload})
	}
	return loanEvent
}

func (u *CollectionMQServiceHandler) consumeCaseCreatedEvent(ctx context.Context, payload interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeCaseCreatedEvent"); span != nil {
		defer span.End()
	}

	event := events.CaseCreatedEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeCaseCreatedEvent|Payload marshal error", logger.LogFields{
			"payload": payload})
	}

	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeCaseCreatedEvent|Payload unmarshal error", logger.LogFields{
			"jsonData": jsonData,
			"payload":  payload,
		})
	}

	genPayReq := transformGenPayLinkReqFromCaseCreatedEvent(event)
	validateGenPayLinkReq(ctx, genPayReq)

	err = u.userURLService.GenerateCustomerPaymentLink(ctx, genPayReq)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	updateCaseDetailsInPermifyOnCaseCreate(ctx, u, &permifyCaseAllocDealloc{CaseRefNumber: event.CaseRefNumber, ClientRefNumber: event.ClientRefNumber, ClientTeamRefNumber: event.ClientTeamRefNumber})

	u.attributeService.PushAttributeEvent(ctx, event.CaseRefNumber, "", eventConstants.CASE_CREATED)
}

func (u *CollectionMQServiceHandler) consumeCaseUpdatedEvent(ctx context.Context, payload interface{}) error {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeCaseUpdatedEvent"); span != nil {
		defer span.End()
	}

	event := events.CaseUpdatedEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeCaseUpdatedEvent|Payload marshal error", logger.LogFields{
			"payload": payload})
	}

	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeCaseUpdatedEvent|Payload unmarshal error", logger.LogFields{
			"jsonData": jsonData,
			"payload":  payload,
		})
	}

	updateCaseDetailsInPermifyOnCaseUpdate(ctx, u, &event)
	logger.Info(ctx, "consumeCaseUpdatedEvent|PushAttributeEvent", logger.LogFields{"case_ref_number": event.CaseRefNumber})
	u.attributeService.PushAttributeEvent(ctx, event.CaseRefNumber, "", eventConstants.CASE_UPDATED)
	return nil
}

func updateCaseDetailsInPermifyOnCaseCreate(ctx context.Context, u *CollectionMQServiceHandler, alloc *permifyCaseAllocDealloc) error {
	// create Case In Permify
	err := allocateCaseToPermify(ctx, u, alloc)
	if err != nil {
		return err
	}

	return nil
}

func updateCaseDetailsInPermifyOnCaseUpdate(ctx context.Context, u *CollectionMQServiceHandler, caseUpdatedEvent *events.CaseUpdatedEvent) error {
	// create Case In Permify
	var previousAllocation *events.AllocationEventNode
	var newAllocation *events.AllocationEventNode

	if caseUpdatedEvent.PreviousClientRefNumber != "" || caseUpdatedEvent.PreviousClientTeamRefNumber != "" {
		previousAllocation = &events.AllocationEventNode{
			CaseRefNumber:       caseUpdatedEvent.CaseRefNumber,
			ClientRefNumber:     caseUpdatedEvent.PreviousClientRefNumber,
			ClientTeamRefNumber: caseUpdatedEvent.PreviousClientTeamRefNumber,
		}
	}
	newAllocation = &events.AllocationEventNode{
		CaseRefNumber:       caseUpdatedEvent.CaseRefNumber,
		ClientRefNumber:     caseUpdatedEvent.ClientRefNumber,
		ClientTeamRefNumber: caseUpdatedEvent.ClientTeamRefNumber,
	}

	err := handlePermifyAllocationChangedEvent(ctx, u, events.AllocationChangedEvent{PreviousAllocation: previousAllocation, NewAllocation: newAllocation})
	if err != nil {
		return err
	}

	return nil
}

func (u *CollectionMQServiceHandler) consumeSpecialOfferCreatedEvent(ctx context.Context, payload interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeSpecialOfferCreatedEvent"); span != nil {
		defer span.End()
	}

	event := events.SpecialOfferCreated{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeSpecialOfferCreatedEvent|Payload marshal error", logger.LogFields{
			"payload": payload})
	}

	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeSpecialOfferCreatedEvent|Payload unmarshal error", logger.LogFields{
			"jsonData": jsonData,
			"payload":  payload,
		})
	}

	u.attributeService.PushAttributeEvent(ctx, event.CaseRefNumber, event.SpecialOfferRefNumber, "special_offer_created")
}

func transformGenPayLinkReqFromCaseCreatedEvent(caseCreatedEvent events.CaseCreatedEvent) request.GeneratePaymentLinkReq {
	return request.GeneratePaymentLinkReq{
		ClientRefNumber: caseCreatedEvent.ClientRefNumber,
		Object:          enum.OBJECT_CUSTOMER,
		ObjectRefNumber: caseCreatedEvent.CustomerRefNumber,
		Entity:          enum.ENTITY_CASE,
		EntityRefNumber: caseCreatedEvent.CaseRefNumber,
		CaseRefNumber:   caseCreatedEvent.CaseRefNumber,
	}
}

/*
It consumes case_attempts event to update case attribute
@author Tejas Surve
*/
func (u *CollectionMQServiceHandler) consumeCaseAttempts(ctx context.Context, payLoad interface{}) bool {
	success := true
	if span := tracing.TraceSpan(ctx, "MQService.consumeCaseAttempts"); span != nil {
		defer span.End()
	}

	event := events.CaseAttemptReport{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "MQService|consumeDisposition|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "MQService|consumeDisposition|Payload unmarshal error", logger.LogFields{})
	}
	//time := time.Now()
	//eventFollowupDate := utils.StringToDateTime(event.FollowupDatetime)
	caseAttr := request.CaseAttributeReq{
		CaseRefNumber:        event.CaseRefNumber,
		TotalCallsAttempted:  event.TotalCallsAttempted,
		TotalCallsConnected:  event.TotalCallsConnected,
		TodaysCallsAttempted: event.TodaysCallsAttempted,
		LastCallConnectedAt:  &event.LastCallConnectedAt,
		TodaysCallsConnected: event.TodaysCallsConnected,
	}
	attrErr := u.caseService.InsertUpdateCaseAttributes(ctx, caseAttr.CaseRefNumber, caseAttr)
	if attrErr != nil {
		success = false
	}

	freezeRequest := request.DailyCallsLimitFreeze{
		CaseRefNumber: event.CaseRefNumber,
		CreatedBy:     event.AgentRefNumber}
	freezeErr := u.caseFreezeService.DailyCallslimitFreeze(ctx, freezeRequest)
	if freezeErr != nil {
		success = false
	}
	return success
}

func mapPayloadToContactEvent(ctx context.Context, payload interface{}) events.CustomerContactCreated {
	contactEvent := events.CustomerContactCreated{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|mapPayloadToContactEvent|Payload marshal error", logger.LogFields{"payload": payload})
	}
	if err := json.Unmarshal(jsonData, &contactEvent); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|mapPayloadToContactEvent|Payload unmarshal error", logger.LogFields{"payload": payload})
	}
	return contactEvent
}

/*
It consumes payment_attributes event and its  update to case_attribute
@author Tejas Surve
*/
func (u *CollectionMQServiceHandler) consumePaymentAttributes(ctx context.Context, payLoad interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumePaymentAttributes"); span != nil {
		defer span.End()
	}

	event := events.CaseAttributeEvent{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumePaymentAttributes|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumePaymentAttributes|Payload unmarshal error", logger.LogFields{})
	}

	caseAttr := request.CaseAttributeReq{
		HavingInprogressPayments:        event.Payment.HavingInprogressPayments,
		HavingMandateInprogressPayments: event.Payment.HavingMandateInprogressPayments,
		CaseRefNumber:                   event.CaseRefNumber,
	}
	attrErr := u.caseService.InsertUpdateCaseAttributes(ctx, event.CaseRefNumber, caseAttr)
	if attrErr != nil {
		panic(attrErr)
	}
}

// Create a ticket when case is blocked
func (u *CollectionMQServiceHandler) consumeCaseBlocked(ctx context.Context, payload interface{}) {
	ginCtx, _ := gin.CreateTestContext(nil)
	ginCtx.Request = &http.Request{}
	ginCtx.Set("trace_id", ctx.Value("trace_id"))
	caseBlocked := events.CaseBlocked{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ginCtx.Request.Context(), err, "CollectionMQServiceHandler|consumeCaseBlocked|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &caseBlocked); err != nil {
		logger.Error(ginCtx.Request.Context(), err, "CollectionMQServiceHandler|generateCase|Payload unmarshal error", logger.LogFields{})
	}

	if caseBlocked.IsResolved == false && caseBlocked.BlockReasonMasterId > 0 {
		createTicket := request.CreateTicket{
			CaseRefNumber: caseBlocked.CaseRefNumber,
			Status:        enum.TICKET_ACTIVE,
		}
		ticketErr := u.ticketService.CreateTicket(ginCtx, createTicket)
		if ticketErr != nil {
			panic(ticketErr)
		}
	}

}

/*
It consumes unblock_case event from airflow service and its  update case
@author Tejas Surve
*/
func (u *CollectionMQServiceHandler) consumeUnblockCase(ctx context.Context, payLoad interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeUnblockCase"); span != nil {
		defer span.End()
	}

	event := events.UnblockCase{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeUnblockCase|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeUnblockCase|Payload unmarshal error", logger.LogFields{})
	}

	attrErr := u.caseBlockService.UnblockCase(ctx, event.CaseRefNumber)
	if attrErr != nil {
		panic(attrErr)
	}
}

func (u *CollectionMQServiceHandler) consumeAgentCreatedEvent(ctx context.Context, payLoad interface{}) error {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeAgentCreatedEvent"); span != nil {
		defer span.End()
	}

	event := events.AgentCreatedEvent{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeAgentCreatedEvent|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeAgentCreatedEvent|Payload unmarshal error", logger.LogFields{})
	}

	// create User In Permify
	err = createAgentInPermify(ctx, u, event)
	if err != nil {
		return err
	}
	return nil
}

func (u *CollectionMQServiceHandler) consumeAgentUpdatedEvent(ctx context.Context, payload interface{}) error {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeAgentUpdatedEvent"); span != nil {
		defer span.End()
	}
	event := events.AgentUpdatedEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeAgentUpdatedEvent|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeAgentUpdatedEvent|Payload unmarshal error", logger.LogFields{})
	}

	err = updateAgentInPermify(ctx, u, event)
	if err != nil {
		return err
	}
	return nil
}

func (u *CollectionMQServiceHandler) consumeClientUserUpdatedEvent(ctx context.Context, payload interface{}) error {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeClientUserUpdatedEvent"); span != nil {
		defer span.End()
	}
	event := events.UpdateClientUserEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeClientUserUpdatedEvent|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeClientUserUpdatedEvent|Payload unmarshal error", logger.LogFields{})
	}

	err = updateClientUserInPermify(ctx, u, event)
	if err != nil {
		return err
	}
	return nil
}

func (u *CollectionMQServiceHandler) consumeAllocationChangedEvent(ctx context.Context, payload interface{}) error {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeAllocationChangedEvent"); span != nil {
		defer span.End()
	}
	event := events.AllocationChangedEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeAllocationChangedEvent|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeAllocationChangedEvent|Payload unmarshal error", logger.LogFields{})
	}

	err = handlePermifyAllocationChangedEvent(ctx, u, event)
	if err != nil {
		// TODO: handle error
	}

	return nil
}

func (u *CollectionMQServiceHandler) consumeCaseWithdrawnEvent(ctx context.Context, payload interface{}) error {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeCaseWithdrawnEvent"); span != nil {
		defer span.End()
	}
	event := events.CaseWithdrawnEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeCaseWithdrawnEvent|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeCaseWithdrawnEvent|Payload unmarshal error", logger.LogFields{})
	}

	err = deallocateCaseFromPermify(ctx, u, permifyCaseAllocDealloc{CaseRefNumber: event.CaseRefNumber})
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeCaseWithdrawnEvent|deallocateCaseFromPermify error", logger.LogFields{"caseRefNumber": event.CaseRefNumber})
		return err
	}

	return nil
}

func deallocateCaseFromPermify(ctx context.Context, u *CollectionMQServiceHandler, dealloc permifyCaseAllocDealloc) error {
	deleteRelationTuple := permifyService.DeleteRelationTuple{
		EntityFilteringTuple: permifyService.EntityFilteringTuple{
			EntityType: permifyConstants.ENTITY_CASE,
			EntityIds:  []string{dealloc.CaseRefNumber},
		},
	}

	err := u.permifyService.DeleteRelationTuple(ctx, deleteRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|deallocateCaseFromPermify|DeleteRelationTuple error", logger.LogFields{"deleteRelationTuple": deleteRelationTuple})
		return err

	}

	return nil
}

func handlePermifyAllocationChangedEvent(ctx context.Context, u *CollectionMQServiceHandler, event events.AllocationChangedEvent) error {
	if event.PreviousAllocation != nil {
		// different agent ref number found in previous and new allocation
		if event.PreviousAllocation.AgentRefNumber != "" &&
			(event.NewAllocation == nil || event.NewAllocation.AgentRefNumber != event.PreviousAllocation.AgentRefNumber) {
			err := deallocateCaseToAgentMappingFromPermify(ctx, u, permifyCaseAllocDealloc{
				CaseRefNumber:  event.PreviousAllocation.CaseRefNumber,
				AgentRefNumber: event.PreviousAllocation.AgentRefNumber,
			})
			if err != nil {
				return err
			}
		}

		// different service provider team ref number found in previous and new allocation
		if event.PreviousAllocation.ServiceProviderTeamRefNumber != "" &&
			(event.NewAllocation == nil || event.NewAllocation.ServiceProviderTeamRefNumber != event.PreviousAllocation.ServiceProviderTeamRefNumber) {
			err := deallocateCaseToSPTeamMappingFromPermify(ctx, u, permifyCaseAllocDealloc{
				CaseRefNumber:                event.PreviousAllocation.CaseRefNumber,
				ServiceProviderTeamRefNumber: event.PreviousAllocation.ServiceProviderTeamRefNumber,
			})
			if err != nil {
				return err
			}
		}

		// different service provider ref number found in previous and new allocation
		if event.PreviousAllocation.ServiceProviderRefNumber != "" &&
			(event.NewAllocation == nil || event.NewAllocation.ServiceProviderRefNumber != event.PreviousAllocation.ServiceProviderRefNumber) {
			err := deallocateCaseToServiceProviderMappingFromPermify(ctx, u, permifyCaseAllocDealloc{
				CaseRefNumber:            event.PreviousAllocation.CaseRefNumber,
				ServiceProviderRefNumber: event.PreviousAllocation.ServiceProviderRefNumber,
			})
			if err != nil {
				return err
			}
		}

		if event.PreviousAllocation.ClientTeamRefNumber != "" &&
			(event.NewAllocation == nil || event.NewAllocation.ClientTeamRefNumber != event.PreviousAllocation.ClientTeamRefNumber) {
			err := deallocateCaseToClientTeamMappingFromPermify(ctx, u, permifyCaseAllocDealloc{
				CaseRefNumber:       event.PreviousAllocation.CaseRefNumber,
				ClientTeamRefNumber: event.PreviousAllocation.ClientTeamRefNumber,
			})
			if err != nil {
				return err
			}
		}

		if event.PreviousAllocation.ClientRefNumber != "" &&
			(event.NewAllocation == nil || event.NewAllocation.ClientRefNumber != event.PreviousAllocation.ClientRefNumber) {
			err := deallocateCaseToClientMappingFromPermify(ctx, u, permifyCaseAllocDealloc{
				CaseRefNumber:   event.PreviousAllocation.CaseRefNumber,
				ClientRefNumber: event.PreviousAllocation.ClientRefNumber,
			})
			if err != nil {
				return err
			}
		}
	}

	if event.NewAllocation != nil {
		permifyAlloc := &permifyCaseAllocDealloc{CaseRefNumber: event.NewAllocation.CaseRefNumber}

		if event.NewAllocation.AgentRefNumber != "" &&
			(event.PreviousAllocation == nil || event.NewAllocation.AgentRefNumber != event.PreviousAllocation.AgentRefNumber) {
			permifyAlloc.AgentRefNumber = event.NewAllocation.AgentRefNumber
		}

		if event.NewAllocation.ServiceProviderTeamRefNumber != "" &&
			(event.PreviousAllocation == nil || event.NewAllocation.ServiceProviderTeamRefNumber != event.PreviousAllocation.ServiceProviderTeamRefNumber) {
			permifyAlloc.ServiceProviderTeamRefNumber = event.NewAllocation.ServiceProviderTeamRefNumber
		}

		if event.NewAllocation.ServiceProviderRefNumber != "" &&
			(event.PreviousAllocation == nil || event.NewAllocation.ServiceProviderRefNumber != event.PreviousAllocation.ServiceProviderRefNumber) {
			permifyAlloc.ServiceProviderRefNumber = event.NewAllocation.ServiceProviderRefNumber
		}

		if event.NewAllocation.ClientTeamRefNumber != "" &&
			(event.PreviousAllocation == nil || event.NewAllocation.ClientTeamRefNumber != event.PreviousAllocation.ClientTeamRefNumber) {
			permifyAlloc.ClientTeamRefNumber = event.NewAllocation.ClientTeamRefNumber
		}

		if event.NewAllocation.ClientRefNumber != "" &&
			(event.PreviousAllocation == nil || event.NewAllocation.ClientRefNumber != event.PreviousAllocation.ClientRefNumber) {
			permifyAlloc.ClientRefNumber = event.NewAllocation.ClientRefNumber
		}

		err := allocateCaseToPermify(ctx, u, permifyAlloc)
		if err != nil {
			return err
		}
	}
	return nil
}

type permifyCaseAllocDealloc struct {
	CaseRefNumber                string `json:"case_ref_number"`
	AgentRefNumber               string `json:"agent_ref_number"`
	ServiceProviderRefNumber     string `json:"service_provider_ref_number"`
	ClientRefNumber              string `json:"client_ref_number"`
	ServiceProviderTeamRefNumber string `json:"service_provider_team_ref_number"`
	ClientTeamRefNumber          string `json:"client_team_ref_number"`
}

func allocateCaseToPermify(ctx context.Context, u *CollectionMQServiceHandler, permifyCaseAlloc *permifyCaseAllocDealloc) error {

	var relationTuples []permifyService.RelationTuple

	// allocate case to agent if agent is present
	if utils.IsNotEmpty(permifyCaseAlloc.AgentRefNumber) {

		agentMapping := permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: permifyConstants.ENTITY_CASE,
				EntityId:   permifyCaseAlloc.CaseRefNumber,
			},
			Relation: permifyConstants.RELATION_ALLOCATED_TO,
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   permifyCaseAlloc.AgentRefNumber,
			}}

		relationTuples = append(relationTuples, agentMapping)
	}

	if utils.IsNotEmpty(permifyCaseAlloc.ServiceProviderRefNumber) {
		spMapping := permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: permifyConstants.ENTITY_CASE,
				EntityId:   permifyCaseAlloc.CaseRefNumber,
			},
			Relation: permifyConstants.RELATION_SERVICE_PROVIDER,
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_SERVICE_PROVIDER,
				SubjectId:   permifyCaseAlloc.ServiceProviderRefNumber,
			}}

		relationTuples = append(relationTuples, spMapping)
	}

	if utils.IsNotEmpty(permifyCaseAlloc.ClientRefNumber) {
		clientMapping := permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: "case",
				EntityId:   permifyCaseAlloc.CaseRefNumber,
			},
			Relation: "client",
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: "client",
				SubjectId:   permifyCaseAlloc.ClientRefNumber,
			}}

		relationTuples = append(relationTuples, clientMapping)

	}

	if utils.IsNotEmpty(permifyCaseAlloc.ServiceProviderTeamRefNumber) {
		spTeamMapping := permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: "case",
				EntityId:   permifyCaseAlloc.CaseRefNumber,
			},
			Relation: "service_provider_team",
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: "team",
				SubjectId:   permifyCaseAlloc.ServiceProviderTeamRefNumber,
			}}

		relationTuples = append(relationTuples, spTeamMapping)

	}

	if utils.IsNotEmpty(permifyCaseAlloc.ClientTeamRefNumber) {
		clientTeamMapping := permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: "case",
				EntityId:   permifyCaseAlloc.CaseRefNumber,
			},
			Relation: "client_team",
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: "team",
				SubjectId:   permifyCaseAlloc.ClientTeamRefNumber,
			}}

		relationTuples = append(relationTuples, clientTeamMapping)
	}

	if len(relationTuples) > 0 {
		err := u.permifyService.WriteRelationTuple(ctx, relationTuples)
		if err != nil {
			logger.Error(ctx, err, "CollectionMQServiceHandler|allocateCaseToPermify|WriteRelationTuple error", logger.LogFields{"relation_tuple": relationTuples})
			return err
		}
	}

	return nil
}

func deallocateCaseToClientTeamMappingFromPermify(ctx context.Context, u *CollectionMQServiceHandler, permifyCaseDealloc permifyCaseAllocDealloc) error {
	deleteRelationTuple := permifyService.DeleteRelationTuple{
		EntityFilteringTuple: permifyService.EntityFilteringTuple{
			EntityType: "case",
			EntityIds:  []string{permifyCaseDealloc.CaseRefNumber},
		},
		Relation: "client_team",
		SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
			SubjectType: "team",
			SubjectIds:  []string{permifyCaseDealloc.ClientTeamRefNumber},
		},
	}

	err := u.permifyService.DeleteRelationTuple(ctx, deleteRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|deallocateCaseToClientTeamMappingFromPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": deleteRelationTuple})
		return err
	}
	return nil
}

func deallocateCaseToServiceProviderMappingFromPermify(ctx context.Context, u *CollectionMQServiceHandler, permifyCaseDealloc permifyCaseAllocDealloc) error {
	deleteRelationTuple := permifyService.DeleteRelationTuple{
		EntityFilteringTuple: permifyService.EntityFilteringTuple{
			EntityType: "case",
			EntityIds:  []string{permifyCaseDealloc.CaseRefNumber},
		},
		Relation: "service_provider",
		SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
			SubjectType: "sp",
			SubjectIds:  []string{permifyCaseDealloc.ServiceProviderRefNumber},
		},
	}

	err := u.permifyService.DeleteRelationTuple(ctx, deleteRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|deallocateCaseToServiceProviderMappingFromPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": deleteRelationTuple})
		return err
	}

	return nil
}

func deallocateCaseToClientMappingFromPermify(ctx context.Context, u *CollectionMQServiceHandler, permifyCaseDealloc permifyCaseAllocDealloc) error {
	deleteRelationTuple := permifyService.DeleteRelationTuple{
		EntityFilteringTuple: permifyService.EntityFilteringTuple{
			EntityType: "case",
			EntityIds:  []string{permifyCaseDealloc.CaseRefNumber},
		},
		Relation: "client",
		SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
			SubjectType: "client",
			SubjectIds:  []string{permifyCaseDealloc.ClientRefNumber},
		},
	}

	err := u.permifyService.DeleteRelationTuple(ctx, deleteRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|deallocateCaseToServiceProviderMappingFromPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": deleteRelationTuple})
		return err
	}

	return nil
}

func deallocateCaseToSPTeamMappingFromPermify(ctx context.Context, u *CollectionMQServiceHandler, permifyCaseDealloc permifyCaseAllocDealloc) error {
	deleteRelationTuple := permifyService.DeleteRelationTuple{
		EntityFilteringTuple: permifyService.EntityFilteringTuple{
			EntityType: "case",
			EntityIds:  []string{permifyCaseDealloc.CaseRefNumber},
		},
		Relation: "service_provider_team",
		SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
			SubjectType: "team",
			SubjectIds:  []string{permifyCaseDealloc.ServiceProviderTeamRefNumber},
		},
	}

	err := u.permifyService.DeleteRelationTuple(ctx, deleteRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|deallocateCaseToSPTeamMappingFromPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": deleteRelationTuple})
		return err
	}

	return nil
}

func deallocateCaseToAgentMappingFromPermify(ctx context.Context, u *CollectionMQServiceHandler, permifyCaseDealloc permifyCaseAllocDealloc) error {
	deleteRelationTuple := permifyService.DeleteRelationTuple{
		EntityFilteringTuple: permifyService.EntityFilteringTuple{
			EntityType: "case",
			EntityIds:  []string{permifyCaseDealloc.CaseRefNumber},
		},
		Relation: "allocated_to",
		SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
			SubjectType: "user",
			SubjectIds:  []string{permifyCaseDealloc.AgentRefNumber},
		},
	}

	err := u.permifyService.DeleteRelationTuple(ctx, deleteRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|deallocateCaseToAgentMappingFromPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": deleteRelationTuple})
		return err
	}

	return nil
}

func updateClientUserInPermify(ctx context.Context, u *CollectionMQServiceHandler, event events.UpdateClientUserEvent) error {
	var roleUpdated bool
	var reportingManagerUpdated bool
	if event.ClientUserRole != enum.ClientUserRole(0) && event.PreviousRole != event.ClientUserRole {
		roleUpdated = true
	}
	if event.ReportingManagerRefNumber != "" && event.PreviousReportingManagerRefNumber != event.ReportingManagerRefNumber {
		reportingManagerUpdated = true
	}

	var permifyWriteRelationTuple []permifyService.RelationTuple

	if roleUpdated {
		permifyDeleteRoleRelationTuple := permifyService.DeleteRelationTuple{
			EntityFilteringTuple: permifyService.EntityFilteringTuple{
				EntityType: "client",
				EntityIds:  []string{event.ClientRefNumber},
			},

			Relation: event.PreviousRole.String(),
			SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectIds:  []string{event.ClientUserRefNumber},
			},
		}

		permifyWriteRelationTuple = append(permifyWriteRelationTuple, permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: "client",
				EntityId:   event.ClientRefNumber,
			},
			Relation: event.ClientUserRole.String(),
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   event.ClientUserRefNumber,
			}})

		err := u.permifyService.DeleteRelationTuple(ctx, permifyDeleteRoleRelationTuple)
		if err != nil {
			logger.Error(ctx, err, "CollectionMQServiceHandler|updateClientUserInPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": permifyDeleteRoleRelationTuple})
			return err
		}
	}

	if reportingManagerUpdated {
		permifyDeleteReportingManagerRelationTuple := permifyService.DeleteRelationTuple{
			EntityFilteringTuple: permifyService.EntityFilteringTuple{
				EntityType: permifyConstants.ENTITY_USER,
				EntityIds:  []string{event.ClientUserRefNumber},
			},
			Relation: permifyConstants.RELATION_REPORTING_MANAGER,
			SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectIds:  []string{event.PreviousReportingManagerRefNumber},
			},
		}

		permifyWriteRelationTuple = append(permifyWriteRelationTuple, permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: permifyConstants.ENTITY_USER,
				EntityId:   event.ClientUserRefNumber,
			},
			Relation: permifyConstants.RELATION_REPORTING_MANAGER,
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   event.ReportingManagerRefNumber,
			},
		})

		err := u.permifyService.DeleteRelationTuple(ctx, permifyDeleteReportingManagerRelationTuple)
		if err != nil {
			logger.Error(ctx, err, "CollectionMQServiceHandler|updateClientUserInPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": permifyDeleteReportingManagerRelationTuple})
			return err
		}
	}

	err := u.permifyService.WriteRelationTuple(ctx, permifyWriteRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|updateClientUserInPermify|WriteRelationTuple error", logger.LogFields{"relation_tuple": permifyWriteRelationTuple})
		return err
	}
	return nil
}

func createAgentInPermify(ctx context.Context, u *CollectionMQServiceHandler, event events.AgentCreatedEvent) error {
	// write permify relation event
	permifyUserReportingManager := event.ReportingManagerRefNumber
	if permifyUserReportingManager == "" {
		permifyUserReportingManager = event.AgentRefNumber
	}
	agentRelationTuple := []permifyService.RelationTuple{
		// RBAC relations
		{
			EntityTuple: permifyService.EntityTuple{
				EntityType: "sp",
				EntityId:   event.ServiceProviderRefNumber,
			},
			Relation: event.Role.String(),
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   event.AgentRefNumber,
			},
		},

		// ReBAC relations
		{
			EntityTuple: permifyService.EntityTuple{
				EntityType: permifyConstants.ENTITY_USER,
				EntityId:   event.AgentRefNumber,
			},
			Relation: permifyConstants.RELATION_MAIN_USER,
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   event.AgentRefNumber,
			},
		},
		{
			EntityTuple: permifyService.EntityTuple{
				EntityType: permifyConstants.ENTITY_USER,
				EntityId:   event.AgentRefNumber,
			},
			Relation: permifyConstants.RELATION_REPORTING_MANAGER,
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   permifyUserReportingManager,
			},
		},
	}

	err := u.permifyService.WriteRelationTuple(ctx, agentRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|createAgentInPermify|WriteRelationTuple error", logger.LogFields{"relation_tuple": agentRelationTuple})
		return err
	}

	return nil
}

func updateAgentInPermify(ctx context.Context, u *CollectionMQServiceHandler, event events.AgentUpdatedEvent) error {
	var roleUpdated bool
	var reportingManagerUpdated bool
	if event.Role != enum.AgentRole(0) && event.PreviousRole != event.Role {
		roleUpdated = true
	}
	if event.ReportingManagerRefNumber != "" && event.PreviousReportingManagerRefNumber != event.ReportingManagerRefNumber {
		reportingManagerUpdated = true
	}

	var permifyWriteRelationTuple []permifyService.RelationTuple

	if roleUpdated {
		permifyDeleteRoleRelationTuple := permifyService.DeleteRelationTuple{
			EntityFilteringTuple: permifyService.EntityFilteringTuple{
				EntityType: "sp",
				EntityIds:  []string{event.ServiceProviderRefNumber},
			},

			Relation: event.PreviousRole.String(),
			SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectIds:  []string{event.AgentRefNumber},
			},
		}

		permifyWriteRelationTuple = append(permifyWriteRelationTuple, permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: "sp",
				EntityId:   event.ServiceProviderRefNumber,
			},
			Relation: event.Role.String(),
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   event.AgentRefNumber,
			}})

		err := u.permifyService.DeleteRelationTuple(ctx, permifyDeleteRoleRelationTuple)
		if err != nil {
			logger.Error(ctx, err, "CollectionMQServiceHandler|updateAgentInPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": permifyDeleteRoleRelationTuple})
			return err
		}
	}

	if reportingManagerUpdated {
		permifyDeleteReportingManagerRelationTuple := permifyService.DeleteRelationTuple{
			EntityFilteringTuple: permifyService.EntityFilteringTuple{
				EntityType: permifyConstants.ENTITY_USER,
				EntityIds:  []string{event.AgentRefNumber},
			},
			Relation: permifyConstants.RELATION_REPORTING_MANAGER,
			SubjectFilteringTuple: permifyService.SubjectFilteringTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectIds:  []string{event.PreviousReportingManagerRefNumber},
			},
		}

		permifyWriteRelationTuple = append(permifyWriteRelationTuple, permifyService.RelationTuple{
			EntityTuple: permifyService.EntityTuple{
				EntityType: permifyConstants.ENTITY_USER,
				EntityId:   event.AgentRefNumber,
			},
			Relation: permifyConstants.RELATION_REPORTING_MANAGER,
			SubjectTuple: permifyService.SubjectTuple{
				SubjectType: permifyConstants.ENTITY_USER,
				SubjectId:   event.ReportingManagerRefNumber,
			},
		})

		err := u.permifyService.DeleteRelationTuple(ctx, permifyDeleteReportingManagerRelationTuple)
		if err != nil {
			logger.Error(ctx, err, "CollectionMQServiceHandler|updateAgentInPermify|DeleteRelationTuple error", logger.LogFields{"relation_tuple": permifyDeleteReportingManagerRelationTuple})
			return err
		}
	}

	err := u.permifyService.WriteRelationTuple(ctx, permifyWriteRelationTuple)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|updateAgentInPermify|WriteRelationTuple error", logger.LogFields{"relation_tuple": permifyWriteRelationTuple})
		return err
	}
	return nil
}

func (u *CollectionMQServiceHandler) freezeCase(ctx context.Context, payLoad interface{}) bool {
	if span := tracing.TraceSpan(ctx, "MQService.freezeCase"); span != nil {
		defer span.End()
	}

	freezeCase := request.FreezeCase{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "MQService|freezeCase|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &freezeCase); err != nil {
		logger.Error(ctx, err, "MQService|freezeCase|Payload unmarshal error", logger.LogFields{})
	}
	freezeErr := u.caseFreezeService.FreezeCase(ctx, freezeCase)
	if freezeErr != nil {
		return false
	}
	return true
}

func (u *CollectionMQServiceHandler) unFreezeCase(ctx context.Context, payLoad interface{}) bool {
	if span := tracing.TraceSpan(ctx, "MQService.freezeCase"); span != nil {
		defer span.End()
	}

	unFreezeCase := request.UnFreezeCase{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "MQService|freezeCase|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &unFreezeCase); err != nil {
		logger.Error(ctx, err, "MQService|freezeCase|Payload unmarshal error", logger.LogFields{})
	}
	freezeErr := u.caseFreezeService.UnFreezeCase(ctx, unFreezeCase)
	if freezeErr != nil {
		return false
	}
	return true
}

func transformLoanCreateEventToEventLoanStruct(ctx context.Context, payload interface{}) events.LoanEvent {
	loanEvent := events.LoanEvent{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "MQService|transformGenerateCaseEventToGenerateCaseStruct|Payload marshal error", logger.LogFields{"payload": payload})
	}
	if err := json.Unmarshal(jsonData, &loanEvent); err != nil {
		logger.Error(ctx, err, "MQService|transformGenerateCaseEventToGenerateCaseStruct|Payload unmarshal error", logger.LogFields{"payload": payload})
	}
	return loanEvent
}

func transformDispositionEventToEvenDispositionStruct(ctx context.Context, payload interface{}) events.Disposition {
	dispositionEvent := events.Disposition{}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error(ctx, err, "MQService|transformDispositionEventToEvenDispositionStruct|Payload marshal error", logger.LogFields{"payload": payload})
	}
	if err := json.Unmarshal(jsonData, &dispositionEvent); err != nil {
		logger.Error(ctx, err, "MQService|transformDispositionEventToEvenDispositionStruct|Payload unmarshal error", logger.LogFields{"payload": payload})
	}
	return dispositionEvent
}

func validateGenPayLinkReq(ctx context.Context, req request.GeneratePaymentLinkReq) {
	if req.ObjectRefNumber == "" {
		utils.BadRequestException(ctx, "", "object_ref_number not found in generate payment link request", nil, nil)
	}

	if req.EntityRefNumber == "" {
		utils.BadRequestException(ctx, "", "entity_ref_number not found in generate payment link request", nil, nil)
	}

	if req.Object == enum.Object(0) {
		utils.BadRequestException(ctx, "", "object not found in generate payment link request", nil, nil)
	}

	if req.Entity == enum.URLEntity(0) {
		utils.BadRequestException(ctx, "", "entity not found in generate payment link request", nil, nil)
	}
}
