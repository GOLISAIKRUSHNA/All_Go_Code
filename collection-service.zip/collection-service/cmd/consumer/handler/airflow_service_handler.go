package handler

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/services/attribute_service"
	cacheclear "collection-service/internal/app/services/cache_clear"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/app/services/ticket"
	"collection-service/internal/app/services/upload"
	"collection-service/internal/app/services/user"
	"collection-service/internal/dto/events"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
)

type AirflowMQServiceHandler struct {
	cacheEnabled           bool
	uploadService          upload.IuploadService
	caseService            _case.ICaseService
	customerAddressService customer.ICustomerAddressService
	cacheClearService      cacheclear.ICacheClearService
	loanPayment            loan.ILoanPaymentService
	userURLService         user.IUserURLService
	attributeService       attribute_service.IAttributeService
	caseBlockService       _case.CaseBlockService
	ticketService          ticket.ITicketService
}

func InitAirflowMQServiceHandler(ctx context.Context) *AirflowMQServiceHandler {
	service := &AirflowMQServiceHandler{
		caseBlockService: *_case.InitCaseBlockService(ctx),
	}

	return service

}

func (u *AirflowMQServiceHandler) ConsumeEvent(ctx context.Context, message adapter.Message) (success bool) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeEvent"); span != nil {
		defer span.End()
	}

	// panic recovery handling.
	defer func() {
		if r := recover(); r != nil {
			logger.Error(ctx, nil, "panic from consumer handling", map[string]interface{}{"panic data": r})
		}
	}()

	// temporary value injection in context
	ctx = context.WithValue(ctx, "trace_id", message.TraceID)

	switch message.EventName {
	case "unblock_case":
		u.consumeUnblockCase(ctx, message.Payload)

	}

	return true
}

func (u *AirflowMQServiceHandler) consumeUnblockCase(ctx context.Context, payLoad interface{}) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeUnblockCase"); span != nil {
		defer span.End()
	}

	event := events.UnblockCase{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeUnblockCase|Payload marshal error", logger.LogFields{})
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeUnblockCase|Payload unmarshal error", logger.LogFields{})
	}

	/*unblockCaseReq := request.UnblockCase{
		CaseRefNumber: event.CaseRefNumber,
	}*/
	attrErr := u.caseBlockService.UnblockCase(ctx, event.CaseRefNumber)
	if attrErr != nil {
		panic(attrErr)
	}
}
