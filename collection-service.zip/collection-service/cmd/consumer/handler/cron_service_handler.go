package handler

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	eventConstants "collection-service/internal/app/constants/events"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/client"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/repositories"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
)

type CronMQServiceHandler struct {
	cacheEnabled      bool
	caseBlockService  _case.CaseBlockService
	caseFreezeService _case.CaseFreezeService
}

func InitCronMQServiceHandler(ctx context.Context) *CronMQServiceHandler {
	caseFreezeRepo := repositories.InitCaseFreezeRepository(ctx)
	caseRepo := repositories.InitCaseRepository(ctx)
	clientService := client.InitClientService(ctx)
	service := &CronMQServiceHandler{
		caseBlockService:  *_case.InitCaseBlockService(ctx),
		caseFreezeService: *_case.InitCaseFreezeService(ctx, caseRepo, caseFreezeRepo, clientService),
	}

	return service

}

func (u *CronMQServiceHandler) ConsumeEvent(ctx context.Context, message adapter.Message) (success bool) {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeEvent"); span != nil {
		defer span.End()
	}

	// panic recovery handling.
	defer func() {
		if r := recover(); r != nil {
			logger.Error(ctx, nil, "panic from consumer handling", map[string]interface{}{"panic data": r})
		}
	}()

	// temporary value injection in context
	ctx = context.WithValue(ctx, "trace_id", message.TraceID)

	switch message.EventName {
	case eventConstants.UNBLOCK_CASE:
		return u.consumeUnblockCase(ctx, message.Payload)
	case eventConstants.UNFREEZE_CASE:
		//return u.unFreezeCase(ctx, message.Payload)

	}

	return true
}

func (u *CronMQServiceHandler) consumeUnblockCase(ctx context.Context, payLoad interface{}) bool {
	if span := tracing.TraceSpan(ctx, "CollectionMQServiceHandler.consumeUnblockCase"); span != nil {
		defer span.End()
	}

	event := events.UnblockCase{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeUnblockCase|Payload marshal error", logger.LogFields{})
		return false
	}
	if err := json.Unmarshal(jsonData, &event); err != nil {
		logger.Error(ctx, err, "CollectionMQServiceHandler|consumeUnblockCase|Payload unmarshal error", logger.LogFields{})
		return false
	}

	attrErr := u.caseBlockService.UnblockCase(ctx, event.CaseRefNumber)
	if attrErr != nil {
		return false
	}
	return true
}

func (u *CronMQServiceHandler) unFreezeCase(ctx context.Context, payLoad interface{}) bool {
	if span := tracing.TraceSpan(ctx, "MQService.freezeCase"); span != nil {
		defer span.End()
	}

	unFreezeCase := request.UnFreezeCase{}
	jsonData, err := json.Marshal(payLoad)
	if err != nil {
		logger.Error(ctx, err, "MQService|freezeCase|Payload marshal error", logger.LogFields{})
		return false
	}
	if err := json.Unmarshal(jsonData, &unFreezeCase); err != nil {
		logger.Error(ctx, err, "MQService|freezeCase|Payload unmarshal error", logger.LogFields{})
		return false
	}
	freezeErr := u.caseFreezeService.UnFreezeCase(ctx, unFreezeCase)
	if freezeErr != nil {
		return false
	}
	return true
}
