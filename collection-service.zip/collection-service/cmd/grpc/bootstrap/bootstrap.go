package grpc_bootstrap

import (
	"collection-service/common/bugtrackingtool"
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/app/services/storage/sqlservice"
	"collection-service/internal/utils/validators"
	"context"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
)

// global variables so that all function can use this
var writeDB sqlservice.ISqlService
var readDB sqlservice.ISqlService
var redis *cacheservice.BaseCacheService

func InitializeApp(ctx context.Context) bool {

	// All required initilization for the app

	// Initializing Logger
	logger.Initialize(ctx)

	// Initializing the bug service tool
	bs := bugtrackingtool.GetNewBugTool()
	bs.Initialize()

	if strings.ToLower(viper.GetString("APP_ENV")) == "production" {
		gin.SetMode(gin.ReleaseMode)
	}

	// Write Database Connection and Migration code starts
	writeDB = sqlservice.GetMysqlClient(ctx, constants.WRITE_DATABASE_TYPE, nil)
	// defer writeDB.Close()

	// Write Database Connection and Migration code starts
	readDB = sqlservice.GetMysqlClient(ctx, constants.READ_DATABASE_TYPE, nil)
	// defer readDB.Close()

	// Redis Connection settings
	if viper.GetBool("REDIS_ENABLED") {
		redis = cacheservice.GetNewCacheService(ctx, nil)
		redis.SetContext(ctx).SetExpiration(time.Duration(viper.GetInt64("REDIS_TTL")) * time.Second)
		// defer redis.Close()
	}

	//Custom Validation Initialization
	validators.InitializeValidatorService()

	return true
}

func DestroyAllInitialization() bool {

	//Closing mysql client_user connections
	writeDB.Close()
	readDB.Close()

	//Closing redis client_user connection
	if viper.GetBool("REDIS_ENABLED") {
		redis.Close()
	}

	return true
}
