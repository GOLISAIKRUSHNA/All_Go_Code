package main

import (
	grpc_bootstrap "collection-service/cmd/grpc/bootstrap"
	"collection-service/common/logger"
	"context"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

func main() {
	// Creating Background context to receive interruption
	// Login a context that will be cancelled when an interrupt signal is received
	ctx, cancel := context.WithCancel(context.Background())

	// Loading Environment Variables
	viper.SetConfigFile(".env")
	viper.ReadInConfig()
	viper.AutomaticEnv()

	server := grpc.NewServer()

	// Booting application
	grpc_bootstrap.InitializeApp(ctx)

	go startGRPCserver(ctx, server)

	// Initializing App
	app := gin.New()

	// HealthCheck Api
	app.GET("/", func(c *gin.Context) {
		c.String(200, "Success GRPC")
	})

	// Run on PORT 8010
	s := &http.Server{
		Addr:    ":8010",
		Handler: app,
	}

	// Listen for interrupt signals and cancel the context when one is received
	go func() {
		sigCh := make(chan os.Signal, 1)
		signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
		<-sigCh
		logger.Info(ctx, "starting to stop application - 2", nil)
		fmt.Println("Received interrupt signal, shutting down golang boilerplate grpc service...")
		cancel()

		// Destroying all intialization
		grpc_bootstrap.DestroyAllInitialization()

		// Server will be closing here
		server.Stop()
		// Server will be closing here
		s.Shutdown(context.Background())
	}()

	if err := s.ListenAndServe(); err != nil {
		logger.Fatal(ctx, err, "Server listen error", nil)
		cancel()
	}
}

func startGRPCserver(ctx context.Context, server *grpc.Server) {
	lis, err := net.Listen("tcp", ":"+viper.GetString("GRPC_SERVER_PORT"))
	if err != nil {
		logger.Fatal(ctx, err, "failed to listen in the server", nil)
	}

	reflection.Register(server)

	logger.Info(ctx, "gRPC server listening on :"+viper.GetString("GRPC_SERVER_PORT"), nil)

	if err := server.Serve(lis); err != nil {
		logger.Fatal(ctx, err, "failed to create server", nil)
	}
}
