package main

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/app/services/storage/sqlservice"
	"collection-service/internal/cronjobs"
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/jasonlvhit/gocron"
	"github.com/spf13/viper"
)

var writeDB sqlservice.ISqlService
var readDB sqlservice.ISqlService
var redis *cacheservice.BaseCacheService

func main() {
	// Create a new context and defer its cancellation
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	// Loading Environment Variables
	viper.SetConfigFile(".env")
	viper.ReadInConfig()
	viper.AutomaticEnv()

	// Initializing Logger
	logger.Initialize(ctx)

	// Write Database Connection and Migration code starts
	writeDB = sqlservice.GetMysqlClient(ctx, constants.WRITE_DATABASE_TYPE, nil)
	defer writeDB.Close()
	// Write Database Connection and Migration code starts
	readDB = sqlservice.GetMysqlClient(ctx, constants.READ_DATABASE_TYPE, nil)
	defer writeDB.Close()
	// Redis Connection settings
	if viper.GetBool("REDIS_ENABLED") {
		redis = cacheservice.GetNewCacheService(ctx, nil)
		redis.SetContext(ctx).SetExpiration(time.Duration(viper.GetInt64("REDIS_TTL")) * time.Second)
		defer redis.Close()
	}
	// Check if scheduler is enabled
	if viper.GetBool("SCHEDULER_ENABLED") {
		// Create a new scheduler instance
		s := gocron.NewScheduler()
		// Schedule job for block at 12:40 PM
		scheduleBlockJob(s, ctx)

		// Start the scheduler in a separate goroutine
		s.Start()

		// Listen for OS signals (SIGINT, SIGTERM) to gracefully shutdown
		waitForShutdownSignal(cancel)
	}

	// Wait indefinitely

}

func scheduleBlockJob(s *gocron.Scheduler, ctx context.Context) {
	//s.Every(1).Day().At("14:38"), s.Every(30).Second()
	err := s.Every(30).Second().Do(func() {
		go cronjobs.InitUnBlockCase(ctx)
	})
	if err != nil {
		log.Fatalf("Failed to schedule block job: %v", err)
	}
}

func waitForShutdownSignal(cancel context.CancelFunc) {
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)

	// Wait for an interrupt signal
	<-sigCh

	// Trigger cancellation
	cancel()
}
