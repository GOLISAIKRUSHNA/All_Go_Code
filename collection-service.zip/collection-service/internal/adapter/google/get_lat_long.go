package google

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/dto/response"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"

	"github.com/spf13/viper"
)

type GoogleLatLong struct {
	Latitude  float64
	Longitude float64
}

type GoogleAdress struct {
	Address string
	City    string
	State   string
	Country string
	Pincode int
}

// Implement your logic to call Google Maps Geocoding API and get latitude and longitude
func GetLatLong(ctx context.Context, address GoogleAdress) (GoogleLatLong, error) {
	apiKey := viper.GetString("GOOGLE_API_KEY")

	location := GoogleLatLong{}

	// Construct the URL for the Geocoding API request
	baseURL := constants.GOOGLE_MAP_BASE_URL + constants.LAT_LONG_ENDPOINT
	addressQuery := fmt.Sprintf("%s, %s, %s, %d, %s", address.Address, address.City, address.State, address.Pincode, address.Country)
	apiURL := fmt.Sprintf("%s?address=%s&key=%s", baseURL, url.QueryEscape(addressQuery), apiKey)

	// Make the API request
	responseBody, err := http.Get(apiURL)
	if err != nil {
		logger.Error(ctx, err, "GoogleService|GetLatLong", logger.LogFields{"address": address, "location": location})
		return location, fmt.Errorf("failed to make API request: %v", err)
	}
	defer responseBody.Body.Close()
	var geocodeResponse response.GeoCodeResponse

	err = json.NewDecoder(responseBody.Body).Decode(&geocodeResponse)
	if err != nil {
		logger.Error(ctx, err, "GoogleService|GetLatLong", logger.LogFields{"address": address, "location": location})
		return location, fmt.Errorf("failed to decode API response: %v", err)
	}

	// Check the API response status
	if geocodeResponse.Status != "OK" || len(geocodeResponse.Results) == 0 {
		logger.Error(ctx, err, "GoogleService|GetLatLong", logger.LogFields{"address": address, "location": location})
		return location, fmt.Errorf("API request unsuccessful. Status: %s", geocodeResponse.Status)
	}

	location.Latitude = geocodeResponse.Results[0].Geometry.Location.Lat
	location.Longitude = geocodeResponse.Results[0].Geometry.Location.Lng

	return location, nil
}
