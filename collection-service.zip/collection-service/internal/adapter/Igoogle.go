package adapter

import (
	"collection-service/internal/adapter/google"
	"github.com/gin-gonic/gin"
)

type IGoogleServices interface {
	GetLatLong(c *gin.Context, address google.GoogleAdress) (google.GoogleLatLong, error)
}