package rabbit_mq

import "github.com/pusher/pusher-http-go/v5"

// write client for pusher
type Pusher struct {
	client *pusher.Client
}

// InitPusherClient creates a new pusher client
func InitPusherClient(appID, key, secret, cluster string) *Pusher {
	client := pusher.Client{
		AppID:   appID,
		Key:     key,
		Secret:  secret,
		Cluster: cluster,
		Secure:  true,
	}

	return &Pusher{
		client: &client,
	}
}

// GetPusherClientInstance returns the pusher client instance
func GetPusherClientInstance(pusherClient *Pusher) *pusher.Client {
	return pusherClient.client
}

// PushMessage sends a message to the pusher channel
func (p *Pusher) PushMessage(userID string, event string, data interface{}) error {
	err := p.client.SendToUser(userID, event, data)
	if err != nil {
		return err
	}

	return nil
}
