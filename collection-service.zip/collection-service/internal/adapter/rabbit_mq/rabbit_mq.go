package rabbit_mq

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"github.com/rabbitmq/amqp091-go"
	"github.com/spf13/viper"
)

// RabbitMQClient is an implementation of IMessageBroker using RabbitMQ.
type RabbitMQClient struct {
	connection *amqp091.Connection
	channel    *amqp091.Channel
}

var rabbitMQConn *amqp091.Connection
var rabbitMQClient *RabbitMQClient

// InitRabbitMQConn creates a new connection for RabbitMQClient.
func InitRabbitMQConn(ctx context.Context) (*amqp091.Connection, chan *amqp091.Error) {

	username := viper.GetString("RABBITMQ_USERNAME")
	password := viper.GetString("RABBBITMQ_PASSWORD")
	host := viper.GetString("RABBITMQ_HOST")
	vhost := viper.GetString("RABBITMQ_VHOST")

	url := fmt.Sprintf("amqp://%s:%s@%s/%s", username, password, host, vhost)

	var err error
	rabbitMQConn, err = amqp091.Dial(url)
	if err != nil {
		panic(err)
	}
	connClose := make(chan *amqp091.Error)
	rabbitMQConn.NotifyClose(connClose)

	return rabbitMQConn, connClose
}

// NewRabbitMQClient creates a new instance of RabbitMQClient.
func NewRabbitMQClient(ctx context.Context, conn *amqp091.Connection, prefetchCount int) (*RabbitMQClient, chan *amqp091.Error) {
	rabbitMQClient := &RabbitMQClient{}
	rabbitMQClient.connection = conn

	var err error
	rabbitMQClient.channel, err = rabbitMQClient.connection.Channel()
	if err != nil {
		panic(err)
	}

	err = rabbitMQClient.channel.Qos(prefetchCount, 0, false)
	if err != nil {
		panic(err)
	}
	chClose := make(chan *amqp091.Error)
	rabbitMQClient.channel.NotifyClose(chClose)

	return rabbitMQClient, chClose
}

func GetRabbitMQConnInstance(ctx context.Context) *amqp091.Connection {
	return rabbitMQConn
}

func GetRabbitMQClientInstance(ctx context.Context) *RabbitMQClient {
	return rabbitMQClient
}

func InitRabbitMQClient(ctx context.Context, prefetchCount int) (*RabbitMQClient, chan *amqp091.Error) {
	var chClose chan *amqp091.Error
	rabbitMQClient, chClose = NewRabbitMQClient(ctx, GetRabbitMQConnInstance(ctx), prefetchCount)

	// initializing service default delayed exchange
	err := rabbitMQClient.DeclareDelayedExchange(ctx, constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE, true, false)
	if err != nil {
		panic(err)
	}

	return rabbitMQClient, chClose
}

// DeclareQueue declares a queue on RabbitMQ server.
func (c *RabbitMQClient) DeclareQueue(ctx context.Context, queueName string, bindingKeys []string, exchange string) error {
	_, err := c.channel.QueueDeclare(
		queueName, // name
		true,      // durable
		false,     // delete when unused
		false,     // exclusive
		false,     // no-wait
		nil,       // arguments
	)
	if err != nil {
		return err
	}

	for i := range bindingKeys {
		err := c.CreateBinding(ctx, queueName, bindingKeys[i], exchange)
		if err != nil {
			return err
		}
	}

	return nil
}

func (c *RabbitMQClient) CreateBinding(ctx context.Context, name, binding, exchange string) error {

	// leaving no wait to false will make the channel return error if it fails to bind the queue.
	return c.channel.QueueBind(name, binding, exchange, false, nil)
}

// Publish publishes a message to a specific queue.
func (c *RabbitMQClient) Publish(ctx context.Context, exchange string, routingKey []string, message []byte, delay *int) error {

	const contentType = "text/plain"

	headers := amqp091.Table{}
	if delay != nil {
		headers["x-delay"] = *delay
	}

	var xApp, xAppVersion string
	reqInfo := utils.GetRequestInfoFromCtx(ctx)
	if reqInfo != nil {
		xApp = reqInfo.App
		xAppVersion = reqInfo.AppVersion
	}

	headers[constants.X_TRACE_ID] = tracing.GetTraceId(ctx)
	headers[constants.X_APP] = xApp
	headers[constants.X_APP_VERSION] = xAppVersion

	for i := range routingKey {
		err := c.channel.PublishWithContext(ctx,
			exchange,      // exchange
			routingKey[i], // routing key
			true,          // mandatory
			false,         // immediate
			amqp091.Publishing{
				ContentType:  contentType,
				Body:         message,
				Headers:      headers,
				DeliveryMode: amqp091.Persistent,
			},
		)

		if err != nil {
			return err
		}
	}
	return nil
}

func (c *RabbitMQClient) DeclareDelayedExchange(ctx context.Context, exchangeName string, durable, autoDelete bool) error {
	err := c.channel.ExchangeDeclare(
		exchangeName,
		"x-delayed-message",
		durable,
		autoDelete,
		false,
		false,
		amqp091.Table{
			"x-delayed-type": "direct",
		},
	)
	if err != nil {
		return err
	}

	return nil
}

// Consume sets up a consumer and starts consuming messages from a queue.
func (c *RabbitMQClient) Consume(ctx context.Context, queueName string, autoAck bool) (<-chan amqp091.Delivery, error) {
	msgs, err := c.channel.Consume(
		queueName, // queue
		"",        // consumer
		autoAck,   // auto-ack
		false,     // exclusive
		false,     // no-local
		false,     // no-wait
		nil,       // args
	)
	if err != nil {
		return nil, err
	}

	return msgs, nil
}

// Close closes the channel.
func (c *RabbitMQClient) CloseChannel() {
	if c.channel != nil {
		if err := c.channel.Close(); err != nil {
			panic(err)
		}
	}
}

// Close closes the connection.
func (c *RabbitMQClient) CloseConn() {
	if c.connection != nil {
		if err := c.connection.Close(); err != nil {
			panic(err)
		}
	}
}
