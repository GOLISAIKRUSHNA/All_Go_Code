package pusher

import "github.com/pusher/pusher-http-go/v5"

// write pusher client

type PusherClient struct {
	client *pusher.Client
}

var pusherClient *PusherClient

func InitPusherClient() *pusher.Client {
	client := pusher.Client{
		AppID:   "1811083",
		Key:     "eb3357e51daf912e1fcd",
		Secret:  "4ea0caee8be82c5a5c92",
		Cluster: "ap2",
		Secure:  true,
	}
	pusherClient = &PusherClient{client: &client}
	return &client
}

func GetPusherClientInstance() *PusherClient {
	return pusherClient
}

func (p *PusherClient) PushMessage(userID string, eventName string, data interface{}) error {
	err := p.client.SendToUser(userID, eventName, data)
	if err != nil {
		return err
	}
	return nil
}
