package adapter

import (
	"context"
	"io"

	"github.com/tealeg/xlsx"
)

type IFileManager interface {
	UploadFile(ctx context.Context, key string, bucket string, file io.Reader, contentType string) error
	GetSharableURL(ctx context.Context, filePath string, bucket string) (string, error)
	UploadBase64Image(ctx context.Context, key string, bucket string, base64Image, contentType string) error
	GetAllFilePathsFromFolder(ctx context.Context, filesPath string, bucket string) ([]string, error)
	ReadXlsx(ctx context.Context, bucket string, filesPath string) *xlsx.File
	GetImageBase64Encode(ctx context.Context, bucket string, filesPath string) (string, error)
	ReadZipFromS3(c context.Context, bucket, path string) ([]ZipFile, error)
}

type ZipFile struct {
	Name    string // File name
	Content []byte // File content
}
