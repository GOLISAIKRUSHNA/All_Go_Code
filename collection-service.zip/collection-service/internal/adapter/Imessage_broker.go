package adapter

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter/rabbit_mq"
	"collection-service/internal/app/constants"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
	"time"

	"go.opentelemetry.io/otel/trace"

	"github.com/spf13/viper"

	"github.com/rabbitmq/amqp091-go"
)

// IMessageBroker is an interface representing a message broker client.
type IMessageBroker interface {
	DeclareQueue(ctx context.Context, queueName string, bindingKeys []string, exchange string) error
	DeclareDelayedExchange(ctx context.Context, exchangeName string, durable, autoDelete bool) error
	Publish(ctx context.Context, exchange string, routingKey []string, message []byte, delay *int) error
	Consume(ctx context.Context, queue string, autoAck bool) (<-chan amqp091.Delivery, error)
	CloseChannel()
	CloseConn()
}

type Message struct {
	TraceID     string      `json:"trace_id"`
	EventName   string      `json:"event_name"`
	Version     string      `json:"version"`
	CreatedAt   time.Time   `json:"created_at"`
	Payload     interface{} `json:"payload"`
	ServiceName string      `json:"service_name"`
}

func NewMessage(ctx context.Context, event string, data interface{}, version string) *Message {
	if version == "" {
		version = constants.DEFAULT_MESSAGE_VERSION
	}

	return &Message{
		TraceID:     tracing.GetTraceId(ctx),
		Version:     version,
		CreatedAt:   time.Now(),
		EventName:   event,
		Payload:     data,
		ServiceName: viper.GetString("SERVICE_NAME"),
	}
}

func PublishEvent(ctx context.Context, keys []string, eventModel interface{}, eventName string, delayTime *int) error {
	data := NewMessage(ctx, eventName, eventModel, "")

	payload, err := json.Marshal(data)
	if err != nil {
		logger.Error(ctx, err, "unable to marshal event",
			logger.LogFields{"event": eventName,
				"queue_keys": keys,
				"payload":    payload,
			})
		return err
	}

	if err := rabbit_mq.GetRabbitMQClientInstance(ctx).Publish(ctx, constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE, keys, payload, delayTime); err != nil {
		logger.Error(ctx, err, "failed to publish event", logger.LogFields{"event": eventName,
			"queue_keys": keys,
			"payload":    payload,
		})
		return err
	}

	return nil
}

func InjectAppInfoIntoCtx(msg *amqp091.Delivery, ctx context.Context) context.Context {

	var requestInfo constants.RequestInfo
	if msg.Headers != nil {
		if msg.Headers[constants.X_APP] != nil {
			requestInfo.App, _ = msg.Headers[constants.X_APP].(string)
		}

		if msg.Headers[constants.X_APP_VERSION] != nil {
			requestInfo.AppVersion, _ = msg.Headers[constants.X_APP_VERSION].(string)
		}
	}

	modCtx := context.WithValue(ctx, constants.CTX_REQUEST_INFO, requestInfo)

	return modCtx
}

func InjectTraceInfoIntoCtx(msg *amqp091.Delivery, ctx context.Context) context.Context {
	var traceIDHeader string
	if msg != nil && msg.Headers != nil {
		if msg.Headers[constants.X_TRACE_ID] != nil {
			traceIDHeader, _ = msg.Headers[constants.X_TRACE_ID].(string)
		}
	}

	traceIdHex, _ := trace.TraceIDFromHex(traceIDHeader)

	spanCtx := trace.NewSpanContext(trace.SpanContextConfig{TraceID: traceIdHex})

	eventCtx := trace.ContextWithRemoteSpanContext(ctx, spanCtx)
	return eventCtx
}
