package aws

import (
	"archive/zip"
	"bytes"
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/utils"
	"context"
	"encoding/base64"
	"fmt"
	"io/ioutil"
	"strings"

	"io"
	"time"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"github.com/tealeg/xlsx"
)

const LinkValidHour = 72

type S3Client struct {
	session *session.Session
}

func InitS3Client(ctx context.Context, sess *session.Session) *S3Client {
	s3Instance = &S3Client{
		session: sess,
	}

	return s3Instance
}

var s3Instance *S3Client

func GetS3Instance() *S3Client {
	return s3Instance
}

func (ss S3Client) UploadFile(ctx context.Context, key string, bucket string, file io.Reader, contentType string) error {

	uploader := s3manager.NewUploader(ss.session)
	_, err := uploader.Upload(&s3manager.UploadInput{
		Bucket:      aws.String(bucket),
		Key:         aws.String(key),
		Body:        file,
		ContentType: aws.String(contentType),
	})

	if err != nil {
		errorMessage := fmt.Sprintf("Upload failed for object with key: %s, bucket: %s", key, bucket)
		logger.Error(ctx, err, errorMessage, nil)
		return err
	}

	return nil
}

func (ss S3Client) UploadBase64Image(ctx context.Context, key string, bucket string, base64Image, contentType string) error {
	base64Data := base64Image[strings.IndexByte(base64Image, ',')+1:]

	decode, err := base64.StdEncoding.DecodeString(base64Data)
	if err != nil {
		return err
	}

	uploader := s3manager.NewUploader(ss.session)

	_, err = uploader.Upload(&s3manager.UploadInput{
		Bucket:      aws.String(bucket),
		Key:         aws.String(key),
		Body:        bytes.NewReader(decode),
		ContentType: aws.String(contentType),
	})
	if err != nil {
		errorMessage := fmt.Sprintf("Upload failed for object with key: %s, bucket: %s", key, bucket)
		logger.Error(ctx, err, errorMessage, nil)
		return err
	}

	return nil
}

func (ss S3Client) GetSharableURL(ctx context.Context, filePath string, bucket string) (string, error) {
	svc := s3.New(ss.session)

	req, _ := svc.GetObjectRequest(&s3.GetObjectInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(filePath),
	})

	urlStr, err := req.Presign(LinkValidHour * time.Hour)
	if err != nil {
		logger.Error(ctx, err, "GetSharableURL: failed to get url, %v", nil)
		return "", err
	}

	return urlStr, err
}

func (ss S3Client) GetAllFilePathsFromFolder(ctx context.Context, filesPath string, bucket string) ([]string, error) {
	svc := s3.New(ss.session)

	resp, err := svc.ListObjectsV2(&s3.ListObjectsV2Input{
		Bucket: aws.String(bucket),
		Prefix: aws.String(filesPath),
	})
	if err != nil {
		return nil, err
	}

	keys := []string{}
	for _, obj := range resp.Contents {
		if obj.Key != nil {
			keys = append(keys, *obj.Key)
		}
	}
	return keys, nil
}

func (ss S3Client) ReadXlsx(c context.Context, bucket string, path string) *xlsx.File {
	// Create an S3 client
	svc := s3.New(ss.session)

	// Download the file from S3
	resp, err := svc.GetObject(&s3.GetObjectInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(path),
	})
	if err != nil {
		logger.Error(c, err, "S3|ReadXlsx|Error: failed to connect", nil)
		utils.SentryCaptureException(err)
	}

	// Read the content of the file
	buffer := new(bytes.Buffer)
	_, err = buffer.ReadFrom(resp.Body)
	if err != nil {
		logger.Error(c, err, "S3|ReadXlsx|Error: In Read the content of the file", nil)
		utils.SentryCaptureException(err)
	}

	// Parse the XLSX file
	data, err := xlsx.OpenBinary(buffer.Bytes())
	if err != nil {
		logger.Error(c, err, "S3|ReadXlsx|Error: In Parse the XLSX file", nil)

	}
	return data
}

func (ss S3Client) GetImageBase64Encode(c context.Context, bucket string, path string) (string, error) {
	// Create an S3 client
	svc := s3.New(ss.session)

	// Download the file from S3
	resp, err := svc.GetObject(&s3.GetObjectInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(path),
	})
	base64Content := ""
	if err != nil {
		logger.Error(c, err, "S3|GetImageBase64Encode|Error: Error getting S3 object", nil)
		return base64Content, err

	}

	// Read the content of the S3 object
	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Error(c, err, "S3|GetImageBase64Encode|Error: rror reading object data", nil)
		return base64Content, err
	}

	// Convert the content to base64 encoding
	base64Content = base64.StdEncoding.EncodeToString(data)
	return base64Content, nil

}

func (ss *S3Client) ReadZipFromS3(c context.Context, bucket, path string) ([]adapter.ZipFile, error) {
	// Initialize S3 downloader
	downloader := s3manager.NewDownloader(ss.session)

	// Create a buffer to download the zip file
	buffer := aws.NewWriteAtBuffer([]byte{})

	// Download the zip file from S3
	_, err := downloader.Download(buffer, &s3.GetObjectInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(path),
	})
	if err != nil {
		return nil, err
	}

	// Open the zip archive
	zipReader, err := zip.NewReader(bytes.NewReader(buffer.Bytes()), int64(len(buffer.Bytes())))
	if err != nil {
		return nil, err
	}

	// Iterate over files in the zip archive
	var files []adapter.ZipFile
	for _, zipFile := range zipReader.File {
		// Skip files starting with "__MACOSX/._"
		if !strings.HasPrefix(zipFile.Name, "__MACOSX/._") {
			// Open file in the zip archive
			fileInZip, err := zipFile.Open()
			if err != nil {
				return nil, err
			}
			defer fileInZip.Close()

			// Read file contents
			fileContents, err := ioutil.ReadAll(fileInZip)
			if err != nil {
				return nil, err
			}

			// Add file to the slice
			files = append(files, adapter.ZipFile{Name: zipFile.Name, Content: fileContents})
		}
	}

	return files, nil
}
