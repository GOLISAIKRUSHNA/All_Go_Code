package aws

import (
	"context"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/spf13/viper"
)

var awsSession *session.Session

func GetAWSSessionInstance() *session.Session {
	return awsSession
}

func InitAWSSession(ctx context.Context) *session.Session {
	region := viper.GetString("AWS_REGION")
	accessKeyID := viper.GetString("AWS_ACCESS_KEY_ID")
	secretAccessKey := viper.GetString("AWS_SECRET_ACCESS_KEY")

	sess, err := session.NewSession(&aws.Config{
		Region:      aws.String(region),
		Credentials: credentials.NewStaticCredentials(accessKeyID, secretAccessKey, ""),
	})
	if err != nil {
		panic(err)
	}

	awsSession = sess
	return sess
}
