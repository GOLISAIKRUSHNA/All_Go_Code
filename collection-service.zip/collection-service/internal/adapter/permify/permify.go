package permify

import (
	"collection-service/common/logger"
	"context"
	"google.golang.org/protobuf/types/known/anypb"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	v1 "github.com/Permify/permify-go/generated/base/v1"

	permify "github.com/Permify/permify-go/v1"
	"github.com/spf13/viper"
)

type PermifyClient struct {
	client *permify.Client
}

var permifyClient *PermifyClient

func InitPermifyClient(ctx context.Context) *permify.Client {
	// generate new client
	client, err := permify.NewClient(
		permify.Config{
			Endpoint: viper.GetString("PERMIFY_SERVICE_BASE_URL"),
		},
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)

	if err != nil {
		logger.Error(ctx, err, "PermifyClient|InitPermifyClient", nil)
		panic(err)
	}

	permifyClient = &PermifyClient{client: client}

	return client
}

func GetPermifyClientInstance(ctx context.Context) *PermifyClient {
	return permifyClient
}

func (p *PermifyClient) WriteSchema(ctx context.Context, schema string) error {
	_, err := p.client.Schema.Write(ctx, &v1.SchemaWriteRequest{
		TenantId: "t1",
		Schema:   schema,
	})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|WriteSchema", logger.LogFields{"schema": schema})
	}

	return nil
}

func (p *PermifyClient) WriteRelationTuple(ctx context.Context, relationTuple []RelationTuple) error {
	if len(relationTuple) == 0 {
		return nil
	}

	tuples := []*v1.Tuple{}
	for _, tuple := range relationTuple {
		tuples = append(tuples, &v1.Tuple{
			Entity:   &v1.Entity{Type: tuple.EntityType, Id: tuple.EntityId},
			Relation: tuple.Relation,
			Subject:  &v1.Subject{Type: tuple.SubjectType, Id: tuple.SubjectId},
		})
	}

	_, err := p.client.Data.Write(context.Background(), &v1.DataWriteRequest{
		TenantId: "t1",
		Metadata: &v1.DataWriteRequestMetadata{
			SchemaVersion: "",
		},
		Tuples: tuples,
	})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|WriteRelationTuple", logger.LogFields{"relationTuple": relationTuple})
		return err
	}

	return nil
}

func (p *PermifyClient) CheckPermission(ctx context.Context, permission PermissionTuple) (bool, error) {
	cr, err := p.client.Permission.Check(ctx, &v1.PermissionCheckRequest{
		Metadata: &v1.PermissionCheckRequestMetadata{
			SchemaVersion: "",
			Depth:         100,
		},
		TenantId: "t1",

		Entity:     &v1.Entity{Type: permission.EntityType, Id: permission.EntityId},
		Permission: permission.Permission,
		Subject:    &v1.Subject{Type: permission.SubjectType, Id: permission.SubjectId},
	})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|CheckPermission", logger.LogFields{"permission": permission})
		return false, err
	}

	if cr.Can == v1.CheckResult_CHECK_RESULT_ALLOWED {
		return true, nil
	}

	return false, nil
}

func (p *PermifyClient) EntityFiltering(ctx context.Context, tuple PermissionTuple) ([]EntityTuple, error) {
	er, err := p.client.Permission.LookupEntity(context.Background(), &v1.PermissionLookupEntityRequest{
		TenantId: "t1",
		Metadata: &v1.PermissionLookupEntityRequestMetadata{
			SnapToken:     "",
			SchemaVersion: "",
			Depth:         100,
		},
		EntityType: tuple.EntityType,
		Permission: tuple.Permission,
		Subject: &v1.Subject{
			Type: tuple.SubjectType,
			Id:   tuple.SubjectId,
		},
	})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|EntityFiltering", logger.LogFields{"tuple": tuple})
		return nil, err
	}

	entityTuples := []EntityTuple{}
	for _, id := range er.EntityIds {
		entityTuples = append(entityTuples, EntityTuple{EntityType: tuple.EntityType, EntityId: id})
	}

	return entityTuples, nil
}

func (p *PermifyClient) SubjectFiltering(ctx context.Context, tuple PermissionTuple) ([]SubjectTuple, error) {
	er, err := p.client.Permission.LookupSubject(context.Background(), &v1.PermissionLookupSubjectRequest{
		TenantId: "t1",
		Metadata: &v1.PermissionLookupSubjectRequestMetadata{
			SnapToken:     "",
			SchemaVersion: "",
			Depth:         100,
		},
		SubjectReference: &v1.RelationReference{
			Type: tuple.SubjectType,
		},
		Permission: tuple.Permission,
		Entity: &v1.Entity{
			Type: tuple.EntityType,
			Id:   tuple.EntityId,
		},
	})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|EntityFiltering", logger.LogFields{"tuple": tuple})
		return nil, err
	}

	entityTuples := []SubjectTuple{}
	for _, id := range er.SubjectIds {
		entityTuples = append(entityTuples, SubjectTuple{SubjectType: tuple.EntityType, SubjectId: id})
	}

	return entityTuples, nil
}

func (p *PermifyClient) DeleteRelationTuple(ctx context.Context, deleteRelationTuple DeleteRelationTuple) error {
	if len(deleteRelationTuple.EntityIds) == 0 && len(deleteRelationTuple.SubjectIds) == 0 {
		return nil
	}

	_, err := p.client.Data.Delete(context.Background(), &v1.DataDeleteRequest{
		TenantId: "t1",
		TupleFilter: &v1.TupleFilter{
			Entity: &v1.EntityFilter{
				Type: deleteRelationTuple.EntityType,
				Ids:  deleteRelationTuple.EntityIds,
			},
			Relation: deleteRelationTuple.Relation,
			Subject: &v1.SubjectFilter{
				Type: deleteRelationTuple.SubjectType,
				Ids:  deleteRelationTuple.SubjectIds,
			},
		},
		AttributeFilter: &v1.AttributeFilter{},
	})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|DeleteRelationTuple", logger.LogFields{"deleteRelationTuple": deleteRelationTuple})
		return err
	}

	return nil
}

func (p *PermifyClient) GetPermissionsList(ctx context.Context, entityTuple EntityTuple, subjectTuple SubjectTuple, onlyPermission bool) (map[string]bool, error) {
	pr, err := p.client.Permission.SubjectPermission(ctx, &v1.PermissionSubjectPermissionRequest{
		TenantId: "t1",
		Metadata: &v1.PermissionSubjectPermissionRequestMetadata{
			SchemaVersion:  "",
			Depth:          100,
			SnapToken:      "",
			OnlyPermission: onlyPermission,
		},
		Entity: &v1.Entity{
			Type: entityTuple.EntityType,
			Id:   entityTuple.EntityId,
		},
		Subject: &v1.Subject{
			Type: subjectTuple.SubjectType,
			Id:   subjectTuple.SubjectId,
		},
	})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|GetPermissionsList", logger.LogFields{"entityTuple": entityTuple})
		return nil, err
	}

	permissions := make(map[string]bool)

	for key, value := range pr.GetResults() {
		if value == v1.CheckResult_CHECK_RESULT_ALLOWED {
			permissions[key] = true
		} else if value == v1.CheckResult_CHECK_RESULT_DENIED {
			permissions[key] = false
		}
	}
	return permissions, nil
}

func (p *PermifyClient) WriteAttributes(ctx context.Context, booleanAttributeTuples []AttributeTuple) error {
	var permifyAttributes []*v1.Attribute

	for _, tuple := range booleanAttributeTuples {
		var value *anypb.Any

		// add boolean values to permify.
		if val, ok := tuple.Value.(bool); ok {
			var err error
			value, err = anypb.New(&v1.BooleanValue{
				Data: val,
			})
			if err != nil {
				logger.Error(ctx, err, "PermifyClient|WriteAttributes", logger.LogFields{"entityTuple": tuple})
				return err
			}

			permifyAttributes = append(permifyAttributes, &v1.Attribute{
				Entity: &v1.Entity{
					Type: tuple.EntityType,
					Id:   tuple.EntityId,
				},
				Attribute: tuple.Attribute,
				Value:     value,
			})
		}
	}

	_, err := p.client.Data.Write(ctx, &v1.DataWriteRequest{
		TenantId: "t1",
		Metadata: &v1.DataWriteRequestMetadata{
			SchemaVersion: "",
		},

		Attributes: permifyAttributes,
	})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|WriteAttributes", logger.LogFields{"permifyAttributes": permifyAttributes})
		return err
	}

	return nil
}

func (p *PermifyClient) ReadAttributes(ctx context.Context, readAttributeTuple ReadAttributeTuple) (map[string]interface{}, error) {
	ar, err := p.client.Data.ReadAttributes(ctx, &v1.AttributeReadRequest{
		TenantId: "t1",
		Metadata: &v1.AttributeReadRequestMetadata{
			SnapToken: "",
		},
		Filter: &v1.AttributeFilter{
			Entity: &v1.EntityFilter{
				Type: readAttributeTuple.EntityType,
				Ids:  readAttributeTuple.EntityIds,
			},
			Attributes: readAttributeTuple.Attributes,
		}})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|ReadAttributes", logger.LogFields{"readAttributeTuple": readAttributeTuple})
		return nil, err
	}

	attributes := make(map[string]interface{})
	for _, attribute := range ar.Attributes {
		attributes[attribute.String()] = attribute.Value.String()

	}
	return attributes, nil
}

func (p *PermifyClient) ReadRelationships(ctx context.Context, readAttributeTuple ReadRelationTuple) ([]RelationTuple, error) {
	ar, err := p.client.Data.ReadRelationships(ctx, &v1.RelationshipReadRequest{
		TenantId: "t1",
		Metadata: &v1.RelationshipReadRequestMetadata{
			SnapToken: "",
		},
		Filter: &v1.TupleFilter{
			Entity: &v1.EntityFilter{
				Type: readAttributeTuple.EntityType,
				Ids:  readAttributeTuple.EntityIds,
			},
			Relation: readAttributeTuple.Relation,
			Subject: &v1.SubjectFilter{
				Type: readAttributeTuple.SubjectType,
				Ids:  readAttributeTuple.SubjectIds,
			},
		}})
	if err != nil {
		logger.Error(ctx, err, "PermifyClient|ReadAttributes", logger.LogFields{"readAttributeTuple": readAttributeTuple})
		return nil, err
	}

	var relationTuples []RelationTuple
	for _, relations := range ar.Tuples {
		relationTuples = append(relationTuples, RelationTuple{
			EntityTuple: EntityTuple{
				EntityType: relations.Entity.Type,
				EntityId:   relations.Entity.Id,
			},
			Relation: relations.Relation,
			SubjectTuple: SubjectTuple{
				SubjectType: relations.Subject.Type,
				SubjectId:   relations.Subject.Id,
			},
		})

	}

	return relationTuples, nil
}

type RelationTuple struct {
	EntityTuple
	Relation string `json:"relation"`
	SubjectTuple
}

type SubjectTuple struct {
	SubjectType string `json:"subject_type"`
	SubjectId   string `json:"subject_id"`
}

type EntityTuple struct {
	EntityType string `json:"entity_type"`
	EntityId   string `json:"entity_id"`
}

type PermissionTuple struct {
	EntityTuple
	Permission string `json:"permission"`
	SubjectTuple
}

type DeleteRelationTuple struct {
	EntityFilteringTuple
	Relation string `json:"relation"`
	SubjectFilteringTuple
}

type ReadRelationTuple struct {
	EntityFilteringTuple
	Relation string `json:"relation"`
	SubjectFilteringTuple
}

type EntityFilteringTuple struct {
	EntityType string   `json:"entity_type"`
	EntityIds  []string `json:"entity_ids"`
}

type SubjectFilteringTuple struct {
	SubjectType string   `json:"subject_type"`
	SubjectIds  []string `json:"subject_ids"`
}

type AttributeTuple struct {
	EntityTuple
	Attribute string      `json:"attribute"`
	Value     interface{} `json:"value"`
}

type ReadAttributeTuple struct {
	EntityFilteringTuple
	Attributes []string `json:"attributes"`
}
