package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type AddressType int

const (
	_ AddressType = iota
	PRESENT_ADDRESS
	PERMANENT_ADDRESS
)

// String - Creating common behavior - give the type a String function
func (a AddressType) String() string {
	return [...]string{"", "PRESENT_ADDRESS", "PERMANENT_ADDRESS"}[a]
}

func (a AddressType) MarshalJSON() ([]byte, error) {
	return json.Marshal(a.String())
}
func (a *AddressType) UnmarshalJSON(data []byte) error {
	var addressTypeStr string
	if err := json.Unmarshal(data, &addressTypeStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(addressTypeStr))

	*a = StringToAddressType(status)

	if *a == AddressType(0) {
		return fmt.Errorf("invalid address medium value: %s", addressTypeStr)
	}

	return nil
}

func StringToAddressType(a string) AddressType {
	switch strings.ToUpper(a) {
	case "PRESENT_ADDRESS":
		return PRESENT_ADDRESS
	case "PERMANENT_ADDRESS":
		return PERMANENT_ADDRESS

	default:
		return AddressType(0)
	}
}

// Value - Implementation of valuer for database/sql
func (a AddressType) Value() (driver.Value, error) {

	return int64(a), nil
}
func (a *AddressType) Scan(value interface{}) error {
	addressTypeStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid address type value: %s", addressTypeStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(addressTypeStr)))

	*a = StringToAddressType(status)

	if *a == AddressType(0) {
		return nil
		//return fmt.Errorf("invalid address type value: %s", addressTypeStr)
	}

	return nil
}
