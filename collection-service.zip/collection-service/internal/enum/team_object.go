package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type TeamObject int

const (
	_ TeamObject = iota
	OBJECT_CLIENT
	OBJECT_SERVICE_PROVIDER
)

// String - Creating common behavior give the type a String function
func (t TeamObject) String() string {
	return [...]string{"", "CLIENT", "SERVICE_PROVIDER"}[t]
}

func (t TeamObject) MarshalJSON() ([]byte, error) {
	return json.Marshal(t.String())
}

func (t *TeamObject) UnmarshalJSON(data []byte) error {
	var objStr string
	if err := json.Unmarshal(data, &objStr); err != nil {
		return err
	}

	object := strings.TrimSpace(strings.ToUpper(objStr))

	*t = StringToTeamObject(object)

	if *t == TeamObject(0) {
		return fmt.Errorf("invalid Team Object value: %s", objStr)
	}

	return nil
}

func StringToTeamObject(t string) TeamObject {
	switch strings.ToUpper(t) {
	case OBJECT_CLIENT.String():
		return OBJECT_CLIENT
	case OBJECT_SERVICE_PROVIDER.String():
		return OBJECT_SERVICE_PROVIDER
	default:
		// Return an error if the input string doesn't match any enum value
		return TeamObject(0)
	}
}

// Value - Implementation of valuer for database/sql
func (t TeamObject) Value() (driver.Value, error) {

	return int64(t), nil
}
func (t *TeamObject) Scan(value interface{}) error {

	objStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid Team object value: %s", objStr)
	}

	object := strings.TrimSpace(strings.ToUpper(string(objStr)))

	*t = StringToTeamObject(object)

	if *t == TeamObject(0) {
		return fmt.Errorf("invalid Team Object value: %s", objStr)
	}

	return nil
}
