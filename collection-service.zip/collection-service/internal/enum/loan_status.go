package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type LoanStatus int

const (
	_ LoanStatus = iota
	LOAN_ACTIVE
	LOAN_CLOSED
)

// String - Creating common behavior - give the type a String function
func (s LoanStatus) String() string {
	return [...]string{"", "ACTIVE", "CLOSED"}[s]
}

func (s LoanStatus) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *LoanStatus) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "ACTIVE":
		*s = LOAN_ACTIVE
	case "CLOSED":
		*s = LOAN_CLOSED
	default:
		return fmt.Errorf("invalid Loan status value: %s", statusStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s LoanStatus) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *LoanStatus) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid status value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "ACTIVE":
		*s = LOAN_ACTIVE
	case "CLOSED":
		*s = LOAN_CLOSED
	default:
		return fmt.Errorf("invalid loan status value: %s", statusStr)
	}

	return nil
}

func StringToLoanStatusEnum(s string) (LoanStatus, error) {
	switch strings.ToUpper(s) {
	case "ACTIVE":
		return LOAN_ACTIVE, nil
	case "CLOSED":
		return LOAN_CLOSED, nil
	default:
		// Return an error if the input string doesn't match any enum value
		return 0, fmt.Errorf("invalid tenure: %s", s)
	}
}
