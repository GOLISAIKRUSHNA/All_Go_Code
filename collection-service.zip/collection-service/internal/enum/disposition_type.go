package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type DispositionType int

const (
	_ DispositionType = iota
	POSITIVE
	NEGATIVE
	NEUTRAL
	PAID // Added SYSTEM as a source
)

func (s DispositionType) String() string {
	return [...]string{"", "POSITIVE", "NEGATIVE", "NEUTRAL", "PAID"}[s]
}

func (s DispositionType) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *DispositionType) UnmarshalJSON(data []byte) error {
	var dispositionTypeStr string
	if err := json.Unmarshal(data, &dispositionTypeStr); err != nil {
		return err
	}

	dispositionType := strings.TrimSpace(strings.ToUpper(dispositionTypeStr))
	switch dispositionType {
	case "POSITIVE":
		*s = POSITIVE
	case "NEGATIVE":
		*s = NEGATIVE
	case "NEUTRAL":
		*s = NEUTRAL
	case "PAID":
		*s = PAID
	default:
		return nil
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s DispositionType) Value() (driver.Value, error) {
	return int64(s), nil
}

func (s *DispositionType) Scan(value interface{}) error {
	dispositionTypeStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid disposition_type value: %s", dispositionTypeStr)
	}

	dispositionType := strings.TrimSpace(strings.ToUpper(string(dispositionTypeStr)))
	*s = StringToDispositionType(dispositionType)

	if *s == DispositionType(0) {
		return nil
		//return fmt.Errorf("invalid address medi value: %s", addressQualityStr)
	}
	return nil
}

func StringToDispositionType(dispositionTypeStr string) DispositionType {
	dispositionType := strings.TrimSpace(strings.ToUpper(dispositionTypeStr))

	switch dispositionType {
	case "POSITIVE":
		return POSITIVE
	case "NEGATIVE":
		return NEGATIVE
	case "NEUTRAL":
		return NEUTRAL
	case "PAID":
		return PAID
	default:
		return DispositionType(0)
	}
}
