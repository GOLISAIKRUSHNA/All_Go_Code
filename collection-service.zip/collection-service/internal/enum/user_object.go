package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type UserObject int

const (
	_ UserObject = iota
	USER_CLIENT_USER
	USER_AGENT
)

// String - Creating common behavior give the type a String function
func (s UserObject) String() string {
	return [...]string{"", "CLIENT_USER", "AGENT"}[s]
}

func (s UserObject) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *UserObject) UnmarshalJSON(data []byte) error {
	var userObjectStr string
	if err := json.Unmarshal(data, &userObjectStr); err != nil {
		return err
	}

	userObject := strings.TrimSpace(strings.ToUpper(userObjectStr))

	*s = StringToUserObject(userObject)

	if *s == UserObject(0) {
		return fmt.Errorf("invalid UserObject value: %s", userObjectStr)
	}

	return nil
}

func StringToUserObject(s string) UserObject {
	switch strings.ToUpper(s) {
	case USER_CLIENT_USER.String():
		return USER_CLIENT_USER
	case USER_AGENT.String():
		return USER_AGENT
	default:
		// Return an error if the input string doesn't match any enum value
		return UserObject(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s UserObject) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *UserObject) Scan(value interface{}) error {

	userObjectStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid userObject value: %s", userObjectStr)
	}

	userObject := strings.TrimSpace(strings.ToUpper(string(userObjectStr)))

	*s = StringToUserObject(userObject)

	if *s == UserObject(0) {
		return fmt.Errorf("invalid UserObject value: %s", userObjectStr)
	}

	return nil
}
