package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type ContactOf int64

const (
	SELF ContactOf = iota + 1
	FATHER
	MOTHER
	HUSBAND
	WIFE
	SON
	SISTER
	DAUGHTER
	BROTHER
	FRIEND
)

// String - Creating common behavior - give the type a String function
func (c ContactOf) String() string {
	return [...]string{"SELF", "FATHER", "MOTHER", "HUSBAND", "WIFE", "SON", "SISTER", "DAUGHTER", "BROTHER", "FRIEND"}[c-1]
}

func (c ContactOf) MarshalJSON() ([]byte, error) {
	return json.Marshal(c.String())
}

func (c *ContactOf) UnmarshalJSON(data []byte) error {
	var contactOfStr string
	if err := json.Unmarshal(data, &contactOfStr); err != nil {
		return err
	}

	contactOf := strings.TrimSpace(strings.ToUpper(contactOfStr))

	switch contactOf {
	case "SELF":
		*c = SELF
	case "FATHER":
		*c = FATHER
	case "MOTHER":
		*c = MOTHER
	case "HUSBAND":
		*c = HUSBAND
	case "WIFE":
		*c = WIFE
	case "SON":
		*c = SON
	case "SISTER":
		*c = SISTER
	case "DAUGHTER":
		*c = DAUGHTER
	case "BROTHER":
		*c = BROTHER
	case "FRIEND":
		*c = FRIEND
	default:
		return fmt.Errorf("invalid ContactOf value: %s", contactOfStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (c ContactOf) Value() (driver.Value, error) {

	return int64(c), nil
}
func (c *ContactOf) Scan(value interface{}) error {

	contactOfStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid ContactOf value: %s", contactOfStr)
	}

	contactOf := strings.TrimSpace(strings.ToUpper(string(contactOfStr)))

	switch contactOf {
	case "SELF":
		*c = SELF
	case "FATHER":
		*c = FATHER
	case "MOTHER":
		*c = MOTHER
	case "HUSBAND":
		*c = HUSBAND
	case "WIFE":
		*c = WIFE
	case "SON":
		*c = SON
	case "SISTER":
		*c = SISTER
	case "DAUGHTER":
		*c = DAUGHTER
	case "BROTHER":
		*c = BROTHER
	case "FRIEND":
		*c = FRIEND
	default:
		return fmt.Errorf("invalid ContactOf value: %s", contactOfStr)
	}

	return nil
}
