package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type AttendanceApprovalStatus int

const (
	_ AttendanceApprovalStatus = iota
	PENDING
	APPROVED
	REJECTED
)

// String - Creating common behavior give the type a String function
func (s AttendanceApprovalStatus) String() string {
	return [...]string{"", "PENDING", "APPROVED", "REJECTED"}[s]
}

func (s AttendanceApprovalStatus) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *AttendanceApprovalStatus) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "PENDING":
		*s = PENDING
	case "APPROVED":
		*s = APPROVED
	case "REJECTED":
		*s = REJECTED

	default:
		return fmt.Errorf("invalid Attendance Type value: %s", statusStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s AttendanceApprovalStatus) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *AttendanceApprovalStatus) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid attendance type value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "PENDING":
		*s = PENDING
	case "APPROVED":
		*s = APPROVED
	case "REJECTED":
		*s = REJECTED
	default:
		return fmt.Errorf("invalid attendance approval status value: %s", statusStr)
	}

	return nil
}

func StringToAttendanceApprovalStatusEnum(s string) (AttendanceApprovalStatus, error) {
	switch strings.ToUpper(s) {
	case "PENDING":
		return PENDING, nil
	case "APPROVED":
		return APPROVED, nil
	case "REJECTED":
		return REJECTED, nil
	default:
		// Return an error if the input string doesn't match any enum value
		return 0, fmt.Errorf("invalid attendance approval status: %s", s)
	}
}
