package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type TicketStatus int

const (
	_ TicketStatus = iota
	TICKET_ACTIVE
	TICKET_INACTIVE
	TICKET_CLOSED
)

// String - Creating common behavior - give the type a String function
func (s TicketStatus) String() string {
	return [...]string{"", "ACTIVE", "INACTIVE", "CLOSED"}[s]
}

func (s TicketStatus) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *TicketStatus) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "ACTIVE":
		*s = TICKET_ACTIVE
	case "INACTIVE":
		*s = TICKET_INACTIVE
	case "CLOSED":
		*s = TICKET_CLOSED
	}

	return nil
}

func StringToTicketStatus(s string) TicketStatus {
	switch strings.ToUpper(s) {
	case "ACTIVE":
		return TICKET_ACTIVE
	case "INACTIVE":
		return TICKET_INACTIVE
	case "CLOSED":
		return TICKET_CLOSED
	default:
		// Return an error if the input string doesn't match any enum value
		return TicketStatus(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s TicketStatus) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *TicketStatus) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid ticket status value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "ACTIVE":
		*s = TICKET_ACTIVE
	case "INACTIVE":
		*s = TICKET_INACTIVE
	case "CLOSED":
		*s = TICKET_CLOSED
	default:
		return fmt.Errorf("invalid ticket status value: %s", statusStr)
	}

	return nil
}
