package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type BlockSource int

const (
	_ BlockSource = iota
	DISPOSITION
	VOICE_ANALYTICS
	AUDIT
	CLIENT
)

// String - Creating common behavior - give the type a String function
func (s BlockSource) String() string {
	return [...]string{"", "DISPOSITION", "VOICE_ANALYTICS", "AUDIT", "CLIENT"}[s]
}

func (s BlockSource) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *BlockSource) UnmarshalJSON(data []byte) error {
	var reasonStr string
	if err := json.Unmarshal(data, &reasonStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(reasonStr))

	switch status {
	case "DISPOSITION":
		*s = DISPOSITION
	case "VOICE_ANALYTICS":
		*s = VOICE_ANALYTICS
	case "AUDIT":
		*s = AUDIT
	case "CLIENT":
		*s = CLIENT
	default:
		return fmt.Errorf("invalid block reason for value: %s", reasonStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s BlockSource) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *BlockSource) Scan(value interface{}) error {
	reasonStr, ok := value.([]byte)
	if !ok {
		return fmt.Errorf("invalid reason for value: %v", value)
	}

	source := strings.TrimSpace(strings.ToUpper(string(reasonStr)))

	switch source {
	case "DISPOSITION":
		*s = DISPOSITION
	case "VOICE_ANALYTICS":
		*s = VOICE_ANALYTICS
	case "AUDIT":
		*s = AUDIT
	case "CLIENT":
		*s = CLIENT
	default:
		return fmt.Errorf("invalid block source for value: %s", source)
	}

	return nil
}

func StringToBlockSourceEnum(s string) (BlockSource, error) {
	switch strings.ToUpper(s) {
	case "DISPOSITION":
		return DISPOSITION, nil
	case "VOICE_ANALYTICS":
		return VOICE_ANALYTICS, nil
	case "AUDIT":
		return AUDIT, nil
	case "CLIENT":
		return CLIENT, nil
	default:
		// Return an error if the input string doesn't match any enum value
		return 0, fmt.Errorf("invalid block reason: %s", s)
	}
}
