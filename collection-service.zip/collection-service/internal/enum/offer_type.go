package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type OfferType int

const (
	_ OfferType = iota
	DUES_WAIVER
	SETTLEMENT
)

// String - Creating common behavior - give the type a String function
func (s OfferType) String() string {
	return [...]string{"", "DUES_WAIVER", "SETTLEMENT"}[s]
}

func (s OfferType) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *OfferType) UnmarshalJSON(data []byte) error {
	var OfferTypeStr string
	if err := json.Unmarshal(data, &OfferTypeStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(OfferTypeStr))

	*s = StringToOfferType(status)

	if *s == OfferType(0) {
		return fmt.Errorf("invalid offer type value: %s", OfferTypeStr)
	}

	return nil
}

func StringToOfferType(s string) OfferType {
	switch strings.ToUpper(s) {
	case "DUES_WAIVER":
		return DUES_WAIVER
	case "SETTLEMENT":
		return SETTLEMENT
	default:
		return OfferType(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s OfferType) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *OfferType) Scan(value interface{}) error {
	OfferTypeStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid Offer Type value: %s", OfferTypeStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(OfferTypeStr)))

	*s = StringToOfferType(status)

	if *s == OfferType(0) {
		return fmt.Errorf("invalid offer type value: %s", OfferTypeStr)
	}

	return nil
}
