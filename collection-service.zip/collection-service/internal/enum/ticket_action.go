package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type TicketAction int

const (
	_ TicketAction = iota
	TICKET_SET_BLOCKING_DATE
	TICKET_PERMANENT_BLOCK
	TICKET_UNBLOCK
)

// String - Creating common behavior - give the type a String function
func (s TicketAction) String() string {
	return [...]string{"", "SET_BLOCKING_DATE", "PERMANENT_BLOCK", "UNBLOCK"}[s]
}

func (s TicketAction) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *TicketAction) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "SET_BLOCKING_DATE":
		*s = TICKET_SET_BLOCKING_DATE
	case "PERMANENT_BLOCK":
		*s = TICKET_PERMANENT_BLOCK
	case "UNBLOCK":
		*s = TICKET_UNBLOCK
	}

	return nil
}

func StringToTicketAction(s string) TicketAction {
	switch strings.ToUpper(s) {
	case "SET_BLOCKING_DATE":
		return TICKET_SET_BLOCKING_DATE
	case "PERMANENT_BLOCK":
		return TICKET_PERMANENT_BLOCK
	case "UNBLOCK":
		return TICKET_UNBLOCK
	default:
		// Return an error if the input string doesn't match any enum value
		return TicketAction(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s TicketAction) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *TicketAction) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid ticket action value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "SET_BLOCKING_DATE":
		*s = TICKET_SET_BLOCKING_DATE
	case "PERMANENT_BLOCK":
		*s = TICKET_PERMANENT_BLOCK
	case "UNBLOCK":
		*s = TICKET_UNBLOCK
	default:
		*s = TicketAction(0)
		//return fmt.Errorf("invalid ticket action value: %s", statusStr)
	}

	return nil
}
