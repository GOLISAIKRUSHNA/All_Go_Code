package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type Object int

const (
	_ Object = iota
	OBJECT_CUSTOMER
	OBJECT_AGENT
)

// String - Creating common behavior give the type a String function
func (s Object) String() string {
	return [...]string{"", "CUSTOMER", "AGENT"}[s]
}

func (s Object) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *Object) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	*s = StringToPaymentObject(status)

	if *s == Object(0) {
		return fmt.Errorf("invalid Object value: %s", statusStr)
	}

	return nil
}

func StringToPaymentObject(s string) Object {
	switch strings.ToUpper(s) {
	case OBJECT_CUSTOMER.String():
		return OBJECT_CUSTOMER
	case OBJECT_AGENT.String():
		return OBJECT_AGENT
	default:
		// Return an error if the input string doesn't match any enum value
		return Object(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s Object) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *Object) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid status value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	*s = StringToPaymentObject(status)

	if *s == Object(0) {
		return fmt.Errorf("invalid Object value: %s", statusStr)
	}

	return nil
}
