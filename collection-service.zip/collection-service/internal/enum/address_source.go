package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type AddressSource int

const (
	_ AddressSource = iota
	SELF_DECLARED
	BUREAU
	AADHAAR
	KYC
	ALTERNATE_DATA_SOURCE
)

// String - Creating common behavior - give the type a String function
func (a AddressSource) String() string {
	return [...]string{"", "SELF_DECLARED", "BUREAU", "AADHAAR", "CKYC", "ALTERNATE_DATA_SOURCE"}[a]
}

func (a AddressSource) MarshalJSON() ([]byte, error) {
	return json.Marshal(a.String())
}
func (a *AddressSource) UnmarshalJSON(data []byte) error {
	var addressSourceStr string
	if err := json.Unmarshal(data, &addressSourceStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(addressSourceStr))

	*a = StringToAddressSource(status)

	if *a == AddressSource(0) {
		return fmt.Errorf("invalid address address source value: %s", addressSourceStr)
	}

	return nil
}

func StringToAddressSource(a string) AddressSource {
	switch strings.ToUpper(a) {
	case "SELF_DECLARED":
		return SELF_DECLARED
	case "BUREAU":
		return BUREAU
	case "AADHAAR":
		return AADHAAR
	case "KYC":
		return KYC
	case "ALTERNATE_DATA_SOURCE":
		return ALTERNATE_DATA_SOURCE

	default:
		return AddressSource(0)
	}
}

// Value - Implementation of valuer for database/sql
func (a AddressSource) Value() (driver.Value, error) {

	return int64(a), nil
}
func (a *AddressSource) Scan(value interface{}) error {
	addressSourceStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid address source value: %s", addressSourceStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(addressSourceStr)))

	*a = StringToAddressSource(status)

	if *a == AddressSource(0) {
		return nil
		//return fmt.Errorf("invalid address source value: %s", addressSourceStr)
	}

	return nil
}
