package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type URLEntity int

const (
	_ URLEntity = iota
	ENTITY_CASE
	ENTITY_LOAN
)

// String - Creating common behavior give the type a String function
func (s URLEntity) String() string {
	return [...]string{"", "CASE", "LOAN"}[s]
}

func (s URLEntity) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *URLEntity) UnmarshalJSON(data []byte) error {
	var URLObjectStr string
	if err := json.Unmarshal(data, &URLObjectStr); err != nil {
		return err
	}

	urlObject := strings.TrimSpace(strings.ToUpper(URLObjectStr))

	*s = StringToURLEntity(urlObject)

	if *s == URLEntity(0) {
		return fmt.Errorf("invalid URLReason value: %s", URLObjectStr)
	}

	return nil
}

func StringToURLEntity(s string) URLEntity {
	switch strings.ToUpper(s) {
	case ENTITY_CASE.String():
		return ENTITY_CASE
	case ENTITY_LOAN.String():
		return ENTITY_LOAN
	default:
		// Return an error if the input string doesn't match any enum value
		return URLEntity(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s URLEntity) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *URLEntity) Scan(value interface{}) error {

	URLObjectStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid URLReason value: %s", URLObjectStr)
	}

	urlObject := strings.TrimSpace(strings.ToUpper(string(URLObjectStr)))

	*s = StringToURLEntity(urlObject)

	if *s == URLEntity(0) {
		return fmt.Errorf("invalid URLReason value: %s", URLObjectStr)
	}

	return nil
}
