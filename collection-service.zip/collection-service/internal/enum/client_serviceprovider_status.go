package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type ClientServiceProviderStatus int

const (
	_ ClientServiceProviderStatus = iota
	STATUS_INACTIVE
	STATUS_ACTIVE
)

// String - Creating common behavior give the type a String function
func (s ClientServiceProviderStatus) String() string {
	return [...]string{"", "INACTIVE", "ACTIVE"}[s]
}

func (s ClientServiceProviderStatus) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *ClientServiceProviderStatus) UnmarshalJSON(data []byte) error {
	var clientServiceProviderStatus string
	if err := json.Unmarshal(data, &clientServiceProviderStatus); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(clientServiceProviderStatus))

	*s = StringToClientServiceProviderStatus(status)

	if *s == ClientServiceProviderStatus(0) {
		return fmt.Errorf("invalid Status value: %s", clientServiceProviderStatus)
	}

	return nil
}

func StringToClientServiceProviderStatus(s string) ClientServiceProviderStatus {
	switch strings.ToUpper(s) {
	case STATUS_INACTIVE.String():
		return STATUS_INACTIVE
	case STATUS_ACTIVE.String():
		return STATUS_ACTIVE
	default:
		// Return an error if the input string doesn't match any enum value
		return ClientServiceProviderStatus(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s ClientServiceProviderStatus) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *ClientServiceProviderStatus) Scan(value interface{}) error {

	clientServiceProviderStatusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid Status value: %s", clientServiceProviderStatusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(clientServiceProviderStatusStr)))

	*s = StringToClientServiceProviderStatus(status)

	if *s == ClientServiceProviderStatus(0) {
		return fmt.Errorf("invalid Status value: %s", clientServiceProviderStatusStr)
	}

	return nil
}
