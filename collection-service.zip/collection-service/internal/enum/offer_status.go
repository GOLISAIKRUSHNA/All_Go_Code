package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type OfferStatus int

const (
	_ OfferStatus = iota
	OFFER_ACTIVE
	OFFER_INACTIVE
)

// String - Creating common behavior give the type a String function
func (s OfferStatus) String() string {
	return [...]string{"", "ACTIVE", "INACTIVE"}[s]
}

func (s OfferStatus) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *OfferStatus) UnmarshalJSON(data []byte) error {
	var offerStatusStr string
	if err := json.Unmarshal(data, &offerStatusStr); err != nil {
		return err
	}

	offerStatus := strings.TrimSpace(strings.ToUpper(offerStatusStr))

	*s = StringToOfferStatus(offerStatus)

	if *s == OfferStatus(0) {
		return fmt.Errorf("invalid Status value: %s", offerStatusStr)
	}

	return nil
}

func StringToOfferStatus(s string) OfferStatus {
	switch strings.ToUpper(s) {
	case OFFER_ACTIVE.String():
		return OFFER_ACTIVE
	case OFFER_INACTIVE.String():
		return OFFER_INACTIVE
	default:
		// Return an error if the input string doesn't match any enum value
		return OfferStatus(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s OfferStatus) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *OfferStatus) Scan(value interface{}) error {

	offerStatusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid Status value: %s", offerStatusStr)
	}

	offerStatus := strings.TrimSpace(strings.ToUpper(string(offerStatusStr)))

	*s = StringToOfferStatus(offerStatus)

	if *s == OfferStatus(0) {
		return fmt.Errorf("invalid Status value: %s", offerStatusStr)
	}

	return nil
}
