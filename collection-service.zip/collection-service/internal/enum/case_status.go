package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type CaseStatus int

const (
	_ CaseStatus = iota
	CASE_INACTIVE
	CASE_ACTIVE
	CASE_WITHDRAWN
	CASE_PAID
)

// String - Creating common behavior - give the type a String function
func (s CaseStatus) String() string {
	return [...]string{"", "INACTIVE", "ACTIVE", "WITHDRAWN", "PAID"}[s]
}

func (s CaseStatus) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *CaseStatus) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "INACTIVE":
		*s = CASE_INACTIVE
	case "ACTIVE":
		*s = CASE_ACTIVE
	case "WITHDRAWN":
		*s = CASE_WITHDRAWN
	case "PAID":
		*s = CASE_PAID

	default:
		return fmt.Errorf("invalid ContactOf value: %s", statusStr)
	}

	return nil
}

func StringToCaseEnum(s string) (CaseStatus, error) {
	switch strings.ToUpper(s) {
	case "INACTIVE":
		return CASE_INACTIVE, nil
	case "ACTIVE":
		return CASE_ACTIVE, nil
	case "WITHDRAWN":
		return CASE_WITHDRAWN, nil
	case "PAID":
		return CASE_PAID, nil
	default:
		// Return an error if the input string doesn't match any enum value
		return 0, fmt.Errorf("invalid status: %s", s)
	}
}

// Value - Implementation of valuer for database/sql
func (s CaseStatus) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *CaseStatus) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid status value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "INACTIVE":
		*s = CASE_INACTIVE
	case "ACTIVE":
		*s = CASE_ACTIVE
	case "WITHDRAWN":
		*s = CASE_WITHDRAWN
	case "PAID":
		*s = CASE_PAID
	default:
		return fmt.Errorf("invalid ContactOf value: %s", statusStr)
	}

	return nil
}
