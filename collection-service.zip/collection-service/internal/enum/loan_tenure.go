package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type LoanTenure int

const (
	_ LoanTenure = iota
	TENURE_MONTHLY
	TENURE_WEEKLY
	TENURE_DAILY
	TENURE_FORTNIGHTLY
	TENURE_BULLET
)

// String - Creating common behavior - give the type a String function
func (s LoanTenure) String() string {
	return [...]string{"", "MONTHLY", "WEEKLY", "DAILY", "FORTNIGHTLY", "BULLET"}[s]
}

func (s LoanTenure) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *LoanTenure) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "MONTHLY":
		*s = TENURE_MONTHLY
	case "WEEKLY":
		*s = TENURE_WEEKLY
	case "DAILY":
		*s = TENURE_DAILY
	case "FORTNIGHTLY":
		*s = TENURE_FORTNIGHTLY
	case "BULLET":
		*s = TENURE_BULLET
	default:
		return fmt.Errorf("invalid tenure type value: %s", statusStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s LoanTenure) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *LoanTenure) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid tenure value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "MONTHLY":
		*s = TENURE_MONTHLY
	case "WEEKLY":
		*s = TENURE_WEEKLY
	case "DAILY":
		*s = TENURE_DAILY
	case "FORTNIGHTLY":
		*s = TENURE_FORTNIGHTLY
	case "BULLET":
		*s = TENURE_BULLET
	default:
		return fmt.Errorf("invalid tenure type value: %s", statusStr)
	}

	return nil
}

func StringToTenureTypeEnum(s string) (LoanTenure, error) {
	switch strings.ToUpper(s) {
	case "MONTHLY":
		return TENURE_MONTHLY, nil
	case "WEEKLY":
		return TENURE_WEEKLY, nil
	case "DAILY":
		return TENURE_DAILY, nil
	case "FORTNIGHTLY":
		return TENURE_FORTNIGHTLY, nil
	case "BULLET":
		return TENURE_BULLET, nil
	default:
		// Return an error if the input string doesn't match any enum value
		return 0, nil
	}
}
