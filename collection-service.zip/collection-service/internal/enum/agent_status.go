package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type Status int

const (
	_ Status = iota
	INACTIVE
	ACTIVE
	SUSPENDED
	TERMINATED
)

// String - Creating common behavior - give the type a String function
func (s Status) String() string {
	return [...]string{"", "INACTIVE", "ACTIVE", "SUSPENDED", "TERMINATED"}[s]
}

func (s Status) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *Status) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "INACTIVE":
		*s = INACTIVE
	case "ACTIVE":
		*s = ACTIVE
	case "SUSPENDED":
		*s = SUSPENDED
	case "TERMINATED":
		*s = TERMINATED
	}

	return nil
}

func StringToStatus(s string) Status {
	switch strings.ToUpper(s) {
	case "INACTIVE":
		return INACTIVE
	case "ACTIVE":
		return ACTIVE
	case "SUSPENDED":
		return SUSPENDED
	case "TERMINATED":
		return TERMINATED
	default:
		// Return an error if the input string doesn't match any enum value
		return Status(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s Status) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *Status) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid status value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "INACTIVE":
		*s = INACTIVE
	case "ACTIVE":
		*s = ACTIVE
	case "SUSPENDED":
		*s = SUSPENDED
	case "TERMINATED":
		*s = TERMINATED
	default:
		return fmt.Errorf("invalid ContactOf value: %s", statusStr)
	}

	return nil
}
