package enum

import (
	"database/sql/driver"
	"encoding/json"
)

// enum('ORG_LEVEL', 'TEAM_LEVEL','SELF_REPORTEE_LEVEL')
type AgentVisibility int

const (
	_ AgentVisibility = iota
	AGENT_VIS_ORG_LEVEL
	AGENT_VIS_TEAM_LEVEL
	AGENT_VIS_SELF_REPORTEE_LEVEL
)

// String - Creating common behavior give the type a String function
func (a AgentVisibility) String() string {
	return [...]string{"", "ORG_LEVEL", "TEAM_LEVEL", "SELF_REPORTEE_LEVEL"}[a]
}

func (a AgentVisibility) MarshalJSON() ([]byte, error) {
	return json.Marshal(a.String())
}

func (a *AgentVisibility) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	*a = StringToAgentVisibility(statusStr)

	return nil
}

func StringToAgentVisibility(s string) AgentVisibility {
	switch s {
	case AGENT_VIS_ORG_LEVEL.String():
		return AGENT_VIS_ORG_LEVEL
	case AGENT_VIS_TEAM_LEVEL.String():
		return AGENT_VIS_TEAM_LEVEL
	case AGENT_VIS_SELF_REPORTEE_LEVEL.String():
		return AGENT_VIS_SELF_REPORTEE_LEVEL
	default:
		// Return an error if the input string doesn't match any enum value
		return AgentVisibility(0)
	}
}

// Value - Implementation of valuer for database/sql
func (a AgentVisibility) Value() (driver.Value, error) {
	return int64(a), nil
}

func (a *AgentVisibility) Scan(value interface{}) error {
	statusStr, ok := value.([]uint8)
	if !ok {
		return nil
	}

	*a = StringToAgentVisibility(string(statusStr))

	return nil
}
