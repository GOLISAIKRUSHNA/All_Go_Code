package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type ActivationSource int

const (
	_ ActivationSource = iota
	SRC_CSAT
	SRC_INGRESS
	SRC_API
)

// String - Creating common behavior - give the type a String function
func (s ActivationSource) String() string {
	return [...]string{"", "CSAT", "INGRESS", "API"}[s]
}

func (s ActivationSource) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *ActivationSource) UnmarshalJSON(data []byte) error {
	var ActivationSourceStr string
	if err := json.Unmarshal(data, &ActivationSourceStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(ActivationSourceStr))

	*s = StringToActivationSource(status)

	if *s == ActivationSource(0) {
		return fmt.Errorf("invalid activation source value: %s", ActivationSourceStr)
	}

	return nil
}

func StringToActivationSource(s string) ActivationSource {
	switch strings.ToUpper(s) {
	case "CSAT":
		return SRC_CSAT
	case "INGRESS":
		return SRC_INGRESS
	case "API":
		return SRC_API
	default:
		return ActivationSource(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s ActivationSource) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *ActivationSource) Scan(value interface{}) error {
	ActivationSourceStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid activation source value: %s", ActivationSourceStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(ActivationSourceStr)))

	*s = StringToActivationSource(status)

	if *s == ActivationSource(0) {
		return fmt.Errorf("invalid Activation Source value: %s", ActivationSourceStr)
	}

	return nil
}
