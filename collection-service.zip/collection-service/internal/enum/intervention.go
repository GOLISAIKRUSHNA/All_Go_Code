package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type Intervention int

const (
	_ Intervention = iota
	INTERVENTION_CALLING
	INTERVENTION_FIELD
	INTERVENTION_AUDIT
	INTREVENTION_CSAT
)

// String - Creating common behavior - give the type a String function
func (s Intervention) String() string {
	return [...]string{"", "CALLING", "FIELD", "AUDIT", "CSAT"}[s]
}

func (s Intervention) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *Intervention) UnmarshalJSON(data []byte) error {
	var reasonStr string
	if err := json.Unmarshal(data, &reasonStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(reasonStr))

	switch status {
	case "CALLING":
		*s = INTERVENTION_CALLING
	case "FIELD":
		*s = INTERVENTION_FIELD
	case "AUDIT":
		*s = INTERVENTION_AUDIT
	case "CSAT":
		*s = INTREVENTION_CSAT
	default:
		*s = 0
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s Intervention) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *Intervention) Scan(value interface{}) error {
	reasonStr, ok := value.([]byte)
	if !ok {
		return fmt.Errorf("invalid intervention for value: %v", value)
	}

	source := strings.TrimSpace(strings.ToUpper(string(reasonStr)))

	switch source {
	case "CALLING":
		*s = INTERVENTION_CALLING
	case "FIELD":
		*s = INTERVENTION_FIELD
	case "AUDIT":
		*s = INTERVENTION_AUDIT
	case "CSAT":
		*s = INTREVENTION_CSAT
	default:
		*s = 0
	}

	return nil
}

func StringToInterventionEnum(s string) (Intervention, error) {
	switch strings.ToUpper(s) {
	case "CALLING":
		return INTERVENTION_CALLING, nil
	case "FIELD":
		return INTERVENTION_FIELD, nil
	case "AUDIT":
		return INTERVENTION_AUDIT, nil
	case "CSAT":
		return INTREVENTION_CSAT, nil

	default:
		// Return an error if the input string doesn't match any enum value
		return 0, fmt.Errorf("invalid intervention: %s", s)
	}
}
