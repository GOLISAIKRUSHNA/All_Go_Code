package enum

import (
	"database/sql/driver"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
)

type ContactType int

const (
	_ ContactType = iota
	APPLICANT
	CO_APPLICANT
	GUARANTOR
	REFERENCE
)

// String - Creating common behavior - give the type a String function
func (s ContactType) String() string {
	return [...]string{"", "APPLICANT", "CO_APPLICANT", "GUARANTOR", "REFERENCE"}[s]
}

func (s ContactType) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *ContactType) UnmarshalJSON(data []byte) error {
	var contactTypeStr string
	if err := json.Unmarshal(data, &contactTypeStr); err != nil {
		return err
	}

	if contactTypeStr == "" {
		*s = APPLICANT
		return nil
	}

	contactType := strings.TrimSpace(strings.ToUpper(contactTypeStr))

	*s = StringToContactType(contactType)

	if *s == ContactType(0) {
		panic(errors.New("my-custom-error"))
	}
	return nil
}

func StringToContactType(s string) ContactType {
	switch strings.ToUpper(s) {
	case APPLICANT.String():
		return APPLICANT
	case CO_APPLICANT.String():
		return CO_APPLICANT
	case GUARANTOR.String():
		return GUARANTOR
	case REFERENCE.String():
		return REFERENCE

	default:
		// Return an error if the input string doesn't match any enum value
		return ContactType(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s ContactType) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *ContactType) Scan(value interface{}) error {
	contactTypeStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid contact_type: %s", contactTypeStr)
	}

	contactType := strings.TrimSpace(strings.ToUpper(string(contactTypeStr)))

	*s = StringToContactType(contactType)

	if *s == ContactType(0) {
		// If the database value doesn't match any enum value, default to APPLICANT
		*s = APPLICANT
	}

	return nil
}
