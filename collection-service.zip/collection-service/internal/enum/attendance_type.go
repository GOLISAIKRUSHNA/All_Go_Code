package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type AttendanceType int

const (
	_ AttendanceType = iota
	HALF_DAY
	FULL_DAY
)

// String - Creating common behavior give the type a String function
func (s AttendanceType) String() string {
	return [...]string{"", "HALF_DAY", "FULL_DAY"}[s]
}

func (s AttendanceType) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *AttendanceType) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))
	*s, _ = StringToAttendanceTypeEnum(status)
	return nil
}

// Value - Implementation of valuer for database/sql
func (s AttendanceType) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *AttendanceType) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid attendance type value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "HALF_DAY":
		*s = HALF_DAY
	case "FULL_DAY":
		*s = FULL_DAY
	default:
		return fmt.Errorf("invalid attendance type value: %s", statusStr)
	}

	return nil
}

func StringToAttendanceTypeEnum(s string) (AttendanceType, error) {
	switch strings.ToUpper(s) {
	case "HALF_DAY":
		return HALF_DAY, nil
	case "FULL_DAY":
		return FULL_DAY, nil
	default:
		// Return an error if the input string doesn't match any enum value
		return 0, fmt.Errorf("invalid attendance type: %s", s)
	}
}
