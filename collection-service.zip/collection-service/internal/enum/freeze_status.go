package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type FreezeStatus int

const (
	_ FreezeStatus = iota
	FREEZE
	UNFREEZE
)

func (s FreezeStatus) String() string {
	return [...]string{"", "FREEZE", "UNFREEZE"}[s]
}

func (s FreezeStatus) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *FreezeStatus) UnmarshalJSON(data []byte) error {
	var dispositionTypeStr string
	if err := json.Unmarshal(data, &dispositionTypeStr); err != nil {
		return err
	}

	freezeStatus := strings.TrimSpace(strings.ToUpper(dispositionTypeStr))
	switch freezeStatus {
	case "FREEZE":
		*s = FREEZE
	case "UNFREEZE":
		*s = UNFREEZE
	default:
		return nil
	}
	return nil
}

// Value - Implementation of valuer for database/sql
func (s FreezeStatus) Value() (driver.Value, error) {
	return int64(s), nil
}

func (s *FreezeStatus) Scan(value interface{}) error {
	freezeStatusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid freeze_status value: %s", freezeStatusStr)
	}

	freezeStatus := strings.TrimSpace(strings.ToUpper(string(freezeStatusStr)))
	*s = StringToFreezeStatus(freezeStatus)

	if *s == FreezeStatus(0) {
		return nil
		//return fmt.Errorf("invalid address medi value: %s", addressQualityStr)
	}
	return nil
}

func StringToFreezeStatus(freezeStatusStr string) FreezeStatus {
	freezeStatus := strings.TrimSpace(strings.ToUpper(freezeStatusStr))

	switch freezeStatus {
	case "FREEZE":
		return FREEZE
	case "UNFREEZE":
		return UNFREEZE
	default:
		return FreezeStatus(0)
	}
}
