package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type Bucket int

const (
	_ Bucket = iota
	BUCKET_X
	BUCKET_1
	BUCKET_2
	BUCKET_3
	BUCKET_4
	PRE_DEL
)

// String - Creating common behavior - give the type a String function
func (s Bucket) String() string {
	return [...]string{"", "BUCKET_X", "BUCKET_1", "BUCKET_2", "BUCKET_3", "BUCKET_4", "PRE_DEL"}[s]
}

func (s Bucket) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *Bucket) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "BUCKET_X":
		*s = BUCKET_X
	case "BUCKET_1":
		*s = BUCKET_1
	case "BUCKET_2":
		*s = BUCKET_2
	case "BUCKET_3":
		*s = BUCKET_3
	case "BUCKET_4":
		*s = BUCKET_4
	case "PRE_DEL":
		*s = PRE_DEL
	default:
		return fmt.Errorf("invalid bucket for value: %s", statusStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s Bucket) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *Bucket) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid collection for value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "BUCKET_X":
		*s = BUCKET_X
	case "BUCKET_1":
		*s = BUCKET_1
	case "BUCKET_2":
		*s = BUCKET_2
	case "BUCKET_3":
		*s = BUCKET_3
	case "BUCKET_4":
		*s = BUCKET_4
	case "PRE_DEL":
		*s = PRE_DEL
	default:
		return nil
		//return fmt.Errorf("invalid bucket for value: %s", statusStr)
	}

	return nil
}

func StringToBucketEnum(s string) (Bucket, error) {
	switch strings.ToUpper(s) {
	case "BUCKET_X":
		return BUCKET_X, nil
	case "BUCKET_1":
		return BUCKET_1, nil
	case "BUCKET_2":
		return BUCKET_2, nil
	case "BUCKET_3":
		return BUCKET_3, nil
	case "BUCKET_4":
		return BUCKET_4, nil
	case "PRE_DEL":
		return PRE_DEL, nil
	default:
		// Return an error if the input string doesn't match any enum value
		return 0, fmt.Errorf("invalid bucket: %s", s)
	}
}
