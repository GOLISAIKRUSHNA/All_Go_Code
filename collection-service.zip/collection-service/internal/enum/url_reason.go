package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type URLReason int

const (
	_ URLReason = iota
	REASON_CASE_PAYMENT
	REASON_LOAN_PAYMENT
)

// String - Creating common behavior give the type a String function
func (s URLReason) String() string {
	return [...]string{"", "CASE_PAYMENT", "LOAN_PAYMENT"}[s]
}

func (s URLReason) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *URLReason) UnmarshalJSON(data []byte) error {
	var URLObjectStr string
	if err := json.Unmarshal(data, &URLObjectStr); err != nil {
		return err
	}

	urlObject := strings.TrimSpace(strings.ToUpper(URLObjectStr))

	*s = StringToURLReason(urlObject)

	if *s == URLReason(0) {
		return fmt.Errorf("invalid URLReason value: %s", URLObjectStr)
	}

	return nil
}

func StringToURLReason(s string) URLReason {
	switch strings.ToUpper(s) {
	case REASON_CASE_PAYMENT.String():
		return REASON_CASE_PAYMENT
	case REASON_LOAN_PAYMENT.String():
		return REASON_LOAN_PAYMENT
	default:
		// Return an error if the input string doesn't match any enum value
		return URLReason(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s URLReason) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *URLReason) Scan(value interface{}) error {

	URLObjectStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid URLReason value: %s", URLObjectStr)
	}

	urlObject := strings.TrimSpace(strings.ToUpper(string(URLObjectStr)))

	*s = StringToURLReason(urlObject)

	if *s == URLReason(0) {
		return fmt.Errorf("invalid URLReason value: %s", URLObjectStr)
	}

	return nil
}
