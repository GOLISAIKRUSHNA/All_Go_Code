package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type ClientUserRole int

const (
	_ ClientUserRole = iota
	CLIENT_USER_ROLE_OWNER
	CLIENT_USER_ROLE_ADMIN

	CLIENT_USER_ROLE_OPERATIONS_MANAGER
	CLIENT_USER_ROLE_UPLOADS_MANAGER
	CLIENT_USER_ROLE_REPORTS_MANAGER
	CLIENT_USER_ROLE_MEMBER
)

// String - Creating common behavior give the type a String function
func (a ClientUserRole) String() string {
	return [...]string{"", "OWNER", "ADMIN", "OPERATIONS_MANAGER", "UPLOADS_MANAGER", "REPORTS_MANAGER", "MEMBER"}[a]
}

func (a ClientUserRole) MarshalJSON() ([]byte, error) {
	return json.Marshal(a.String())
}

func (a *ClientUserRole) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	*a = StringToClientUserRole(statusStr)

	return nil
}

func StringToClientUserRole(s string) ClientUserRole {
	switch s {
	case CLIENT_USER_ROLE_OWNER.String():
		return CLIENT_USER_ROLE_OWNER
	case CLIENT_USER_ROLE_ADMIN.String():
		return CLIENT_USER_ROLE_ADMIN
	case CLIENT_USER_ROLE_OPERATIONS_MANAGER.String():
		return CLIENT_USER_ROLE_OPERATIONS_MANAGER
	case CLIENT_USER_ROLE_UPLOADS_MANAGER.String():
		return CLIENT_USER_ROLE_UPLOADS_MANAGER
	case CLIENT_USER_ROLE_REPORTS_MANAGER.String():
		return CLIENT_USER_ROLE_REPORTS_MANAGER
	case CLIENT_USER_ROLE_MEMBER.String():
		return CLIENT_USER_ROLE_MEMBER
	default:
		// Return an error if the input string doesn't match any enum value
		return ClientUserRole(0)
	}
}

// Value - Implementation of valuer for database/sql
func (a ClientUserRole) Value() (driver.Value, error) {
	return int64(a), nil
}

func (a *ClientUserRole) Scan(value interface{}) error {
	clientUserRoleStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid client user role value: %s", clientUserRoleStr)
	}

	clientUserRole := strings.TrimSpace(strings.ToUpper(string(clientUserRoleStr)))

	*a = StringToClientUserRole(clientUserRole)

	return nil
}
