package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type WaiverType int

const (
	_ WaiverType = iota
	FLAT
	PERCENTAGE
)

// String - Creating common behavior - give the type a String function
func (s WaiverType) String() string {
	return [...]string{"", "FLAT", "PERCENTAGE"}[s]
}

func (s WaiverType) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *WaiverType) UnmarshalJSON(data []byte) error {
	var WaiverTypeStr string
	if err := json.Unmarshal(data, &WaiverTypeStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(WaiverTypeStr))

	*s = StringToWaiverType(status)

	return nil
}

func StringToWaiverType(s string) WaiverType {
	switch strings.ToUpper(s) {
	case "FLAT":
		return FLAT
	case "PERCENTAGE":
		return PERCENTAGE
	default:
		return WaiverType(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s WaiverType) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *WaiverType) Scan(value interface{}) error {
	WaiverTypeStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid waiver Type value: %s", WaiverTypeStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(WaiverTypeStr)))

	*s = StringToWaiverType(status)

	return nil
}
