package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

// enum('ORG_LEVEL', 'TEAM_LEVEL')
type ClientUserVisibility int

const (
	_ ClientUserVisibility = iota
	CLIENT_USER_VISIBILITY_ORG_LEVEL
	CLIENT_USER_VISIBILITY_TEAM_LEVEL
)

// String - Creating common behavior give the type a String function
func (s ClientUserVisibility) String() string {
	return [...]string{"", "ORG_LEVEL", "TEAM_LEVEL"}[s]
}

func (s ClientUserVisibility) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *ClientUserVisibility) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	*s = StringToClientUserVisibility(statusStr)

	return nil
}

func StringToClientUserVisibility(s string) ClientUserVisibility {
	switch s {
	case CLIENT_USER_VISIBILITY_ORG_LEVEL.String():
		return CLIENT_USER_VISIBILITY_ORG_LEVEL
	case CLIENT_USER_VISIBILITY_TEAM_LEVEL.String():
		return CLIENT_USER_VISIBILITY_TEAM_LEVEL
	default:
		// Return an error if the input string doesn't match any enum value
		return ClientUserVisibility(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s *ClientUserVisibility) Value() (driver.Value, error) {
	return int64(*s), nil
}

func (s *ClientUserVisibility) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid client user visibility value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	*s = StringToClientUserVisibility(status)

	return nil
}
