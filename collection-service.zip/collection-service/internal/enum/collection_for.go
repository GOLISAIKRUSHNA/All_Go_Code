package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type CollectionFor int

const (
	_ CollectionFor = iota
	FOR_TOTAL_DUE
	FOR_TOTAL_OUTSTANDING
)

// String - Creating common behavior - give the type a String function
func (s CollectionFor) String() string {
	return [...]string{"", "TOTAL_DUE", "TOTAL_OUTSTANDING"}[s]
}

func (s CollectionFor) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *CollectionFor) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "TOTAL_DUE":
		*s = FOR_TOTAL_DUE
	case "TOTAL_OUTSTANDING":
		*s = FOR_TOTAL_OUTSTANDING
	default:
		return fmt.Errorf("invalid collection for value: %s", statusStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s CollectionFor) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *CollectionFor) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid collection for value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "TOTAL_DUE":
		*s = FOR_TOTAL_DUE
	case "TOTAL_OUTSTANDING":
		*s = FOR_TOTAL_OUTSTANDING
	default:
		return nil
	}

	return nil
}
