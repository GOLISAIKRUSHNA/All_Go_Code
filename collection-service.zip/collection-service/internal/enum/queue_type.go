package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type QueueType int

const (
	_ QueueType = iota
	QUEUE_CSAT
)

// String - Creating common behavior - give the type a String function
func (s QueueType) String() string {
	return [...]string{"", "CSAT"}[s]
}

func (s QueueType) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *QueueType) UnmarshalJSON(data []byte) error {
	var QueueTypeStr string
	if err := json.Unmarshal(data, &QueueTypeStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(QueueTypeStr))

	*s = StringToQueueType(status)

	if *s == QueueType(0) {
		return fmt.Errorf("invalid queue type value: %s", QueueTypeStr)
	}

	return nil
}

func StringToQueueType(s string) QueueType {
	switch strings.ToUpper(s) {
	case "CSAT":
		return QUEUE_CSAT
	default:
		return QueueType(0)
	}
}

// Value - Implementation of valuer for database/sql
func (s QueueType) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *QueueType) Scan(value interface{}) error {
	QueueTypeStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid queue type value: %s", QueueTypeStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(QueueTypeStr)))

	*s = StringToQueueType(status)

	if *s == QueueType(0) {
		return fmt.Errorf("invalid queue type value: %s", QueueTypeStr)
	}

	return nil
}
