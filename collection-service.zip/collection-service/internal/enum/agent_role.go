package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type AgentRole int

const (
	_ AgentRole = iota
	AGENT_ROLE_OWNER
	AGENT_ROLE_ADMIN
	AGENT_ROLE_MANAGER
	AGENT_ROLE_UPLOADS_MANAGER
	AGENT_ROLE_REPORTS_MANAGER
	AGENT_ROLE_CALLER
	AGENT_ROLE_CALLER_TL
	AGENT_ROLE_CALLING_MANAGER
	AGENT_ROLE_FIELD_AGENT
	AGENT_ROLE_FIELD_TL
	AGENT_ROLE_FIELD_MANAGER
	AGENT_ROLE_AUDITOR
	AGENT_ROLE_AUDITOR_TL
	AGENT_ROLE_AUDITOR_MANAGER
	AGENT_ROLE_CSAT_CALLER
	AGENT_ROLE_CSAT_TL
	AGENT_ROLE_CSAT_MANAGER
)

func (a AgentRole) String() string {
	return [...]string{"", "OWNER", "ADMIN", "MANAGER", "UPLOADS_MANAGER", "REPORTS_MANAGER", "CALLER", "CALLER_TL", "CALLING_MANAGER", "FIELD_AGENT", "FIELD_TL", "FIELD_MANAGER", "AUDITOR", "AUDITOR_TL", "AUDITOR_MANAGER", "CSAT_CALLER", "CSAT_TL", "CSAT_MANAGER"}[a]
}

func (a AgentRole) MarshalJSON() ([]byte, error) {
	return json.Marshal(a.String())
}

func (a *AgentRole) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := StringToAgentRole(statusStr)

	*a = status

	return nil
}

func StringToAgentRole(s string) AgentRole {
	switch s {
	case AGENT_ROLE_OWNER.String():
		return AGENT_ROLE_OWNER
	case AGENT_ROLE_ADMIN.String():
		return AGENT_ROLE_ADMIN
	case AGENT_ROLE_MANAGER.String():
		return AGENT_ROLE_MANAGER
	case AGENT_ROLE_UPLOADS_MANAGER.String():
		return AGENT_ROLE_UPLOADS_MANAGER
	case AGENT_ROLE_REPORTS_MANAGER.String():
		return AGENT_ROLE_REPORTS_MANAGER
	case AGENT_ROLE_CALLER.String():
		return AGENT_ROLE_CALLER
	case AGENT_ROLE_CALLER_TL.String():
		return AGENT_ROLE_CALLER_TL
	case AGENT_ROLE_CALLING_MANAGER.String():
		return AGENT_ROLE_CALLING_MANAGER
	case AGENT_ROLE_FIELD_AGENT.String():
		return AGENT_ROLE_FIELD_AGENT
	case AGENT_ROLE_FIELD_TL.String():
		return AGENT_ROLE_FIELD_TL
	case AGENT_ROLE_FIELD_MANAGER.String():
		return AGENT_ROLE_FIELD_MANAGER
	case AGENT_ROLE_AUDITOR.String():
		return AGENT_ROLE_AUDITOR
	case AGENT_ROLE_AUDITOR_TL.String():
		return AGENT_ROLE_AUDITOR_TL
	case AGENT_ROLE_AUDITOR_MANAGER.String():
		return AGENT_ROLE_AUDITOR_MANAGER
	case AGENT_ROLE_CSAT_CALLER.String():
		return AGENT_ROLE_CSAT_CALLER
	case AGENT_ROLE_CSAT_TL.String():
		return AGENT_ROLE_CSAT_TL
	case AGENT_ROLE_CSAT_MANAGER.String():
		return AGENT_ROLE_CSAT_MANAGER
	default:
		return AgentRole(0)
	}
}

func (s AgentRole) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *AgentRole) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid Agent role value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	*s = StringToAgentRole(status)

	if *s == AgentRole(0) {
		return nil
	}

	return nil
}
