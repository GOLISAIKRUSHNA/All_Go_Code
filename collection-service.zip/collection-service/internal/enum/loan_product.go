package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type LoanProduct int

// PL','HL','CC','AL','GL','LAP','BL
const (
	_ LoanProduct = iota
	PRODUCT_PL
	PRODUCT_HL
	PRODUCT_CC
	PRODUCT_AL
	PRODUCT_GL
	PRODUCT_LAP
	PRODUCT_BL
)

// String - Creating common behavior - give the type a String function
func (s LoanProduct) String() string {
	return [...]string{"", "PL", "HL", "CC", "AL", "GL", "LAP", "BL"}[s]
}

func (s LoanProduct) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *LoanProduct) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "PL":
		*s = PRODUCT_PL
	case "HL":
		*s = PRODUCT_HL
	case "CC":
		*s = PRODUCT_CC
	case "AL":
		*s = PRODUCT_AL
	case "GL":
		*s = PRODUCT_GL
	case "LAP":
		*s = PRODUCT_LAP
	case "BL":
		*s = PRODUCT_BL
	default:
		return fmt.Errorf("invalid product type value: %s", statusStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s LoanProduct) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *LoanProduct) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid product value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch status {
	case "PL":
		*s = PRODUCT_PL
	case "HL":
		*s = PRODUCT_HL
	case "CC":
		*s = PRODUCT_CC
	case "AL":
		*s = PRODUCT_AL
	case "GL":
		*s = PRODUCT_GL
	case "LAP":
		*s = PRODUCT_LAP
	case "BL":
		*s = PRODUCT_BL
	default:
		return fmt.Errorf("invalid product type value: %s", statusStr)
	}

	return nil
}

func StringToLoanProductEnum(s string) (LoanProduct, error) {
	switch strings.ToUpper(s) {
	case "PL":
		return PRODUCT_PL, nil
	case "HL":
		return PRODUCT_HL, nil
	case "CC":
		return PRODUCT_CC, nil
	case "AL":
		return PRODUCT_AL, nil
	case "GL":
		return PRODUCT_GL, nil
	case "LAP":
		return PRODUCT_LAP, nil
	case "BL":
		return PRODUCT_BL, nil
	default:
		// Return an error if the input string doesn't match any enum value
		return 0, fmt.Errorf("invalid produt: %s", s)
	}
}
