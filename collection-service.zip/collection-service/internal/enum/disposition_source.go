package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type Source int

const (
	_ Source = iota
	TELECALLING
	FIELD
	AUTODIALER
	SYSTEM
	FIELD_TELECALLING
)

func (s Source) String() string {
	return [...]string{"", "TELECALLING", "FIELD", "AUTODIALER", "SYSTEM", "FIELD_TELECALLING"}[s]
}

func (s Source) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *Source) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}
	source := strings.TrimSpace(strings.ToUpper(statusStr))
	switch source {
	case "TELECALLING":
		*s = TELECALLING
	case "FIELD":
		*s = FIELD
	case "AUTODIALER":
		*s = AUTODIALER
	case "SYSTEM":
		*s = SYSTEM
	case "FIELD_TELECALLING":
		*s = FIELD_TELECALLING
	default:
		return fmt.Errorf("invalid source value: %s", statusStr)
	}

	fmt.Printf("Source after unmarshal: %s\n", s.String()) // Debug statement
	return nil
}

// Value - Implementation of valuer for database/sql
func (s Source) Value() (driver.Value, error) {
	return int64(s), nil
}

func (s *Source) Scan(value interface{}) error {
	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid status value: %s", statusStr)
	}

	source := strings.TrimSpace(strings.ToUpper(string(statusStr)))

	switch source {
	case "TELECALLING":
		*s = TELECALLING
	case "FIELD":
		*s = FIELD
	case "AUTODIALER":
		*s = AUTODIALER
	case "SYSTEM":
		*s = SYSTEM
	case "FIELD_TELECALLING":
		*s = FIELD_TELECALLING
	default:
		return fmt.Errorf("invalid ContactOf value: %s", statusStr)
	}

	return nil
}
