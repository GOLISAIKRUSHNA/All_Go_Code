package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type HierarchyScope int

const (
	_                  HierarchyScope = iota
	OWN_SELF                          = 1
	ALL_REPORTEES                     = 2
	DIRECT_REPORTEES                  = 3
	INDIRECT_REPORTEES                = 4
	DIRECT_MANAGER                    = 5
	ALL_MANAGERS                      = 6
)

// String - Creating common behavior give the type a String function
func (s HierarchyScope) String() string {
	return [...]string{"", "OWN_SELF", "ALL_REPORTEES", "DIRECT_REPORTEES", "INDIRECT_REPORTEES", "DIRECT_MANAGER", "ALL_MANAGERS"}[s]
}

func (s HierarchyScope) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *HierarchyScope) UnmarshalJSON(data []byte) error {
	var statusStr string
	if err := json.Unmarshal(data, &statusStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(statusStr))

	switch status {
	case "OWN_SELF":
		*s = OWN_SELF
	case "ALL_REPORTEES":
		*s = ALL_REPORTEES
	case "DIRECT_REPORTEES":
		*s = DIRECT_REPORTEES
	case "INDIRECT_REPORTEES":
		*s = INDIRECT_REPORTEES
	case "DIRECT_MANAGER":
		*s = DIRECT_MANAGER
	case "ALL_MANAGERS":
		*s = ALL_MANAGERS

	default:
		return fmt.Errorf("invalid Hierarchy Scope value: %s", statusStr)
	}

	return nil
}

// Value - Implementation of valuer for database/sql
func (s HierarchyScope) Value() (driver.Value, error) {

	return int64(s), nil
}
func (s *HierarchyScope) Scan(value interface{}) error {

	statusStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid Hierarchy Scope value: %s", statusStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(statusStr)))
	*s = StringToHierarchyScopeEnum(status)

	return nil
}

func StringToHierarchyScopeEnum(s string) HierarchyScope {
	switch strings.ToUpper(s) {
	case "OWN_SELF":
		return OWN_SELF
	case "ALL_REPORTEES":
		return ALL_REPORTEES
	case "DIRECT_REPORTEES":
		return DIRECT_REPORTEES
	case "INDIRECT_REPORTEES":
		return INDIRECT_REPORTEES
	case "DIRECT_MANAGER":
		return DIRECT_MANAGER
	case "ALL_MANAGERS":
		return ALL_MANAGERS

	default:
		return HierarchyScope(0)

	}
}
