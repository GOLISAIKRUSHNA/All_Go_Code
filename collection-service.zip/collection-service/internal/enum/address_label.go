package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type AddressLabel int

const (
	_ AddressLabel = iota
	HOME
	OFFICE
	OTHERS
)

// String - Creating common behavior - give the type a String function
func (a AddressLabel) String() string {
	return [...]string{"", "HOME", "OFFICE", "OTHERS"}[a]
}

func (a AddressLabel) MarshalJSON() ([]byte, error) {
	return json.Marshal(a.String())
}
func (a *AddressLabel) UnmarshalJSON(data []byte) error {
	var addressLableStr string
	if err := json.Unmarshal(data, &addressLableStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(addressLableStr))

	*a = StringToAddressLabel(status)

	if *a == AddressLabel(0) {
		return fmt.Errorf("invalid address label value: %s", addressLableStr)
	}

	return nil
}

func StringToAddressLabel(a string) AddressLabel {
	switch strings.ToUpper(a) {
	case "HOME":
		return HOME
	case "OFFICE":
		return OFFICE
	case "OTHERS":
		return OTHERS
	default:
		return AddressLabel(0)
	}
}

// Value - Implementation of valuer for database/sql
func (a AddressLabel) Value() (driver.Value, error) {

	return int64(a), nil
}
func (a *AddressLabel) Scan(value interface{}) error {
	addressLabelStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid address label value: %s", addressLabelStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(addressLabelStr)))

	*a = StringToAddressLabel(status)

	if *a == AddressLabel(0) {
		return nil
	}

	return nil
}
