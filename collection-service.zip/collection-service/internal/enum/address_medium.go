package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type AddressMedium int

const (
	_ AddressMedium = iota
	FOS_APP
	CLIENT_DATA_INGRESS
)

// String - Creating common behavior - give the type a String function
func (a AddressMedium) String() string {
	return [...]string{"", "FOS_APP", "CLIENT_DATA_INGRESS"}[a]
}

func (a AddressMedium) MarshalJSON() ([]byte, error) {
	return json.Marshal(a.String())
}
func (a *AddressMedium) UnmarshalJSON(data []byte) error {
	var addressMediumStr string
	if err := json.Unmarshal(data, &addressMediumStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(addressMediumStr))

	*a = StringToAddressMedium(status)

	if *a == AddressMedium(0) {
		return fmt.Errorf("invalid address medium value: %s", addressMediumStr)
	}

	return nil
}

func StringToAddressMedium(a string) AddressMedium {
	switch strings.ToUpper(a) {
	case "FOS_APP":
		return FOS_APP
	case "CLIENT_DATA_INGRESS":
		return CLIENT_DATA_INGRESS

	default:
		return AddressMedium(0)
	}
}

// Value - Implementation of valuer for database/sql
func (a AddressMedium) Value() (driver.Value, error) {

	return int64(a), nil
}
func (a *AddressMedium) Scan(value interface{}) error {
	addressMediumStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid AddressMedium value: %s", addressMediumStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(addressMediumStr)))

	*a = StringToAddressMedium(status)

	if *a == AddressMedium(0) {
		return nil
		//return fmt.Errorf("invalid address medi value: %s", addressMediumStr)
	}

	return nil
}
