package enum

import (
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"strings"
)

type AddressQuality int

const (
	_ AddressQuality = iota
	LOW
	MEDIUM
	HIGH
)

// String - Creating common behavior - give the type a String function
func (a AddressQuality) String() string {
	return [...]string{"", "LOW", "MEDIUM", "HIGH"}[a]
}

func (a AddressQuality) MarshalJSON() ([]byte, error) {
	return json.Marshal(a.String())
}
func (a *AddressQuality) UnmarshalJSON(data []byte) error {
	var addressQualityStr string
	if err := json.Unmarshal(data, &addressQualityStr); err != nil {
		return err
	}

	status := strings.TrimSpace(strings.ToUpper(addressQualityStr))

	*a = StringToAddressQuality(status)

	if *a == AddressQuality(0) {
		return fmt.Errorf("invalid address medium value: %s", addressQualityStr)
	}

	return nil
}

func StringToAddressQuality(a string) AddressQuality {
	switch strings.ToUpper(a) {
	case "LOW":
		return LOW
	case "MEDIUM":
		return MEDIUM
	case "HIGH":
		return HIGH

	default:
		return AddressQuality(0)
	}
}

// Value - Implementation of valuer for database/sql
func (a AddressQuality) Value() (driver.Value, error) {

	return int64(a), nil
}
func (a *AddressQuality) Scan(value interface{}) error {
	addressQualityStr, ok := value.([]uint8)
	if !ok {
		return fmt.Errorf("invalid AddressQuality value: %s", addressQualityStr)
	}

	status := strings.TrimSpace(strings.ToUpper(string(addressQualityStr)))

	*a = StringToAddressQuality(status)

	if *a == AddressQuality(0) {
		return nil
		//return fmt.Errorf("invalid address medi value: %s", addressQualityStr)
	}

	return nil
}
