package models

import "time"

const CustomersTable = "customers"

type Customer struct {
	ID                string    `json:"id"`
	CustomerRefNumber string    `json:"customer_ref_number"`
	ClientRefNumber   string    `json:"client_ref_number"`
	ClientCustomerId  string    `json:"client_customer_id"`
	FirstName         string    `json:"first_name"`
	LastName          string    `json:"last_name"`
	MobileNumber      string    `json:"mobile_number"`
	Email             string    `json:"email"`
	Dob               time.Time `json:"dob"`
	Gender            string    `json:"gender"`
	PreferredLanguage string    `json:"preferred_language"`
	CreatedBy         string    `json:"created_by"`
	UpdatedBy         string    `json:"updated_by"`
	DeletedBy         string    `json:"deleted_by"`
}

// Model table name used by gorm
func (Customer) TableName() string {
	return CustomersTable
}

func (c Customer) Age() int {
	today := time.Now()
	years := today.Year() - c.Dob.Year()

	// Check if the birthday has occurred this year or not
	if today.Month() < c.Dob.Month() || (today.Month() == c.Dob.Month() && today.Day() < c.Dob.Day()) {
		years--
	}

	return years
}

type CustomerWhereParams struct {
	ClientCustomerId  string
	CustomerRefNumber string
	MobileNumber      string
	ClientRefNumber   string
}
