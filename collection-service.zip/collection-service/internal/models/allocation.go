package models

import (
	"collection-service/internal/enum"
	"time"
)

const ALLOCATION_TABLE = "allocations"

type Allocation struct {
	CaseRefNumber                string
	AgentRefNumber               string
	ServiceProviderTeamRefNumber string
	ServiceProviderRefNumber     string
	Intervention                 enum.Intervention
	CreatedBy                    string
	CreatedAt                    *time.Time
	Agent                        Agent `gorm:"foreignKey:agent_ref_number;references:agent_ref_number"`
}

func (Allocation) TableName() string {
	return ALLOCATION_TABLE
}
