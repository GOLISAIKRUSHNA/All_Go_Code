package models

import "time"

const PincodeMasterTable = "pincode_master"

type PincodeMaster struct {
	Id        int       `gorm:"column:id"`
	Pincode   int       `gorm:"column:pincode"`
	CityId    int       `gorm:"column:city_id"`
	StateId   int       `gorm:"column:state_id"`
	CreatedAt time.Time `gorm:"column:created_at"`
	City      City      `gorm:"foreignKey:CityId;references:id"`
	State     State     `gorm:"foreignKey:StateId;references:id"`
}

// Model table name used by gorm
func (PincodeMaster) TableName() string {
	return PincodeMasterTable
}
