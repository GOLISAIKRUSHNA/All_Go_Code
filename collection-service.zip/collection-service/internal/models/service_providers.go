package models

import "time"

type ServiceProviders struct {
	ID                       uint   `gorm:"primaryKey"`
	Name                     string `gorm:"column:name"`
	ServiceProviderRefNumber string
	CreatedBy                string    `gorm:"column:created_by"`
	CreatedAt                time.Time `gorm:"column:created_at"`
}
