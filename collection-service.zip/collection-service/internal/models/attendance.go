package models

import (
	"collection-service/internal/enum"
	"time"
)

const ATTENDANCE_TABLE = "agent_attendance"

type Attendance struct {
	AttendanceRefNumber string
	AgentRefNumber      string
	AttendanceDate      string
	Location            Location `gorm:"type:point"`
	MarkDatetime        time.Time
	MarkType            enum.AttendanceType
	SelfieFilePath      string
	ApprovalDatetime    time.Time
	ApprovalStatus      string
	ApprovedBy          string
	CreatedBy           string
	AgentInfo           Agent `gorm:"foreignKey:AgentRefNumber;references:AgentRefNumber"`
}

// TODO: Fix Lat Long to Point, references below
// https://stackoverflow.com/questions/73772036/storing-and-retrieving-lat-long-values-stored-as-geography-point-type-in-databas
// https://github.com/go-pg/pg/issues/829#issuecomment-505882885

func (Attendance) TableName() string {
	return ATTENDANCE_TABLE
}
