package models

import "gorm.io/datatypes"

const CLIENT_TABLE = "clients"

type Client struct {
	ID              int
	ClientRefNumber string
	Name            string
	LogoUrl         string
	Configuration   datatypes.JSON
	CreatedBy       string
	OrgID           string
}

// Model table name used by gorm
func (Client) TableName() string {
	return CLIENT_TABLE
}

type ClientWhere struct {
	ClientRefNumber string
}
