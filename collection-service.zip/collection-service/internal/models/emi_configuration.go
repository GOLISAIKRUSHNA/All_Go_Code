package models

type EmiSingleConfig struct {
	TenureDays          string `json:"tenure_days"`
	PrincipalPercentage string `json:"principal_percentage"`
}
