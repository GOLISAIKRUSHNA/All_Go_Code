package models

import "time"

const CityMasterTable = "cities"

type City struct {
	Id        int       `gorm:"column:id"`
	Name      string    `gorm:"column:name"`
	CreatedAt time.Time `gorm:"column:created_at"`
}

// Model table name used by gorm
func (City) TableName() string {
	return CityMasterTable
}
