package models

import (
	"collection-service/internal/enum"
	"time"
)

const CLIENT_USER_TABLE = "client_users"

type ClientUser struct {
	ID                        uint                      `gorm:"primarykey"`
	ClientUserRefNo           string                    `gorm:"column:client_user_ref_number"`
	ClientRefNumber           string                    `gorm:"column:client_ref_number"`
	FirstName                 string                    `gorm:"column:first_name"`
	LastName                  string                    `gorm:"column:last_name"`
	Email                     string                    `gorm:"column:email"`
	MobileNumber              string                    `gorm:"column:mobile_number"`
	Status                    enum.Status               `gorm:"column:status"`
	Designation               string                    `gorm:"column:designation"`
	ReportingManagerRefNumber string                    `gorm:"column:reporting_manager_ref_number"`
	Role                      enum.ClientUserRole       `gorm:"column:role"`
	Visibility                enum.ClientUserVisibility `gorm:"column:visibility"`
	ReportingManagerInfo      *ClientUser               `gorm:"foreignKey:reporting_manager_ref_number;references:client_user_ref_number"`
	CreatedBy                 string                    `gorm:"column:created_by"`
	UpdatedBy                 string                    `gorm:"column:updated_by"`
	PhotoPath                 string
	CreatedAt                 time.Time
	UpdatedAt                 time.Time
	OrgID                     string `gorm:"column:org_id"`
	ClientTeamRefNumber       string `gorm:"column:client_team_ref_number"`
	TeamInfo                  Teams  `gorm:"foreignKey:client_team_ref_number;references:team_ref_number"`
	NotInAnyTeam              bool   `gorm:"-"`
}

// Model table name used by gorm
func (ClientUser) TableName() string {
	return CLIENT_USER_TABLE
}
