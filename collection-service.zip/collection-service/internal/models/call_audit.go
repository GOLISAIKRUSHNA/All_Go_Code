package models

import (
	"time"
)

const CALL_AUDITS = "call_audits"

type CallAudits struct {
	ID                   int
	AuditRefNumber       string
	AttemptRefNumber     string
	CaseRefNumber        string
	CallerAgentRefNumber string
	AuditAgentRefNumber  string
	Status               string
	CallDuration         string
	CallDate             time.Time
	TemplateId           string
	ResponseId           string
	ResponseDatetime     time.Time
	CreatedAt            time.Time
	UpdatedAt            time.Time
	Agent                Agent         `gorm:"foreignKey:caller_agent_ref_number;references:agent_ref_number"`
	Disposition          []Disposition `gorm:"foreignKey:attempt_ref_number;references:attempt_ref_number"`
}

// Model table name used by gorm
func (CallAudits) TableName() string {
	return CALL_AUDITS
}
