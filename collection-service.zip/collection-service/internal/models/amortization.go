package models

type SingleAmortization struct {
	ScheduledPaymentAmt   float64 `json:"scheduled_payment_amount"`
	ScheduledPrincipleAmt float64 `json:"scheduled_principal_amount"`
	ScheduledInterestAmt  float64 `json:"scheduled_interest_amount"`
	ScheduledPaymentDate  string  `json:"scheduled_payment_date"`
	Month                 int     `json:"month"`
}

type AmortizationData struct {
	Amortization []SingleAmortization
	NextEmiDate  string
}
