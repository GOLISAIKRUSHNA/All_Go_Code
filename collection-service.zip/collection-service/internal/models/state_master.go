package models

import "time"

const StateMasterTable = "states"

type State struct {
	Id        int       `gorm:"column:id"`
	Name      string    `gorm:"column:name"`
	CreatedAt time.Time `gorm:"column:created_at"`
}

// Model table name used by gorm
func (State) TableName() string {
	return StateMasterTable
}
