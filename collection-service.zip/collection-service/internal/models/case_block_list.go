package models

import (
	"collection-service/internal/enum"
	"time"
)

const CASE_BLOCK_LIST_TABLE = "case_block_list"

type CaseBlockList struct {
	ID                   int
	CaseRefNumber        string
	BlockReasonMasterId  int
	OriginalBlockedUntil time.Time
	BlockedUntil         time.Time
	BlockedAt            time.Time
	BlockedBy            string
	IsResolved           bool
	TicketRefNumber      string
	CreatedAt            time.Time
	UpdatedAt            time.Time
	Limit                int               `gorm:"-"`
	Offset               int               `gorm:"-"`
	BlockedByData        Agent             `gorm:"foreignKey:blocked_by;references:agent_ref_number"`
	BlockReasonMaster    BlockReasonMaster `gorm:"foreignKey:block_reason_master_id;references:id"`
	Tickets              *Tickets          `gorm:"foreignKey:ticket_ref_number;references:ticket_ref_number"`
	BlockSource          enum.BlockSource  `gorm:"-"`
	BlockReasonId        int               `gorm:"-"`
}

// Model table name used by gorm
func (CaseBlockList) TableName() string {
	return CASE_BLOCK_LIST_TABLE
}

type MaxBlockedUntil struct {
	MaxBlockedUntil time.Time
	BlockedDays     int // Assuming blocked_days is of type int
	CaseRefNumber   string
	IsResolved      bool
	Id              int
}
