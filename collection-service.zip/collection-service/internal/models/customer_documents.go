package models

import "time"

type CustomerDocument struct {
	ID                uint `gorm:"primarykey"`
	DocumentRefNumber string
	CustomerRefNumber string
	LoanRefNumber     string
	Type              string
	FilePath          string
	CreatedBy         string
	CreatedAt         time.Time
}
