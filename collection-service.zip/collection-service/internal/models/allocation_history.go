package models

import "time"

const ALLOCATION_HISTORY_TABLE = "allocations_history"

type AllocationHistory struct {
	CaseRefNumber            string
	AgentRefNumber           string
	ServiceProviderRefNumber string
	CreatedBy                string
	CreatedAt                *time.Time
	OriginalCreatedAt        *time.Time
}

// Model table name used by gorm
func (AllocationHistory) TableName() string {
	return ALLOCATION_HISTORY_TABLE
}
