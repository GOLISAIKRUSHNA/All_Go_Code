package models

import (
	"gorm.io/datatypes"
	"gorm.io/gorm"
)

const AGENT_ROLE_MAPPING_TABLE = "agent_role_mapping"

type AgentRoleMapping struct {
	gorm.Model
	AgentRefNumber            string
	CollectionPanelPermission datatypes.JSON
	CollectionAppPermission   datatypes.JSON
	CreatedBy                 string
	UpdatedBy                 string
	DeletedBy                 string
	RoleInfo                  AgentRole `gorm:"foreignKey:id;references:agent_role_id"`
}

// Model table name used by gorm
func (AgentRoleMapping) TableName() string {
	return AGENT_ROLE_MAPPING_TABLE
}
