package models

import "time"

type Violations struct {
	ID              int
	ClientRefNumber string
	Violation       string
	ViolationLevel  string
	IsCaseToBlock   bool
	CreatedAt       time.Time
	CreatedBy       string
	UpdatedAt       time.Time
	DeletedAt       *time.Time
}

func (Violations) TableName() string {
	return "violations"
}
