package models

import (
	"collection-service/internal/enum"
	"time"
)

const DISPOSITION_TABLE = "dispositions"

type Disposition struct {
	DispositionRefNumber string
	AttemptRefNumber     string
	Source               enum.Source
	CaseRefNumber        string
	CustomerRefNumber    string
	AgentRefNumber       string
	Disposition          string
	DispositionType      enum.DispositionType
	Comment              string
	FollowupDatetime     string
	Latitude             float64
	Longitude            float64
	SelfieFilePath       string
	AddressRefNumber     string
	ContactRefNumber     string
	CreatedAt            time.Time
	CustomerInfo         Customer         `gorm:"foreignKey:customer_ref_number;references:customer_ref_number"`
	AgentInfo            Agent            `gorm:"foreignKey:agent_ref_number;references:agent_ref_number"`
	AddressInfo          CustomerAddress  `gorm:"foreignKey:address_ref_number;references:address_ref_number"`
	ContactInfo          CustomerContacts `gorm:"foreignKey:contact_ref_number;references:contact_ref_number"`
	CreatedBy            string
}

func (Disposition) TableName() string {
	return DISPOSITION_TABLE
}
