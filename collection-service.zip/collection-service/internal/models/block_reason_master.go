package models

import (
	"collection-service/internal/enum"
	"time"
)

const BLOCK_REASON_MASTER_TABLE = "block_reason_master"

type BlockReasonMaster struct {
	ID                            int
	Description                   string
	Source                        enum.BlockSource
	Reason                        string
	IsDigitalCommunicationAllowed bool
	DaysToBlock                   int
	UntilFollowupDate             bool
	IsManualResolutionRequired    bool
	ViolationId                   int
	CreatedAt                     time.Time
	Violation                     Violations `gorm:"foreignKey:violation_id;references:id"`
}

// Model table name used by gorm
func (BlockReasonMaster) TableName() string {
	return BLOCK_REASON_MASTER_TABLE
}
