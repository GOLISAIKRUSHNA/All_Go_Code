package models

import (
	"collection-service/internal/enum"
	"time"
)

const CasesTable = "cases"

type Case struct {
	ID                        int
	CaseRefNumber             string
	CustomerRefNumber         string
	ClientRefNumber           string
	ClientTeamRefNumber       string
	LoanRefNumber             string
	CaseType                  string `gorm:"column:case_type"`
	CaseLevel                 string
	CollectionFor             enum.CollectionFor
	Product                   string
	FinancierRefNumber        string
	MaxDpd                    int
	CurrentDpd                int
	Bucket                    enum.Bucket
	TotalDue                  float64
	TotalPrincipalDue         float64
	TotalInterestDue          float64
	TotalFeesDue              float64
	NoOfLoansDue              float64
	NoOfEmisDue               int
	TotalOutstanding          float64
	TotalPrincipalOutstanding float64
	TotalInterestOutstanding  float64
	TotalFeesOutstanding      float64
	TotalPrincipalPaid        float64
	TotalInterestPaid         float64
	TotalFeesPaid             float64
	NoOfEmisPaid              int
	IsBlocked                 bool
	IsFreezed                 bool
	Status                    enum.CaseStatus
	CreatedBy                 string
	CreatedAt                 time.Time
	UpdatedBy                 string
	Limit                     int           `gorm:"-"`
	Offset                    int           `gorm:"-"`
	Customer                  Customer      `gorm:"foreignKey:customer_ref_number;references:customer_ref_number"`
	CaseAttribute             CaseAttribute `gorm:"foreignKey:case_ref_number;references:case_ref_number"`
	Client                    Client        `gorm:"foreignKey:client_ref_number;references:client_ref_number"`
	AllocationInfo            []Allocation  `gorm:"foreignKey:case_ref_number;references:case_ref_number"`
}

// Model table name used by gorm
func (Case) TableName() string {
	return CasesTable
}
