package models

import (
	"collection-service/internal/enum"
	"time"
)

const CASE_ATTRIBUTE = "case_attributes"

type CaseAttribute struct {
	CaseRefNumber                   string
	ClientLoanIds                   string
	LastDisposition                 string
	LastDispositionDatetime         *time.Time
	LastDispositionFollowupDate     *time.Time
	TotalCallsAttempted             int
	TotalCallsConnected             int
	TodaysCallsAttempted            int
	TodaysCallsConnected            int
	LastCallConnectedAt             *time.Time
	ContactRefNumber                string
	HavingMandateInprogressPayments bool
	HavingInprogressPayments        bool
	DispositionType                 enum.DispositionType
}

// Model table name used by gorm
func (CaseAttribute) TableName() string {
	return CASE_ATTRIBUTE
}
