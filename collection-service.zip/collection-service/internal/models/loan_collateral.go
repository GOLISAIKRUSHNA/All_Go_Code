package models

const LoanCollateralTable = "loan_collaterals"

type LoanCollateral struct {
	ID                       string  `json:"id"` 
	LoanRefNumber            string  `json:"loan_ref_number"` 
	CustomerRefNumber        string  `json:"customer_ref_number"`
	Type                     string  `json:"type"`
	Value                    float64 `json:"value"`
	Description              string  `json:"description"`
	PrimaryIdentifierType    string  `json:"primary_identifier_type"`
	PrimaryIdentifier        string  `json:"primary_identifier"`
	AdditionalIdentifierType string  `json:"additional_identifier_type"`
	AdditionalIdentifier     string  `json:"additional_identifier"`
	MakeAndModel             string  `json:"make_and_model"`
	CreatedBy                string  `json:"created_by"`
}

// Model table name used by gorm
func (LoanCollateral) TableName() string {
	return LoanCollateralTable
}
