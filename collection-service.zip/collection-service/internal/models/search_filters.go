package models

type SearchFilters struct {
	QueryString *string
	Limit       *int
	Offset      *int
	AscOrder    []string
	DescOrder   []string
	Filters     map[string]interface{}
}
