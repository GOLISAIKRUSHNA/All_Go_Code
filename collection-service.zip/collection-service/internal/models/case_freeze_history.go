package models

import (
	"collection-service/internal/enum"
	"time"
)

const CASE_FREEZE_HISTORY_TABLE = "case_freeze_history"

type CaseFreezeHistory struct {
	ID            int
	CaseRefNumber string
	Action        enum.FreezeStatus
	Reason        string
	CreatedBy     string
	CreatedAt     time.Time
}

// Model table name used by gorm
func (CaseFreezeHistory) TableName() string {
	return CASE_FREEZE_HISTORY_TABLE
}
