package models

import (
	"collection-service/internal/enum"

	"gorm.io/gorm"
)

const AGENTS_TABLE = "agents"

type Agent struct {
	gorm.Model
	AgentRefNumber string
	FirstName      string
	LastName       string
	MobileNumber   string
	Email          string
	//Username                  string
	//Password                  string
	Status enum.Status
	//HasPanelAccess            bool
	//HasAppAccess              bool
	CashCollectionLimit          float64
	CashDepositByDays            int
	CreatedBy                    string
	UpdatedBy                    string
	ReportingManagerRefNumber    string
	LanguagesSupported           string
	Designation                  string
	ServiceProviderRefNumber     string
	EmployeeId                   string
	Role                         enum.AgentRole
	Visibility                   enum.AgentVisibility
	PhotoPath                    string
	ServiceProviderTeamRefNumber string
	NotInAnyTeam                 bool `gorm:"-"`
	OrgID                        string
	//AgentRoleMappings         []AgentRoleMapping `gorm:"foreignKey:agent_ref_number;references:agent_ref_number"`
	ServiceProviderInfo  ServiceProviders `gorm:"foreignKey:service_provider_ref_number;references:service_provider_ref_number"`
	ReportingManagerInfo *Agent           `gorm:"foreignKey:reporting_manager_ref_number;references:agent_ref_number"`
	TeamInfo             Teams            `gorm:"foreignKey:service_provider_team_ref_number;references:team_ref_number"`
}

func (Agent) TableName() string {
	return AGENTS_TABLE
}
