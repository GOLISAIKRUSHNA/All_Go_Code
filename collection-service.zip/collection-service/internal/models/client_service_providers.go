package models

import "collection-service/internal/enum"

const CLIENT_SERVICE_TABLE = "client_service_providers"

type ClientServiceProviders struct {
	ID                       int
	ClientRefNumber          string
	ServiceProviderRefNumber string
	Intervention             enum.Intervention
	Status                   enum.ClientServiceProviderStatus
	CreatedBy                string
	ServiceProvider          ServiceProvider `gorm:"foreignKey:service_provider_ref_number;references:service_provider_ref_number"`
	Client                   Client          `gorm:"foreignKey:client_ref_number;references:client_ref_number"`
}

// Model table name used by gorm
func (ClientServiceProviders) TableName() string {
	return CLIENT_SERVICE_TABLE
}
