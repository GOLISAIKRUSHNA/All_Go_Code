package models

import "time"

const CASE_STATUS_HISTORY_TABLE = "case_status_history"

type CaseStatusHistory struct {
	ID            int
	CaseRefNumber string
	Status        string
	ChangedBy     string
	ChangedDate   *time.Time
	CreatedAt     *time.Time
}

// Model table name used by gorm
func (CaseStatusHistory) TableName() string {
	return CASE_STATUS_HISTORY_TABLE
}
