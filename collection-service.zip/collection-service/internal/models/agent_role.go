package models

import (
	"gorm.io/datatypes"
	"gorm.io/gorm"
)

const AGENT_ROLES_TABLE = "agent_roles"

type AgentRole struct {
	gorm.Model
	Name                      string
	CollectionPanelPermission datatypes.JSON
	CollectionAppPermission   datatypes.JSON
	CreatedAt                 string
	CreatedBy                 string
	DeletedAt                 string
	DeletedBy                 string
}

func (AgentRole) TableName() string {
	return AGENT_ROLES_TABLE
}
