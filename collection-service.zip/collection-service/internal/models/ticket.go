package models

import (
	"collection-service/internal/enum"
	"time"
)

const TICKETS_TABLE = "tickets"

type Tickets struct {
	ID               int
	TicketRefNumber  string
	CaseRefNumber    string
	AgentRefNumber   string
	Status           enum.TicketStatus
	IssueId          int
	SubIssueId       int
	ExtendedDatetime time.Time
	Action           enum.TicketAction
	Comment          string
	ClosedAt         time.Time
	ClosedBy         string
	CreatedAt        time.Time
	UpdatedAt        time.Time
	Limit            int           `gorm:"-"`
	Offset           int           `gorm:"-"`
	Case             Case          `gorm:"foreignKey:case_ref_number;references:case_ref_number"`
	Agent            Agent         `gorm:"foreignKey:agent_ref_number;references:agent_ref_number"`
	CaseBlockList    CaseBlockList `gorm:"foreignKey:case_ref_number;references:case_ref_number"`
}

// Model table name used by gorm
func (Tickets) TableName() string {
	return TICKETS_TABLE
}
