package models

const LoanReferenceTable = "loan_references"

type LoanReference struct {
	ID                string
	CustomerRefNumber string
	LoanRefNumber     string
	FirstName         string
	LastName          string
	ContactNumber     int
	Relation          string
	CreatedBy         string
}

// Model table name used by gorm
func (LoanReference) TableName() string {
	return LoanReferenceTable
}
