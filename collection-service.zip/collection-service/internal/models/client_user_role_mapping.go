package models

import (
	"gorm.io/gorm"
)

const CLIENT_USER_ROLE_MAPPING_TABLE = "client_user_role_mapping"

type ClientUserRoleMapping struct {
	gorm.Model
	ClientUserRefNo       string `gorm:"column:client_user_ref_number"`
	ClientRoleID          string `gorm:"column:client_role_id"`
	ClientPanelPermission bool   `gorm:"column:client_panel_permission"`
	CreatedBy             string `gorm:"column:created_by"`
	UpdatedBy             string `gorm:"column:updated_by"`
	DeletedBy             string `gorm:"column:deleted_by"`
}

// Model table name used by gorm
func (ClientUserRoleMapping) TableName() string {
	return CLIENT_USER_ROLE_MAPPING_TABLE
}
