package models

import "collection-service/internal/enum"

const ServiceProvidersTable = "service_providers"

type ServiceProvider struct {
	ID                       string `json:"id"`
	ServiceProviderRefNumber string
	Name                     string
	LogoUrl                  string
	Intervention             enum.Intervention
	CreatedBy                string
	OrgID                    string
}

// Model table name used by gorm
func (ServiceProvider) TableName() string {
	return ServiceProvidersTable
}
