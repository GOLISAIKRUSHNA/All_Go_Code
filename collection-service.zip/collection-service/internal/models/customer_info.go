package models

const CustomerInfoTable = "customer_info"

type CustomerInfo struct {
	InfoRefNumber     string
	CustomerRefNumber string
	LoanRefNumber     string
	EmploymentType    string
	EmployerName      string
	MonthlyIncome     float64
	Occupation        string
	CibilScore        int
}

// Model table name used by gorm
func (CustomerInfo) TableName() string {
	return CustomerInfoTable
}
