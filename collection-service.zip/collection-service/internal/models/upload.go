package models

import "time"

const UPLOAD_TABLE = "uploads"

type Upload struct {
	UploadRefNumber       string
	Reason                string
	FileName              string
	InputFilePath         string
	OutputFilePath        string
	Status                string
	TotalRecordsCount     int32
	ProcessedRecordsCount int32
	SuccessCount          int32
	FailedCount           int32
	Object                string
	ObjectRefNumber       string
	UploadedBy            string
	CreatedAt             time.Time
	UploadedByInfo        Agent      `gorm:"foreignKey:uploaded_by;references:agent_ref_number"`
	UploadedByClientUser  ClientUser `gorm:"foreignKey:uploaded_by;references:client_user_ref_number"`
}

// Model table name used by gorm
func (Upload) TableName() string {
	return UPLOAD_TABLE
}
