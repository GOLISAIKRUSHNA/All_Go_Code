package models

import "time"

type OTP struct {
	Val                string    `json:"val,omitempty"`
	PhoneNo            string    `json:"phoneNo,omitempty"`
	ResendLimit        int64     `json:"rl,omitempty"`
	WrongAttemptsLimit int64     `json:"wal,omitempty"`
	FirstIssuedAt      time.Time `json:"fia"`
	LastIssuedAt       time.Time `json:"lia"`
	Blocked            bool      `json:"blck,omitempty"`
}
