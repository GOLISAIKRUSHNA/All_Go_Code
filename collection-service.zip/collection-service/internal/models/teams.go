package models

import (
	"collection-service/internal/enum"
	"time"
)

type Teams struct {
	ID              uint `gorm:"primarykey"`
	TeamRefNumber   string
	Name            string
	Object          enum.TeamObject
	ObjectRefNumber string
	CreatedBy       string
	CreatedAt       time.Time
	UpdatedAt       time.Time
	UpdatedBy       string
}

func (Teams) TableName() string {
	return "teams"
}
