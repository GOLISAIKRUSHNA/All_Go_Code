package models

import (
	"collection-service/internal/enum"
	"gorm.io/gorm"
)

const CustomerAddressTable = "customer_addresses"

type CustomerAddress struct {
	gorm.Model
	CustomerRefNumber string `gorm:"column:customer_ref_number"`
	AddressRefNumber  string `gorm:"column:address_ref_number"`
	LoanRefNumber     string `gorm:"column:loan_ref_number"`
	CaseRefNumber     string
	Line1             string              `gorm:"column:line_1"`
	Line2             string              `gorm:"column:line_2"`
	Line3             string              `gorm:"column:line_3"`
	Label             enum.AddressLabel   `gorm:"column:label"`
	Type              enum.AddressType    `gorm:"column:type"`
	ResidentType      string              `gorm:"column:resident_type"`
	Source            enum.AddressSource  `gorm:"column:source"`
	AddressQuality    enum.AddressQuality `gorm:"column:address_quality"`
	AddressMedium     enum.AddressMedium  `gorm:"column:address_medium"`
	Landmark          string              `gorm:"column:landmark"`
	Pincode           int                 `gorm:"column:pincode"`
	City              string              `gorm:"column:city"`
	State             string              `gorm:"column:state"`
	Country           string              `gorm:"column:country"`
	CityId            int                 `gorm:"column:city_id"`
	StateId           int                 `gorm:"column:state_id"`
	Lat               float64             `gorm:"column:lat"`
	Long              float64             `gorm:"column:long"`
	CreatedBy         string              `gorm:"column:created_by"`
	UpdatedBy         string              `gorm:"column:updated_by"`
	DeletedBy         string              `gorm:"column:deleted_by"`
	IsPrimary         bool                `gorm:"column:is_primary"`
}

// Model table name used by gorm
func (CustomerAddress) TableName() string {
	return CustomerAddressTable
}
