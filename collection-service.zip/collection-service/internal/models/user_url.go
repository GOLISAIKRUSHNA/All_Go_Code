package models

import (
	"collection-service/internal/enum"
	"time"
)

type UserUrl struct {
	ID               uint `gorm:"primarykey"`
	UserURLRefNumber string
	Object           enum.Object
	ObjectRefNumber  string
	Reason           enum.URLReason
	Entity           enum.URLEntity
	EntityRefNumber  string
	ShortURL         string
	LongURL          string
	ExpiryTime       time.Time
	CreatedAt        time.Time
	UpdatedAt        time.Time
}
