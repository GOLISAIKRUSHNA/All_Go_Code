package models

import (
	"context"
	"fmt"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type Location struct {
	Latitude  float64
	Longitude float64
}

// mention your data type
func (loc Location) GormDataType() string {
	return "point"
}

/*
s

	func (loc Location) Scan(value interface{}) error {
		if data, ok := value.([]byte); ok {
			// Parse the POINT string
			_, err := fmt.Sscanf(string(data), "POINT(%f %f)", &loc.Longitude, &loc.Latitude)
			return err
		}
		return nil
	}
*/
func (loc Location) GormValue(ctx context.Context, db *gorm.DB) clause.Expr {
	return clause.Expr{
		SQL:  "ST_PointFromText(?)",
		Vars: []interface{}{fmt.Sprintf("POINT(%f %f)", loc.Latitude, loc.Longitude)},
	}
}

func (p *Location) Scan(v interface{}) error {
	if v == nil {
		return nil
	}

	val, ok := v.([]byte)
	if !ok {
		return fmt.Errorf("Scan error: invalid type for Point: %T", v)
	}

	coordinates := string(val)
	fmt.Sscanf(coordinates, "POINT(%f %f)", &p.Longitude, &p.Latitude)
	return nil
}
