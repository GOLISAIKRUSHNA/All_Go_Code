package models

const LoanPaymentsTable = "loan_payments"

type LoanPayment struct {
	ID                      int
	LoanPaymentRefNumber    string
	LoanRefNumber           string
	PaymentRefNumber        string
	ClientPaymentId         string
	PaymentGateway          string
	PaymentAmount           float64
	PaymentDatetime         string
	AppliedTowardsPrincipal float64
	AppliedTowardsInterest  float64
	AppliedTowardsFees      float64
	IsWaiver                bool
	CreatedBy               string
	UpdatedBy               string
}

// Model table name used by gorm
func (LoanPayment) TableName() string {
	return LoanPaymentsTable
}

type LoanPaymentWhereParams struct {
	LoanRefNumber        string
	ClientLoanId         string
	ClientPaymentId      string
	LoanPaymentRefNumber string
}
