package models

const FINANCIER_TABLE = "financiers"

type Financier struct {
	ID                 string `json:"id"`
	FinancierRefNumber string `json:"financier_ref_number"`
	Name               string `json:"name"`
	CreatedBy          string `json:"created_by"`
}

// Model table name used by gorm
func (Financier) TableName() string {
	return FINANCIER_TABLE
}
