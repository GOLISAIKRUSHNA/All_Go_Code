package models

import (
	"collection-service/internal/enum"
	"time"
)

const SpecialOffersMasterTable = "special_offers_master"

type SpecialOffersMaster struct {
	ID                           int `gorm:"primarykey"`
	SpecialOffersMasterRefNumber string
	ClientRefNumber              string
	QueueType                    enum.QueueType
	OfferType                    enum.OfferType
	OfferTypePercentage          float64
	Days                         int
	CreatedAt                    time.Time
	CreatedBy                    string
	UpdatedAt                    time.Time
}

// Model table name used by gorm
func (SpecialOffersMaster) TableName() string {
	return SpecialOffersMasterTable
}
