package models

import (
	"collection-service/internal/enum"
	"time"
)

const CUSTOMER_CONTACTS_TABLE = "customer_contacts"

type CustomerContacts struct {
	ID                uint `gorm:"primarykey"`
	ContactRefNumber  string
	CustomerRefNumber string
	LoanRefNumber     string
	CaseRefNumber     string
	ContactNumber     string
	ContactName       string
	ContactOf         enum.ContactOf
	ContactType       enum.ContactType
	IsPrimary         bool
	CreatedAt         time.Time
	CreatedBy         string
	DeletedAt         time.Time
	DeletedBy         string
}

func (CustomerContacts) TableName() string {
	return CUSTOMER_CONTACTS_TABLE
}
