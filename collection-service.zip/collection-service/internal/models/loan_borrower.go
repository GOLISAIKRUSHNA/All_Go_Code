package models

const LoanBorrowersTable = "loan_borrowers"

type LoanBorrower struct {
	ID                        string   `json:"id"`
	LoanRefNumber             string   `json:"loan_ref_number"`
	BorrowerCustomerRefNumber string   `json:"borrower_customer_ref_number"`
	Type                      string   `json:"type"`
	RelationWithPrimary       string   `json:"relation_with_primary"`
	CreatedBy                 string   `json:"created_by"`
	Customer                  Customer `gorm:"foreignKey:borrower_customer_ref_number;references:customer_ref_number"`
}

// Model table name used by gorm
func (LoanBorrower) TableName() string {
	return LoanBorrowersTable
}
