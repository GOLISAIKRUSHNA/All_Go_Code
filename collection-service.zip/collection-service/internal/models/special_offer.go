package models

import (
	"collection-service/internal/enum"
	"time"

	"github.com/guregu/null/v5"
)

type SpecialOffer struct {
	ID                          uint `gorm:"primarykey"`
	SpecialOfferRefNumber       string
	SpecialOfferMasterRefNumber string `gorm:"-"`
	CaseRefNumber               string
	LoanRefNumber               string
	OfferType                   enum.OfferType
	WaiverType                  enum.WaiverType
	WaiverValue                 null.Float
	MinimumPaymentAmount        float64
	Status                      enum.OfferStatus
	ActivationSource            enum.ActivationSource
	StartDatetime               time.Time
	EndDatetime                 time.Time
	CreatedBy                   string
	CreatedAt                   time.Time
	UpdatedAt                   time.Time
}
