package models

import (
	"collection-service/internal/enum"
	"time"
)

const LoansTable = "loans"

type Loan struct {
	ID                          int
	LoanRefNumber               string
	ClientLoanId                string
	CreditCardNo                string
	CustomerRefNumber           string
	ClientRefNumber             string
	CaseRefNumber               string
	LoanAmount                  float64
	Tenure                      int
	TenureType                  enum.LoanTenure
	InterestRate                float64
	EmiAmount                   float64
	Status                      enum.LoanStatus
	Product                     enum.LoanProduct
	SubProduct                  string
	ActiveFinancierRefNumber    string
	SecondaryFinancierRefNumber string
	DisbursementAmount          float64
	DisbursementDate            string
	DueDate                     time.Time
	FirstEmiDate                string
	LastEmiDate                 string
	EarliestUnpaidEmiDate       time.Time
	BillTotalPaymentDue         float64
	BillMinPaymentDue           float64
	BillStatementGenerationDate string
	CreditLimit                 float64
	AvailableCreditLimit        float64
	TotalDue                    float64
	TotalPrincipalDue           float64
	TotalInterestDue            float64
	TotalFeesDue                float64
	TotalOutstanding            float64
	TotalPrincipalOutstanding   float64
	TotalInterestOutstanding    float64
	TotalFeesOutstanding        float64
	TotalPrincipalPaid          float64
	TotalInterestPaid           float64
	TotalFeesPaid               float64
	NoOfEmisPaid                int
	NoOfEmisUnpaid              int
	CurrentDpd                  int
	MaxDpd                      int
	PaymentLink                 string
	CreatedBy                   string
	UpdatedBy                   string
	GroupedLoans                string             `json:"grouped_loans"`
	ClientLoanIds               string             `json:"client_loan_ids"`
	Client                      Client             `gorm:"foreignKey:client_ref_number;references:client_ref_number"`
	LoanPayment                 []LoanPayment      `gorm:"foreignKey:loan_ref_number;references:loan_ref_number" json:"loan_payment"`
	LoanCollateral              []LoanCollateral   `gorm:"foreignKey:loan_ref_number;references:loan_ref_number" json:"loan_collateral"`
	LoanBorrower                []LoanBorrower     `gorm:"foreignKey:loan_ref_number;references:loan_ref_number" json:"loan_borrower"`
	ActiveFinancier             Financier          `gorm:"foreignKey:active_financier_ref_number;references:financier_ref_number"`
	SecondaryFinancier          Financier          `gorm:"foreignKey:secondary_financier_ref_number;references:financier_ref_number"`
	CollectionFor               enum.CollectionFor `gorm:"-"`
	CustomerInfo                CustomerInfo       `gorm:"foreignKey:customer_ref_number;references:customer_ref_number"`
	Level                       string             `gorm:"-"`
}

// Model table name used by gorm
func (Loan) TableName() string {
	return LoansTable
}

type LoanGroupBy struct {
	LoanRefNumber string
}
