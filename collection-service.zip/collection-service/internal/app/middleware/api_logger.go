package middleware

import (
	"bytes"
	"collection-service/common/logger"
	"encoding/json"
	"fmt"
	"io"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

type bodyLogWriter struct {
	gin.ResponseWriter
	body *bytes.Buffer
}

func (w bodyLogWriter) Write(b []byte) (int, error) {
	w.body.Write(b)
	return w.ResponseWriter.Write(b)
}

func ApiLogger() gin.HandlerFunc {
	return func(c *gin.Context) {

		startTime := time.Now()
		//Getting raw request payload from request and compacting to parin in log
		jsonData, _ := c.GetRawData()
		compactJson := &bytes.Buffer{}
		json.Compact(compactJson, jsonData)

		//Reassigning request payload to request body as it removes payload from request once accessed
		c.Request.Body = io.NopCloser(bytes.NewBuffer(jsonData))

		//Setting payload to context so that it will be available for sentry
		c.Set("payload", jsonData)

		fields := make(map[string]interface{})
		fields["log_type"] = "http-log"

		fields["request"] = compactJson.String()
		fields["request_method"] = c.Request.Method
		fields["uri"] = c.Request.RequestURI
		fields["headers"] = c.Request.Header

		// Logging request information in log file
		logger.Info(c.Request.Context(), "request", fields)
		delete(fields, "request")

		// Overriding response writer to the context response
		blw := &bodyLogWriter{body: bytes.NewBufferString(""), ResponseWriter: c.Writer}
		c.Writer = blw

		//Calling next middleware or proceeding program
		c.Next()
		responseBodyMap := make(map[string]interface{})
		err := json.Unmarshal(blw.body.Bytes(), &responseBodyMap)
		if err != nil {
			fields["response"] = blw.body.String()
		} else {
			fields["response"] = responseBodyMap
		}

		fields["status"] = strconv.Itoa(blw.Status())
		fields["latency"] = fmt.Sprintf("%fms", float64(time.Now().Sub(startTime).Nanoseconds())/1000000.0)
		fields["request_method"] = c.Request.Method
		fields["uri"] = c.Request.RequestURI
		fields["body_size"] = c.Writer.Size()
		fields["headers"] = c.Request.Header

		// Logging response information in log file
		logger.Info(c.Request.Context(), "response", fields)

	}
}
