package middleware

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/dto"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

func ExceptionHandler() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if r := recover(); r != nil {
				errCode := http.StatusInternalServerError
				var resp interface{} = nil
				if ce, ok := r.(utils.CustomError); ok {
					errCode = ce.StatusCode
					resp = ce.Data
				}
				err := fmt.Sprintf("%v", r)

				if errCode == http.StatusInternalServerError {
					if err_data, ok := r.(error); ok {
						logger.Error(c.Request.Context(), err_data, "", nil)
					} else {
						logger.Error(c.Request.Context(), errors.New(err), "", nil)
					}
				}

				if resp == nil {
					resp = dto.ServerErrorResponse{
						TraceId: tracing.GetTraceIdFromGinCtx(c),
						Error: dto.RequestError{
							Code:    constants.INTERNAL_SERVER_ERROR_CODE,
							Message: "Internal Server Error",
							Details: []dto.RequestDetails{
								{
									Field:   "Not Applicable",
									Message: err,
								},
							},
						},
					}
				}

				marshalled_response, _ := json.Marshal(resp)
				fields := utils.GetHTTPLogFields(c)
				fields["status"] = errCode
				logger.Info(c.Request.Context(), logger.CreateLogMsg(tracing.GetTraceIdFromGinCtx(c), c.Request.Method, "response", c.Request.RequestURI, string(marshalled_response)+", "+strconv.Itoa(errCode)), fields)
				c.AbortWithStatusJSON(errCode, resp)
			}
		}()
		c.Next()
	}
}
