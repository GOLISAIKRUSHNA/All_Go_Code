package middleware

import (
	"collection-service/internal/app/constants"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

func MandatoryHeaderMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		missingHeaders := []string{}

		if c.GetHeader(constants.X_APP) == "" {
			missingHeaders = append(missingHeaders, constants.X_APP)
		}

		if c.GetHeader(constants.X_APP_VERSION) == "" {
			missingHeaders = append(missingHeaders, constants.X_APP_VERSION)
		}

		if c.GetHeader(constants.X_REFERER) == "" {
			missingHeaders = append(missingHeaders, constants.X_REFERER)
		}

		if c.GetHeader(constants.X_TRACE_ID) == "" {
			missingHeaders = append(missingHeaders, constants.X_TRACE_ID)
		}

		if len(missingHeaders) > 0 {
			c.String(http.StatusBadRequest, fmt.Sprintf("missing mandatory headers %s", missingHeaders))
			c.Abort()
			return
		}

		c.Next()
	}
}
