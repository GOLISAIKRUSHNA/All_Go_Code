package constants

type DatabaseType string

const (
	// Database connection type initialization
	DB_CONNECTION_TYPE               = "db_connection_type"
	READ_DATABASE_TYPE  DatabaseType = "READ"
	WRITE_DATABASE_TYPE DatabaseType = "WRITE"

	// Other constants initialization
	COLLECTIONS_TABLE = "collections"
)
