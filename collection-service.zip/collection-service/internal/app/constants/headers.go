package constants

const (
	CONTENT_TYPE     = "Content-Type"
	APPLICATION_JSON = "application/json"
	X_APP            = "X-App"
	X_APP_VERSION    = "X-App-Version"
	X_REFERER        = "X-Referer"
	X_TRACE_ID       = "X-Trace-Id"
	X_CLIENT_NAME    = "x-client-name"
)



