package constants

const (
	ROUTE_NOT_IMPLEMENTED    = "This route is not implemented"
	ROUTE_METHOD_NOT_DEFINED = "The route handlers not defined yet"
)
