package events

const (
	AGENT_CREATED = "agent_created"
	AGENT_UPDATED = "agent_updated"

	CLIENT_USER_CREATED = "client_user_created"
	CLIENT_USER_UPDATED = "client_user_updated"

	ALLOCATION_CHANGED = "allocation_changed"

	CASE_UPDATED   = "case_updated"
	CASE_CREATED   = "case_created"
	CASE_WITHDRAWN = "case_withdrawn"
	FREEZE_CASE    = "freeze_case"
	UNFREEZE_CASE  = "unfreeze_case"
	UNBLOCK_CASE   = "unblock_case"
)
