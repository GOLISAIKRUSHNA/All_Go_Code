package constants

const (
	VALIDATION_ERROR_CODE      = "2400"
	NOT_FOUND_ERROR_CODE       = "2404"
	INTERNAL_SERVER_ERROR_CODE = "2500"

	// OTP error codes
	OTP_EXPIRED_ERROR_CODE      = "2410"
	OTP_INVALID_ERROR_CODE      = "2411"
	OTP_BLOCKED_ERROR_CODE      = "2412"
	OTP_RESEND_LIMIT_ERROR_CODE = "2413"
	REQUEST_FIELD_EMPTY         = "2414"

	// login error codes
	PASSWORD_INVALID = "2510"
	USERNAME_INVALID = "2511"

	// Agent error codes
	EMAIL_ALREADY_EXISTS            = "2310"
	MOBILE_ALREADY_EXISTS           = "2311"
	AGENT_REF_NUMBER_INVALID        = "2312"
	EMAIL_AND_ORGID_ALREADY_EXISTS  = "2313"
	MOBILE_AND_ORGID_ALREADY_EXISTS = "2314"
	AGENT_NOT_FOUND                 = "2315"
	// Customer error codes
	CONTACT_NUMBER_ALREADY_EXISTS = "2311"

	GOOGLE_API_CALL_ERROR_CODE = "2800"
	CASE_NOT_ALLOCATED         = "3500"
	CALLS_NOT_ALLOWED          = "3501"

	ATTENDANCE_ALREADY_PRESENT = "3601"

	SERVICE_PROVIDER_NOT_FOUND = "3700"
)

func GetErrMsg(errCode string) (msg string) {

	switch errCode {
	// otp error codes.
	case OTP_EXPIRED_ERROR_CODE:
		msg = "otp expired. Please try again"
	case OTP_BLOCKED_ERROR_CODE:
		msg = "wrong attempts limit exhausted. Try again after sometime"
	case OTP_RESEND_LIMIT_ERROR_CODE:
		msg = "resend limit exhausted. Try again after sometime"
	case OTP_INVALID_ERROR_CODE:
		msg = "invalid OTP entered. Please try again"
	case EMAIL_ALREADY_EXISTS:
		msg = "Email already assigned to another user"
	case MOBILE_ALREADY_EXISTS:
		msg = "Mobile number already assigned to another user"
	case MOBILE_AND_ORGID_ALREADY_EXISTS:
		msg = "Mobile number already assigned to another user"
	case EMAIL_AND_ORGID_ALREADY_EXISTS:
		msg = "Email already assigned to another user"

		// login error codes
	case PASSWORD_INVALID:
		msg = "invalid password entered. Please try again"
	case USERNAME_INVALID:
		msg = "invalid username entered. Please try again"

	case AGENT_REF_NUMBER_INVALID:
		msg = "Agent Reference Number in the Request is Incorrect"
	case ATTENDANCE_ALREADY_PRESENT:
		msg = "Attendance is Already Present for given agent and date"
	case SERVICE_PROVIDER_NOT_FOUND:
		msg = "Service Provider Not Found"
	case AGENT_NOT_FOUND:
		msg = "Agent Not Found"
	}

	return msg
}
