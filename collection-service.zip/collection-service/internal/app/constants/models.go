package constants

const (
	MODEL_NOT_FOUND = "Provided model is not found"
	MODEL_IS_EMPTY  = "Model instance is empty"
)
