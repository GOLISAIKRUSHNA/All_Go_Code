package constants

const (
	CTX_REQUEST_INFO = "request_info"

	CTX_DB_CONNECTION_TYPE = "db_connection_type"
)

type RequestInfo struct {
	App        string `json:"app"`
	AppVersion string `json:"app_version"`
}
