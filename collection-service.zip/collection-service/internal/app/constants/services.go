package constants

const (
	REPO_NOT_FOUND  = "Provided repository is not found"
	REPO_IS_EMPTY   = "BaseRepo instance is empty"
	CACHE_NOT_FOUND = "Provided cache is not found"
	CACHE_IS_EMPTY  = "Cache instance is empty"
	TRACE_ID        = "trace_id"
	SPAN_ID         = "span_id"

	// AWS constants
	CUSTOMER_DOCUMENTS_AWS_BUCKET      = "collection-customer-documents"
	CLIENT_DOCS                        = "clients-docs-bkt"
	SERVICE_PROVIDER_DOCS              = "svc-pvd-bkt"
	SERVICE_PROVIDER_ATTENDANCE_BUCKET = "sp-attendance-bucket"
	BULK_UPLOAD_AWS_BUCKET             = "collection-bulk-uploads"
	CLIENT_AWS_BUCKET                  = "ramp-clients"
	UPLOAD_SAMPLE_FILES_AWS_BUCKET     = "uploads-sample-files"
	// Services list
	COLLECTION_SERVICE = "collection-service"
	PAYMENT_SERVICE    = "payment-service"
	DIALER_SERVICE     = "dialer-service"
	COMMON_SERVICE     = "common-service"
	PERMIFY_SERVICE    = "permify-service"
	AIRFLOW_SERVICE    = "airflow-service"
	CRON_SERVICE       = "cron-service"

	BULLET                     = "bullet"
	NORMAL                     = "normal"
	FLEXIBLE                   = "flexible"
	INSTA_LOAN_MERCHANT_REF_NO = ""
	SOFT_UPGRADE_VERSION       = "1.0.0"
	FORCE_UPGRADE_VERSION      = "1.0.0"

	//Google Constants
	GOOGLE_MAP_BASE_URL = "https://maps.googleapis.com"
	LAT_LONG_ENDPOINT   = "/maps/api/geocode/json"

	MANUAL_CASE_BLOCKED_DATE                          = "2099-01-01"
	PERMANENT_CASE_BLOCKED_DATE                       = "2050-12-31"
	PERMANENT_CASE_DAYS_TO_BLOCK                      = 999
	DEFAULT_PAGE_SIZE                                 = 10
	SYSTEM_AGENT_REF_NUMBER                           = "SYGASAGNTABVX"
	DISTANCE_CHECK_METERS                             = 100
	DAILY_CALLS_LIMIT_FREEZE_FOR_PTP_CB               = 3
	DAILY_CALLS_CONNECT_LIMIT                         = 1
	FREEZE_REASON_PTP_CB                              = "PTP_CB_FREEZED"
	FREEZE_REASON_DAILY_CALLS_ATTEMPTS_LIMIT_EXCEEDED = "DAILY_CALLS_ATTEMPTS_LIMIT_EXCEEDED"
	FREEZE_REASON_DAILY_CALL_CONNECTED_LIMIT_EXCEEDED = "DAILY_CALL_CONNECTED_LIMIT_EXCEEDED"
	FREEZE_REASON_MANDATE_INPROGRESS                  = "MANDATE_INPROGRESS"
	FREEZE_REASON_PPS_PPA                             = "PPS_PPA_FREEZED"
)
