package constants

const (
	COLLECTION_APP_NAME = "collection-app"
	// collection panel secret constants
	COLLECTION_PANEL_NAME        = "collection-panel"
	COLLECTION_PANEL_AUTH_KEY_ID = "KY000003"

	// client panel secret constants
	CLIENT_PANEL_NAME        = "client-panel"
	CLIENT_PANEL_AUTH_KEY_ID = "KY000004"

	SERVICE_PROIVDER_PANEL_NAME        = "service-provider-panel"
	SERVICE_PROIVDER_PANEL_AUTH_KEY_ID = "KY000005"

	CSAT_PANEL_NAME        = "csat-panel"
	CSAT_PANEL_AUTH_KEY_ID = "KY000006"

	CALLING_PANEL_NAME = "calling-panel"

	// JWT expiry configs
	JWT_ACCESS_TOKEN_EXPIRY_MINUTES  = 10080
	JWT_REFRESH_TOKEN_EXPIRY_MINUTES = 10080

	SERVICE_PROVIDER_PANEL_NAME = "service-provider-panel"

	AUDIT_PANEL_NAME = "audit-panel"

	RAMP_PANEL_NAME = "ramp-panel"

	FIELD_APP_NAME = "field-app"
)

//func GetClientAuthSecretKey(clientID string) (secret string) {
//
//	switch clientID {
//	case COLLECTION_APP_AUTH_KEY_ID:
//		secret = COLLECTION_APP_AUTH_ACCESS_TOKEN_SECRET
//	// TODO: add more secrets
//	case COLLECTION_PANEL_AUTH_KEY_ID:
//		clientID = COLLECTION_PANEL_AUTH_ACCESS_TOKEN_SECRET
//	}
//
//	return
//}
