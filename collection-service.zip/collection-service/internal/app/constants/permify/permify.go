package permify

const (
	// events
	WRITE_RELATION_EVENT  = "permify_write_relation_event"
	DELETE_RELATION_EVENT = "permify_delete_relation_event"
	WRITE_ATTRIBUTE_EVENT = "permify_write_attribute_event"

	// user attributes
	CA_ACCESS  = "ca_access"
	SP_ACCESS  = "sp_access"
	RAP_ACCESS = "rap_access"
	CAP_ACCESS = "cap_access"
	CSP_ACCESS = "csp_access"
	AUP_ACCESS = "aup_access"
	FIA_ACCESS = "fia_access"

	// entities
	ENTITY_USER             = "user"
	ENTITY_CLIENT           = "client"
	ENTITY_SERVICE_PROVIDER = "sp"
	ENTITY_CASE             = "case"
	ENTITY_TEAM             = "team"

	PERMIFY_PERMISSIONS_DELIMITER = "_subpermission_"

	// permissions prefix
	CALLING_PANEL_PERMISSION_PREFIX          = "cap"
	CSAT_PANEL_PERMISSION_PREFIX             = "csp"
	AUDIT_PANEL_PERMISSION_PREFIX            = "aup"
	CLIENT_PANEL_PERMISSION_PREFIX           = "cp"
	SERVICE_PROVIDER_PANEL_PERMISSION_PREFIX = "sp"
	COLLECTION_APP_PERMISSION_PREFIX         = "fia"

	// permissions
	PERMISSION_VISIBILITY      = "visibility"
	PERMISSION_CASE_LEVEL_VIEW = "case_level_view"

	// relations
	RELATION_MAIN_USER             = "main_user"
	RELATION_REPORTING_MANAGER     = "reporting_manager"
	RELATION_SERVICE_PROVIDER      = "service_provider"
	RELATION_CLIENT                = "client"
	RELATION_SERVICE_PROVIDER_TEAM = "service_provider_team"
	RELATION_CLIENT_TEAM           = "client_team"
	RELATION_ALLOCATED_TO          = "allocated_to"
)
