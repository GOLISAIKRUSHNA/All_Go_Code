package constants

const (
	API_CASELOAN          = "case-loan"
	API_CASELIST          = "case-list"
	API_DISPOSITION_LIST  = "disposition-list"
	API_CONTACT_LIST      = "contact-list"
	API_CLIENT_USER_LIST  = "client-user-list"
	API_CLIENT_NAMES_LIST = "client-names-list"

	CUSTOMER_REF_NUMBER = "crn"
	CASE_REF_NUMBER     = "carn"
	LOAN_REF_NUMBER     = "lrn"
	AGENT_REF_NUMBER    = "arn"
	GET_PTP_CASE        = "ptp-case"
	GET_UNTOUCHED_CASE  = "untouched-case"

	CLIENT_REF_NUMBER      = "clrn"
	CLIENT_USER_REF_NUMBER = "curn"
	MOBILE_NUMBER          = "mb"
	EMAIL                  = "eml"
	STATUS                 = "st"

	PAGE_NO = "page-no"
)
