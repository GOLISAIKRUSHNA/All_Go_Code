package constants

const (
	DEFAULT_MESSAGE_VERSION = "v1"

	RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE = "collections-app-direct-delayed-exchg"

	RMQ_PAYMENT_SERVICE_MAIN_QUEUE     = "payment-service-main-queue"
	RMQ_PAYMENT_SERVICE_MAIN_QUEUE_KEY = "payment-service-main-key"

	RMQ_PAYMENT_SERVICE_DL_QUEUE     = "payment-service-dl-queue"
	RMQ_PAYMENT_SERVICE_DL_QUEUE_KEY = "payment-service-dl-key"

	RMQ_COLLECTION_SERVICE_MAIN_QUEUE     = "collection-service-main-queue"
	RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY = "collection-service-main-key"

	RMQ_COLLECTION_SERVICE_DL_QUEUE     = "collection-service-dl-queue"
	RMQ_COLLECTION_SERVICE_DL_QUEUE_KEY = "collection-service-dl-key"

	RMQ_AUTH_SERVICE_MAIN_QUEUE     = "auth-service-main-queue"
	RMQ_AUTH_SERVICE_MAIN_QUEUE_KEY = "auth-service-main-key"

	RMQ_AUTH_SERVICE_DL_QUEUE     = "auth-service-dl-queue"
	RMQ_AUTH_SERVICE_DL_QUEUE_KEY = "auth-service-dl-key"

	RMQ_COMMON_SERVICE_MAIN_QUEUE     = "common-service-main-queue"
	RMQ_COMMON_SERVICE_MAIN_QUEUE_KEY = "common-service-main-key"

	RMQ_COMMON_SERVICE_DL_QUEUE     = "common-service-dl-queue"
	RMQ_COMMON_SERVICE_DL_QUEUE_KEY = "common-service-dl-key"

	RMQ_DIALER_SERVICE_MAIN_QUEUE     = "dialer-service-main-queue"
	RMQ_DIALER_SERVICE_MAIN_QUEUE_KEY = "dialer-service-main-key"

	RMQ_DIALER_SERVICE_DL_QUEUE     = "dialer-service-dl-queue"
	RMQ_DIALER_SERVICE_DL_QUEUE_KEY = "dialer-service-dl-key"

	RMQ_COMMUNICATION_SERVICE_MAIN_QUEUE     = "communication-service-main-queue"
	RMQ_COMMUNICATION_SERVICE_MAIN_QUEUE_KEY = "communication-service-main-key"

	RMQ_SEGMENT_SERVICE_MAIN_QUEUE_KEY = "segment-service-main-queue-key"

	RMQ_DEAD_LETTER_QUEUE_DELAY_MS          = 5000 * 60
	RMQ_DEAD_LETTER_QUEUE_TWELVE_HRS_TTL_MS = 12 * 60 * 60 * 1000
	RMQ_DEAD_LETTER_QUEUE_THIRTY_MIN_TTL_MS = 30 * 60 * 1000
)
