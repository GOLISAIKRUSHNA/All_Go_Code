package services

import (
	"collection-service/internal/app/services/storage/cacheservice"
)

type IBaseService interface {
	SetCacheInstance(cache *cacheservice.BaseCacheService)
	GetCacheInstance() *cacheservice.BaseCacheService
}
