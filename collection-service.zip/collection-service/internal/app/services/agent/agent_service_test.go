package agent

//import (
//	"collection-handler/internal/app/services/mocks"
//	"testing"
//
//	"github.com/golang/mock/gomock"
//)
//
//// initializes asset and feature store mocks.
//func initializeMock(t *testing.T) (*mock_otp.MockIOtpService, *services.MockAssetFeature, *services.MockSubscriptionFeature, *services.MockStatusHistory, handlers.Service) {
//	mockCtrl := gomock.NewController(t)
//	defer mockCtrl.Finish()
//
//	//mockAssetStore := services.NewMockAsset(mockCtrl)
//	//mockAssetFeatureStore := services.NewMockAssetFeature(mockCtrl)
//	//mockSubscriptionFeatureStore := services.NewMockSubscriptionFeature(mockCtrl)
//	//mockStatusHistory := services.NewMockStatusHistory(mockCtrl)
//	mockOtpService := mocks.NewMockIOtpService(mockCtrl)
//	mockAgentRepo := mocks.New
//
//	return mockOtpService, mockAssetFeatureStore, mockSubscriptionFeatureStore, mockStatusHistory,
//		New(mockAssetStore, mockAssetFeatureStore, mockSubscriptionFeatureStore, mockStatusHistory)
//}
