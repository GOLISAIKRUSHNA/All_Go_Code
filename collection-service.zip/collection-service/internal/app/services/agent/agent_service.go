package agent

import (
	config "collection-service"
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/adapter/permify"
	"collection-service/internal/app/constants"
	eventConstants "collection-service/internal/app/constants/events"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	jwt_token "collection-service/internal/app/services/token"
	"collection-service/internal/dto"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"fmt"
	"reflect"
	"slices"
	"strings"
	"time"

	"github.com/golang-jwt/jwt"

	"github.com/mitchellh/mapstructure"

	"errors"

	"github.com/spf13/viper"

	_ "github.com/go-sql-driver/mysql"
)

type AgentService struct {
	services.BaseService
	agentRepo           repo_interfaces.IAgentRepository
	attendanceRepo      repo_interfaces.IAttendanceRepository
	agentRoleMapRepo    repo_interfaces.IAgentRoleMappingRepo
	agentRoleRepo       repo_interfaces.IAgentRoleRepository
	serviceProviderRepo repo_interfaces.IServiceProviderRepository
	awsS3               aws.S3Client
	permify             *permify.PermifyClient
	cacheEnabled        bool
}

const MOBILE_AND_MOBILE_NO_OTP = "mobile_number&mobile_number_otp"
const USERNAME_AND_PASSWORD = "username&password"

// Initialization of AgentService with respect to the interface IAgentService
// Accepts only context as a parameter and hardcodes the loanKey, searchKey and cacheEnabled from .env variables
// Returns the AgentService pointer instance to the caller
func InitAgentService(ctx context.Context) *AgentService {
	service := &AgentService{
		agentRepo:           repositories.InitAgentRepository(ctx),
		attendanceRepo:      repositories.InitAttendanceRepository(ctx),
		agentRoleMapRepo:    repositories.InitAgentRoleMappingRepo(ctx),
		agentRoleRepo:       repositories.InitAgentRoleRepository(ctx),
		serviceProviderRepo: repositories.InitServiceProviderRepository(ctx),
		awsS3:               *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
		permify:             permify.GetPermifyClientInstance(ctx),
		cacheEnabled:        viper.GetBool("REDIS_ENABLED"),
	}

	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func generateAgentClaims(agent *models.Agent) (agentClaims *jwt_token.Claims) {
	agentClaims = &jwt_token.Claims{

		Object:          enum.USER_AGENT,
		ObjectRefNumber: agent.AgentRefNumber,
		Name:            agent.FirstName + " " + agent.LastName,

		ServiceProviderRefNumber: agent.ServiceProviderRefNumber,
		StandardClaims:           jwt.StandardClaims{},
		Roles:                    []string{agent.Role.String()},
	}

	return
}

func getAgentClaims(agent *models.Agent) (agentClaims *jwt_token.Claims) {
	agentClaims = &jwt_token.Claims{
		Object:          enum.USER_AGENT,
		ObjectRefNumber: agent.AgentRefNumber,
		Name:            agent.FirstName + " " + agent.LastName,

		ServiceProviderRefNumber: agent.ServiceProviderRefNumber,
		StandardClaims:           jwt.StandardClaims{},
		Roles:                    []string{agent.Role.String()},
	}
	return
}

func updateAgentClaims(updatedAgent *models.Agent, prevClaims *jwt_token.Claims, agent *models.Agent, req *request.UpdateAgentReq) {
	if len(prevClaims.Roles) > 0 &&
		updatedAgent.Role != enum.AgentRole(0) &&
		updatedAgent.Role != enum.StringToAgentRole(prevClaims.Roles[0]) {
		prevClaims.Roles = []string{updatedAgent.Role.String()}
	}

	firstName := agent.FirstName
	if req.FirstName != "" {
		firstName = req.FirstName
	}
	lastName := agent.LastName
	if req.LastName != "" {
		lastName = req.LastName
	}

	prevClaims.Name = firstName + " " + lastName
	return
}

func getToken(ctx context.Context, claims *jwt_token.Claims) string {
	// send token after successful validation
	token, err := claims.GetNewAccessToken()
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}
	return token
}

func (s *AgentService) GetAgentInfo(ctx context.Context, agentRefNumber string) (response.AgentInfoResponse, error) {
	//making sure agentRefNumber cannot be empty
	if agentRefNumber == "" {
		utils.BadRequestException(ctx, constants.NOT_FOUND_ERROR_CODE, "agent reference number cannot be empty!", nil, nil)
	}

	agent, err := s.agentRepo.GetAgentInfo(ctx, agentRefNumber)

	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	// fetching user info
	_, successResp, _, success, err := service_calls.GetUserInfo(ctx, agentRefNumber)
	if !success && err == nil {
		err = errors.New("unable to fetch user info for agent ref number: " + agentRefNumber)
	}
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}
	var getUserResp response.UserInfoResponse

	decoder, err := GetUserInfoMapstructDecoder(&getUserResp)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	err = decoder.Decode(successResp.Data)
	if err != nil {
		logger.Error(ctx, err, "unable to decode response received from user info",
			logger.LogFields{"agentRefNumber": agentRefNumber})
		utils.InternalServerError(ctx, err, "")
	}

	agentInfoResponseObject := response.AgentInfo{
		AgentRefNumber:            agent.AgentRefNumber,
		ServiceProviderRefNumber:  agent.ServiceProviderRefNumber,
		ServiceProviderName:       agent.ServiceProviderInfo.Name,
		FirstName:                 agent.FirstName,
		LastName:                  agent.LastName,
		MobileNumber:              agent.MobileNumber,
		Email:                     agent.Email,
		Status:                    agent.Status,
		ReportingManagerRefNumber: agent.ReportingManagerRefNumber,
		LanguagesSupported:        agent.LanguagesSupported,
		CashCollectionLimit:       agent.CashCollectionLimit,
		CashDepositByDays:         agent.CashDepositByDays,
		Designation:               agent.Designation,
		AgentRole:                 agent.Role,
		AgentVisibility:           agent.Visibility,
		EmployeeID:                agent.EmployeeId,
		TeamRefNumber:             agent.ServiceProviderTeamRefNumber,
		TeamName:                  agent.TeamInfo.Name,
	}

	agentInfoResponseObject.PhotoPath, err = s.awsS3.GetSharableURL(ctx, agent.PhotoPath, constants.SERVICE_PROVIDER_DOCS)
	if err != nil {
		logger.Error(ctx, err, "unable to decode image from saved file path", logger.LogFields{
			agentRefNumber: agent.AgentRefNumber})
	}

	if agent.ReportingManagerInfo != nil {
		agentInfoResponseObject.ReportingManagerName = agent.ReportingManagerInfo.FirstName + " " + agent.ReportingManagerInfo.LastName
	} else if agent.ReportingManagerRefNumber != "" {
		logger.Warn(ctx, "reporting manager not found",
			logger.LogFields{"reporting_manager_ref_number": agent.ReportingManagerRefNumber})
	}
	//Get the attendance of today for this user
	is_attendance_pending := true
	//todaysDate := time.Now().Format("2006-01-02")
	filters := models.Attendance{AgentRefNumber: agent.AgentRefNumber, AttendanceDate: time.Now().Format("2006-01-02")}
	attendances, err := s.attendanceRepo.FindMany(ctx, &filters)
	if err != nil {
		logger.Error(ctx, err, "AgentAttendanceService|MarkAttendance|err", nil)
		utils.InternalServerError(ctx, err, "AgentAttendanceService|MarkAttendance|err")
	}

	for i := range attendances {
		if attendances[i].ApprovalStatus == "APPROVED" || attendances[i].ApprovalStatus == "PENDING" {
			is_attendance_pending = false
		}
	}
	agentInfoResponseObject.IsAttendancePending = is_attendance_pending

	agentInfoResponse := response.AgentInfoResponse{
		Agent: agentInfoResponseObject,
	}

	return agentInfoResponse, nil

}

func GetUserInfoMapstructDecoder(userInfoResp *response.UserInfoResponse) (*mapstructure.Decoder, error) {
	config := &mapstructure.DecoderConfig{
		DecodeHook: mapstructure.ComposeDecodeHookFunc(
			func(f reflect.Type, t reflect.Type, data interface{}) (interface{}, error) {
				if f == reflect.TypeOf("") && t == reflect.TypeOf(enum.UserObject(0)) {
					return enum.StringToUserObject(data.(string)), nil
				}
				return data, nil
			},
		),
		Result: userInfoResp,
	}

	decoder, err := mapstructure.NewDecoder(config)
	if err != nil {
		fmt.Println("Error while creating userInfoResponse decoder:", err)
		return nil, err
	}
	return decoder, nil
}

func (s *AgentService) GetAgentCollectionSummary(ctx context.Context, agentRefNumber string) (response.AgentCollectionSummaryResponse, error) {
	if agentRefNumber == "" {
		//agentRefNumber should be present.
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "invalid agent reference number", nil, nil)
	}

	res := response.AgentCollectionSummaryResponse{
		TotalCollection:     50000,
		TodayCollection:     2000,
		YesterdayCollection: 4000,
		PendingDeposit:      0,
		UnverifiedAmount:    45000,
	}
	return res, nil
}
func (s *AgentService) GetAllTheAgentsWithMatchingName(ctx context.Context, req request.AutoSuggestParams, pagination dto.PaginationData) (response.AgentAutoSuggestResponse, error) {
	if pagination.CurrentPage <= 0 {
		pagination.CurrentPage = 1
	}
	// calling Init() func to set the value
	pagination = dto.Init(pagination.CurrentPage)
	agentModel := transformRequestToAgentModel(req)

	result, totalRecords, err := s.agentRepo.GetAgentsMatchingByName(ctx, agentModel, pagination)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	// Calculating totalPages based on totalRecords
	totalPages := totalRecords / pagination.Limit
	if totalRecords%pagination.Limit > 0 {
		totalPages++
	}
	autoSuggestResults := response.AgentAutoSuggestResponse{
		Agents:         []response.AgentAutoSuggestedAgent{},
		PaginationData: response.PaginationData{Pages: totalPages, CurrentPage: pagination.CurrentPage},
	}

	for _, a := range result {
		agentInfo := response.AgentAutoSuggestedAgent{
			AgentRefNumber: a.AgentRefNumber,
			FirstName:      a.FirstName,
			LastName:       a.LastName,
			Email:          a.Email,
			TeamRefNumber:  a.ServiceProviderTeamRefNumber,
			TeamName:       a.TeamInfo.Name,
		}
		autoSuggestResults.Agents = append(autoSuggestResults.Agents, agentInfo)
	}
	return autoSuggestResults, nil

}

func transformRequestToAgentModel(req request.AutoSuggestParams) *models.Agent {
	data := &models.Agent{
		FirstName:                    req.Name,
		ServiceProviderRefNumber:     req.ServiceProviderRefNumber,
		ServiceProviderTeamRefNumber: req.TeamRefNumber,
	}
	return data
}

// Create Agent
// Need to discuss about error return type
func (s *AgentService) Create(ctx context.Context, req request.CreateAgentReq) (string, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	var details []dto.RequestDetails
	if req.Email == "" && req.Username == "" {
		logger.Error(ctx, nil, "email or username should be present", nil)
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "email or username should be present", nil, nil)
	}

	// getServiceProviderInfo using serviceProviderRefNumber
	serviceProviderInfo, err := s.serviceProviderRepo.FindOne(ctx, models.ServiceProvider{ServiceProviderRefNumber: req.ServiceProviderRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "unable to get service provider info")
	}
	orgID := serviceProviderInfo.OrgID

	languages1 := req.LanguagesSupported
	ValidateLanguagesSupported(languages1)

	// check if mobile number and org_id are present
	if req.MobileNumber != "" && orgID != "" {
		result, err := s.agentRepo.FindOne(ctx, &models.Agent{MobileNumber: req.MobileNumber, OrgID: orgID})
		if err == nil || result != nil {
			// give error in requestDetails
			details = append(details, dto.RequestDetails{
				Field:   "mobile_number",
				Message: constants.GetErrMsg(constants.MOBILE_AND_ORGID_ALREADY_EXISTS),
			})
			logger.Error(ctx, err, "AgentService|Create|Mobile number record already present with this org_id!", nil)
			utils.BadRequestException(ctx, constants.MOBILE_AND_ORGID_ALREADY_EXISTS, constants.GetErrMsg(constants.MOBILE_AND_ORGID_ALREADY_EXISTS), nil, details)

		}
	}
	// check if email and org_id are present
	if req.Email != "" && orgID != "" {
		result, err := s.agentRepo.FindOne(ctx, &models.Agent{Email: req.Email, OrgID: orgID})
		if err == nil || result != nil {
			details = append(details, dto.RequestDetails{
				Field:   "email",
				Message: constants.GetErrMsg(constants.EMAIL_AND_ORGID_ALREADY_EXISTS),
			})
			logger.Error(ctx, err, "AgentService|Create|Email record already present!", nil)
			utils.BadRequestException(ctx, constants.EMAIL_AND_ORGID_ALREADY_EXISTS, constants.GetErrMsg(constants.EMAIL_AND_ORGID_ALREADY_EXISTS), nil, details)

		}
	}
	if req.Username != "" {
		// check if username already exists if present.
		isExists := CheckUsernameExistence(ctx, req.Username)
		if isExists {
			var details []dto.RequestDetails
			details = append(details, dto.RequestDetails{Field: "username", Message: "username already exists"})
			utils.BadRequestException(ctx, "", "username already exists", nil, details)
		}
	}

	passwordString, err := utils.Base64Decode(req.Password)
	if err != nil {
		logger.Error(ctx, err, "unable to decode password", logger.LogFields{"password": req.Password})
	}

	// call utils.ValidatePassword to validate password
	isValidate, details := utils.ValidatePassword(passwordString)
	if !isValidate {
		utils.BadRequestException(ctx, constants.PASSWORD_INVALID, "invalid password entered", nil, details)
	}

	var res models.Agent

	//supported languages from config
	languages := req.LanguagesSupported
	languagesString := ValidateLanguagesSupported(languages)
	if len(languagesString) < 0 {
		//return "", errors.New("enter a valid language")
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "enter a valid language", nil, nil)
	}
	newAgent := getAgentModelFromCreateAgentReq(req, "CREATE")
	newAgent.OrgID = orgID
	if newAgent.Status == 0 {
		newAgent.Status = enum.ACTIVE
	}

	newAgent.LanguagesSupported = languagesString

	// upload agent photo
	var filePath string
	if req.PhotoBase64String != "" {
		contentType, errTypeErr := utils.GetBase64ContentType(req.PhotoBase64String)
		if errTypeErr != nil {
			logger.Error(ctx, errTypeErr, "agent_service|Create|contentTypeError", logger.LogFields{"base64 image": req.PhotoBase64String})
		}
		extention := strings.Split(contentType, "/")
		filePath = "agent-photos" + "/" + utils.GenerateRandomString(6, "") + "." + extention[1]

		uploadErr := s.awsS3.UploadBase64Image(ctx, filePath, constants.SERVICE_PROVIDER_DOCS, req.PhotoBase64String, contentType)
		if uploadErr != nil {
			logger.Error(ctx, err, "agent_service|Create|update.uploadError", logger.LogFields{"file": req.PhotoBase64String})
		}
	}

	newAgent.PhotoPath = filePath

	// If the agent doesn't exist , create a new one
	res, err = s.agentRepo.Create(ctx, newAgent)
	if err != nil {
		utils.InternalServerError(ctx, err, "unable to create agent")
	}

	agentEvent := transformToAgentEventReq(res, req.Password)
	agentEvent.Username = req.Username
	agentEvent.OrgID = orgID

	// generate agent Claims
	agentEvent.Claims = generateAgentClaims(&res)

	err = adapter.PublishEvent(ctx, []string{constants.RMQ_AUTH_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_DIALER_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, agentEvent, eventConstants.AGENT_CREATED, nil)
	if err != nil {
		logger.Error(ctx, err, "unable to publish event", logger.LogFields{"event": agentEvent})
	}
	return "", nil
}

func CheckUsernameExistence(ctx context.Context, username string) bool {

	_, successResp, _, success, err := service_calls.UserExists(ctx, request.UserExistsReq{Username: username})
	if err != nil || !success {
		var msg string
		if err == nil {
			msg = "unable to check user existence."
			err = fmt.Errorf(msg)
		}

		logger.Error(ctx, err, msg, nil)
		utils.InternalServerError(ctx, err, msg)
	}

	var userExistsResp response.UserExistsResponse
	jsonData, err := json.Marshal(successResp.Data)
	if err != nil {
		logger.Error(ctx, err, "collection-service|AgentService|Payload marshal error", logger.LogFields{"payload": successResp.Data})
		utils.InternalServerError(ctx, err, "")
	}

	if err := json.Unmarshal(jsonData, &userExistsResp); err != nil {
		logger.Error(ctx, err, "collection-service|AgentService|Payload  unmarshal error", logger.LogFields{"jsondata": jsonData})
		utils.InternalServerError(ctx, err, "")
	}

	return userExistsResp.IsExists
}

func CheckUsernameExistenceExceptSelf(ctx context.Context, username, objectRefNumber string) bool {
	_, successResp, _, success, err := service_calls.UserExistsExceptSelf(ctx, request.UserExistsReq{Username: username}, objectRefNumber)
	if err != nil || !success {
		var msg string
		if err == nil {
			msg = "unable to check user existence."
			err = fmt.Errorf(msg)
		}

		logger.Error(ctx, err, msg, nil)
		utils.InternalServerError(ctx, err, msg)
	}

	var userExistsResp response.UserExistsResponse
	jsonData, err := json.Marshal(successResp.Data)
	if err != nil {
		logger.Error(ctx, err, "collection-service|AgentService|Payload marshal error", logger.LogFields{"payload": successResp.Data})
		utils.InternalServerError(ctx, err, "")
	}

	if err := json.Unmarshal(jsonData, &userExistsResp); err != nil {
		logger.Error(ctx, err, "collection-service|AgentService|Payload  unmarshal error", logger.LogFields{"jsondata": jsonData})
		utils.InternalServerError(ctx, err, "")
	}

	return userExistsResp.IsExists
}

func transformAgentToUpdateUserReq(ctx context.Context, updateAgentReq request.UpdateAgentReq, agentModel *models.Agent, agentRefNumber string) events.AgentUpdatedEvent {
	updateUserReq := events.AgentUpdatedEvent{
		AgentRefNumber:                    agentRefNumber,
		Claims:                            getAgentClaims(agentModel),
		Username:                          updateAgentReq.Username,
		PreviousReportingManagerRefNumber: agentModel.ReportingManagerRefNumber,
		PreviousRole:                      agentModel.Role,
		ReportingManagerRefNumber:         updateAgentReq.ReportingManagerRefNumber,
		Role:                              updateAgentReq.AgentRole,
		ServiceProviderRefNumber:          agentModel.ServiceProviderRefNumber,
		Email:                             updateAgentReq.Email,
		FirstName:                         updateAgentReq.FirstName,
		LastName:                          updateAgentReq.LastName,
		MobileNumber:                      updateAgentReq.MobileNumber,
	}

	return updateUserReq
}

// Update Agent
func (s *AgentService) Update(ctx context.Context, req request.UpdateAgentReq, agentRefNumber string) (string, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	var details []dto.RequestDetails
	result, err := s.agentRepo.FindOne(ctx, &models.Agent{AgentRefNumber: agentRefNumber})
	if err != nil || result == nil {
		if err == nil {
			err = fmt.Errorf("unable to find agent with agentRefNumber: %s", agentRefNumber)
		}
		utils.InternalServerError(ctx, err, "")
	}

	if req.Email != "" {
		result, err := s.agentRepo.FindOneExceptAgent(ctx, &models.Agent{Email: req.Email}, []string{agentRefNumber})
		if err == nil || result != nil {
			details = append(details, dto.RequestDetails{
				Field:   "email",
				Message: constants.GetErrMsg(constants.EMAIL_ALREADY_EXISTS),
			})
			logger.Error(ctx, err, "AgentService|Update|Email record already present!", nil)
			utils.BadRequestException(ctx, constants.EMAIL_ALREADY_EXISTS, constants.GetErrMsg(constants.EMAIL_ALREADY_EXISTS), nil, details)
		}

	}

	if req.MobileNumber != "" {
		result, err := s.agentRepo.FindOneExceptAgent(ctx, &models.Agent{MobileNumber: req.MobileNumber}, []string{agentRefNumber})
		if err == nil || result != nil {
			details = append(details, dto.RequestDetails{
				Field:   "mobile_number",
				Message: constants.GetErrMsg(constants.MOBILE_ALREADY_EXISTS),
			})

			logger.Error(ctx, err, "AgentService|Update|Mobile number record already present!", nil)
			utils.BadRequestException(ctx, constants.MOBILE_ALREADY_EXISTS, constants.GetErrMsg(constants.MOBILE_ALREADY_EXISTS), nil, details)
		}

	}

	params := models.Agent{
		AgentRefNumber: agentRefNumber,
	}

	//supported languages from config
	languages := req.LanguagesSupported
	languagesString := ValidateLanguagesSupported(languages)
	if len(languagesString) < 0 {
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "enter a valid language", nil, nil)
	}

	agentModel := models.Agent{
		LanguagesSupported:        languagesString,
		Email:                     req.Email,
		MobileNumber:              req.MobileNumber,
		ReportingManagerRefNumber: req.ReportingManagerRefNumber,
		Designation:               req.Designation,
		CashCollectionLimit:       req.CashCollectionLimit,
		CashDepositByDays:         req.CashDepositByDays,
		Role:                      req.AgentRole,
		Visibility:                req.AgentVisibility,
		Status:                    req.Status,
		FirstName:                 req.FirstName,
		LastName:                  req.LastName,
	}

	// upload agent photo
	var filePath string
	if req.PhotoBase64String != "" {
		contentType, errTypeErr := utils.GetBase64ContentType(req.PhotoBase64String)
		if errTypeErr != nil {
			logger.Error(ctx, errTypeErr, "agent_service|Create|contentTypeError", logger.LogFields{"base64 image": req.PhotoBase64String})
		}
		extention := strings.Split(contentType, "/")
		filePath = "agent-photos" + "/" + utils.GenerateRandomString(6, "") + "." + extention[1]

		uploadErr := s.awsS3.UploadBase64Image(ctx, filePath, constants.SERVICE_PROVIDER_DOCS, req.PhotoBase64String, contentType)
		if uploadErr != nil {
			logger.Error(ctx, err, "agent_service|Create|update.uploadError", logger.LogFields{"file": req.PhotoBase64String})
		}
	}
	agentModel.PhotoPath = filePath

	isUpdated, err := s.agentRepo.Update(ctx, &params, &agentModel)
	if err != nil || !isUpdated {
		if err == nil {
			err = fmt.Errorf("unable to update agent with agentRefNumber: %s", agentRefNumber)
		}
		utils.InternalServerError(ctx, err, "")
	}

	agentUpdatedEvent := transformAgentToUpdateUserReq(ctx, req, result, agentRefNumber)
	if req.Username != "" {
		// check if username already exists
		isExists := CheckUsernameExistenceExceptSelf(ctx, req.Username, agentRefNumber)
		if isExists {
			var details []dto.RequestDetails
			details = append(details, dto.RequestDetails{Field: "username", Message: "username already exists"})
			utils.BadRequestException(ctx, "", "username already exists", nil, details)
		}
	}

	serviceProviderInfo, err := s.serviceProviderRepo.FindOne(ctx, models.ServiceProvider{ServiceProviderRefNumber: result.ServiceProviderRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "unable to get service provider info")

	}
	agentUpdatedEvent.OrgID = serviceProviderInfo.OrgID

	// create user after successful user creation
	updateAgentClaims(&agentModel, agentUpdatedEvent.Claims, result, &req)
	// TODO: remove/handle dialer service queue key
	adapter.PublishEvent(ctx, []string{constants.RMQ_AUTH_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_DIALER_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, agentUpdatedEvent, eventConstants.AGENT_UPDATED, nil)

	// update permify role if changed for this user.

	return "", nil
}

// FindAllUnexpired Agent
func (s *AgentService) FindAgentList(ctx context.Context, req request.GetAgent, pagination dto.PaginationData) (response.GetAgentResp, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)
	search := req.Search
	if pagination.CurrentPage <= 0 {
		pagination.CurrentPage = 1
	}
	// calling Init() func to set the value
	pagination = dto.Init(pagination.CurrentPage)
	agent := models.Agent{
		ServiceProviderRefNumber: req.ServiceProviderRefNumber,
		FirstName:                req.FirstName,
		LastName:                 req.LastName,
		MobileNumber:             req.MobileNumber,
		Email:                    req.Email,
		//Username:                  req.Username,
		ReportingManagerRefNumber: req.ReportingManagerRefNumber,
		Status:                    req.Status,
		Role:                      req.Role,
		Visibility:                req.Visibility,
		AgentRefNumber:            req.AgentRefNumber,
	}
	agentRes, totalRecords, err := s.agentRepo.FindAgentList(ctx, &agent, search, pagination)

	// Calculating totalPages based on totalRecords
	totalPages := totalRecords / pagination.Limit
	if totalRecords%pagination.Limit > 0 {
		totalPages++
	}

	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	resp := transformAgentResponse(ctx, s, agentRes)

	return response.GetAgentResp{Agents: resp, PaginationData: response.PaginationData{CurrentPage: pagination.CurrentPage, Pages: totalPages}}, nil
}

func transformAgentResponse(ctx context.Context, s *AgentService, agent []models.Agent) []response.Agent {
	var res []response.Agent

	for i := range agent {
		respAgent := response.Agent{
			FirstName:                 agent[i].FirstName,
			LastName:                  agent[i].LastName,
			MobileNumber:              agent[i].MobileNumber,
			Email:                     agent[i].Email,
			Status:                    agent[i].Status,
			CashCollectionLimit:       agent[i].CashCollectionLimit,
			CashDepositByDays:         agent[i].CashDepositByDays,
			ReportingManagerRefNumber: agent[i].ReportingManagerRefNumber,
			CreatedBy:                 agent[i].CreatedBy,
			ServiceProviderRefNumber:  agent[i].ServiceProviderRefNumber,
			Role:                      agent[i].Role,
			EmployeeID:                agent[i].EmployeeId,
			AgentRefNumber:            agent[i].AgentRefNumber,
			Visibility:                agent[i].Visibility,
			TeamName:                  agent[i].TeamInfo.Name,
			Designation:               agent[i].Designation,
			TeamRefNumber:             agent[i].ServiceProviderTeamRefNumber,
		}

		if agent[i].ReportingManagerInfo != nil {
			respAgent.ReportingManagerName = agent[i].ReportingManagerInfo.FirstName + " " + agent[i].ReportingManagerInfo.LastName
		} else if agent[i].ReportingManagerRefNumber != "" {
			logger.Warn(ctx, "reporting manager not found",
				logger.LogFields{"reporting_manager_ref_number": agent[i].ReportingManagerRefNumber})
		}

		var err error
		respAgent.PhotoPath, err = s.awsS3.GetSharableURL(ctx, agent[i].PhotoPath, constants.SERVICE_PROVIDER_DOCS)
		if err != nil {
			logger.Error(ctx, err, "unable to decode image from saved file path", logger.LogFields{
				"agentRefNumber": agent[i].AgentRefNumber})
		}

		if agent[i].LanguagesSupported != "" {
			respAgent.LanguagesSupported = strings.Split(agent[i].LanguagesSupported, ",")
		}

		res = append(res, respAgent)
	}
	return res
}
func getAgentModelFromCreateAgentReq(req request.CreateAgentReq, action string) models.Agent {
	data := models.Agent{
		FirstName:    req.FirstName,
		LastName:     req.LastName,
		MobileNumber: req.MobileNumber,
		Email:        req.Email,
		//Username:                  req.Username,
		//Password:                  req.Password,
		//HasPanelAccess:            req.HasPanelAccess,
		//HasAppAccess:              req.HasAppAccess,
		Status:                       req.Status,
		CashCollectionLimit:          req.CashCollectionLimit,
		Designation:                  req.Designation,
		CashDepositByDays:            req.CashDepositByDays,
		ReportingManagerRefNumber:    req.ReportingManagerRefNumber,
		CreatedBy:                    req.CreatedBy,
		UpdatedBy:                    req.UpdatedBy,
		ServiceProviderRefNumber:     req.ServiceProviderRefNumber,
		EmployeeId:                   req.EmployeeID,
		ServiceProviderTeamRefNumber: req.TeamRefNumber,
	}

	if req.AgentRole == enum.AgentRole(0) {
		data.Role = enum.AGENT_ROLE_FIELD_AGENT
	} else {
		data.Role = req.AgentRole
	}

	if req.AgentVisibility == enum.AgentVisibility(0) {
		data.Visibility = enum.AGENT_VIS_SELF_REPORTEE_LEVEL
	} else {
		data.Visibility = req.AgentVisibility
	}

	if action == "CREATE" {
		return data
	}
	return data
}

func ValidateLanguagesSupported(languages []string) string {

	languagesSupported := config.AppConfig.GetStringSlice("product_config.languages_supported")

	// convert all supported languages to lower case for easy comparison.
	for i := range languagesSupported {
		languagesSupported[i] = strings.TrimSpace(strings.ToLower(languagesSupported[i]))
	}

	var languagesString string
	var validLanguages []string

	for i := range languages {
		languages[i] = strings.TrimSpace(strings.ToLower(languages[i]))
		isPresent := slices.Contains(languagesSupported, languages[i])
		if isPresent {
			validLanguages = append(validLanguages, languages[i])
			languagesString = strings.Join(validLanguages, ",")
		}
	}

	return languagesString
}

func transformToAgentEventReq(agent models.Agent, base64Password string) events.AgentCreatedEvent {
	return events.AgentCreatedEvent{
		FirstName:                 agent.FirstName,
		LastName:                  agent.LastName,
		MobileNumber:              agent.MobileNumber,
		Password:                  base64Password,
		AgentRefNumber:            agent.AgentRefNumber,
		ServiceProviderRefNumber:  agent.ServiceProviderRefNumber,
		Role:                      agent.Role,
		Visibility:                agent.Visibility,
		Email:                     agent.Email,
		Object:                    enum.USER_AGENT,
		ObjectRefNumber:           agent.AgentRefNumber,
		ReportingManagerRefNumber: agent.ReportingManagerRefNumber,
	}
}
