package agent

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IAgentService interface {
	services.IBaseService

	GetAllTheAgentsWithMatchingName(ctx context.Context, req request.AutoSuggestParams, pagination dto.PaginationData) (response.AgentAutoSuggestResponse, error)
	Create(ctx context.Context, req request.CreateAgentReq) (string, error)
	Update(ctx context.Context, req request.UpdateAgentReq, agentReNumber string) (string, error)
	FindAgentList(ctx context.Context, req request.GetAgent, pagination dto.PaginationData) (response.GetAgentResp, error)
	GetAgentCollectionSummary(ctx context.Context, agentRefNumber string) (response.AgentCollectionSummaryResponse, error)
	GetAgentInfo(ctx context.Context, agentRefNumber string) (response.AgentInfoResponse, error)
}
