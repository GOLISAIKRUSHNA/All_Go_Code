package agent

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/spf13/viper"

	_ "github.com/go-sql-driver/mysql"
)

type AgentAttendanceService struct {
	services.BaseService
	agentRepo      repo_interfaces.IAgentRepository
	attendanceRepo repo_interfaces.IAttendanceRepository
	awsS3          adapter.IFileManager
	cacheEnabled   bool
}

// Initialization of AgentAttendanceService with respect to the interface IAgentAttendanceService
// Returns the AgentAttendanceService pointer instance to the caller
func InitAgentAttendanceService(ctx context.Context, agentRepo repo_interfaces.IAgentRepository, attendanceRepo repo_interfaces.IAttendanceRepository) *AgentAttendanceService {
	service := &AgentAttendanceService{
		agentRepo:      agentRepo,
		attendanceRepo: attendanceRepo,
		awsS3:          aws.GetS3Instance(),
		cacheEnabled:   viper.GetBool("REDIS_ENABLED"),
	}

	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func getAttendanceModelFromMarkAttendanceReq(req request.MarkAttendanceReq) models.Attendance {

	now := time.Now()

	//TODO : Handle lat long to point and enum switch for Attendance type
	data := models.Attendance{

		AgentRefNumber: req.AgentRefNumber,
		//Location:       clause.Expr{SQL: "ST_PointFromText(?)", Vars: []interface{}{"POINT(100 100)"}},
		MarkDatetime: now,
		MarkType:     enum.FULL_DAY,
		//SelfieFilePath: req.,
		ApprovalStatus: "PENDING",
	}
	return data
}

// MarkAttendance
func (s *AgentAttendanceService) MarkAttendance(ctx context.Context, req request.MarkAttendanceReq) (string, error) {

	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	//Check if attendance date is in the future
	if req.AttendanceDate > time.Now().Format("2006-01-02 15:04:05") {
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "Attendance Date is in the Future", nil, nil)
	}

	//Check if the Agent exists and is active.
	result, err := s.agentRepo.FindOne(ctx, &models.Agent{AgentRefNumber: req.AgentRefNumber})
	if err != nil || result == nil {
		logger.Error(ctx, err, "Agent not found", nil)
		utils.BadRequestException(ctx, constants.AGENT_REF_NUMBER_INVALID, constants.GetErrMsg(constants.AGENT_REF_NUMBER_INVALID), nil, nil)
	}

	attendanceDate, err := time.Parse(time.DateOnly, req.AttendanceDate)
	if err != nil {
		logger.Error(ctx, err, "Error Parsing Attendance Date", nil)
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "Invalid Date Format", nil, nil)
	}

	//See if a similar attendance is already present, if yes, return details

	filters := models.Attendance{AgentRefNumber: req.AgentRefNumber, AttendanceDate: attendanceDate.Format("2006-01-02")}
	attendances, err := s.attendanceRepo.FindMany(ctx, &filters)
	if err != nil {
		logger.Error(ctx, err, "AgentAttendanceService|MarkAttendance|err", nil)
		utils.InternalServerError(ctx, err, "AgentAttendanceService|MarkAttendance|err")
	}

	for i := range attendances {
		if attendances[i].ApprovalStatus != "REJECTED" {
			utils.BadRequestException(ctx, constants.ATTENDANCE_ALREADY_PRESENT, constants.GetErrMsg(constants.ATTENDANCE_ALREADY_PRESENT), nil, nil)
		}
	}

	//TODO : check if the image has a detectable face.

	//Save the attendance image to S3
	var filePath string
	if req.AttendanceSelfieBase64String != "" {
		contentType, err := utils.GetBase64ContentType(req.AttendanceSelfieBase64String)
		if err != nil {
			logger.Error(ctx, err, "Error converting Base64 image", nil)
			utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "Invalid Base64 Image", nil, nil)
		}
		extension := strings.Split(contentType, "/")
		filePath = fmt.Sprintf("attendance-photos/%s/%s.%s", req.AttendanceDate, utils.GenerateRandomString(6, ""), extension[1])
		s.awsS3.UploadBase64Image(ctx, filePath, constants.SERVICE_PROVIDER_ATTENDANCE_BUCKET, req.AttendanceSelfieBase64String, contentType)
	}

	//If Not Add a New Attendance Entry
	newAttendance := getAttendanceModelFromMarkAttendanceReq(req)
	newAttendance.AttendanceDate = attendanceDate.Format("2006-01-02")
	newAttendance.SelfieFilePath = filePath
	createResult, err := s.attendanceRepo.Create(ctx, &newAttendance)
	if err != nil || createResult == false {
		logger.Error(ctx, err, "Could Not Create Attendance", nil)
		utils.InternalServerError(ctx, err, "Attendance Service > Attendance Repo > Create")
	}
	return "", err
}

// GetAttendance
func (s *AgentAttendanceService) GetAttendance(ctx context.Context, req request.GetAttendanceReq) (response.GetAttendanceResp, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	//Check if the attedance request is for self or for the reportees
	//If for reportees, get the list of reportees who are field agents.
	var agentRefNumbers []string
	//compare req.AttendanceRequestScope with the enum values of Hierarchy Scope for ALL_REPORTEES

	if req.AttendanceRequestScope == enum.ALL_REPORTEES {

		//Find Reportees from the Agent Repo
		agentRes, err := s.agentRepo.FindReportees(ctx, req.AgentRefNumber)
		if err != nil {
			utils.InternalServerError(ctx, err, "Attendance Service > Agent Repo > Find Reportees")
		}
		//iterate over agentRes and create string array of agentRefNumbers
		for i := range agentRes {
			agentRefNumbers = append(agentRefNumbers, agentRes[i].AgentRefNumber)
		}
	} else if req.AttendanceRequestScope == enum.OWN_SELF {
		//Request only for oneself
		agentRefNumbers = append(agentRefNumbers, req.AgentRefNumber)
	} else {
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "Invalid Attendance Request Type", nil, nil)
	}

	//get all attendances from attendance repo matching the string array or agent reference numbers and the approval status
	attendances, err := s.attendanceRepo.FindManyByAgentRefNumbers(ctx, agentRefNumbers, req.ApprovalStatus)
	if err != nil {
		utils.InternalServerError(ctx, err, "Attendance Service > Attendance Repo > Find FindManyByAgentRefNumbers")
	}

	//Return the array of attendances in the response
	return response.GetAttendanceResp{Attendances: transformAttendanceResponse(ctx, s, attendances)}, nil

}

func (s *AgentAttendanceService) UpdateAttendances(ctx context.Context, req request.AttendanceUpdateReq) (string, error) {

	//TODO :  Verify that all Attendances exists and are in pending status
	//TODO:  Attendances all belong to reportees of the given agent

	//Check if the Agent exists and is active.
	result, err := s.agentRepo.FindOne(ctx, &models.Agent{AgentRefNumber: req.AgentRefNumber})
	if err != nil || result == nil {
		logger.Error(ctx, err, "Agent not found", nil)
		utils.BadRequestException(ctx, constants.AGENT_REF_NUMBER_INVALID, constants.GetErrMsg(constants.AGENT_REF_NUMBER_INVALID), nil, nil)
	}

	if result.Status != enum.ACTIVE {
		utils.BadRequestException(ctx, constants.AGENT_REF_NUMBER_INVALID, "Agent is not active", nil, nil)
	}

	//Check if the attendance exists
	attendances, err := s.attendanceRepo.FindManyByAttendanceRefNumbers(ctx, req.AttendanceReferenceNumbers)
	if err != nil {
		logger.Error(ctx, err, "Could Not Find Attendances", nil)
		utils.InternalServerError(ctx, err, "Attendance Service > Attendance Repo >  FindManyByAgentRefNumbers")
	}
	//Check if all the attendances are in PENDING STATE
	for j := range attendances {
		if attendances[j].ApprovalStatus != "PENDING" {
			utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "Attendance is Not in Pending state Attendance Ref Number: "+attendances[j].AttendanceRefNumber, nil, nil)
		}
	}

	var attendanceRefNumbers []string
	//Update the attendance
	for i := range attendances {
		attendanceRefNumbers = append(attendanceRefNumbers, attendances[i].AttendanceRefNumber)
	}

	agentName := result.FirstName + " " + result.LastName
	_, err = s.attendanceRepo.UpdateApprovalStatus(ctx, attendanceRefNumbers, req.ApprovalStatus, agentName)
	if err != nil {
		logger.Error(ctx, err, "Could Not Update Attendances", nil)
		utils.InternalServerError(ctx, err, "Attendance Service > Attendance Repo > Update")
	}

	return "", nil

}

func transformAttendanceResponse(ctx context.Context, s *AgentAttendanceService, attendances []models.Attendance) []response.Attendance {
	var res []response.Attendance

	for i := range attendances {

		attendanDate, err := time.Parse(time.RFC3339, attendances[i].AttendanceDate)
		if err != nil {
			logger.Error(ctx, err, "Error Parsing Attendance Date", nil)
		}
		//TODO: fix missing parts : Lat Long
		//TODO: fix the issue of formatting date time strings
		respAttendance := response.Attendance{
			AttendanceRefNumber: attendances[i].AttendanceRefNumber,
			AgentRefNumber:      attendances[i].AgentRefNumber,
			AttendanceDate:      attendanDate.Format("2006-01-02"),
			//Latitude:         attendances[i].Latitude,
			//Longitude:        attendances[i].Longitude,
			MarkType:         attendances[i].MarkType.String(),
			ApprovalStatus:   attendances[i].ApprovalStatus,
			MarkDateTime:     attendances[i].MarkDatetime.Format("2006-01-02 15:04:05"),
			ApprovalDateTime: attendances[i].ApprovalDatetime.Format("2006-01-02 15:04:05"),
			CreatedBy:        attendances[i].CreatedBy,
			AgentName:        attendances[i].AgentInfo.FirstName + " " + attendances[i].AgentInfo.LastName,
		}

		respAttendance.SelfieFilePath, err = s.awsS3.GetSharableURL(ctx, attendances[i].SelfieFilePath, constants.SERVICE_PROVIDER_ATTENDANCE_BUCKET)
		if err != nil {
			logger.Error(ctx, err, "unable to decode image from saved file path", logger.LogFields{
				"agentRefNumber": attendances[i].AgentRefNumber})
		}

		res = append(res, respAttendance)
	}
	return res
}
