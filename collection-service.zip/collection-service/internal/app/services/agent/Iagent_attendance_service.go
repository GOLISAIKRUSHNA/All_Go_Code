package agent

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IAgentAttendanceService interface {
	services.IBaseService

	MarkAttendance(ctx context.Context, req request.MarkAttendanceReq) (string, error)
	GetAttendance(ctx context.Context, req request.GetAttendanceReq) (response.GetAttendanceResp, error)
	UpdateAttendances(ctx context.Context, req request.AttendanceUpdateReq) (string, error)
}
