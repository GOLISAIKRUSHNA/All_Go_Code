package call_audits

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
	"errors"
	"strings"
	"time"
)

type CallAuditsService struct {
	services.BaseService
	callAuditsRepo repo_interfaces.ICallAuditsRepository
	awsImport      aws.S3Client
	cacheEnabled   bool
}

func InitCallAuditsService(ctx context.Context, callAuditsRepo repo_interfaces.ICallAuditsRepository, cacheEnabled bool) *CallAuditsService {
	service := &CallAuditsService{
		callAuditsRepo: callAuditsRepo,
		awsImport:      *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
		cacheEnabled:   cacheEnabled,
	}

	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (ca CallAuditsService) CreateCallAudits(ctx context.Context, request request.CallAudits) error {
	if span := tracing.TraceSpan(ctx, "CallAuditsService.CreateCallAudits"); span != nil {
		defer span.End()
	}
	res, err := transformCallAuditsRequestToModel(request)
	if err != nil {
		return err
	}
	if err := ca.callAuditsRepo.CreateCallAudits(ctx, res); err != nil {
		return err
	}
	return nil
}

func transformCallAuditsRequestToModel(request request.CallAudits) (models.CallAudits, error) {
	// Parse the CallDate from string to time.Time
	callDate, err := time.Parse("2006-01-02 15:04:05", request.CallDate)
	if err != nil {
		return models.CallAudits{}, err
	}

	return models.CallAudits{
		AttemptRefNumber:     request.AttemptRefNumber,
		CaseRefNumber:        request.CaseRefNumber,
		CallerAgentRefNumber: request.CallerAgentRefNumber,
		Status:               "PENDING",
		TemplateId:           request.TemplateId,
		CallDuration:         request.CallDuration,
		CallDate:             callDate,
	}, nil
}

func (ca CallAuditsService) CallAuditsList(ctx context.Context, request request.CallAuditsList) (response.CallAuditsResponse, error) {
	var finalResponse response.CallAuditsResponse
	callAudits, pages, currentPage, err := ca.callAuditsRepo.CallAuditsList(ctx, request)
	if err != nil {
		return finalResponse, err
	}
	if len(callAudits) == 0 {
		return finalResponse, nil
	}
	// Extract AttemptRefNumbers and join them into a comma-separated string
	var attemptRefNumbers []string
	for _, audit := range callAudits {
		attemptRefNumbers = append(attemptRefNumbers, audit.AttemptRefNumber)
	}
	attemptRefNumbersStr := strings.Join(attemptRefNumbers, ",")
	statusCode, successResp, failureResp, _, err := service_calls.MakeAttemptListToDialerService(ctx, attemptRefNumbersStr)
	if err != nil {
		logger.Error(ctx, err, "no audit record found for the agent",
			map[string]interface{}{
				"statusCode":  statusCode,
				"successResp": successResp,
				"failureResp": failureResp})
		return response.CallAuditsResponse{}, nil
	}
	attemptListInterface := successResp.Data
	b, err := json.Marshal(attemptListInterface)
	if err != nil {
		logger.Error(ctx, err, "unable to marshal attemptListInterface",
			map[string]interface{}{
				"attemptListInterface": attemptListInterface,
			})
	}
	var attemptList response.AttemptListResponse
	err = json.Unmarshal(b, &attemptList)
	if err != nil {
		logger.Error(ctx, err, "unable to unmarshal attemptListInterface",
			map[string]interface{}{
				"attemptListInterface": attemptListInterface,
			})
	}
	finalResponse = ca.transformCallAuditListResponse(ctx, callAudits, attemptList, currentPage, pages)
	return finalResponse, nil
}

func (ca CallAuditsService) transformCallAuditListResponse(ctx context.Context, callAudits []models.CallAudits, attemptList response.AttemptListResponse, currentPage int, pages int64) response.CallAuditsResponse {
	var transformedCallAudits []response.CallAudit

	for _, audit := range callAudits {
		// Find the corresponding attempt from attemptList
		var correspondingAttempt response.AttemptList
		for _, attempt := range attemptList.Attempts {
			if attempt.AttemptRefNumber == audit.AttemptRefNumber {
				correspondingAttempt = attempt
				break
			}
		}
		callRecordings := correspondingAttempt.CallRecordFileURL
		/*callRecordings, err := ca.awsImport.GetSharableURL(ctx, correspondingAttempt.CallRecordFileURL, "case-call-recordings")
		if err != nil {
			callRecordings = ""
		}*/

		// Get the first disposition or an empty string if none exist
		disposition := ""
		if len(audit.Disposition) > 0 {
			disposition = audit.Disposition[0].Disposition
		}

		transformedCallAudit := response.CallAudit{
			AuditRefNumber:       audit.AuditRefNumber,
			CaseRefNumber:        audit.CaseRefNumber,
			AttemptRefNumber:     audit.AttemptRefNumber,
			CustomerMobileNumber: correspondingAttempt.CustomerMobileNumber,
			CallerName:           audit.Agent.FirstName + " " + audit.Agent.LastName,
			CallerRole:           audit.Agent.Role.String(),
			CallerVisibility:     audit.Agent.Visibility.String(),
			Status:               audit.Status,
			AgentStatus:          correspondingAttempt.AgentStatus,
			ConnectedStatus:      correspondingAttempt.ConnectedStatus,
			CallStartDatetime:    correspondingAttempt.CallStartDatetime,
			CallEndDatetime:      correspondingAttempt.CallEndDatetime,
			CallDuration:         audit.CallDuration,
			CallRecordFileURL:    callRecordings,
			Disposition:          disposition,
			CreatedAt:            audit.CreatedAt.Format("2006-01-02 15:04:05"),
			TemplateId:           audit.TemplateId,
		}

		transformedCallAudits = append(transformedCallAudits, transformedCallAudit)
	}

	return response.CallAuditsResponse{
		CallAudits:  transformedCallAudits,
		CurrentPage: currentPage,
		Pages:       pages,
	}
}

func (ca CallAuditsService) CallAuditSubmitResponse(ctx context.Context, requestBody request.CallAuditSubmit, param request.CallAuditParam) (response.CallAuditFinalResponse, error) {
	if span := tracing.TraceSpan(ctx, "CallAuditService.CallAuditSubmitResponse"); span != nil {
		defer span.End()
	}
	var finalResponse response.CallAuditFinalResponse
	// Find the call audit by AuditRefNumber
	callAudits, err := ca.findCallAuditByAuditRefNumber(ctx, param.AuditRefNumber)
	if err != nil {
		return finalResponse, err
	}

	// Check if status is already COMPLETED
	if callAudits.Status == "COMPLETED" {
		utils.BadRequestException(ctx, "400", "response already submitted", nil, nil)
		return finalResponse, err
	}

	// Transform request for common service
	transformedRequest := transformCallAuditCommonServiceRequest(callAudits, requestBody)

	// Submit response and get the response body
	statusCode, successResp, failureResp, success, err := service_calls.CallAuditsResponseSubmit(ctx, param, transformedRequest)
	if !success {
		logger.Error(ctx, err, "common service call failed",
			map[string]interface{}{
				"statusCode":  statusCode,
				"successResp": successResp,
				"failureResp": failureResp})
		if err == nil {
			err = errors.New("common service call failed")
		}
		utils.InternalServerError(ctx, err, "")
	}

	respMap := successResp.Data.(map[string]interface{})
	responseID, _ := respMap["response_id"].(string)

	// Update the call audit status and response details
	if err := ca.updateCallAuditStatusAndResponse(ctx, param.AuditRefNumber, responseID); err != nil {
		return finalResponse, err
	}
	finalResponse = transformCallAuditSubmitResponse(responseID, callAudits)

	return finalResponse, nil
}

func transformCallAuditSubmitResponse(responseID string, callAudits models.CallAudits) response.CallAuditFinalResponse {
	return response.CallAuditFinalResponse{
		response.CallAuditSubmitResponse{
			AuditRefNumber: callAudits.AuditRefNumber,
			Status:         "COMPLETED",
			ResponseId:     responseID,
		},
	}
}

func (ca CallAuditsService) findCallAuditByAuditRefNumber(ctx context.Context, auditRefNumber string) (models.CallAudits, error) {
	filter := models.CallAudits{
		AuditRefNumber: auditRefNumber,
	}
	return ca.callAuditsRepo.FindOne(ctx, filter)
}

func (ca CallAuditsService) updateCallAuditStatusAndResponse(ctx context.Context, auditRefNumber, responseID string) error {
	filter := models.CallAudits{
		AuditRefNumber: auditRefNumber,
	}
	update := models.CallAudits{
		Status:           "COMPLETED",
		ResponseDatetime: time.Now(),
		ResponseId:       responseID,
	}
	return ca.callAuditsRepo.UpdateOne(ctx, filter, update)
}

func transformCallAuditCommonServiceRequest(callAudits models.CallAudits, requestBody request.CallAuditSubmit) request.CallAuditCommonServiceRequest {
	auditedTime := time.Now()
	auditedDatetimeStr := auditedTime.Format("2006-01-02T15:04:05Z07:00")
	return request.CallAuditCommonServiceRequest{
		AuditRefNumber:     callAudits.AuditRefNumber,
		AuditedBy:          callAudits.AuditAgentRefNumber,
		AuditedDatetime:    auditedDatetimeStr,
		CaseRefNumber:      callAudits.CaseRefNumber,
		Template:           requestBody.Template,
		SubmittedResponses: requestBody.SubmittedResponses,
	}
}

func (ca CallAuditsService) AuditAgentAllocate(ctx context.Context, requestBody request.AuditAgentAllocate) error {
	// Start tracing span
	defer tracing.TraceSpan(ctx, "CallAuditsService.AuditAgentAllocate").End()

	// Fetch call audits based on AuditRefNumbers
	callAudits, err := ca.fetchAndExtractCallAudits(ctx, requestBody)
	if err != nil {
		return err
	}

	// Update the call audit agent reference number
	if err := ca.updateAuditAgentRefNumber(ctx, callAudits, requestBody.AuditAgentRefNumber); err != nil {
		return err
	}

	return nil
}

// fetchAndExtractCallAudits fetches call audits based on AuditRefNumbers and extracts AuditRefNumbers from fetched call audits
func (ca CallAuditsService) fetchAndExtractCallAudits(ctx context.Context, requestBody request.AuditAgentAllocate) ([]string, error) {
	callAudits, err := ca.callAuditsRepo.FindByAuditRefNumbers(ctx, requestBody)
	if err != nil {
		return nil, err
	}

	var auditRefNumbers []string
	for _, audit := range callAudits {
		auditRefNumbers = append(auditRefNumbers, audit.AuditRefNumber)
	}

	return auditRefNumbers, nil
}

// updateAuditAgentRefNumber updates audit agent reference number in repository
func (ca CallAuditsService) updateAuditAgentRefNumber(ctx context.Context, auditRefNumbers []string, agentRefNumber string) error {
	updateRequest := request.AuditAgentAllocate{
		AuditRefNumbers:     auditRefNumbers,
		AuditAgentRefNumber: agentRefNumber,
	}

	if err := ca.callAuditsRepo.UpdateAuditAgentRefNumber(ctx, updateRequest); err != nil {
		return err
	}

	return nil
}
