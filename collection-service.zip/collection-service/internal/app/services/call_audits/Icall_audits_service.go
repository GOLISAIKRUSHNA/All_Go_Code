package call_audits

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type ICallAuditsService interface {
	services.IBaseService
	CreateCallAudits(ctx context.Context, request request.CallAudits) error
	CallAuditsList(ctx context.Context, request request.CallAuditsList) (response.CallAuditsResponse, error)
	CallAuditSubmitResponse(ctx context.Context, requestBody request.CallAuditSubmit, param request.CallAuditParam) (response.CallAuditFinalResponse, error)
	AuditAgentAllocate(ctx context.Context, requestBody request.AuditAgentAllocate) error
}
