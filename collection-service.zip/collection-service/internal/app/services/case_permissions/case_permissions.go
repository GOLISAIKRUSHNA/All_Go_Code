package case_permissions

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter/permify"
	permify2 "collection-service/internal/app/constants/permify"
	permifyConstants "collection-service/internal/app/constants/permify"
	"collection-service/internal/app/services/agent"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"errors"
	"gorm.io/gorm"
)

type CasePermissionsService struct {
	permify        *permify.PermifyClient
	agentService   agent.IAgentService
	agentRepo      repo_interfaces.IAgentRepository
	clientUserRepo repo_interfaces.IClientUserRepository
	caseRepo       repo_interfaces.ICaseRepository
	allocationRepo repo_interfaces.IAllocationRepository
}

type CasePermifyFilter struct {
	Object          enum.UserObject
	ObjectRefNumber string
	CaseRefNumber   string
}

func InitCasePermissionsService(ctx context.Context) CasePermissionsService {

	service := CasePermissionsService{

		permify:        permify.GetPermifyClientInstance(ctx),
		agentService:   agent.InitAgentService(ctx),
		agentRepo:      repositories.InitAgentRepository(ctx),
		clientUserRepo: repositories.InitClientUserRepository(ctx),
		caseRepo:       repositories.InitCaseRepository(ctx),
		allocationRepo: repositories.InitAllocationRepository(ctx),
	}

	return service
}

func (s CasePermissionsService) ExtractTeamAndUsersToBeFetched(ctx context.Context, filter *CasePermifyFilter) (*string, *string, *[]string) {
	switch filter.Object {
	case enum.USER_AGENT:
		return s.ExtractTeamAndUsersForAgent(ctx, filter)

	case enum.USER_CLIENT_USER:
		return s.ExtractTeamForClientUser(ctx, filter)
	}

	return nil, nil, nil
}

func (s CasePermissionsService) ExtractTeamAndUsersForAgent(ctx context.Context, filter *CasePermifyFilter) (*string, *string, *[]string) {
	// fetch visibility from agent repo. (assuming agent ref number is present in context)
	agentModel, err := s.agentRepo.FindOne(ctx, &models.Agent{AgentRefNumber: filter.ObjectRefNumber})
	if err != nil {
		logger.Error(ctx, err, "CacseService|FindCaseList|error while fetching agent details", logger.LogFields{"agent_ref_number": filter.ObjectRefNumber})
		utils.InternalServerError(ctx, err, "error while fetching agent details")
	}

	var serviceProviderTeamRefNumber *string
	var usersListFromPermify *[]string

	switch agentModel.Visibility {
	case enum.AGENT_VIS_TEAM_LEVEL:
		serviceProviderTeamRefNumber = &agentModel.ServiceProviderTeamRefNumber
		fallthrough
	case enum.AGENT_VIS_SELF_REPORTEE_LEVEL:
		usersFromPermify, err := s.GetSubUsersListFromPermify(ctx, filter.ObjectRefNumber)
		if err != nil {
			msg := "error from permify service while fetching case list"
			logger.Error(ctx, err, "CacseService|FindCaseList|getSubUsersListFromPermify"+msg, logger.LogFields{"payload": filter})
			utils.InternalServerError(ctx, err, msg)
		}
		usersListFromPermify = &usersFromPermify

	}

	return nil, serviceProviderTeamRefNumber, usersListFromPermify
}

func (s CasePermissionsService) ExtractTeamForClientUser(ctx context.Context, filter *CasePermifyFilter) (*string, *string, *[]string) {
	// fetch visibility from agent repo. (assuming agent ref number is present in context)
	clientUserModel, err := s.clientUserRepo.FindOne(ctx, &models.ClientUser{ClientUserRefNo: filter.ObjectRefNumber})
	if err != nil {
		logger.Error(ctx, err, "CacseService|FindCaseList|error while fetching client user details", logger.LogFields{"agent_ref_number": filter.ObjectRefNumber})
		utils.InternalServerError(ctx, err, "error while fetching agent details")
	}

	var clientTeamRefNumber *string

	if clientUserModel.Visibility == enum.CLIENT_USER_VISIBILITY_TEAM_LEVEL {
		clientTeamRefNumber = &clientUserModel.ClientTeamRefNumber
	}

	return clientTeamRefNumber, nil, nil
}

func (s CasePermissionsService) GetSubUsersListFromPermify(ctx context.Context, allocatedTo string) ([]string, error) {
	permissionTuple := permify.PermissionTuple{
		EntityTuple: permify.EntityTuple{
			EntityType: permify2.ENTITY_USER,
		},
		Permission: permify2.PERMISSION_CASE_LEVEL_VIEW,
		SubjectTuple: permify.SubjectTuple{
			SubjectType: permify2.ENTITY_USER,
			SubjectId:   allocatedTo,
		},
	}
	casesEntity, err := s.permify.EntityFiltering(ctx, permissionTuple)
	if err != nil {
		return nil, err
	}

	userRefNumbers := make([]string, 0)
	for i := range casesEntity {
		userRefNumbers = append(userRefNumbers, casesEntity[i].EntityId)
	}

	return userRefNumbers, nil
}

func (s CasePermissionsService) CheckCaseDetailsPermission(ctx context.Context, filter *CasePermifyFilter) (bool, error) {
	switch filter.Object {
	case enum.USER_AGENT:
		return s.GetCaseDetailsPermissionsFromAgent(ctx, filter)
	case enum.USER_CLIENT_USER:
		return s.GetCaseDetailsPermissionsFromClientUser(ctx, filter)
	}

	return false, nil
}

func (s CasePermissionsService) GetCaseDetailsPermissionsFromClientUser(ctx context.Context, filter *CasePermifyFilter) (bool, error) {
	// fetch client user details
	clientUserModel, err := s.clientUserRepo.FindOne(ctx, &models.ClientUser{ClientUserRefNo: filter.ObjectRefNumber})
	if err != nil {
		logger.Error(ctx, err, "CacseService|FindCaseList|error while fetching client user details", logger.LogFields{"client_user_ref_number": filter.ObjectRefNumber})
		return false, err
	}

	switch clientUserModel.Visibility {
	case enum.CLIENT_USER_VISIBILITY_TEAM_LEVEL:
		return s.MatchCaseAndClientUserTeam(ctx, filter, clientUserModel.ClientTeamRefNumber)
	case enum.CLIENT_USER_VISIBILITY_ORG_LEVEL:
		return true, nil
	}

	return false, nil
}

func (s CasePermissionsService) GetCaseDetailsPermissionsFromAgent(ctx context.Context, filter *CasePermifyFilter) (bool, error) {
	// fetch agent details
	agentModel, err := s.agentRepo.FindOne(ctx, &models.Agent{AgentRefNumber: filter.ObjectRefNumber})
	if err != nil {
		logger.Error(ctx, err, "CaseService|FindCaseList|error while fetching agent details", logger.LogFields{"agent_ref_number": filter.ObjectRefNumber})
		return false, err
	}

	switch agentModel.Visibility {
	case enum.AGENT_VIS_SELF_REPORTEE_LEVEL:
		return s.CheckCaseToUserPermissionFromPermify(ctx, filter)
	case enum.AGENT_VIS_TEAM_LEVEL:
		return s.MatchCaseAndAgentTeam(ctx, filter, agentModel.ServiceProviderTeamRefNumber)
	case enum.AGENT_VIS_ORG_LEVEL:
		return true, nil
	}

	return false, err
}

func (s CasePermissionsService) CheckCaseToUserPermissionFromPermify(ctx context.Context, filter *CasePermifyFilter) (bool, error) {
	permissionTuple := permify.PermissionTuple{
		EntityTuple: permify.EntityTuple{
			EntityType: permifyConstants.ENTITY_CASE,
			EntityId:   filter.CaseRefNumber,
		},
		Permission: permifyConstants.PERMISSION_VISIBILITY,
		SubjectTuple: permify.SubjectTuple{
			SubjectType: permifyConstants.ENTITY_USER,
			SubjectId:   filter.ObjectRefNumber,
		},
	}
	granted, err := s.permify.CheckPermission(ctx, permissionTuple)
	if err != nil {
		logger.Error(ctx, err, "CaseService|checkCaseToUserPermissionFromPermify|EntityFiltering|error while fetching agent details", logger.LogFields{"agent_ref_number": filter.ObjectRefNumber})
		return false, err
	}

	return granted, nil
}

func (s CasePermissionsService) MatchCaseAndAgentTeam(ctx context.Context, filter *CasePermifyFilter, teamRefNumber string) (bool, error) {
	// fetch service provider team mapping
	allocation, err := s.allocationRepo.FindByReferenceNumberOne(ctx, models.Allocation{ServiceProviderTeamRefNumber: teamRefNumber, CaseRefNumber: filter.CaseRefNumber})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return false, nil
		}
		logger.Error(ctx, err, "CaseService|matchCaseAndAgentTeam|error while fetching allocation details", logger.LogFields{"team_ref_number": teamRefNumber, "case_ref_number": filter.CaseRefNumber})
		return false, err
	}

	if allocation.CaseRefNumber == "" {
		logger.Error(ctx, err, "CaseService|matchCaseAndAgentTeam| no allocation found", logger.LogFields{"team_ref_number": teamRefNumber, "case_ref_number": filter.CaseRefNumber})
		return false, nil
	}

	return true, nil
}
func (s CasePermissionsService) MatchCaseAndClientUserTeam(ctx context.Context, filter *CasePermifyFilter, clientUserTeamRefNumber string) (bool, error) {
	// fetch case details
	caseModel, err := s.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: filter.CaseRefNumber, ClientTeamRefNumber: clientUserTeamRefNumber})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return false, nil
		}
		logger.Error(ctx, err, "CaseService|FindCaseList|error while fetching case details", logger.LogFields{"case_ref_number": filter.CaseRefNumber, "client_team_ref_number": clientUserTeamRefNumber})
		return false, err
	}

	if caseModel.CaseRefNumber == "" {
		logger.Error(ctx, err, "CaseService|FindCaseList| no case found", logger.LogFields{"case_ref_number": filter.CaseRefNumber, "client_team_ref_number": clientUserTeamRefNumber})
		return false, nil
	}

	return true, nil
}
