package jwt_token

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/enum"
	"strings"
	"time"

	"github.com/gin-gonic/gin"

	"github.com/spf13/viper"

	"github.com/golang-jwt/jwt"
)

type Claims struct {
	KeyID         string `json:"key_id,omitempty"`
	UserRefNumber string `json:"user_ref_number,omitempty"`
	Username      string `json:"username,omitempty"`

	ServiceProviderRefNumber string `json:"service_provider_ref_number,omitempty"`
	ClientRefNumber          string `json:"client_ref_number,omitempty"`

	Object          enum.UserObject `json:"object,omitempty"`
	ObjectRefNumber string          `json:"object_ref_number,omitempty"`
	Name            string          `json:"name"`

	Roles []string `json:"roles,omitempty"`

	jwt.StandardClaims
}

func (claims *Claims) GetNewAccessToken() (string, error) {
	expiryDuration := time.Duration(constants.JWT_ACCESS_TOKEN_EXPIRY_MINUTES) * time.Minute

	claims.StandardClaims.IssuedAt = time.Now().Unix()
	claims.StandardClaims.ExpiresAt = time.Now().Add(expiryDuration).Unix()

	return newAccessToken(claims)
}

func (claims *Claims) GetNewRefreshToken() {
	expiryDuration := time.Duration(constants.JWT_REFRESH_TOKEN_EXPIRY_MINUTES) * time.Minute

	claims.StandardClaims.IssuedAt = time.Now().Unix()
	claims.StandardClaims.ExpiresAt = time.Now().Add(expiryDuration).Unix()

}

func newAccessToken(claims *Claims) (string, error) {
	//fmt.Println(constants.GetClientAuthSecretKey(claims.KeyID))
	//accessToken := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	//
	//return accessToken.SignedString([]byte(constants.GetClientAuthSecretKey(claims.KeyID)))
	panic("implement")
}

func newRefreshToken(claims jwt.StandardClaims) (string, error) {
	refreshToken := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)

	return refreshToken.SignedString([]byte(viper.GetString("JWT_REFRESH_TOKEN_SECRET")))
}

func ParseAccessToken(accessToken string) (*Claims, error) {
	token, err := jwt.ParseWithClaims(accessToken, &Claims{}, func(token *jwt.Token) (interface{}, error) {
		return []byte(viper.GetString("JWT_ACCESS_TOKEN_SECRET")), nil
	})

	if err != nil {
		return nil, err
	}

	claims, ok := token.Claims.(*Claims)
	if ok && token.Valid {
		//custom checks
		return claims, nil
	}

	return nil, nil
}

func ParseRefreshToken(refreshToken string) (*jwt.StandardClaims, error) {
	parsedRefreshToken, _ := jwt.ParseWithClaims(refreshToken, &jwt.StandardClaims{}, func(token *jwt.Token) (interface{}, error) {
		return []byte(viper.GetString("JWT_REFRESH_TOKEN_SECRET")), nil
	})

	return parsedRefreshToken.Claims.(*jwt.StandardClaims), nil
}

func ExtractToken(c *gin.Context) string {

	bearerToken := c.Request.Header.Get("Authorization")
	if len(strings.Split(bearerToken, " ")) == 2 {
		return strings.Split(bearerToken, " ")[1]
	}

	return ""
}
