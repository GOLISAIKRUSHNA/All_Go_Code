package user

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/spf13/viper"

	"github.com/mitchellh/mapstructure"

	"gorm.io/gorm"
)

type UserURLService struct {
	services.BaseService
	userURLRepo repo_interfaces.IUserUrlRepo
	loanRepo    repo_interfaces.ILoanRepository

	cacheEnabled bool
}

func InitUserURLService(ctx context.Context, userURLRepo repo_interfaces.IUserUrlRepo, loanRepo repo_interfaces.ILoanRepository, cacheEnabled bool) *UserURLService {
	service := &UserURLService{
		userURLRepo:  userURLRepo,
		cacheEnabled: cacheEnabled,
		loanRepo:     loanRepo,
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (s UserURLService) GenerateCustomerPaymentLink(ctx context.Context, req request.GeneratePaymentLinkReq) error {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	// check if user url already exists
	userUrlEntity, err := s.userURLRepo.FindUserURLWithUnexpiredShortUrl(ctx, &models.UserUrl{
		ObjectRefNumber: req.ObjectRefNumber,
		EntityRefNumber: req.EntityRefNumber,
	})
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			utils.InternalServerError(ctx, err, "")
		}
	}

	// if user url already exists return.
	if userUrlEntity != nil {
		return nil
	}

	queryString := generateQueryString(req)

	encryptedString := encryptServiceCall(ctx, queryString)

	longURL := generateLongPaymentLink(encryptedString)

	// send long url and object ref number as client ref number in short url generate api call.
	shortURL, shortURLExpiresAt := generateShortURLCall(ctx, longURL, req.ObjectRefNumber)

	var userURLs []models.UserUrl

	// append case payment user url entry
	userURLs = append(userURLs, *createUserURLModel(shortURL, shortURLExpiresAt, longURL, req, enum.REASON_CASE_PAYMENT))

	// fetch loans having payment links
	loansWithPaymentLinks, err := s.loanRepo.FindLoansByCaseRefNumberHavingPayLinks(ctx, req.EntityRefNumber)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	//
	for i := 0; i < len(loansWithPaymentLinks); i++ {
		// generate short url for loan with object ref number as client ref number
		shortURL, shortURLExpiresAt := generateShortURLCall(ctx, loansWithPaymentLinks[i].PaymentLink, req.ObjectRefNumber)
		userURLs = append(userURLs, *createUserURLModel(shortURL, shortURLExpiresAt, loansWithPaymentLinks[i].PaymentLink, req, enum.REASON_LOAN_PAYMENT))
	}

	// save user urls generated
	err = s.userURLRepo.CreateUserURLs(ctx, userURLs)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	return nil
}

func createUserURLModel(shortURL string, shortURLExpiresAt time.Time, longURL string, req request.GeneratePaymentLinkReq, reason enum.URLReason) *models.UserUrl {
	userURLModel := &models.UserUrl{
		ShortURL:        shortURL,
		LongURL:         longURL,
		Entity:          req.Entity,
		EntityRefNumber: req.EntityRefNumber,
		Object:          req.Object,
		ObjectRefNumber: req.ObjectRefNumber,
		Reason:          enum.REASON_CASE_PAYMENT,
		ExpiryTime:      shortURLExpiresAt,
	}

	return userURLModel
}

func generateLongPaymentLink(encryptedString string) string {

	return fmt.Sprintf("%s/case-payment/%s", viper.GetString("PAYMENT_PAGE_BASE_URL"), encryptedString)
}

func encryptServiceCall(ctx context.Context, cipherString string) string {
	statusCode, successResp, failureResp, success, err := service_calls.EncryptString(ctx, request.EncryptReq{
		Text:  cipherString,
		KeyId: "KY000001",
	})
	if !success {
		logger.Error(ctx, err, "encrypt call to auth service failed.",
			map[string]interface{}{
				"statusCode":  statusCode,
				"successResp": successResp,
				"failureResp": failureResp})
		if err == nil {
			err = errors.New("unable to encrypt string")
		}
		utils.InternalServerError(ctx, err, "")
	}

	var encryptedResp response.EncryptResp
	bindErr := mapstructure.Decode(successResp.Data, &encryptedResp)
	if bindErr != nil {
		err := errors.New("invalid payment config")
		logger.Error(ctx, nil, "Invalid response received while encrypting string from auth service",
			map[string]interface{}{"response": successResp, "err": bindErr})
		utils.InternalServerError(ctx, err, "")
	}

	return encryptedResp.EncryptedString
}

func generateShortURLCall(ctx context.Context, longURL string, clientRefNumber string) (string, time.Time) {
	statusCode, successResp, failureResp, success, err := service_calls.GenerateShortURL(ctx, request.CreateShortUrlReq{
		LongURL:         longURL,
		ClientRefNumber: clientRefNumber,
	})

	if !success {
		logger.Error(ctx, err, "encrypt call to short url service failed.",
			map[string]interface{}{
				"statusCode":  statusCode,
				"successResp": successResp,
				"failureResp": failureResp})
		if err == nil {
			err = errors.New("unable to generate short url")
		}
		utils.InternalServerError(ctx, err, "")
	}

	var encryptedResp response.CreateShortURLResp

	jsonBody, err := json.Marshal(successResp.Data)
	if err != nil {
		logger.Error(ctx, err, "error while marshalling short url response", logger.LogFields{
			"response": successResp,
		})
		utils.InternalServerError(ctx, err, "")
	}

	bindErr := json.Unmarshal(jsonBody, &encryptedResp)
	if bindErr != nil {
		err := errors.New("invalid short url response")
		logger.Error(ctx, err, "Invalid response received while generating short url from short url service",
			map[string]interface{}{"response": successResp, "err": bindErr})
		utils.InternalServerError(ctx, err, "")
	}

	return encryptedResp.ShortURL, encryptedResp.ExpiresAt
}

func generateQueryString(req request.GeneratePaymentLinkReq) string {
	return fmt.Sprintf("client_ref_number=%s,object=%s,object_ref_number=%s,payment_for=%s,payment_for_ref_number=%s,case_ref_number=%s",
		req.ClientRefNumber,
		req.Object,
		req.ObjectRefNumber,
		req.Entity,
		req.EntityRefNumber,
		req.CaseRefNumber,
	)
}
