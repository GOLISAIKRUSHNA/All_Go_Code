package user

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"context"
)

type IUserURLService interface {
	services.IBaseService
	GenerateCustomerPaymentLink(ctx context.Context, req request.GeneratePaymentLinkReq) error
}
