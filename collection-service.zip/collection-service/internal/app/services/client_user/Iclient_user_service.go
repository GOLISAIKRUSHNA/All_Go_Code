package client_user

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IClientUserService interface {
	services.IBaseService
	Create(ctx context.Context, req request.CreateClientUserReq) error
	FindClientUserList(ctx context.Context, queryParams request.GetClientUserQueryParam, pagination dto.PaginationData) (*response.GetClientUsersResp, error)
	GetClientUser(ctx context.Context, clientUserRefNumber string) (response.GetClientUserResp, error)
	Update(ctx context.Context, req request.UpdateClientUserReq, clientUserRefNumber string) (string, error)
	GetAllTheClientUsersWithMatchingName(ctx context.Context, req request.AutoSuggestClientUserReq, pagination dto.PaginationData) (response.AutoSuggestClientUserRes, error)
}
