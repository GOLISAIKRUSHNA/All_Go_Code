package client_user

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/adapter/permify"
	"collection-service/internal/app/constants"
	eventConstants "collection-service/internal/app/constants/events"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/agent"
	"collection-service/internal/app/services/storage/cacheservice"
	jwt_token "collection-service/internal/app/services/token"
	"collection-service/internal/dto"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"errors"
	"fmt"
	"github.com/spf13/viper"
	"strings"

	"github.com/golang-jwt/jwt"
)

type ClientUserService struct {
	services.BaseService
	clientUserRepo        repo_interfaces.IClientUserRepository
	clientUserRoleMapRepo repo_interfaces.IClientUserRoleMappingRepo
	ClientRepo            repo_interfaces.IClientRepository
	awsS3                 aws.S3Client
	permify               *permify.PermifyClient

	cacheEnabled bool
}

func InitClientUserService(ctx context.Context) *ClientUserService {
	service := &ClientUserService{
		clientUserRepo:        repositories.InitClientUserRepository(ctx),
		clientUserRoleMapRepo: repositories.InitClientUserRoleMappingRepo(ctx),
		ClientRepo:            repositories.InitClientRepository(ctx),
		awsS3:                 *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
		cacheEnabled:          viper.GetBool("REDIS_ENABLED"),
		permify:               permify.GetPermifyClientInstance(ctx),
	}

	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (cs *ClientUserService) Create(ctx context.Context, req request.CreateClientUserReq) error {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)
	var details []dto.RequestDetails
	if req.Email == "" && req.Username == "" {
		logger.Error(ctx, nil, "email or username should be present", nil)
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "email or username should be present", nil, nil)
	}

	// call client Repo to get the client details
	clientRes, err := cs.ClientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: req.ClientRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")

	}
	orgID := clientRes.OrgID

	// check if mobile number and org_id are present
	if req.MobileNumber != "" && orgID != "" {
		result, err := cs.clientUserRepo.FindOne(ctx, &models.ClientUser{MobileNumber: req.MobileNumber, OrgID: orgID})
		if err == nil || result != nil {
			// give error in requestDetails
			details = append(details, dto.RequestDetails{
				Field:   "mobile_number",
				Message: constants.GetErrMsg(constants.MOBILE_AND_ORGID_ALREADY_EXISTS),
			})
			logger.Error(ctx, err, "AgentService|Create|Mobile number record already present with this org_id!", nil)
			utils.BadRequestException(ctx, constants.MOBILE_AND_ORGID_ALREADY_EXISTS, constants.GetErrMsg(constants.MOBILE_AND_ORGID_ALREADY_EXISTS), nil, details)

		}
	}
	// check if email and org_id are present
	if req.Email != "" && orgID != "" {
		result, err := cs.clientUserRepo.FindOne(ctx, &models.ClientUser{Email: req.Email, OrgID: orgID})
		if err == nil || result != nil {
			details = append(details, dto.RequestDetails{
				Field:   "email",
				Message: constants.GetErrMsg(constants.EMAIL_AND_ORGID_ALREADY_EXISTS),
			})
			logger.Error(ctx, err, "AgentService|Create|Email record already present!", nil)
			utils.BadRequestException(ctx, constants.EMAIL_AND_ORGID_ALREADY_EXISTS, constants.GetErrMsg(constants.EMAIL_AND_ORGID_ALREADY_EXISTS), nil, details)

		}
	}

	passwordString, err := utils.Base64Decode(req.Password)
	if err != nil {
		logger.Error(ctx, err, "unable to decode password", logger.LogFields{"password": req.Password})
	}

	// call utils.ValidatePassword to validate password
	isValidate, details := utils.ValidatePassword(passwordString)
	if !isValidate {
		utils.BadRequestException(ctx, constants.PASSWORD_INVALID, "invalid password entered", nil, details)
	}

	clientUser := getClientUserModelFromCreateAgentReq(req)
	if clientUser.Status == 0 {
		clientUser.Status = enum.ACTIVE
	}
	clientUser.OrgID = orgID

	if req.Username != "" {
		// check if username already exists
		isExists := agent.CheckUsernameExistence(ctx, req.Username)
		if isExists {
			utils.BadRequestException(ctx, "", "username already exists", nil, nil)
		}
	}

	// upload client-user photo
	var filePath string
	if req.PhotoBase64String != "" {
		contentType, errTypeErr := utils.GetBase64ContentType(req.PhotoBase64String)
		if errTypeErr != nil {
			logger.Error(ctx, errTypeErr, "client_user_service|Create|contentTypeError", logger.LogFields{"base64 image": req.PhotoBase64String})
		}
		extention := strings.Split(contentType, "/")
		filePath = "client-user-photos" + "/" + utils.GenerateRandomString(6, "") + "." + extention[1]

		uploadErr := cs.awsS3.UploadBase64Image(ctx, filePath, constants.CLIENT_DOCS, req.PhotoBase64String, contentType)
		if uploadErr != nil {
			logger.Error(ctx, uploadErr, "client_user_service|Create|update.uploadError", logger.LogFields{"file": req.PhotoBase64String})
		}
	}

	clientUser.PhotoPath = filePath

	// If the agent doesn't exist , create a new one
	res, err := cs.clientUserRepo.Create(ctx, clientUser)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	// client_user_create events publish
	// create user after successful user creation
	createClientUserEvent := transformClientUserToCreateClientUserReq(ctx, req, res.ClientUserRefNo)
	createClientUserEvent.OrgID = orgID
	// generate agent Claims
	createClientUserEvent.Claims = generateClientUserClaims(ctx, res)
	adapter.PublishEvent(ctx, []string{constants.RMQ_AUTH_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, createClientUserEvent, eventConstants.CLIENT_USER_CREATED, nil)

	return nil
}

func (cs *ClientUserService) FindClientUserList(ctx context.Context, req request.GetClientUserQueryParam, pagination dto.PaginationData) (*response.GetClientUsersResp, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)
	search := req.Search
	if pagination.CurrentPage <= 0 {
		pagination.CurrentPage = 1
	}
	pagination = dto.Init(pagination.CurrentPage)

	if req.ClientRefNumber == "" {
		utils.MissingParamsException(ctx, []string{"client_ref_number"})
	}

	var clientUsersResp response.GetClientUsersResp

	pagination.Limit = 20
	clientUser := models.ClientUser{
		ClientRefNumber: req.ClientRefNumber,
		ClientUserRefNo: req.ClientUserRefNumber,
		MobileNumber:    req.MobileNumber,
		Email:           req.Email,
		Status:          req.Status,
	}
	clientUserPage, totalRecords, err := cs.clientUserRepo.FindClientUserPage(ctx, &clientUser, search, pagination)

	// Calculating totalPages based on totalRecords
	totalPages := totalRecords / pagination.Limit
	if totalRecords%pagination.Limit > 0 {
		totalPages++
	}

	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	resp := transformClientUsersResponse(ctx, cs, clientUserPage)

	clientUsersResp = response.GetClientUsersResp{ClientUsers: resp, PaginationData: response.PaginationData{CurrentPage: pagination.CurrentPage, Pages: totalPages}}

	return &clientUsersResp, nil
}

func generateClientUserClaims(ctx context.Context, clientUser *models.ClientUser) (claims *jwt_token.Claims) {
	claims = &jwt_token.Claims{
		Object:          enum.USER_CLIENT_USER,
		ObjectRefNumber: clientUser.ClientUserRefNo,
		Name:            clientUser.FirstName + " " + clientUser.LastName,

		ClientRefNumber: clientUser.ClientRefNumber,
		StandardClaims:  jwt.StandardClaims{},
		Roles:           []string{clientUser.Role.String()},
	}

	return
}
func transformClientUserToCreateClientUserReq(ctx context.Context, clientUserReq request.CreateClientUserReq, clientUserRefNumber string) events.CreateClientUserEvent {
	return events.CreateClientUserEvent{
		FirstName:           clientUserReq.FirstName,
		LastName:            clientUserReq.LastName,
		MobileNumber:        clientUserReq.MobileNumber,
		Email:               clientUserReq.Email,
		Username:            clientUserReq.Username,
		Password:            clientUserReq.Password,
		ClientUserRefNumber: clientUserRefNumber,
		ClientRefNumber:     clientUserReq.ClientRefNumber,
		ClientUserRole:      clientUserReq.ClientUserRole,
	}
}

const MOBILE_AND_MOBILE_NO_OTP = "mobile_number&mobile_number_otp"
const USERNAME_AND_PASSWORD = "username&password"

func getClientUserModelFromCreateAgentReq(req request.CreateClientUserReq) *models.ClientUser {
	data := &models.ClientUser{
		ClientRefNumber:           req.ClientRefNumber,
		FirstName:                 req.FirstName,
		LastName:                  req.LastName,
		Email:                     req.Email,
		MobileNumber:              req.MobileNumber,
		Status:                    enum.ACTIVE,
		Designation:               req.Designation,
		ReportingManagerRefNumber: req.ReportingManagerRefNumber,
		CreatedBy:                 req.CreatedBy,
		UpdatedBy:                 "",
		ClientTeamRefNumber:       req.TeamRefNumber,
	}

	if req.ClientUserRole == enum.ClientUserRole(0) {
		data.Role = enum.CLIENT_USER_ROLE_MEMBER
	} else {
		data.Role = req.ClientUserRole
	}

	if req.ClientUserVisibility == enum.ClientUserVisibility(0) {
		data.Visibility = enum.CLIENT_USER_VISIBILITY_TEAM_LEVEL
	} else {
		data.Visibility = req.ClientUserVisibility

	}

	return data
}

func transformClientUsersResponse(ctx context.Context, cs *ClientUserService, clientUsers []models.ClientUser) []response.ClientUser {
	var res []response.ClientUser

	for i := range clientUsers {
		clientUserRes := response.ClientUser{
			ClientUserRefNo:           clientUsers[i].ClientUserRefNo,
			ClientRefNo:               clientUsers[i].ClientRefNumber,
			FirstName:                 clientUsers[i].FirstName,
			LastName:                  clientUsers[i].LastName,
			Email:                     clientUsers[i].Email,
			MobileNumber:              clientUsers[i].MobileNumber,
			Status:                    clientUsers[i].Status,
			Designation:               clientUsers[i].Designation,
			ReportingManagerRefNumber: clientUsers[i].ReportingManagerRefNumber,
			ClientUserRole:            clientUsers[i].Role,
			ClientUserVisibility:      clientUsers[i].Visibility,
			CreatedBy:                 clientUsers[i].CreatedBy,
			UpdatedBy:                 clientUsers[i].UpdatedBy,
			CreatedAt:                 clientUsers[i].CreatedAt.Format("2006-01-02 15:04:05"),
			UpdatedAt:                 clientUsers[i].UpdatedAt.Format("2006-01-02 15:04:05"),
			TeamName:                  clientUsers[i].TeamInfo.Name,
			TeamRefNumber:             clientUsers[i].ClientTeamRefNumber,
		}

		var err error
		clientUserRes.PhotoPath, err = cs.awsS3.GetSharableURL(ctx, clientUsers[i].PhotoPath, constants.CLIENT_DOCS)
		if err != nil {
			logger.Error(ctx, err, "unable to decode image from saved file path", logger.LogFields{
				"clientUserRefNumber": clientUsers[i].ClientUserRefNo})
		}

		if clientUsers[i].ReportingManagerInfo != nil {
			clientUserRes.ReportingManagerName = clientUsers[i].ReportingManagerInfo.FirstName
		} else if clientUsers[i].ReportingManagerRefNumber != "" {
			logger.Warn(ctx, "reporting manager not found",
				logger.LogFields{"reporting_manager_ref_number": clientUsers[i].ReportingManagerRefNumber})
		}

		res = append(res, clientUserRes)

	}
	return res
}

func constructClientUserListRedisKey(req request.GetClientUserQueryParam, pageNo int64) string {
	return fmt.Sprintf("api:%s:%s:%s:%s:%s:%s:%s:%s:%s:%s:%s:%s:%d", constants.API_CLIENT_USER_LIST,
		constants.CLIENT_REF_NUMBER, req.ClientRefNumber,
		constants.CLIENT_USER_REF_NUMBER, req.ClientUserRefNumber,
		constants.MOBILE_NUMBER, req.MobileNumber,
		constants.EMAIL, req.Email,
		constants.STATUS, req.Status,
		constants.PAGE_NO, pageNo)
}

func (p *ClientUserService) GetClientUser(ctx context.Context, clientUserRefNumber string) (response.GetClientUserResp, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	filters := &models.ClientUser{
		ClientUserRefNo: clientUserRefNumber,
	}

	var clientUserResp response.GetClientUserResp
	clientUserModel, err := p.clientUserRepo.FindClientUser(ctx, filters)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
		return clientUserResp, err
	}

	// fetching user info
	_, successResp, _, success, err := service_calls.GetUserInfo(ctx, clientUserRefNumber)
	if !success && err == nil {
		err = errors.New("unable to fetch user info for client user ref number: " + clientUserRefNumber)
	}
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}
	var getUserResp response.UserInfoResponse

	decoder, err := agent.GetUserInfoMapstructDecoder(&getUserResp)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	err = decoder.Decode(successResp.Data)
	if err != nil {
		logger.Error(ctx, err, "unable to decode response received from user info",
			logger.LogFields{"client user ref number": clientUserRefNumber})
		utils.InternalServerError(ctx, err, "")
	}

	clientUser := transformClientUserResponse(ctx, p, clientUserModel, &getUserResp)

	clientUserResp.ClientUser = clientUser

	return clientUserResp, nil
}

func transformClientUserResponse(ctx context.Context, p *ClientUserService, clientUsers *models.ClientUser, userInfoResponse *response.UserInfoResponse) response.ClientUser {
	clientUserResp := response.ClientUser{
		ClientUserRefNo:           clientUsers.ClientUserRefNo,
		ClientRefNo:               clientUsers.ClientRefNumber,
		FirstName:                 clientUsers.FirstName,
		LastName:                  clientUsers.LastName,
		Email:                     clientUsers.Email,
		MobileNumber:              clientUsers.MobileNumber,
		Status:                    clientUsers.Status,
		Designation:               clientUsers.Designation,
		ReportingManagerRefNumber: clientUsers.ReportingManagerRefNumber,
		CreatedBy:                 clientUsers.CreatedBy,
		UpdatedBy:                 clientUsers.UpdatedBy,
		TeamRefNumber:             clientUsers.ClientTeamRefNumber,
		CreatedAt:                 clientUsers.CreatedAt.Format("2006-01-02 15:04:05"),
		UpdatedAt:                 clientUsers.UpdatedAt.Format("2006-01-02 15:04:05"),
		TeamName:                  clientUsers.TeamInfo.Name,
		ClientUserRole:            clientUsers.Role,
		ClientUserVisibility:      clientUsers.Visibility,
	}

	var err error
	clientUserResp.PhotoPath, err = p.awsS3.GetSharableURL(ctx, clientUsers.PhotoPath, constants.CLIENT_DOCS)
	if err != nil {
		logger.Error(ctx, err, "unable to decode image from saved file path", logger.LogFields{
			"clientUserRefNumber": clientUsers.ClientUserRefNo})
	}

	if clientUsers.ReportingManagerInfo != nil {
		clientUserResp.ReportingManagerName = clientUsers.ReportingManagerInfo.FirstName + " " + clientUsers.ReportingManagerInfo.LastName
	}

	return clientUserResp
}

// Update Agent
func (s *ClientUserService) Update(ctx context.Context, req request.UpdateClientUserReq, clientUserRefNumber string) (string, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	var details []dto.RequestDetails
	previousCLientUserModel, err := s.clientUserRepo.FindOne(ctx, &models.ClientUser{ClientUserRefNo: clientUserRefNumber})
	if err != nil || previousCLientUserModel == nil {
		if err == nil {
			err = fmt.Errorf("unable to find client user with clientUserRefNumber: %s", clientUserRefNumber)
		}
		utils.InternalServerError(ctx, err, "")
	}
	if req.Email != "" {
		result, err := s.clientUserRepo.FindOneExceptClientUsers(ctx, &models.ClientUser{Email: req.Email}, []string{clientUserRefNumber})
		if err == nil || result != nil {
			details = append(details, dto.RequestDetails{
				Field:   "email",
				Message: constants.GetErrMsg(constants.EMAIL_ALREADY_EXISTS),
			})

			logger.Error(ctx, err, " ClientUserService|Update|Email record already present!", nil)
			utils.BadRequestException(ctx, constants.EMAIL_ALREADY_EXISTS, constants.GetErrMsg(constants.EMAIL_ALREADY_EXISTS), nil, details)
		}
	}
	if req.MobileNumber != "" {
		result, err := s.clientUserRepo.FindOneExceptClientUsers(ctx, &models.ClientUser{MobileNumber: req.MobileNumber}, []string{clientUserRefNumber})
		if err == nil || result != nil {
			details = append(details, dto.RequestDetails{
				Field:   "mobile_number",
				Message: constants.GetErrMsg(constants.MOBILE_ALREADY_EXISTS),
			})

			logger.Error(ctx, err, "ClientUserService|Update|Mobile number record already present!", nil)
			utils.BadRequestException(ctx, constants.MOBILE_ALREADY_EXISTS, constants.GetErrMsg(constants.MOBILE_ALREADY_EXISTS), nil, details)
		}

	}

	// upload agent photo
	var filePath string
	var clientUserModel *models.ClientUser

	// TODO: remove previous photo from s3 if new photo is uploaded.
	if req.PhotoBase64String != "" {
		contentType, errTypeErr := utils.GetBase64ContentType(req.PhotoBase64String)
		if errTypeErr != nil {
			logger.Error(ctx, errTypeErr, "agent_service|Create|contentTypeError", logger.LogFields{"base64 image": req.PhotoBase64String})
		}
		extention := strings.Split(contentType, "/")
		filePath = "agent-photos" + "/" + utils.GenerateRandomString(6, "") + "." + extention[1]

		uploadErr := s.awsS3.UploadBase64Image(ctx, filePath, constants.CLIENT_DOCS, req.PhotoBase64String, contentType)
		if uploadErr != nil {
			logger.Error(ctx, err, "agent_service|Create|update.uploadError", logger.LogFields{"file": req.PhotoBase64String})
		}
	}

	// update file path, role and visibility. zero values set will be ignored by gorm.
	clientUserModel = transformClientUserModelFromUpdateReq(req)
	clientUserModel.PhotoPath = filePath

	isUpdated, err := s.clientUserRepo.Update(ctx, &models.ClientUser{ClientUserRefNo: clientUserRefNumber}, clientUserModel)
	if err != nil || !isUpdated {
		if err == nil {
			err = fmt.Errorf("unable to update client user with client user ref number: %s", clientUserRefNumber)
		}
		utils.InternalServerError(ctx, err, "")
	}

	// TODO: update previousCLientUserModel if firstname and lastname is changed.(currently not supported) for claims regeneration.

	// create user after successful user creation.
	updateClientUserReq := transformClientUserToUpdateUserReq(ctx, req, previousCLientUserModel, clientUserRefNumber)
	// TODO: update username if passed in request.
	if req.Username != "" {
		// check if username already exists
		isExists := agent.CheckUsernameExistenceExceptSelf(ctx, req.Username, clientUserRefNumber)
		if isExists {
			utils.BadRequestException(ctx, "", "username already exists", nil, nil)
		}
		updateClientUserReq.Username = req.Username
	}

	// call client Repo to get the client details
	clientRes, err := s.ClientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: previousCLientUserModel.ClientRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")

	}
	updateClientUserReq.OrgID = clientRes.OrgID

	updateClientUserClaims(clientUserModel, updateClientUserReq.Claims, previousCLientUserModel, &req)
	adapter.PublishEvent(ctx, []string{constants.RMQ_AUTH_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_DIALER_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, updateClientUserReq, eventConstants.CLIENT_USER_UPDATED, nil)

	// update permify role if changed for this user.

	return "", err
}

func transformClientUserModelFromUpdateReq(req request.UpdateClientUserReq) *models.ClientUser {
	data := &models.ClientUser{
		FirstName:                 req.FirstName,
		LastName:                  req.LastName,
		Email:                     req.Email,
		MobileNumber:              req.MobileNumber,
		Status:                    req.Status,
		Designation:               req.Designation,
		Visibility:                req.ClientUserVisibility,
		Role:                      req.ClientUserRole,
		ClientTeamRefNumber:       req.TeamRefNumber,
		ReportingManagerRefNumber: req.ReportingManagerRefNumber,
	}
	return data
}

func transformClientUserToUpdateUserReq(ctx context.Context, clientUserReq request.UpdateClientUserReq, clientUserModel *models.ClientUser, clientUserRefNumber string) events.UpdateClientUserEvent {
	return events.UpdateClientUserEvent{
		ClientUserRefNumber:               clientUserRefNumber,
		Claims:                            getClientUserClaims(clientUserModel),
		PreviousReportingManagerRefNumber: clientUserModel.ReportingManagerRefNumber,
		ReportingManagerRefNumber:         clientUserReq.ReportingManagerRefNumber,
		PreviousRole:                      clientUserModel.Role,
		ClientUserRole:                    clientUserReq.ClientUserRole,
		ClientRefNumber:                   clientUserModel.ClientRefNumber,
		Email:                             clientUserReq.Email,
		FirstName:                         clientUserReq.FirstName,
		LastName:                          clientUserReq.LastName,
		MobileNumber:                      clientUserReq.MobileNumber,
	}
}

func getClientUserClaims(clientUser *models.ClientUser) (agentClaims *jwt_token.Claims) {
	agentClaims = &jwt_token.Claims{
		Object:          enum.USER_CLIENT_USER,
		ObjectRefNumber: clientUser.ClientUserRefNo,
		Name:            clientUser.FirstName + " " + clientUser.LastName,

		ClientRefNumber: clientUser.ClientRefNumber,
		StandardClaims:  jwt.StandardClaims{},
		Roles:           []string{clientUser.Role.String()},
	}
	return
}

func updateClientUserClaims(updatedAgent *models.ClientUser, prevClaims *jwt_token.Claims, previousClientUserModel *models.ClientUser, req *request.UpdateClientUserReq) {
	if len(prevClaims.Roles) > 0 &&
		updatedAgent.Role != enum.ClientUserRole(0) &&
		updatedAgent.Role != enum.StringToClientUserRole(prevClaims.Roles[0]) {
		prevClaims.Roles = []string{updatedAgent.Role.String()}
	}

	firstName := previousClientUserModel.FirstName
	if req.FirstName != "" {
		firstName = req.FirstName
	}
	lastName := previousClientUserModel.LastName
	if req.LastName != "" {
		lastName = req.LastName
	}

	prevClaims.Name = firstName + " " + lastName
	return
}

func (s *ClientUserService) GetAllTheClientUsersWithMatchingName(ctx context.Context, req request.AutoSuggestClientUserReq, pagination dto.PaginationData) (response.AutoSuggestClientUserRes, error) {
	var result []models.ClientUser
	var err error
	if pagination.CurrentPage <= 0 {
		pagination.CurrentPage = 1
	}
	// calling Init() func to set the value
	pagination = dto.Init(pagination.CurrentPage)
	clientUserModel := transformRequestToClientUserModel(req)

	result, totalRecords, err := s.clientUserRepo.GetClientUserMatchingByName(ctx, clientUserModel, pagination)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	// Calculating totalPages based on totalRecords
	totalPages := totalRecords / pagination.Limit
	if totalRecords%pagination.Limit > 0 {
		totalPages++
	}

	autoSuggestResults := response.AutoSuggestClientUserRes{
		ClientUsers:    []response.AutoSuggestedClientUser{},
		PaginationData: response.PaginationData{Pages: totalPages, CurrentPage: pagination.CurrentPage},
	}
	for _, res := range result {
		clientUserInfo := response.AutoSuggestedClientUser{
			ClientUserRefNumber: res.ClientUserRefNo,
			FirstName:           res.FirstName,
			LastName:            res.LastName,
			Email:               res.Email,
			TeamRefNumber:       res.ClientTeamRefNumber,
			TeamName:            res.TeamInfo.Name,
		}
		autoSuggestResults.ClientUsers = append(autoSuggestResults.ClientUsers, clientUserInfo)
	}
	return autoSuggestResults, nil

}

func transformRequestToClientUserModel(req request.AutoSuggestClientUserReq) *models.ClientUser {
	data := &models.ClientUser{
		FirstName:           req.Name,
		ClientRefNumber:     req.ClientRefNumber,
		ClientTeamRefNumber: req.TeamRefNumber,
	}
	return data
}
