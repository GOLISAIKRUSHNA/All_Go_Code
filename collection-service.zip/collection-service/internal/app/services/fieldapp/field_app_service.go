package fieldapp

import (
	"collection-service/common/logger"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"context"
)

type FieldAppService struct {
	repositories.BaseRepo
	services.BaseService
	agentRepo repo_interfaces.IAgentRepository
}

func InitFieldAppService(ctx context.Context) *FieldAppService {
	return &FieldAppService{
		agentRepo: repositories.InitAgentRepository(ctx),
	}
}

/*
GetHomePageData : Get home page data for field app
* @param ctx : gin.Context, homePageRequest : request.HomePageRequest
* @return response.HomePage, error
@author:Tejas Surve
*/
func (s *FieldAppService) GetHomePageData(ctx context.Context, homePageRequest request.HomePageRequest) (response.HomePage, error) {
	logger.Info(ctx, "FieldAppService|GetHomePageData|Request", logger.LogFields{"request": homePageRequest})

	//get agent collection summary
	collectionSummary, err := s.agentRepo.GetCollectionSummary(ctx, homePageRequest.AgentRefNumber)
	if err != nil {
		logger.Error(ctx, err, "FieldAppService|GetHomePageData|Error", logger.LogFields{"error": err.Error()})
		return response.HomePage{}, err
	}
	_, paymentSummaryData, _, isSuccess, paymentFetchErr := service_calls.GetPaymentSummary(ctx, homePageRequest.AgentRefNumber)
	if !isSuccess && paymentFetchErr != nil {
		logger.Error(ctx, paymentFetchErr, "FieldAppService|GetHomePageData|Error", logger.LogFields{"error": paymentFetchErr.Error()})
		return response.HomePage{}, paymentFetchErr
	}
	paymentSummary := s.mapPaymentServiceResponse(ctx, paymentSummaryData)
	homePageData := s.transformHomePageData(collectionSummary, paymentSummary)

	return homePageData, nil
}

/*
transformHomePageData : Transform collection summary data to home page data
* @param collecton : response.CollectionSummary
* @return response.HomePage
* @author:Tejas Surve
*/
func (s *FieldAppService) transformHomePageData(collecton response.CollectionSummary, paymentSummary response.PaymentSummary) response.HomePage {
	return response.HomePage{
		CollectionSummary: response.CollectionSummary{
			TotalToBeCollected:  collecton.TotalToBeCollected,
			TotalCollected:      collecton.TotalCollected,
			TodayCollection:     collecton.TodayCollection,
			YesterdayCollection: collecton.YesterdayCollection,
		},
		DepositSummary: response.DispositionSummary{
			TotalPendingForDeposit: paymentSummary.TotalPendingForDeposit,
			TotalUnverifiedDeposit: paymentSummary.TotalUnverifiedDeposit,
		},
	}
}

func (s *FieldAppService) mapPaymentServiceResponse(ctx context.Context, summary *dto.SuccessResponse) response.PaymentSummary {
	// Accessing deposit_summary from the SuccessResponse struct
	dataMap, ok := summary.Data.(map[string]interface{})
	if !ok {
		logger.Error(ctx, nil, "Failed to assert data to map[string]interface{}", logger.LogFields{"data": summary.Data})
	}

	depositSummaryData, ok := dataMap["deposit_summary"].(map[string]interface{})
	if !ok {
		logger.Error(ctx, nil, "Failed to assert deposit_summary to map[string]interface{}", logger.LogFields{"data": depositSummaryData})
	}

	return response.PaymentSummary{
		TotalPendingForDeposit: depositSummaryData["total_pending_for_deposit"].(float64),
		TotalUnverifiedDeposit: depositSummaryData["total_unverified_deposit"].(float64),
	}
}
