package fieldapp

import (
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IFieldAppService interface {
	GetHomePageData(ctx context.Context, homePageReq request.HomePageRequest) (response.HomePage, error)
}
