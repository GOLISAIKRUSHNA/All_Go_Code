package customer

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type ICustomerAddressService interface {
	services.IBaseService
	GetAddresses(ctx context.Context, customerRefNumber string) ([]response.CustomerAddress, error)
	UpdateCustomerLocation(ctx context.Context, address request.Address) error
	CreateAddress(ctx context.Context, addressReq request.CreateAddressRequest) (*response.CreateAddressRes, error)
}
