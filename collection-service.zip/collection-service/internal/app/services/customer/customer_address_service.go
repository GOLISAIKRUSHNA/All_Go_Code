package customer

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/google"
	"collection-service/internal/adapter/rabbit_mq"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"github.com/spf13/viper"
)

type CustomerAddressService struct {
	services.BaseService
	customerAddressRepo repo_interfaces.ICustomerAddressRepository
	pincodeRepo         repo_interfaces.IPincodeMasterRepository
	cacheEnabled        bool
}

func InitCustomerAddressService(ctx context.Context) *CustomerAddressService {
	service := &CustomerAddressService{
		customerAddressRepo: repositories.InitCustomerAddressRepository(ctx),
		pincodeRepo:         repositories.InitPincodeMasterRepository(ctx),
		cacheEnabled:        viper.GetBool("REDIS_ENABLED"),
	}

	if service.cacheEnabled {
		//service.BaseService.(cacheservice.GetInstance())
	}

	return service
}

func (s CustomerAddressService) GetAddresses(ctx context.Context, customerRefNumber string) ([]response.CustomerAddress, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)
	if customerRefNumber == "" {
		utils.MissingParamsException(ctx, []string{CUSTOMER_REF_NUMBER})
	}

	filters := models.CustomerAddress{CustomerRefNumber: customerRefNumber}
	addresses, err := s.customerAddressRepo.FindMany(ctx, &filters)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	resp := transformCustomerAddresses(addresses)
	return resp, nil
}
func (s CustomerAddressService) CreateAddress(ctx context.Context, addressReq request.CreateAddressRequest) (*response.CreateAddressRes, error) {
	logger.Info(ctx, "CustomerAddressService|CreateAddress", logger.LogFields{"requestbody": addressReq})
	addressErr := utils.ValidateAddress(addressReq)
	if addressErr != nil {
		return nil, addressErr
	}
	// get city , state id from pincode
	pincode, pincodeErr := s.pincodeRepo.FindByPincode(ctx, addressReq.Pincode)
	if pincodeErr != nil {
		return nil, pincodeErr
	}

	addressReq.CityId = pincode.CityId
	addressReq.StateId = pincode.StateId
	addressReq.City = pincode.City.Name
	addressReq.State = pincode.State.Name
	addressModel := transformCustomerAddressReqToModel(&addressReq)
	if addressModel.IsPrimary {
		// set all other address of this customer as non primary
		primaryUpdate := make(map[string]interface{})
		primaryUpdate["IsPrimary"] = false
		updateErr := s.customerAddressRepo.UpdateWithMapInterface(ctx, primaryUpdate, models.CustomerAddress{CustomerRefNumber: addressReq.CustomerRefNumber})
		if updateErr != nil {
			utils.InternalServerError(ctx, updateErr, "CreateAddress|error while updating customer address: "+addressReq.CustomerRefNumber)
		}
	}
	res, err := s.customerAddressRepo.Create(ctx, addressModel)
	if err != nil {
		utils.InternalServerError(ctx, err, "error while creating customer address")
	}
	eventdata := convertModelAddressToEventAddress(addressModel)
	publishCreateAddressEvent(ctx, eventdata)

	addressRes := response.AddressDetails{AddressRefNumber: res.AddressRefNumber}
	return &response.CreateAddressRes{Address: addressRes}, nil
}

func transformCustomerAddressReqToModel(addrreq *request.CreateAddressRequest) *models.CustomerAddress {
	return &models.CustomerAddress{
		CaseRefNumber:     addrreq.CaseRefNumber,
		CustomerRefNumber: addrreq.CustomerRefNumber,
		LoanRefNumber:     addrreq.LoanRefNumber,
		Label:             addrreq.Label,
		Source:            addrreq.Source,
		AddressMedium:     addrreq.AddressMedium,
		Type:              addrreq.Type,
		ResidentType:      addrreq.ResidentType,
		Line1:             addrreq.Line1,
		Line2:             addrreq.Line2,
		Line3:             addrreq.Line3,
		Landmark:          addrreq.Landmark,
		Pincode:           addrreq.Pincode,
		City:              addrreq.City,
		State:             addrreq.State,
		CityId:            addrreq.CityId,
		StateId:           addrreq.StateId,
		Country:           addrreq.Country,
		IsPrimary:         addrreq.IsPrimary,
	}
}

func transformCustomerAddresses(addresses []models.CustomerAddress) []response.CustomerAddress {
	var resp []response.CustomerAddress
	for i := range addresses {
		resp = append(resp, response.CustomerAddress{
			ID:                addresses[i].ID,
			CustomerRefNumber: addresses[i].CustomerRefNumber,
			AddressRefNumber:  addresses[i].AddressRefNumber,
			LoanRefNumber:     addresses[i].LoanRefNumber,
			Label:             addresses[i].Label.String(),
			Type:              addresses[i].Type.String(),
			ResidentType:      addresses[i].ResidentType,
			Source:            addresses[i].Source.String(),
			Latitude:          addresses[i].Lat,
			Longitude:         addresses[i].Long,
			Line1:             addresses[i].Line1,
			Line2:             addresses[i].Line2,
			Line3:             addresses[i].Line3,
			Landmark:          addresses[i].Landmark,
			Pincode:           addresses[i].Pincode,
			City:              addresses[i].City,
			State:             addresses[i].State,
			Country:           addresses[i].Country,
			CityId:            addresses[i].CityId,
			StateId:           addresses[i].StateId,
			CreatedAt:         addresses[i].CreatedAt,
			UpdatedAt:         addresses[i].UpdatedAt,
			IsPrimary:         addresses[i].IsPrimary,
		})
	}

	return resp
}

func (s CustomerAddressService) UpdateCustomerLocation(ctx context.Context, address request.Address) error {
	logger.Info(ctx, "CustomerAddressService|UpdateCustomerLocation", logger.LogFields{"requestbody": address})
	locationRes, err := s.convertAddressToLatLong(ctx, address)
	if err != nil {
		return err
	}
	whereBlock := models.CustomerAddress{
		AddressRefNumber: address.AddressRefNumber,
	}
	updateAddress := models.CustomerAddress{
		Lat:  locationRes.Latitude,
		Long: locationRes.Longitude,
	}

	ok, err := s.customerAddressRepo.Update(ctx, updateAddress, whereBlock)
	if err != nil {
		logger.Error(ctx, err, "CustomerAddressService|UpdateCustomerLocation", logger.LogFields{"address": address, "Where": whereBlock.AddressRefNumber, "location": updateAddress})
		return err
	}
	if !ok {
		logger.Error(ctx, err, "CustomerAddressService|UpdateCustomerLocation", logger.LogFields{"address": address, "Where": whereBlock.AddressRefNumber, "location": updateAddress})
		return err
	}

	return nil
}

func (s CustomerAddressService) convertAddressToLatLong(ctx context.Context, address request.Address) (google.GoogleLatLong, error) {
	googleAddress := convertAddressRequestDTOtoGoogleAddressDTO(ctx, address)
	locationRes, err := google.GetLatLong(ctx, googleAddress)
	if err != nil {
		logger.Error(ctx, err, "CustomerAddressService|convertAddressToLatLong", logger.LogFields{"address": address, "location": locationRes})
		return locationRes, err
	}

	return locationRes, nil
}

func convertAddressRequestDTOtoGoogleAddressDTO(ctx context.Context, address request.Address) google.GoogleAdress {
	return google.GoogleAdress{
		Address: address.Line1 + " " + address.Line2 + " " + address.Line3 + " " + address.Landmark,
		City:    address.City,
		State:   address.State,
		Pincode: address.Pincode,
		Country: address.Country,
	}
}

func convertModelAddressToEventAddress(reqAddr *models.CustomerAddress) events.Address {
	return events.Address{
		AddressRefNumber: reqAddr.AddressRefNumber,
		Label:            reqAddr.Label.String(),
		Type:             reqAddr.Type.String(),
		ResidentType:     reqAddr.ResidentType,
		Source:           reqAddr.Source.String(),
		Line1:            reqAddr.Line1,
		Line2:            reqAddr.Line2,
		Line3:            reqAddr.Line3,
		Landmark:         reqAddr.Landmark,
		Pincode:          reqAddr.Pincode,
		City:             reqAddr.City,
		State:            reqAddr.State,
		Country:          reqAddr.Country,
	}
}

// This function is used for publish address list events to RabbitMQ
func publishCreateAddressEvent(ctx context.Context, event events.Address) bool {
	data := adapter.NewMessage(ctx, "address_created", event, "")
	payload, err := json.Marshal(data)

	if err != nil {
		logger.Error(ctx, err, "LoanService|publishAddressListEvent|MarshalError", logger.LogFields{"address_event": event})
		return false
	}

	if err := rabbit_mq.GetRabbitMQClientInstance(ctx).Publish(ctx, constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, payload, nil); err != nil {
		logger.Error(ctx, err, "LoanService|publishAddressListEvent", logger.LogFields{"address_event": event})
		return false
	}
	return true
}
