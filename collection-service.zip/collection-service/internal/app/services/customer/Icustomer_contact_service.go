package customer

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type ICustomerContactService interface {
	services.IBaseService
	AddCustomerContact(ctx context.Context, req request.AddContact) (*string, error)
	CustomerContactList(context.Context, request.CustomerContactListFilter) (response.CustomerContactListResponse, error)
}
