package customer

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type ICustomerDocumentService interface {
	services.IBaseService

	GetDocuments(ctx context.Context, customerRefNumber, loanRefNumber string) ([]response.CustomerDocument, error)
	UploadCustomerDocuments(ctx context.Context, fileBytes []byte, customerDoc request.CustomerDocumentRequest) error
}
