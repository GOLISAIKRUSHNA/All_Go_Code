package customer

import (
	"bytes"
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"

	"github.com/spf13/viper"
	"gorm.io/gorm"
)

type CustomerDocumentService struct {
	services.BaseService
	customerDocsRepo repo_interfaces.ICustomerDocsRepository
	fileManager      adapter.IFileManager
	cacheEnabled     bool
	customerRepo     repo_interfaces.ICustomerRepository
	awsImport        aws.S3Client
}

const (
	CUSTOMER_REF_NUMBER = "customer_ref_number"
	LOAN_REF_NUMBER     = "loan_ref_number"
)

func InitCustomerDocumentService(ctx context.Context) *CustomerDocumentService {
	service := &CustomerDocumentService{
		customerDocsRepo: repositories.InitCustomerDocsRepository(ctx),
		cacheEnabled:     viper.GetBool("REDIS_ENABLED"),
		fileManager:      aws.GetS3Instance(),
		customerRepo:     repositories.InitCustomerRepository(ctx),
		awsImport:        *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (d *CustomerDocumentService) GetDocuments(ctx context.Context, customerRefNumber, loanRefNumber string) ([]response.CustomerDocument, error) {
	if span := tracing.TraceSpan(ctx, "CustomerDocumentService.GetDocuments"); span != nil {
		defer span.End()
	}

	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	validateGetDocumentsQueryParams(ctx, customerRefNumber, loanRefNumber)

	filters := models.CustomerDocument{
		CustomerRefNumber: customerRefNumber,
		LoanRefNumber:     loanRefNumber,
	}

	addresses, err := d.customerDocsRepo.FindMany(ctx, &filters)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	resp, err := transformCustomerDocsModelsToResp(ctx, addresses, d)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	return resp, nil

}

func validateGetDocumentsQueryParams(ctx context.Context, customerRefNumber, loanRefNumber string) {
	if customerRefNumber == "" &&
		loanRefNumber == "" {
		utils.MissingParamsException(ctx,
			[]string{fmt.Sprintf("%s or %s", CUSTOMER_REF_NUMBER, LOAN_REF_NUMBER)})
	}
}

func transformCustomerDocsModelsToResp(ctx context.Context, documents []models.CustomerDocument, service *CustomerDocumentService) ([]response.CustomerDocument, error) {
	var resp []response.CustomerDocument

	for i := range documents {
		fileURL, err := service.fileManager.GetSharableURL(ctx, documents[i].FilePath, constants.CUSTOMER_DOCUMENTS_AWS_BUCKET)
		if err != nil {
			return nil, err
		}

		resp = append(resp, response.CustomerDocument{
			ID:                documents[i].ID,
			DocumentRefNumber: documents[i].DocumentRefNumber,
			CustomerRefNumber: documents[i].CustomerRefNumber,
			LoanRefNumber:     documents[i].LoanRefNumber,
			Type:              documents[i].Type,
			CreatedAt:         documents[i].CreatedAt,
			FileURL:           fileURL,
		})
	}

	return resp, nil
}

/*
Save Customer Documents based on clientId
- Upload document on s3 & save path in table
@author Tejas Surve
*/
func (l *CustomerDocumentService) UploadCustomerDocuments(ctx context.Context, fileBytes []byte, customerDoc request.CustomerDocumentRequest) error {
	logger.Info(ctx, "CustomerDocumentService|saveCustomerDocuments|Input", logger.LogFields{"documentRequest": customerDoc})

	// Check existing document
	where := models.CustomerWhereParams{
		ClientCustomerId: customerDoc.ClientCustomerId,
		ClientRefNumber:  customerDoc.ClientRefNumber,
	}
	customer, err := l.customerRepo.FindOne(ctx, where)
	if err != gorm.ErrRecordNotFound && err != nil {
		logger.Error(ctx, err, "CustomerDocumentService|saveCustomerDocuments|DBError", logger.LogFields{"input": where.CustomerRefNumber})
		return err
	}

	// Convert byte slice to multipart.File
	fileContent := ioutil.NopCloser(bytes.NewReader(fileBytes))

	contentType := http.DetectContentType(fileBytes)                                                                                                      // Detect content type
	filePath := customer.CustomerRefNumber + "/" + utils.GenerateRandomString(6, customerDoc.DocumentType+"_") + "." + strings.Split(contentType, "/")[1] // Extract extension
	s3Err := l.awsImport.UploadFile(ctx, filePath, constants.CUSTOMER_DOCUMENTS_AWS_BUCKET, fileContent, contentType)
	if s3Err != nil {
		logger.Error(ctx, s3Err, "UploadService|UploadFile|err", logger.LogFields{})
		return s3Err
	}

	docPresent, docErr := l.customerDocsRepo.FindCustomerDocument(ctx, models.CustomerDocument{CustomerRefNumber: customer.CustomerRefNumber, Type: customerDoc.DocumentType})
	if docErr == nil && utils.IsNotEmpty(docPresent.DocumentRefNumber) {
		updateDocReq := models.CustomerDocument{
			FilePath:  filePath,
			CreatedBy: customerDoc.CreatedBy,
		}
		_, updateErr := l.customerDocsRepo.Update(ctx, updateDocReq, models.CustomerDocument{DocumentRefNumber: docPresent.DocumentRefNumber})
		if updateErr != nil {
			return updateErr
		}
	} else {
		docReq := models.CustomerDocument{
			CustomerRefNumber: customer.CustomerRefNumber,
			Type:              customerDoc.DocumentType,
			FilePath:          filePath,
			CreatedBy:         customerDoc.CreatedBy,
		}

		_, createErr := l.customerDocsRepo.Create(ctx, docReq)
		if createErr != nil {
			return createErr
		}
	}

	return nil
}
