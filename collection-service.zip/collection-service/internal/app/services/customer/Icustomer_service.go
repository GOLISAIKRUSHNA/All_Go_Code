package customer

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	"context"
)

type ICustomerService interface {
	services.IBaseService

	//FindLoan(ctx context.Context, customer_ref_number string) map[string]interface{}
	GetCustomer(ctx context.Context, filter models.CustomerWhereParams) (response.Customer, error)
	Create(ctx context.Context, customerReq request.CustomerReq) (response.Customer, error)
	Update(ctx context.Context, customerReq request.CustomerReq, customerId string) response.Customer
	CreateCustomerWithInfo(ctx context.Context, request request.CustomerAndCustomerInfoReq) (response.Customer, error)
}
