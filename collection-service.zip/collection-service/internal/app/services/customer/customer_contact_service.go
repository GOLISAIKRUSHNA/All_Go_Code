package customer

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"time"

	"github.com/spf13/viper"
)

type CustomerContactService struct {
	services.BaseService
	customerContactRepo repo_interfaces.ICustomerContactRepository

	cacheEnabled bool
}

func InitCustomerContactService(ctx context.Context) *CustomerContactService {
	service := &CustomerContactService{
		customerContactRepo: repositories.InitCustomerContactRepository(ctx),
		cacheEnabled:        viper.GetBool("REDIS_ENABLED"),
	}

	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

/*
Desc: Add customer contact : func add new customer contact record
@return string, error
@author Shehreen
*/
func (s CustomerContactService) AddCustomerContact(ctx context.Context, req request.AddContact) (*string, error) {
	logger.Info(ctx, "CustomerContactService|AddCustomerContact|Request", logger.LogFields{"request": req})

	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	// Unique constraint for CustomerRefNumber and ContactNumber
	filters := models.CustomerContacts{CustomerRefNumber: req.CustomerRefNumber, ContactNumber: req.ContactNumber}
	contacts, err := s.customerContactRepo.FindOne(ctx, &filters)
	if err == nil || contacts != nil {
		return nil, errors.New("customer contact already exist")
		//utils.BadRequestException(ctx, constants.CONTACT_NUMBER_ALREADY_EXISTS, "customer contact already exist", nil)
	}

	if req.IsPrimary {
		updateParams := map[string]interface{}{
			"is_primary": 0,
		}
		where := models.CustomerContacts{
			CustomerRefNumber: req.CustomerRefNumber,
		}

		if err := s.customerContactRepo.UpdateCustomerContact(ctx, updateParams, where); err != nil {
			return nil, err
		}

	}

	newContact := transformCustomerContacts(req, "CREATE")

	// If the contact doesn't exist create a new one
	contact, err := s.customerContactRepo.AddCustomerContact(ctx, newContact)
	if err != nil {
		return nil, err
		//utils.InternalServerError(ctx, err)
	}
	//Publish contact event
	contactCreatedEvent := mapContactCreatedEvent(contact)
	adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, contactCreatedEvent, "customer_contact_created", nil)
	return nil, nil
}

// This function is buisness logics about customer contact list
func (s CustomerContactService) CustomerContactList(ctx context.Context, filter request.CustomerContactListFilter) (response.CustomerContactListResponse, error) {
	// implementing logger to monitor input fileds
	logger.Info(ctx, "customer_contact_service|CustomerContactList|Input", logger.LogFields{"Input": filter})
	// implementing sentry traceSpan to track errors
	if span := tracing.TraceSpan(ctx, "CaseService.ListCustomerContact"); span != nil {
		defer span.End()
	}
	// setting db dype
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)
	// checking validation. If both fields empty, throw error
	if filter.CustomerRefNumber == "" && filter.CaseRefNumber == "" {
		utils.BadRequestException(ctx, constants.REQUEST_FIELD_EMPTY, "bad request", "customer_ref_number or case_ref_number is required", nil)
	}
	var contactListResponse response.CustomerContactListResponse

	redisCustomerContactListKey := fmt.Sprintf("api:%s:%s:%s:%s:%s", constants.API_CONTACT_LIST, constants.CUSTOMER_REF_NUMBER, filter.CustomerRefNumber, constants.CASE_REF_NUMBER, filter.CaseRefNumber)

	var redisExpiry = 1 * time.Hour
	// this sub function is converting query params to string
	//queryParamString := convertQueryParamsToString(filter)
	// Getting redis instance
	redisService := cacheservice.GetInstance()
	// checking data is present in cache
	res, err := redisService.Read(redisCustomerContactListKey, "get")
	if err != nil {
		return contactListResponse, err
	}
	// If redis has no data, open db, get data and set in cache
	if res == "" {
		result, err := s.customerContactRepo.CustomerContactList(ctx, filter)
		if err != nil {
			return contactListResponse, err
		}
		// This sub function is for mapping model to dto response
		finalResponse := mapCustomerContactToDTOResponse(result)

		marshalResult, err := json.Marshal(finalResponse)
		if err != nil {
			return contactListResponse, err
		}
		// setting cache
		ok, err := redisService.Create(redisCustomerContactListKey, marshalResult, "set", redisExpiry)
		if !ok {
			return contactListResponse, err
		}
		if err != nil {
			return contactListResponse, err
		}
		// after setting cache, returning data from db
		return finalResponse, nil
	}
	// unmarshalling redis response to our dto response struct
	err = json.Unmarshal([]byte(res), &contactListResponse)

	if err != nil {
		return contactListResponse, err
	}
	// returning response from redis cache
	return contactListResponse, nil
}

// this function is used for transforming query params to string for setting redis key
func convertQueryParamsToString(filter request.CustomerContactListFilter) string {
	values := url.Values{}
	values.Set("customer_ref_number", filter.CustomerRefNumber)
	values.Set("case_ref_number", filter.CaseRefNumber)

	// Convert url.Values to string
	queryString := values.Encode()

	// Example Output: case_ref_number=456&customer_ref_number=123
	return queryString
}

func mapCustomerContactToDTOResponse(contact []models.CustomerContacts) response.CustomerContactListResponse {
	var contactsList []response.Contacts // Accumulate the results outside the loop

	for _, val := range contact {
		contactItem := response.Contacts{
			ContactRefNumber: val.ContactRefNumber,
			ContactNumber:    utils.MaskMobileNumber(val.ContactNumber),
			ContactName:      val.ContactName,
			ContactOf:        val.ContactOf,
			ContactType:      val.ContactType,
			IsPrimary:        val.IsPrimary,
			CreatedBy:        val.CreatedBy,
		}

		contactsList = append(contactsList, contactItem)
	}

	// Create the final response outside the loop
	res := response.CustomerContactListResponse{
		Contacts: contactsList,
	}

	return res
}

func transformCustomerContacts(req request.AddContact, action string) models.CustomerContacts {
	if req.ContactType == enum.ContactType(0) {
		req.ContactType = enum.APPLICANT
	}
	data := models.CustomerContacts{
		ContactNumber:     req.ContactNumber,
		ContactName:       req.ContactName,
		ContactOf:         req.ContactOf,
		ContactType:       req.ContactType,
		CaseRefNumber:     req.CaseRefNumber,
		CustomerRefNumber: req.CustomerRefNumber,
		LoanRefNumber:     req.LoanRefNumber,
		IsPrimary:         req.IsPrimary,
		CreatedBy:         req.CreatedBy,
	}
	if action == "CREATE" {
		data.ContactRefNumber = utils.GenerateRandomString(8, "CO")
	}
	return data
}

func mapContactCreatedEvent(event models.CustomerContacts) events.CustomerContactCreated {
	return events.CustomerContactCreated{
		ContactRefNumber:  event.ContactRefNumber,
		CustomerRefNumber: event.CustomerRefNumber,
		LoanRefNumber:     event.LoanRefNumber,
		CaseRefNumber:     event.CaseRefNumber,
		ContactNumber:     event.ContactName,
		ContactName:       event.ContactName,
		ContactOf:         event.ContactOf,
		ContactType:       event.ContactType,
		CreatedBy:         event.CreatedBy,
	}
}
