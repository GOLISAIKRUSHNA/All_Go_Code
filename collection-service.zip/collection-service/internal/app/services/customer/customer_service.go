package customer

import (
	"collection-service/common/logger"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/attribute_service"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"

	"github.com/spf13/viper"
)

type CustomerService struct {
	services.BaseService
	repo             repo_interfaces.ICustomerRepository
	customerKey      string
	searchKey        string
	cacheEnabled     bool
	customerInfoRepo repo_interfaces.ICustomerInfoRepository
	attributeService attribute_service.AttributeService
}

func InitCustomerService(ctx context.Context) *CustomerService {
	service := &CustomerService{
		repo:             repositories.InitCustomerRepository(ctx),
		customerKey:      "customer",
		searchKey:        "customer_search",
		cacheEnabled:     viper.GetBool("REDIS_ENABLED"),
		customerInfoRepo: repositories.InitCustomerInfoRepository(ctx),
		attributeService: *attribute_service.InitAttributeService(ctx),
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}
	return service
}

func (cu *CustomerService) GetCustomer(ctx context.Context, searchFilter models.CustomerWhereParams) (response.Customer, error) {
	cuResponse := response.Customer{}
	customer, err := cu.repo.FindOne(ctx, searchFilter)
	if err != nil {
		logger.Error(ctx, err, "Error while fetching customer record", logger.LogFields{"error": err})
		return cuResponse, err
	}
	cuResponse = response.Customer{
		MobileNumber:      customer.MobileNumber,
		ClientCustomerId:  customer.ClientCustomerId,
		CustomerRefNumber: customer.CustomerRefNumber,
	}

	return cuResponse, nil
}

func (cu *CustomerService) Create(ctx context.Context, customerReq request.CustomerReq) (response.Customer, error) {
	custModel := getCustomerModelFromRequest(customerReq, "CREATE")

	resultData, err := cu.repo.Create(ctx, custModel)
	res := transformCustomerResponse(&resultData)
	if err != nil {
		logger.Error(ctx, err, "Customer not created", logger.LogFields{"error": err})
		return res, err
	}
	return res, nil
}

func (cu *CustomerService) Update(ctx context.Context, customerReq request.CustomerReq, customerId string) response.Customer {

	custModel := getCustomerModelFromRequest(customerReq, "UPDATE")
	whereBlock := models.CustomerWhereParams{
		MobileNumber:     customerReq.MobileNumber,
		ClientRefNumber:  customerReq.ClientRefNumber,
		ClientCustomerId: customerId,
	}
	customer, err := cu.repo.Update(ctx, custModel, whereBlock)
	if err != nil {
		logger.Error(ctx, err, "CustomerService|Update", logger.LogFields{"err": err})
	}
	response := transformCustomerResponse(&customer)
	//	cu.attributeService.PushAttributeEvent(ctx, customer.CustomerRefNumber)
	return response
}

func getCustomerModelFromRequest(req request.CustomerReq, action string) models.Customer {
	data := models.Customer{
		ClientCustomerId:  req.ClientCustomerId,
		CustomerRefNumber: req.CustomerRefNumber,
		ClientRefNumber:   req.ClientRefNumber,
		FirstName:         req.FirstName,
		LastName:          req.LastName,
		PreferredLanguage: req.PreferredLanguage,
		Email:             req.Email,
		Dob:               req.Dob,
		Gender:            utils.CapitalizeFirstLetter(req.Gender),
		CreatedBy:         req.CreatedBy,
		UpdatedBy:         req.CreatedBy,
	}
	if action == "CREATE" {
		if utils.IsEmpty(req.CustomerRefNumber) {
			data.CustomerRefNumber = utils.GenerateRandomString(6, "CR")
		}
		data.MobileNumber = req.MobileNumber
	}
	return data
}

func (cu *CustomerService) CreateCustomerWithInfo(ctx context.Context, request request.CustomerAndCustomerInfoReq) (response.Customer, error) {

	custModel := getCustomerModelFromRequest(request.Customer, "CREATE")
	resultData, err := cu.repo.Create(ctx, custModel)
	res := transformCustomerResponse(&resultData)
	if err != nil {
		logger.Error(ctx, err, "CustomerService|CreateCustomerWithInfo|Customer not created", logger.LogFields{"error": err})
		return res, err
	}
	customerInfoReq := models.CustomerInfo{
		CustomerRefNumber: resultData.CustomerRefNumber,
		EmploymentType:    request.CustomerInfo.EmploymentType,
		EmployerName:      request.CustomerInfo.EmployerName,
		MonthlyIncome:     request.CustomerInfo.MonthlyIncome,
		Occupation:        request.CustomerInfo.Occupation,
		CibilScore:        request.CustomerInfo.CibilScore,
	}
	_, infoErr := cu.customerInfoRepo.Create(ctx, customerInfoReq)
	if infoErr != nil {
		logger.Error(ctx, err, "CustomerService|CreateCustomerWithInfo|Customer Info not created", logger.LogFields{"error": infoErr})
	}
	return res, nil
}

func transformCustomerResponse(result *models.Customer) response.Customer {
	custResp := response.Customer{
		ClientCustomerId:  result.ClientCustomerId,
		CustomerRefNumber: result.CustomerRefNumber,
		ClientRefNumber:   result.ClientRefNumber,
		FirstName:         result.FirstName,
		LastName:          result.LastName,
		PreferredLanguage: result.PreferredLanguage,
		MobileNumber:      result.MobileNumber,
		Email:             result.Email,
		CreatedBy:         result.CreatedBy,
	}

	return custResp
}
