package special_offer

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"context"
)

type ISpecialOfferService interface {
	services.IBaseService
	Create(ctx context.Context, offer *request.CreateSpecialOffer, loanModel *models.Loan) (*models.SpecialOffer, error)
	CreateSP(ctx context.Context, offer *request.PostCreateSpecialOffer) (response.PostSpecialOfferResp, error)
	GetSpecialOffers(ctx context.Context, caseRefNumber string) (response.GetSpecialOffersResp, error)
	GetEligibleSpecialOffers(ctx context.Context, caseRefNumber string, queueType enum.QueueType) (response.GetSpecialOffersResp, error)
	ActivateSpecialOffer(ctx context.Context, caseRefNumber string, req request.ActivateSpecialOfferReq) error
	DeactivateSpecialOffer(ctx context.Context, deactivateSpecialOfferRequest *request.DeactivateSpecialOfferReq) error
}
