package special_offer

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"errors"
	"fmt"
	"math"
	"time"

	"github.com/guregu/null/v5"

	"gorm.io/gorm"

	"github.com/spf13/viper"
)

type SpecialOfferService struct {
	services.BaseService
	cacheEnabled           bool
	specialOfferRepo       repo_interfaces.ISpecialOfferRepository
	specialOfferMasterRepo repo_interfaces.ISpecialOffersMasterRepo
	loanRepo               repo_interfaces.ILoanRepository
}

func (s *SpecialOfferService) DeactivateSpecialOffer(ctx context.Context, deactivateSpecialOfferRequest *request.DeactivateSpecialOfferReq) error {
	if span := tracing.TraceSpan(ctx, "SpecialOfferService.DeactivateSpecialOffer"); span != nil {
		defer span.End()
	}
	// fetch special offer based on special offer ref number
	specialOfferModel, err := s.specialOfferRepo.Get(ctx, &models.SpecialOffer{SpecialOfferRefNumber: deactivateSpecialOfferRequest.SpecialOfferRefNumber})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			utils.BadRequestException(ctx, "", "special offer not found", nil, nil)
		}

		utils.InternalServerError(ctx, err, "error while fetching special offer based on special offer ref number")
	}

	// deactivate special offer
	specialOfferModel.Status = enum.OFFER_INACTIVE
	err = s.specialOfferRepo.Update(ctx, &models.SpecialOffer{SpecialOfferRefNumber: deactivateSpecialOfferRequest.SpecialOfferRefNumber}, &models.SpecialOffer{Status: enum.OFFER_INACTIVE})
	if err != nil {
		utils.InternalServerError(ctx, err, "error while deactivating special offer")
	}

	return nil
}

func InitSpecialOfferService(ctx context.Context,
	specialOfferRepo repo_interfaces.ISpecialOfferRepository,
	specialOffersMasterRepo repo_interfaces.ISpecialOffersMasterRepo,
	loanRepo repo_interfaces.ILoanRepository) *SpecialOfferService {

	service := &SpecialOfferService{
		cacheEnabled:           viper.GetBool("REDIS_ENABLED"),
		specialOfferRepo:       specialOfferRepo,
		specialOfferMasterRepo: specialOffersMasterRepo,
		loanRepo:               loanRepo,
	}
	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}
	return service

}

func (s *SpecialOfferService) CreateSP(ctx context.Context, SPOfferReq *request.PostCreateSpecialOffer) (response.PostSpecialOfferResp, error) {

	offer, err := validateSpecialOfferReq(ctx, SPOfferReq)
	if err != nil {
		utils.BadRequestException(ctx, "", err.Error(), nil, nil)
	}

	loanModel, err := s.loanRepo.GetLoan(ctx, &models.Loan{ClientLoanId: offer.ClientLoanId, Status: enum.LOAN_ACTIVE})
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching loan based on client loan id")
	}

	if offer.ActivationSource == enum.ActivationSource(0) {
		offer.ActivationSource = enum.SRC_API
	}

	if offer.Status == enum.OfferStatus(0) {
		offer.Status = enum.OFFER_ACTIVE
	}

	specialOfferModel, err := s.Create(ctx, offer, loanModel)
	if err != nil {
		utils.InternalServerError(ctx, err, "error while creating special offer")
	}

	specialOfferResp := transfromSpecialOfferModelToResp(ctx, specialOfferModel)

	return specialOfferResp, nil
}

func validateSpecialOfferReq(ctx context.Context, req *request.PostCreateSpecialOffer) (*request.CreateSpecialOffer, error) {
	if req.StartDatetime == "" || req.EndDatetime == "" {
		return nil, fmt.Errorf("start date time and end date time are mandatory")
	}

	layout := "2006-01-02 15:04:05"

	// Parse the time string into a time.Time object
	startDateTime, err := time.Parse(layout, req.StartDatetime)
	if err != nil {
		logger.Error(ctx, err, "UploadService|mapSpecialOfferInput|parsedateErr", nil)
		return nil, fmt.Errorf("invalid time format entered")
	}

	endDateTime, err := time.Parse(layout, req.EndDatetime)
	if err != nil {
		logger.Error(ctx, err, "UploadService|mapSpecialOfferInput|parsedateErr", nil)
		return nil, fmt.Errorf("invalid time format entered")
	}

	return &request.CreateSpecialOffer{
		ClientLoanId:         req.ClientLoanId,
		OfferType:            req.OfferType,
		WaiverType:           req.WaiverType,
		WaiverValue:          req.WaiverValue,
		MinimumPaymentAmount: req.MinimumPaymentAmount,
		Status:               req.Status,
		StartDatetime:        startDateTime,
		EndDatetime:          endDateTime,
		CreatedBy:            req.CreatedBy,
		ActivationSource:     enum.SRC_API,
		ClientRefNumber:      req.ClientRefNumber,
	}, nil
}

func (s *SpecialOfferService) Create(ctx context.Context, offer *request.CreateSpecialOffer, loanModel *models.Loan) (*models.SpecialOffer, error) {
	if offer.ClientLoanId == "" {
		utils.BadRequestException(ctx, "", "client loan id is required", nil, nil)
	}
	// special offers date validations
	if offer.StartDatetime.After(offer.EndDatetime) {
		utils.BadRequestException(ctx, "", "start time should be less than end time.", nil, nil)
	}

	if offer.EndDatetime.Before(time.Now()) {
		utils.BadRequestException(ctx, "", "end time should be greater than current time.", nil, nil)
	}

	// fetch loan from client loan id if not present.
	if loanModel == nil {
		var err error
		loanModel, err = s.loanRepo.GetLoan(ctx, &models.Loan{ClientLoanId: offer.ClientLoanId, Status: enum.LOAN_ACTIVE})
		if err != nil {
			utils.InternalServerError(ctx, err, "error while fetching loan based on client loan id")
		}
	}

	if offer.ClientRefNumber != "" && loanModel.ClientRefNumber != offer.ClientRefNumber {
		utils.BadRequestException(ctx, "", "invalid client ref number", nil, nil)
	}

	// minimum payment amount should be less than total due.
	if offer.MinimumPaymentAmount > loanModel.TotalDue {
		utils.BadRequestException(ctx, "", "minimum payment amount should be less than total due", nil, nil)
	}

	// for flat settlement discount total due waiver value should be less than total due
	if offer.OfferType == enum.SETTLEMENT {
		if offer.WaiverType == enum.FLAT && offer.WaiverValue > loanModel.TotalDue {
			utils.BadRequestException(ctx, "", "total due waiver value should be less than total due", nil, nil)
		}
	}

	// for flat due waiver discount total fees due waiver value should be less than total fees due.
	if offer.OfferType == enum.DUES_WAIVER {
		if offer.WaiverType == enum.FLAT && offer.WaiverValue > loanModel.TotalFeesDue {
			utils.BadRequestException(ctx, "", "total fees due waiver value should be less than total fees due", nil, nil)
		}
	}

	// fetch same offer if already present.
	previousOfferFound := true
	var specialOfferFilter *models.SpecialOffer
	if offer.ActivationSource == enum.SRC_CSAT {
		specialOfferFilter = &models.SpecialOffer{LoanRefNumber: loanModel.LoanRefNumber, OfferType: offer.OfferType, Status: enum.OFFER_ACTIVE,
			ActivationSource: enum.SRC_CSAT, WaiverValue: null.NewFloat(offer.WaiverValue, true), WaiverType: offer.WaiverType, MinimumPaymentAmount: offer.MinimumPaymentAmount}

	} else if offer.ActivationSource == enum.SRC_INGRESS || offer.ActivationSource == enum.SRC_API {
		specialOfferFilter = &models.SpecialOffer{LoanRefNumber: loanModel.LoanRefNumber, OfferType: offer.OfferType, Status: enum.OFFER_ACTIVE,
			EndDatetime: offer.EndDatetime, StartDatetime: offer.StartDatetime, WaiverValue: null.NewFloat(offer.WaiverValue, true), WaiverType: offer.WaiverType, MinimumPaymentAmount: offer.MinimumPaymentAmount}
	} else {
		utils.BadRequestException(ctx, "", "invalid activation source", nil, nil)
	}

	_, err := s.specialOfferRepo.GetUnexpired(ctx, specialOfferFilter)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			previousOfferFound = false
		} else {
			utils.InternalServerError(ctx, err, "unable to fetch previous offer details")
		}
	}

	// if same offer found return offer already exists.
	if previousOfferFound {
		utils.BadRequestException(ctx, "", "offer already exists", nil, nil)
	}

	specialOfferModel := transformSpecialOfferRequestToModel(offer, loanModel.LoanRefNumber)
	specialOfferModel.CaseRefNumber = loanModel.CaseRefNumber

	// create special offer
	err = s.specialOfferRepo.Create(ctx, specialOfferModel)
	if err != nil {
		utils.InternalServerError(ctx, err, "error while saving special offer in DB")
	}

	// publish special offer created event.
	specialOfferCreatedEvent := transformSpecialOfferRequestToCreateEvent(ctx, specialOfferModel.SpecialOfferRefNumber, specialOfferModel)
	adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, specialOfferCreatedEvent, "special_offer_created", nil)
	return specialOfferModel, nil
}

func transfromSpecialOfferModelToResp(ctx context.Context, model *models.SpecialOffer) response.PostSpecialOfferResp {
	return response.PostSpecialOfferResp{
		SpecialOfferRefNumber: model.SpecialOfferRefNumber,
		CaseRefNumber:         model.CaseRefNumber,
		LoanRefNumber:         model.LoanRefNumber,
		OfferType:             model.OfferType,
		WaiverType:            model.WaiverType,
		WaiverValue:           model.WaiverValue,
		MinimumPaymentAmount:  model.MinimumPaymentAmount,
		Status:                model.Status,
		ActivationSource:      model.ActivationSource,
		StartDatetime:         model.StartDatetime,
		EndDatetime:           model.EndDatetime,
		CreatedBy:             model.CreatedBy,
		CreatedAt:             model.CreatedAt,
		UpdatedAt:             model.UpdatedAt,
	}
}

// create special offer by creating special offer request and then calling create method using case ref number as input param.
func (s *SpecialOfferService) ActivateSpecialOffer(ctx context.Context, caseRefNumber string, req request.ActivateSpecialOfferReq) error {

	// fetch loan based on case ref number
	loanModel, err := s.loanRepo.GetLoan(ctx, &models.Loan{CaseRefNumber: caseRefNumber, Status: enum.LOAN_ACTIVE})
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching loan based on case ref number")
	}

	// fetch special offer master.
	specialOfferMasterModel, err := s.specialOfferMasterRepo.GetSpecialOfferMaster(ctx,
		&models.SpecialOffersMaster{ClientRefNumber: loanModel.ClientRefNumber,
			QueueType: req.QueueType,
			OfferType: req.OfferType, SpecialOffersMasterRefNumber: req.SpecialOffersMasterRefNumber})

	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching special offer master")
	}

	offer := request.CreateSpecialOffer{
		OfferType:   specialOfferMasterModel.OfferType,
		WaiverValue: specialOfferMasterModel.OfferTypePercentage,
		WaiverType:  enum.PERCENTAGE,
	}

	offer.Status = enum.OFFER_ACTIVE
	offer.StartDatetime = time.Now()
	offer.EndDatetime = time.Now().AddDate(0, 0, specialOfferMasterModel.Days)
	offer.ClientLoanId = loanModel.ClientLoanId
	offer.ClientRefNumber = req.ClientRefNumber
	if req.QueueType == enum.QUEUE_CSAT {
		offer.ActivationSource = enum.SRC_CSAT
	}

	_, err = s.Create(ctx, &offer, loanModel)
	if err != nil {
		utils.InternalServerError(ctx, err, "error while creating special offer")
	}

	return nil
}

func transformSpecialOfferRequestToCreateEvent(ctx context.Context, specialOfferRefNumber string, specialOfferModel *models.SpecialOffer) *events.SpecialOfferCreated {

	event := &events.SpecialOfferCreated{
		SpecialOfferRefNumber: specialOfferRefNumber,
		CaseRefNumber:         specialOfferModel.CaseRefNumber,
		LoanRefNumber:         specialOfferModel.LoanRefNumber,
		OfferType:             specialOfferModel.OfferType,
		MinimumPaymentAmount:  specialOfferModel.MinimumPaymentAmount,
		OfferStatus:           specialOfferModel.Status,
		StartDatetime:         specialOfferModel.StartDatetime.Format("2006-01-02 15:04:05"),
		EndDatetime:           specialOfferModel.EndDatetime.Format("2006-01-02 15:04:05"),
		CreatedBy:             specialOfferModel.CreatedBy,
		CreatedAt:             specialOfferModel.CreatedAt,
		UpdatedAt:             specialOfferModel.UpdatedAt,
		WaiverValue:           specialOfferModel.WaiverValue.Float64,
		WaiverType:            specialOfferModel.WaiverType,
	}

	return event
}

func (s *SpecialOfferService) GetSpecialOffers(ctx context.Context, caseRefNumber string) (response.GetSpecialOffersResp, error) {
	// fetch loan ref number from case ref number
	loanModel, err := s.loanRepo.GetLoan(ctx, &models.Loan{CaseRefNumber: caseRefNumber})
	if err != nil {
		msg := "error while fetching loan info"

		if errors.Is(err, gorm.ErrRecordNotFound) {
			msg = "can not find loan corresponding to case ref number"
		}
		utils.InternalServerError(ctx, err, msg)
	}

	specialOffers, err := s.specialOfferRepo.FindAllUnexpired(ctx, &models.SpecialOffer{LoanRefNumber: loanModel.LoanRefNumber, Status: enum.OFFER_ACTIVE})
	if err != nil {
		utils.InternalServerError(ctx, err, "unable to find special offers")
	}

	_, offerTypeToSpecialOfferMap := calculateSpecialOffers(ctx, specialOffers, loanModel)

	tagBestOffersPerOfferType(offerTypeToSpecialOfferMap)

	// get list of special offers resp from map
	var specialOffersResp []response.SpecialOfferRespInfo
	for _, v := range offerTypeToSpecialOfferMap {
		for i := range v {
			if v[i].CurrentlyActive {
				specialOffersResp = append(specialOffersResp, v[i])
			}
		}
	}

	return response.GetSpecialOffersResp{SpecialOffers: specialOffersResp}, nil
}

func tagBestOffersPerOfferType(offerTypeToSpecialOfferMap map[enum.OfferType][]response.SpecialOfferRespInfo) {
	var bestOffers []response.SpecialOfferRespInfo

	for _, offerList := range offerTypeToSpecialOfferMap {
		bestOfferIndex := -1
		minimumDueDiscounted := math.MaxFloat64

		for i := range offerList {
			if offerList[i].Status == enum.OFFER_INACTIVE {
				bestOffers = append(bestOffers, offerList[i])
				continue
			}

			if offerList[i].TotalDueDiscounted < minimumDueDiscounted {
				bestOfferIndex = i
				minimumDueDiscounted = offerList[i].TotalDueDiscounted
			} else if offerList[i].TotalDueDiscounted == minimumDueDiscounted {
				if offerList[i].MinimumPaymentAmount < offerList[bestOfferIndex].MinimumPaymentAmount {
					bestOfferIndex = i
				}
			}
		}

		if bestOfferIndex != -1 {
			offerList[bestOfferIndex].CurrentlyActive = true
		}
	}
}

func (s *SpecialOfferService) GetEligibleSpecialOffers(ctx context.Context, caseRefNumber string, queueType enum.QueueType) (response.GetSpecialOffersResp, error) {
	// mandatory fields for eligible special offers
	if caseRefNumber == "" {
		utils.BadRequestException(ctx, "", "case ref number is required", nil, nil)
	}

	if queueType == enum.QueueType(0) {
		utils.BadRequestException(ctx, "", "queue type is required", nil, nil)
	}

	// fetch loan details
	loanModel, err := s.loanRepo.GetLoan(ctx, &models.Loan{CaseRefNumber: caseRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching loan info")
	}

	// fetch special offers from master
	specialOffersMasterModels, err := s.specialOfferMasterRepo.GetSpecialOffersMaster(ctx, &models.SpecialOffersMaster{ClientRefNumber: loanModel.ClientRefNumber, QueueType: queueType})
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching special offers master")
	}

	specialOffersModelsFromMaster := generateSpecialOffersFromMaster(ctx, specialOffersMasterModels, loanModel)

	offerTypeToSpecialOfferMap := make(map[enum.OfferType][]models.SpecialOffer)
	for i := range specialOffersModelsFromMaster {
		offerTypeToSpecialOfferMap[specialOffersModelsFromMaster[i].OfferType] = append(offerTypeToSpecialOfferMap[specialOffersModelsFromMaster[i].OfferType], specialOffersModelsFromMaster[i])
	}

	activatedSpecialOffers, err := s.specialOfferRepo.FindAllUnexpired(ctx, &models.SpecialOffer{LoanRefNumber: loanModel.LoanRefNumber, Status: enum.OFFER_ACTIVE})
	if err != nil {
		utils.InternalServerError(ctx, err, "unable to find special offers")
	}

	// update offer type map with activated special offers
	for i := range activatedSpecialOffers {
		if activatedSpecialOffers[i].ActivationSource == enum.SRC_CSAT {
			processCSATInactiveSpecialOffer(ctx, &activatedSpecialOffers[i], offerTypeToSpecialOfferMap)
		}
	}

	for i := range activatedSpecialOffers {
		offerTypeToSpecialOfferMap[activatedSpecialOffers[i].OfferType] = append(offerTypeToSpecialOfferMap[activatedSpecialOffers[i].OfferType], activatedSpecialOffers[i])
	}

	var specialOffers []models.SpecialOffer
	for _, v := range offerTypeToSpecialOfferMap {
		specialOffers = append(specialOffers, v...)
	}

	_, offersMap := calculateSpecialOffers(ctx, specialOffers, loanModel)

	tagBestOffersPerOfferType(offersMap)

	// get list of special offers resp from map
	var specialOffersResp []response.SpecialOfferRespInfo
	for _, v := range offersMap {
		for i := range v {
			specialOffersResp = append(specialOffersResp, v[i])
		}
	}

	return response.GetSpecialOffersResp{SpecialOffers: specialOffersResp}, nil
}

func processCSATInactiveSpecialOffer(ctx context.Context, activeCsatOffer *models.SpecialOffer, inactiveCsatOffersMap map[enum.OfferType][]models.SpecialOffer) {
	offerType := activeCsatOffer.OfferType

	for i := range inactiveCsatOffersMap[offerType] {
		// remove same offer with same waiver type and waiver value from inactive offers.
		if inactiveCsatOffersMap[offerType][i].WaiverValue.Float64 == activeCsatOffer.WaiverValue.Float64 &&
			inactiveCsatOffersMap[offerType][i].WaiverType == activeCsatOffer.WaiverType {
			//if len(inactiveCsatOffersMap[offerType]) > 1 {
			inactiveCsatOffersMap[offerType] = append(inactiveCsatOffersMap[offerType][:i], inactiveCsatOffersMap[offerType][i+1:]...)
			//}
		}
	}
}

func generateSpecialOffersFromMaster(ctx context.Context, masterModels []models.SpecialOffersMaster, loanModel *models.Loan) []models.SpecialOffer {
	var specialOffers []models.SpecialOffer

	for i := range masterModels {
		var specialOffer models.SpecialOffer

		specialOffer.LoanRefNumber = loanModel.LoanRefNumber
		specialOffer.CaseRefNumber = loanModel.CaseRefNumber
		specialOffer.OfferType = masterModels[i].OfferType
		specialOffer.WaiverType = enum.PERCENTAGE
		specialOffer.WaiverValue = null.NewFloat(masterModels[i].OfferTypePercentage, true)

		specialOffer.Status = enum.OFFER_INACTIVE

		specialOffer.StartDatetime = time.Now()
		specialOffer.EndDatetime = time.Now().AddDate(0, 0, masterModels[i].Days)

		specialOffer.CreatedBy = masterModels[i].CreatedBy
		specialOffer.CreatedAt = masterModels[i].CreatedAt
		specialOffer.UpdatedAt = masterModels[i].UpdatedAt
		specialOffer.SpecialOfferMasterRefNumber = masterModels[i].SpecialOffersMasterRefNumber

		if masterModels[i].QueueType == enum.QUEUE_CSAT {
			specialOffer.ActivationSource = enum.SRC_CSAT
		}

		specialOffers = append(specialOffers, specialOffer)

	}

	return specialOffers
}

func calculateSpecialOffers(ctx context.Context, specialOffers []models.SpecialOffer, loanModel *models.Loan) ([]response.SpecialOfferRespInfo, map[enum.OfferType][]response.SpecialOfferRespInfo) {
	var specialOffersResp []response.SpecialOfferRespInfo
	var offerTypeToSpecialOfferMap = make(map[enum.OfferType][]response.SpecialOfferRespInfo)

	for i := range specialOffers {
		// filtering out expired offers
		if specialOffers[i].EndDatetime.Before(time.Now()) {
			continue
		}

		// filtering out offers with total due amount less than or equal to 0
		switch specialOffers[i].OfferType {
		case enum.DUES_WAIVER:
			if loanModel.TotalFeesDue <= 0 {
				continue
			}
		case enum.SETTLEMENT:
			if loanModel.TotalDue <= 0 {
				continue
			}
		}

		var specialOfferResp response.SpecialOfferRespInfo

		// extract info from special offer
		specialOfferResp.SpecialOfferRefNumber = specialOffers[i].SpecialOfferRefNumber
		specialOfferResp.OfferType = specialOffers[i].OfferType.String()
		specialOfferResp.LoanRefNumber = specialOffers[i].LoanRefNumber
		specialOfferResp.StartDatetime = specialOffers[i].StartDatetime.Format("2006-01-02 15:04:05")
		specialOfferResp.EndDatetime = specialOffers[i].EndDatetime.Format("2006-01-02 15:04:05")
		specialOfferResp.MinimumPaymentAmount = specialOffers[i].MinimumPaymentAmount
		specialOfferResp.Status = specialOffers[i].Status
		specialOfferResp.ActivationSource = specialOffers[i].ActivationSource
		specialOfferResp.SpecialOffersMasterRefNumber = specialOffers[i].SpecialOfferMasterRefNumber

		// extract info from loan model
		specialOfferResp.TotalDue = loanModel.TotalDue
		specialOfferResp.TotalInterestDue = loanModel.TotalInterestDue
		specialOfferResp.TotalFeesDue = loanModel.TotalFeesDue
		specialOfferResp.TotalPrincipalDue = loanModel.TotalPrincipalDue

		if specialOffers[i].OfferType == enum.DUES_WAIVER {
			if specialOffers[i].WaiverType == enum.FLAT {
				specialOfferResp.TotalFeesDueDiscounted = specialOfferResp.TotalFeesDue - specialOffers[i].WaiverValue.Float64
				specialOfferResp.TotalFeesDueWaiverPercentage = specialOffers[i].WaiverValue.Float64 / specialOfferResp.TotalFeesDue * 100.0
			} else if specialOffers[i].WaiverType == enum.PERCENTAGE {
				specialOfferResp.TotalFeesDueWaiverPercentage = specialOffers[i].WaiverValue.Float64
				specialOfferResp.TotalFeesDueDiscounted = specialOfferResp.TotalFeesDue * (100 - specialOfferResp.TotalFeesDueWaiverPercentage) / 100
			}
			specialOfferResp.TotalPrincipalDueDiscounted = specialOfferResp.TotalPrincipalDue
			specialOfferResp.TotalInterestDueDiscounted = specialOfferResp.TotalInterestDue
			specialOfferResp.TotalDueDiscounted = specialOfferResp.TotalDue + specialOfferResp.TotalFeesDueDiscounted - specialOfferResp.TotalFeesDue
			specialOfferResp.OfferWaiverPercentage = math.Round(specialOfferResp.TotalFeesDueWaiverPercentage*100) / 100
		} else if specialOffers[i].OfferType == enum.SETTLEMENT {
			specialOfferResp.TotalPrincipalDueDiscounted = specialOfferResp.TotalPrincipalDue
			specialOfferResp.TotalInterestDueDiscounted = specialOfferResp.TotalInterestDue
			specialOfferResp.TotalFeesDueDiscounted = specialOfferResp.TotalFeesDue
			specialOfferResp.TotalDueDiscounted = specialOfferResp.TotalDue

			if specialOffers[i].WaiverType == enum.FLAT {
				specialOfferResp.TotalFeesDueDiscounted -= specialOffers[i].WaiverValue.Float64
				specialOfferResp.TotalDueDiscounted -= specialOffers[i].WaiverValue.Float64

				if specialOfferResp.TotalFeesDueDiscounted < 0 {
					specialOfferResp.TotalInterestDueDiscounted += specialOfferResp.TotalFeesDueDiscounted
					specialOfferResp.TotalDueDiscounted += specialOfferResp.TotalFeesDueDiscounted

					specialOfferResp.TotalFeesDueDiscounted = 0
				}

				if specialOfferResp.TotalInterestDueDiscounted < 0 {
					specialOfferResp.TotalPrincipalDueDiscounted += specialOfferResp.TotalInterestDueDiscounted
					specialOfferResp.TotalDueDiscounted += specialOfferResp.TotalInterestDueDiscounted

					specialOfferResp.TotalInterestDueDiscounted = 0
				}

				specialOfferResp.TotalPrincipalDueDiscounted = math.Max(specialOfferResp.TotalPrincipalDueDiscounted, 0)
				specialOfferResp.TotalDueDiscounted = math.Max(specialOfferResp.TotalDueDiscounted, 0)

				specialOfferResp.TotalDueWaiverPercentage = (specialOfferResp.TotalDue - specialOfferResp.TotalDueDiscounted) / specialOfferResp.TotalDue * 100.0

			} else if specialOffers[i].WaiverType == enum.PERCENTAGE {
				specialOfferResp.TotalDueWaiverPercentage = specialOffers[i].WaiverValue.Float64
				specialOfferResp.TotalFeesDueDiscounted = specialOfferResp.TotalFeesDue * (100 - specialOfferResp.TotalDueWaiverPercentage) / 100
				specialOfferResp.TotalInterestDueDiscounted = specialOfferResp.TotalInterestDue * (100 - specialOfferResp.TotalDueWaiverPercentage) / 100
				specialOfferResp.TotalPrincipalDueDiscounted = specialOfferResp.TotalPrincipalDue * (100 - specialOfferResp.TotalDueWaiverPercentage) / 100
				specialOfferResp.TotalDueDiscounted = specialOfferResp.TotalDue * (100 - specialOfferResp.TotalDueWaiverPercentage) / 100
			}
			specialOfferResp.OfferWaiverPercentage = math.Round(specialOfferResp.TotalDueWaiverPercentage*100) / 100
		}

		// no discounted value can be negative
		specialOfferResp.TotalFeesDueDiscounted = math.Max(specialOfferResp.TotalFeesDueDiscounted, 0)
		specialOfferResp.TotalInterestDueDiscounted = math.Max(specialOfferResp.TotalInterestDueDiscounted, 0)
		specialOfferResp.TotalPrincipalDueDiscounted = math.Max(specialOfferResp.TotalPrincipalDueDiscounted, 0)
		specialOfferResp.TotalDueDiscounted = math.Max(specialOfferResp.TotalDueDiscounted, 0)

		specialOffersResp = append(specialOffersResp, specialOfferResp)
		offerTypeToSpecialOfferMap[specialOffers[i].OfferType] = append(offerTypeToSpecialOfferMap[specialOffers[i].OfferType], specialOfferResp)

	}
	return specialOffersResp, offerTypeToSpecialOfferMap
}

func transformSpecialOfferRequestToModel(offer *request.CreateSpecialOffer, loanRefNumber string) *models.SpecialOffer {
	model := &models.SpecialOffer{
		LoanRefNumber:        loanRefNumber,
		OfferType:            offer.OfferType,
		WaiverType:           offer.WaiverType,
		WaiverValue:          null.NewFloat(offer.WaiverValue, true),
		MinimumPaymentAmount: offer.MinimumPaymentAmount,
		Status:               offer.Status,
		StartDatetime:        offer.StartDatetime,
		EndDatetime:          offer.EndDatetime,
		CreatedBy:            offer.CreatedBy,
		ActivationSource:     offer.ActivationSource,
	}

	return model
}
