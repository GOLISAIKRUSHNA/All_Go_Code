package _case

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"context"
	//"collection-service/internal/dto/response"
)

type ICaseFreezeService interface {
	services.IBaseService
	FreezeCase(ctx context.Context, request request.FreezeCase) error
	UnFreezeCase(ctx context.Context, request request.UnFreezeCase) error
	DailyCallslimitFreeze(ctx context.Context, request request.DailyCallsLimitFreeze) error
}
