package _case

import (
	config "collection-service"
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/app/constants"
	eventConstants "collection-service/internal/app/constants/events"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/agent"
	"collection-service/internal/app/services/attribute_service"
	"collection-service/internal/app/services/case_permissions"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/mitchellh/mapstructure"

	"github.com/spf13/viper"
	"gorm.io/gorm"
)

type CaseService struct {
	repositories.BaseRepo
	services.BaseService
	caseRepo                     repo_interfaces.ICaseRepository
	CaseStatusHistoryRepo        repo_interfaces.ICaseStatusHistoryRepository
	caseKey                      string
	searchKey                    string
	cacheEnabled                 bool
	loanRepo                     repo_interfaces.ILoanRepository
	clientRepo                   repo_interfaces.IClientRepository
	allocationRepo               repo_interfaces.IAllocationRepository
	allocationHistoryRepo        repo_interfaces.IAllocationHistoryRepository
	caseAttributeRepo            repo_interfaces.ICaseAttributeRepository
	customerContactRepo          repo_interfaces.ICustomerContactRepository
	awsImport                    aws.S3Client
	attributeService             attribute_service.AttributeService
	serviceProviderRepo          repo_interfaces.IServiceProviderRepository
	agentRepo                    repo_interfaces.IAgentRepository
	clientUserRepo               repo_interfaces.IClientUserRepository
	blockReasonRepo              repo_interfaces.IBlockReasonMasterRepository
	caseBlockListRepo            repo_interfaces.ICaseBlockListRepository
	dispositionRepo              repo_interfaces.IDispositionRepository
	clientServiceProviderMapping repo_interfaces.IClientServiceProviderRepository
	agentService                 agent.IAgentService
	casePermissionService        case_permissions.CasePermissionsService

	//permify *permify.PermifyClient
}

type Client struct {
	ClientRefNumber     string `json:"client_ref_number"`
	CaseLevel           string `json:"case_level"`
	ApplyPaymentLogic   string `json:"apply_payment_logic"`
	CCCaseLevel         string `json:"cc_case_level"`
	DailyCallsLimit     int    `json:"daily_calls_limit"`
	DistanceCheckMeters int    `json:"distance_check_meters"`
}

var clientInfo *Client

// Initialization of CaseService with respect to the interface IcaseService
// Accepts only context as a parameter and hardcodes the loanKey, searchKey and cacheEnabled from .env variables
// Returns the LoanService pointer instance to the caller
func InitCaseService(ctx context.Context) *CaseService {

	service := &CaseService{
		caseRepo:                     repositories.InitCaseRepository(ctx),
		CaseStatusHistoryRepo:        repositories.InitCaseStatusHistoryRepository(ctx),
		caseKey:                      "case",
		searchKey:                    "case_search",
		cacheEnabled:                 viper.GetBool("REDIS_ENABLED"),
		loanRepo:                     repositories.InitLoanRepository(ctx),
		clientRepo:                   repositories.InitClientRepository(ctx),
		allocationRepo:               repositories.InitAllocationRepository(ctx),
		allocationHistoryRepo:        repositories.InitAllocationHistoryRepository(ctx),
		caseAttributeRepo:            repositories.InitCaseAttributeRepository(ctx),
		awsImport:                    *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
		customerContactRepo:          repositories.InitCustomerContactRepository(ctx),
		attributeService:             *attribute_service.InitAttributeService(ctx),
		serviceProviderRepo:          repositories.InitServiceProviderRepository(ctx),
		agentRepo:                    repositories.InitAgentRepository(ctx),
		blockReasonRepo:              repositories.InitBlockReasonRepository(ctx),
		caseBlockListRepo:            repositories.InitCaseBlockListRepository(ctx),
		dispositionRepo:              repositories.InitDispositionRepository(ctx),
		clientServiceProviderMapping: repositories.InitClientServiceProviderRepository(ctx),
		agentService:                 agent.InitAgentService(ctx),
		clientUserRepo:               repositories.InitClientUserRepository(ctx),
		casePermissionService:        case_permissions.InitCasePermissionsService(ctx),
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (ca *CaseService) FindCase(ctx context.Context, caseFilter models.Case) models.Case {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "CaseService.FindCase"); span != nil {
		defer span.End()
	}

	result, err := ca.caseRepo.FindByReferenceNumberOne(ctx, caseFilter)
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			utils.ValidationError(ctx, []dto.RequestDetails{
				{
					Field:   "CaseRefNumber",
					Message: "CaseRefNumber is not valid",
				},
			})
		}
		return *result
	}

	return *result
}

/*
GenerateCase : func will create new or update case based on client case generation logic
Func is also called by rabbitmq consumer
@return bool , error
@author Tejas Surve
*/
func (ca *CaseService) GenerateCase(ctx context.Context, caseReq request.GenerateCase) (bool, error) {
	logger.Info(ctx, "CaseService|GenerateCase|Input", logger.LogFields{"input": caseReq})

	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	// Setting client information for request
	ca.setClientInfo(ctx, caseReq.ClientRefNumber)

	caseGenerated := false
	loanFilter := models.Loan{
		LoanRefNumber:     caseReq.LoanRefNumber, //Not required
		CustomerRefNumber: caseReq.CustomerRefNumber,
		Level:             clientInfo.CaseLevel,
		ClientRefNumber:   caseReq.ClientRefNumber,
	}
	caseReq.Level = clientInfo.CaseLevel
	//Fetched aggregate values of loans based on Level
	loansAggrigate, err := ca.loanRepo.GetSumOfColumns(ctx, loanFilter)

	//logger.Info(ctx, "CaseService|GenerateCase|aggrigate loans data", logger.LogFields{"loans": loansAggrigate})
	if len(loansAggrigate) > 0 || err == nil {
		for _, loanCase := range loansAggrigate {
			//Get primary contact number from contact table
			var primaryContactRefNumber string
			customerContact, cnErr := ca.customerContactRepo.FindOne(ctx, &models.CustomerContacts{CustomerRefNumber: loanCase.CustomerRefNumber, IsPrimary: true})
			if cnErr != nil {
				logger.Error(ctx, cnErr, "CaseService|GenerateCase|GetPrimaryContact", logger.LogFields{"input": loanCase.CustomerRefNumber})
			} else {
				primaryContactRefNumber = customerContact.ContactRefNumber
			}
			loanCase.CollectionFor = caseReq.CollectionFor
			var caseFilter = models.Case{
				ClientRefNumber:   caseReq.ClientRefNumber,
				CustomerRefNumber: caseReq.CustomerRefNumber,
			}
			if loanCase.Product == enum.PRODUCT_CC && utils.IsNotEmpty(clientInfo.CCCaseLevel) {
				caseFilter.LoanRefNumber = loanCase.LoanRefNumber
				caseFilter.Product = "CC"
			} else {
				if clientInfo.CaseLevel == "PRODUCT" {
					caseFilter.Product = loanCase.Product.String()
				} else if clientInfo.CaseLevel == "FINANCIER" {
					caseFilter.FinancierRefNumber = loanCase.ActiveFinancierRefNumber
				} else if clientInfo.CaseLevel == "PRODUCT_AND_FINANCIER" {
					caseFilter.FinancierRefNumber = loanCase.ActiveFinancierRefNumber
					caseFilter.Product = loanCase.Product.String()
				} else if clientInfo.CaseLevel == "LOAN" {
					caseFilter.LoanRefNumber = loanCase.LoanRefNumber
				}
			}
			// Check case is present for case level [LOAN,PRODUCT, FINANCIER, PRODUCT_AND_FINANCIER]
			previousCaseModel, err := ca.caseRepo.FindByReferenceNumberOne(ctx, caseFilter)
			//var customerRefNumber string
			if utils.IsNotEmpty(previousCaseModel.CaseRefNumber) && err == nil {
				params := models.Case{
					CaseRefNumber: previousCaseModel.CaseRefNumber,
				}
				if caseReq.Level != "LOAN" && loanCase.Product != enum.PRODUCT_CC {
					loanCase.LoanRefNumber = ""
				}
				caseModel := getUpdateParams(loanCase, caseReq.CollectionFor, caseReq.ClientTeamRefNumber)
				caseModel["CaseLevel"] = caseReq.Level
				isUpdated := ca.caseRepo.UpdateWithMapInterface(ctx, caseModel, params)
				if isUpdated {
					logger.Info(ctx, "CaseService|GenerateCase|Updated", logger.LogFields{"update_data": caseModel})
					caseGenerated = true
					//Update case_ref_number in loan table
					ca.MapCaseToLoan(ctx, previousCaseModel.CaseRefNumber, loanCase.GroupedLoans)

					//Update case attributes value
					updateCaseAttribute := request.CaseAttributeReq{
						ClientLoanIds:    loanCase.ClientLoanIds,
						ContactRefNumber: primaryContactRefNumber,
					}
					ca.InsertUpdateCaseAttributes(ctx, previousCaseModel.CaseRefNumber, updateCaseAttribute)

					// fetch updated case data based on case ref number
					updatedCaseModel, err := ca.caseRepo.FindByReferenceNumberOne(ctx, caseFilter)
					if err != nil {
						utils.InternalServerError(ctx, err, "Error in fetching updated case data")
					}

					caseUpdatedEvent := mapCaseModelToCaseUpdatedEvent(previousCaseModel, updatedCaseModel)
					adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, caseUpdatedEvent, eventConstants.CASE_UPDATED, nil)
				}

			} else {
				//Create New Case
				if caseReq.Level != "LOAN" && loanCase.Product != enum.PRODUCT_CC {
					loanCase.LoanRefNumber = ""
				}
				loanCase.CollectionFor = caseReq.CollectionFor
				caseModel := getCaseModelFromRequest(loanCase, "CREATE", caseReq.ClientTeamRefNumber)
				caseModel.CaseLevel = caseReq.Level
				resultData, err := ca.caseRepo.Create(ctx, caseModel)
				if err != nil {
					caseGenerated = false
					logger.Error(ctx, err, "CaseService|GenerateCase|Error in case generation", logger.LogFields{"error": err})
					return caseGenerated, err
				}
				if utils.IsNotEmpty(resultData.CaseRefNumber) {
					//Update case_ref_number in loan table
					ca.MapCaseToLoan(ctx, resultData.CaseRefNumber, loanCase.GroupedLoans)
					//Update case attributes value
					updateCaseAttribute := request.CaseAttributeReq{
						ClientLoanIds:    loanCase.ClientLoanIds,
						ContactRefNumber: primaryContactRefNumber,
					}
					ca.InsertUpdateCaseAttributes(ctx, resultData.CaseRefNumber, updateCaseAttribute)
					caseCreateEvent := mapCaseModelToCaseCreatedEvent(resultData)
					adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, caseCreateEvent, eventConstants.CASE_CREATED, nil)
					caseGenerated = true
				}

			}
		}
	}
	return caseGenerated, nil

}

/*
MapCaseToLoan : After case generation CaseRefNumber will map to its loan
@return
@author Tejas Surve
*/
func (ca *CaseService) MapCaseToLoan(ctx context.Context, caseRefNumber string, loans string) {
	for _, loan := range strings.Split(loans, ",") {
		where := models.Loan{
			LoanRefNumber: loan,
		}
		loanUpadte := models.Loan{
			CaseRefNumber: caseRefNumber,
			//Status: "CLOSED",
		}
		ca.loanRepo.Update(ctx, loanUpadte, where)
	}
}

func (s *CaseService) FindCaseListWithPaginate(ctx context.Context, filter request.CaseListFilter) (interface{}, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "CaseService.FindCaseListWithPaginate"); span != nil {
		defer span.End()
	}
	// Set filter status to "ACTIVE"
	filter.Status = "ACTIVE"

	// Initialize response map
	finalResp := make(map[string]interface{})
	// Validate the filter
	if err := validateCaseListFilter(ctx, filter); err != nil {
		logger.Error(ctx, err, "CacseService|FindCaseListWithPaginate|validateCaseListFilter error", logger.LogFields{"payload": filter, "error": err})
		return finalResp, err
	}
	// Extract team and user reference numbers
	clientTeamRefNumber, serviceProviderTeamRefNumber, agentRefNumbers := s.casePermissionService.ExtractTeamAndUsersToBeFetched(ctx, &case_permissions.CasePermifyFilter{
		Object:          filter.Object,
		ObjectRefNumber: filter.ObjectRefNumber,
		CaseRefNumber:   filter.CaseRefNumber,
	})

	// Update filter with reference numbers
	filter.AgentRefNumbers = agentRefNumbers
	filter.ServiceProviderTeamRefNumber = serviceProviderTeamRefNumber
	filter.ClientTeamRefNumber = clientTeamRefNumber
	// Fetch paginated case list from the repository
	repoRes, totalPage, page, err := s.caseRepo.GetCaseListWithPaginate(ctx, filter, agentRefNumbers, serviceProviderTeamRefNumber, clientTeamRefNumber)
	if err != nil {
		return finalResp, err
	}

	// Fetch data and construct final response
	finalResp = s.fetchCaseListDataFromRepo(ctx, repoRes, totalPage, page)
	return finalResp, nil
}

func validateCaseListFilter(ctx context.Context, filter request.CaseListFilter) error {
	if filter.Object == enum.UserObject(0) {
		utils.BadRequestException(ctx, "400", "user object not found", nil, nil)
	}
	if filter.PageNo <= 0 {
		filter.PageNo = 1
	}
	return nil
}

func (s *CaseService) fetchCaseListDataFromRepo(ctx context.Context, caseList []dto.CaseResponse, totalPage int64, page int) map[string]interface{} {
	finalResp := map[string]interface{}{
		"cases":        s.mapCaseListResponse(ctx, caseList),
		"pages":        totalPage,
		"current_page": page,
	}
	return finalResp
}

func (s *CaseService) mapCaseListResponse(ctx context.Context, caseList []dto.CaseResponse) []map[string]interface{} {
	var mappedCases []map[string]interface{}

	if len(caseList) > 0 {
		s.setClientInfo(ctx, caseList[0].ClientRefNumber)
	}

	for _, value := range caseList {
		mappedCases = append(mappedCases, map[string]interface{}{
			"customer": mapCustomerResponse(value),
			"case":     mapCaseDetailsResponse(ctx, value, s),
		})
	}
	return mappedCases
}

func mapCustomerResponse(value dto.CaseResponse) map[string]interface{} {
	return map[string]interface{}{
		"first_name":                 value.FirstName,
		"last_name":                  value.LastName,
		"email":                      utils.MaskEmail(value.Email),
		"gender":                     value.Gender,
		"age":                        utils.GetAge(value.Dob),
		"mobile_number":              utils.MaskMobileNumber(value.MobileNumber),
		"client_customer_id":         value.ClientCustomerId,
		"preferred_language":         value.PreferredLanguage,
		"primary_contact_ref_number": value.ContactRefNumber,
		"customer_ref_number":        value.CustomerRefNumber,
	}
}

func mapCaseDetailsResponse(ctx context.Context, value dto.CaseResponse, s *CaseService) map[string]interface{} {
	logoUrl, logoErr := s.awsImport.GetSharableURL(ctx, value.LogoUrl, constants.CLIENT_AWS_BUCKET)
	if logoErr != nil {
		logger.Error(ctx, logoErr, "Error while fetching logo", logger.LogFields{})
	}

	return map[string]interface{}{
		"customer_ref_number":                value.CustomerRefNumber,
		"case_ref_number":                    value.CaseRefNumber,
		"loan_ref_number":                    value.LoanRefNumber,
		"client_ref_number":                  value.ClientRefNumber,
		"service_provider_ref_number":        value.ServiceProviderRefNumber,
		"total_due":                          value.TotalDue,
		"total_principal_due":                value.TotalPrincipalDue,
		"total_interest_due":                 value.TotalInterestDue,
		"total_fees_due":                     value.TotalFeesDue,
		"no_of_loans_due":                    value.NoOfLoansDue,
		"no_of_emis_due":                     value.NoOfEmisDue,
		"total_outstanding":                  value.TotalOutstanding,
		"total_principal_outstanding":        value.TotalPrincipalOutstanding,
		"total_interest_outstanding":         value.TotalInterestOutstanding,
		"total_principal_paid":               value.TotalPrincipalPaid,
		"total_interest_paid":                value.TotalInterestPaid,
		"total_fees_paid":                    value.TotalFeesPaid,
		"no_of_emis_paid":                    value.NoOfEmisPaid,
		"current_dpd":                        value.CurrentDpd,
		"bucket":                             value.Bucket,
		"max_dpd":                            value.MaxDpd,
		"status":                             value.Status,
		"collection_for":                     value.CollectionFor,
		"case_type":                          value.CaseType,
		"last_disposition":                   value.LastDisposition,
		"last_disposition_datetime":          utils.FormatDateTime(value.LastDispositionDatetime),
		"last_disposition_followup_date":     utils.FormatDateTime(value.LastDispositionFollowupDate),
		"total_calls_attempted":              value.TotalCallsAttempted,
		"total_calls_connected":              value.TotalCallsConnected,
		"last_call_connected_at":             utils.FormatDateTime(value.LastCallConnectedAt),
		"client_loan_ids":                    value.ClientLoanIds,
		"client_logo_url":                    logoUrl,
		"calls_left":                         clientInfo.DailyCallsLimit - value.TodaysCallsAttempted,
		"having_mandate_inprogress_payments": value.HavingMandateInprogressPayments,
		"having_inprogress_payments":         value.HavingInprogressPayments,
		"allocated_to":                       value.AllocatedTo,
		"allocated_to_first_name":            value.AllocatedToFirstName,
		"allocated_to_last_name":             value.AllocatedToLastName,
		"is_freezed":                         value.IsFreezed,
		"product":                            value.Product,
	}
}

func extractTeamAndUsersForAgent(ctx context.Context, filter *case_permissions.CasePermifyFilter, s *CaseService) (*string, *string, *[]string) {
	// fetch visibility from agent repo. (assuming agent ref number is present in context)
	agentModel, err := s.agentRepo.FindOne(ctx, &models.Agent{AgentRefNumber: filter.ObjectRefNumber})
	if err != nil {
		logger.Error(ctx, err, "CacseService|FindCaseList|error while fetching agent details", logger.LogFields{"agent_ref_number": filter.ObjectRefNumber})
		utils.InternalServerError(ctx, err, "error while fetching agent details")
	}

	var serviceProviderTeamRefNumber *string
	var usersListFromPermify *[]string

	switch agentModel.Visibility {
	case enum.AGENT_VIS_TEAM_LEVEL:
		serviceProviderTeamRefNumber = &agentModel.ServiceProviderTeamRefNumber
		fallthrough
	case enum.AGENT_VIS_SELF_REPORTEE_LEVEL:
		usersFromPermify, err := s.casePermissionService.GetSubUsersListFromPermify(ctx, filter.ObjectRefNumber)
		if err != nil {
			msg := "error from permify service while fetching case list"
			logger.Error(ctx, err, "CacseService|FindCaseList|getSubUsersListFromPermify"+msg, logger.LogFields{"payload": filter})
			utils.InternalServerError(ctx, err, msg)
		}
		usersListFromPermify = &usersFromPermify

	}

	return nil, serviceProviderTeamRefNumber, usersListFromPermify
}

func (s *CaseService) GetCaseLoan(ctx context.Context, filter request.CaseLoanFilter) (interface{}, error) {
	if span := tracing.TraceSpan(ctx, "CaseService.FindCaseList"); span != nil {
		defer span.End()
	}

	// check Permission from permify
	granted, err := s.casePermissionService.CheckCaseDetailsPermission(ctx, &case_permissions.CasePermifyFilter{Object: filter.Object, ObjectRefNumber: filter.ObjectRefNumber, CaseRefNumber: filter.CaseRefNumber})
	if err != nil {
		logger.Error(ctx, err, "CaseService|GetCaseLoanForAgents|error while checking permission", logger.LogFields{"payload": filter})
	}
	if !granted {
		msg := "case details permission denied for this user."
		logger.Error(ctx, err, "CaseService|GetCaseLoanForAgents|"+msg, logger.LogFields{"payload": filter})
		utils.ForbiddenException(ctx, "", msg, nil)
	}

	redisDataPresent := false
	isRedisEnabled := false //viper.GetBool("REDIS_ENABLED")
	var finalResp = map[string]interface{}{
		"case":     response.Case{},
		"customer": response.Customer{},
		"loans":    []map[string]interface{}{},
	}

	if strings.TrimSpace(filter.CaseRefNumber) == "" {
		utils.BadRequestException(ctx, "400", "bad request", "case reference number is required", nil)
	}
	redisKey := fmt.Sprintf("api:%s:%s:%s", constants.API_CASELOAN, constants.CASE_REF_NUMBER, filter.CaseRefNumber)
	var redisExpiry = 1 * time.Hour

	if isRedisEnabled {
		redisService := cacheservice.GetInstance()
		res, err := redisService.Read(redisKey, "get")
		if err != nil {
			return finalResp, err
		}
		if res != "" {
			err = json.Unmarshal([]byte(res), &finalResp)
			if err != nil {
				return finalResp, err
			}
		} else {
			redisDataPresent = false
		}

	}

	// If redis has no records, get data from primary db and set cache
	if !redisDataPresent {
		caseInfo, caseErr := s.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: filter.CaseRefNumber})
		if caseErr != nil {
			utils.BadRequestException(ctx, "400", "not found", caseErr.Error(), nil)
		}
		s.setClientInfo(ctx, caseInfo.ClientRefNumber)

		var caseLoans []models.Loan
		switch filter.Object {
		case enum.USER_AGENT:
			caseLoans, err = s.caseRepo.GetCaseLoanForAgents(ctx, filter)
			if err != nil {
				return finalResp, err
			}
		case enum.USER_CLIENT_USER:
			caseLoans, err = s.caseRepo.GetCaseLoanForCLientUser(ctx, filter)
			if err != nil {
				return finalResp, err
			}
		}
		finalResp["case"] = transformModelToCaseToResponse(*caseInfo, caseInfo.CaseAttribute)
		finalResp["customer"] = transformModelToCustomerToResponse(caseInfo.Customer, caseInfo.CaseAttribute)
		// Iterate over 'caseLoanResponses' and map each individual data
		for _, response := range caseLoans {
			loanData := map[string]interface{}{
				"loan_ref_number":                response.LoanRefNumber,
				"client_loan_id":                 response.ClientLoanId,
				"credit_card_no":                 response.CreditCardNo,
				"customer_ref_number":            response.CustomerRefNumber,
				"client_ref_number":              response.ClientRefNumber,
				"client_name":                    response.Client.Name,
				"loan_amount":                    response.LoanAmount,
				"tenure":                         response.Tenure,
				"tenure_type":                    response.TenureType,
				"interest_rate":                  response.InterestRate,
				"emi_amount":                     response.EmiAmount,
				"status":                         response.Status,
				"product":                        response.Product,
				"sub_product":                    response.SubProduct,
				"active_financier_ref_number":    response.ActiveFinancierRefNumber,
				"active_financier_name":          response.ActiveFinancier.Name,
				"secondary_financier_ref_number": response.SecondaryFinancierRefNumber,
				"secondary_financier_name":       response.SecondaryFinancier.Name,
				"disbursement_amount":            response.DisbursementAmount,
				"disbursement_date":              utils.FormatDate(response.DisbursementDate),
				"due_date":                       response.DueDate,
				"first_emi_date":                 utils.FormatDate(response.FirstEmiDate),
				"last_emi_date":                  utils.FormatDate(response.LastEmiDate),
				"earliest_unpaid_emi_date":       response.EarliestUnpaidEmiDate,
				"total_due":                      response.TotalDue,
				"total_principal_due":            response.TotalPrincipalDue,
				"total_interest_due":             response.TotalInterestDue,
				"total_fees_due":                 response.TotalFeesDue,
				"total_outstanding":              response.TotalOutstanding,
				"total_principal_outstanding":    response.TotalPrincipalOutstanding,
				"total_interest_outstanding":     response.TotalInterestOutstanding,
				"total_fees_outstanding":         response.TotalFeesOutstanding,
				"total_principal_paid":           response.TotalPrincipalPaid,
				"total_interest_paid":            response.TotalInterestPaid,
				"total_fees_paid":                response.TotalFeesPaid,
				"no_of_emis_paid":                response.NoOfEmisPaid,
				"no_of_emis_unpaid":              response.NoOfEmisUnpaid,
				"current_dpd":                    response.CurrentDpd,
				"max_dpd":                        response.MaxDpd,
				"bill_total_payment_due":         response.BillTotalPaymentDue,
				"bill_min_payment_due":           response.BillMinPaymentDue,
				"bill_statement_date":            utils.FormatDate(response.BillStatementGenerationDate),
				"credit_limit":                   response.CreditLimit,
				"available_credit_limit":         response.AvailableCreditLimit,
				"payment_link":                   response.PaymentLink,
				"loan_payments":                  []map[string]interface{}{},
				"collaterals":                    []map[string]interface{}{},
				"borrowers":                      []map[string]interface{}{},
				"customer_info":                  map[string]interface{}{},
			}

			// mapping customer info
			if !utils.IsEmptyStruct(response.CustomerInfo) {
				customerInfoMap := map[string]interface{}{
					"info_ref_number":     response.CustomerInfo.InfoRefNumber,
					"customer_ref_number": response.CustomerInfo.CustomerRefNumber,
					"loan_ref_number":     response.CustomerInfo.LoanRefNumber,
					"employment_type":     response.CustomerInfo.EmploymentType,
					"employer_name":       response.CustomerInfo.EmployerName,
					"monthly_income":      response.CustomerInfo.MonthlyIncome,
					"occupation":          response.CustomerInfo.Occupation,
					"cibil_score":         response.CustomerInfo.CibilScore,
				}
				loanData["customer_info"] = customerInfoMap
			}

			// Map loan payment data
			for _, payment := range response.LoanPayment {
				paymentData := map[string]interface{}{
					"loan_payment_ref_number":   payment.LoanPaymentRefNumber,
					"payment_ref_number":        payment.PaymentRefNumber,
					"client_payment_id":         payment.ClientPaymentId,
					"payment_gateway":           payment.PaymentGateway,
					"payment_amount":            payment.PaymentAmount,
					"payment_datetime":          utils.FormatDateTime(payment.PaymentDatetime),
					"applied_towards_principal": payment.AppliedTowardsPrincipal,
					"applied_towards_interest":  payment.AppliedTowardsInterest,
					"applied_towards_fees":      payment.AppliedTowardsFees,
				}
				loanData["loan_payments"] = append(loanData["loan_payments"].([]map[string]interface{}), paymentData)
			}

			// Map loan collateral data
			for _, collateral := range response.LoanCollateral {
				collateralData := map[string]interface{}{
					"type":                       collateral.Type,
					"value":                      collateral.Value,
					"description":                collateral.Description,
					"primary_identifier_type":    collateral.PrimaryIdentifierType,
					"primary_identifier":         collateral.PrimaryIdentifier,
					"additional_identifier_type": collateral.AdditionalIdentifierType,
					"additional_identifier":      collateral.AdditionalIdentifier,
					"make_and_model":             collateral.MakeAndModel,
				}
				loanData["collaterals"] = append(loanData["collaterals"].([]map[string]interface{}), collateralData)
			}

			// Map loan borrower data
			for _, borrower := range response.LoanBorrower {
				borrowerData := map[string]interface{}{
					"first_name":            borrower.Customer.FirstName,
					"last_name":             borrower.Customer.LastName,
					"mobile_number":         utils.MaskMobileNumber(borrower.Customer.MobileNumber),
					"type":                  borrower.Type,
					"relation_with_primary": borrower.RelationWithPrimary,
				}
				loanData["borrowers"] = append(loanData["borrowers"].([]map[string]interface{}), borrowerData)
			}

			// Append the loanData to the loans array
			finalResp["loans"] = append(finalResp["loans"].([]map[string]interface{}), loanData)

		}

		result, err := json.Marshal(finalResp)
		if err != nil {
			return finalResp, err
		}
		//ok, err := redisService.Create(redisCaseLoanKey, filter.CaseRefNumber, result, "set", redisExpiry)
		if isRedisEnabled {
			redisService := cacheservice.GetInstance()
			ok, err := redisService.Create(redisKey, result, "set", redisExpiry)
			if !ok {
				return finalResp, nil
			}
			if err != nil {
				return finalResp, err
			}
			return finalResp, nil
		}

	}

	return finalResp, nil
}

func getCaseModelFromRequest(req models.Loan, action string, clientTeamRefNumber string) models.Case {

	data := models.Case{
		ClientRefNumber:           req.ClientRefNumber,
		CustomerRefNumber:         req.CustomerRefNumber,
		Product:                   req.Product.String(),
		FinancierRefNumber:        req.ActiveFinancierRefNumber,
		CollectionFor:             req.CollectionFor,
		LoanRefNumber:             req.LoanRefNumber,
		MaxDpd:                    req.MaxDpd,
		CurrentDpd:                req.CurrentDpd,
		TotalDue:                  req.TotalDue,
		TotalPrincipalDue:         req.TotalPrincipalDue,
		TotalInterestDue:          req.TotalInterestDue,
		TotalFeesDue:              req.TotalFeesDue,
		TotalOutstanding:          req.TotalOutstanding,
		TotalPrincipalOutstanding: req.TotalPrincipalOutstanding,
		TotalInterestOutstanding:  req.TotalInterestOutstanding,
		TotalFeesOutstanding:      req.TotalFeesOutstanding,
		TotalPrincipalPaid:        req.TotalPrincipalPaid,
		TotalInterestPaid:         req.TotalInterestPaid,
		TotalFeesPaid:             req.TotalFeesPaid,
		NoOfEmisPaid:              req.NoOfEmisPaid,
		NoOfEmisDue:               req.NoOfEmisUnpaid,
		CreatedBy:                 req.CreatedBy,
		ClientTeamRefNumber:       clientTeamRefNumber,
		UpdatedBy:                 req.UpdatedBy,
		CaseType:                  "LOAN",
	}
	if action == "CREATE" {
		data.CaseRefNumber = utils.GenerateRandomString(6, "CR")
		data.Status = enum.CASE_ACTIVE
	}
	if req.TotalDue <= 0 {
		data.Status = enum.CASE_PAID
	}
	if req.Product == enum.PRODUCT_CC {
		data.CaseType = "CREDIT_CARD"
	}
	//data.NoOfLoansDue = float64(req.CurrentDpd)
	dpd_bucket := config.AppConfig.Get("product_config.dpd_bucket").([]interface{})
	for _, b := range dpd_bucket {
		bucket, ok := b.(map[string]interface{})
		if ok {
			if float64(req.CurrentDpd) >= bucket["from"].(float64) && float64(req.CurrentDpd) <= bucket["to"].(float64) {
				bucketString := bucket["bucket"].(string)
				bucketVale, _ := enum.StringToBucketEnum(bucketString)
				data.Bucket = bucketVale
			} else if (float64(req.CurrentDpd)) > 180 {
				data.Bucket = enum.BUCKET_4
			} else if (float64(req.CurrentDpd)) < 0 {
				data.Bucket = enum.PRE_DEL
			}
		}
	}

	return data
}

/*
AllocateCase :
Func will insert records in allocation table with agent_ref & case_ref
return error
@Author Tejas Surve
*/
func (ca *CaseService) AllocateCase(ctx context.Context, request request.CaseAllocationReq) error {
	logger.Info(ctx, "CaseService|AllocateCase|Request", logger.LogFields{"request": request})
	loanData, err := ca.loanRepo.FindByReferenceNumberOne(ctx, models.Loan{ClientLoanId: request.ClientLoanId, CaseRefNumber: request.CaseRefNumber, Status: enum.LOAN_ACTIVE})
	if err != nil {
		if err.Error() == "record not found" {
			return errors.New("Client Loan ID not found:" + request.ClientLoanId)
		}
		return err
	}
	request.CaseRefNumber = loanData.CaseRefNumber

	// fetch client ref
	checksErr := ca.allocationInitialChecks(ctx, request)
	if checksErr != nil {
		return checksErr
	}

	if !utils.IsNotEmpty(request.CaseRefNumber) {
		return nil
	}

	var previousAllocationDetails *events.AllocationEventNode
	var newAllocationDetails *events.AllocationEventNode

	//Check existing record for allocation
	allocationWhere := models.Allocation{
		CaseRefNumber:            request.CaseRefNumber,
		ServiceProviderRefNumber: request.ServiceProviderRefNumber,
		Intervention:             request.Intervention, //intervention entry comes from client upload only

	}
	allocation, err := ca.allocationRepo.FindByReferenceNumberOne(ctx, allocationWhere)
	if err != nil && err != gorm.ErrRecordNotFound {
		logger.Error(ctx, err, "CaseService|AllocateCase|GetAllocation", logger.LogFields{"where": allocationWhere})
		return err
	}

	var previousAgentDetails response.AgentInfoResponse
	var newAgentDetails response.AgentInfoResponse

	if request.AgentRefNumber != "" {
		newAgentDetails, err = ca.agentService.GetAgentInfo(ctx, request.AgentRefNumber)
		if err != nil {
			logger.Error(ctx, err, "CaseService|AllocateCase|GetAgentInfo", logger.LogFields{"agent_ref_number": request.AgentRefNumber})
			utils.InternalServerError(ctx, err, "error while fetching agent details")
		}
	}

	if allocation.AgentRefNumber != "" {
		previousAgentDetails, err = ca.agentService.GetAgentInfo(ctx, allocation.AgentRefNumber)
		if err != nil {
			logger.Error(ctx, err, "CaseService|AllocateCase|GetAgentInfo", logger.LogFields{"agent_ref_number": request.AgentRefNumber})
			utils.InternalServerError(ctx, err, "error while fetching agent details")
		}
	}

	// Db connection for rollback commit
	dbTxn := ca.allocationRepo.GetWriteDBConnection().Begin()
	// previous allocation found
	if utils.IsNotEmpty(allocation.CaseRefNumber) {
		previousAllocationDetails = &events.AllocationEventNode{
			CaseRefNumber:                allocation.CaseRefNumber,
			ServiceProviderRefNumber:     allocation.ServiceProviderRefNumber,
			AgentRefNumber:               allocation.AgentRefNumber,
			ServiceProviderTeamRefNumber: previousAgentDetails.Agent.TeamRefNumber,
			Intervention:                 allocation.Intervention,
		}
		//Delete Existing case allocation
		//deleteError := ca.allocationRepo.DeleteCaseAllocation(ctx, allocation.CaseRefNumber, allocation.ServiceProviderRefNumber, dbTxn)
		deleteError := ca.allocationRepo.DeleteCaseAllocation(ctx, models.Allocation{CaseRefNumber: allocation.CaseRefNumber, Intervention: allocation.Intervention}, dbTxn)
		if deleteError != nil {
			dbTxn.Rollback()
			logger.Error(ctx, deleteError, "CaseService|AllocateCase|Delete", logger.LogFields{"where": deleteError})
			return deleteError
		}
	}

	//Create Allocation Input
	createParams := models.Allocation{
		CaseRefNumber:                request.CaseRefNumber,
		AgentRefNumber:               request.AgentRefNumber,
		ServiceProviderRefNumber:     request.ServiceProviderRefNumber,
		Intervention:                 request.Intervention,
		CreatedBy:                    request.CreatedBy,
		ServiceProviderTeamRefNumber: newAgentDetails.Agent.TeamRefNumber,
	}
	if utils.IsEmpty(request.ServiceProviderRefNumber) { //empty means its agent allocation and allocation data should present
		createParams.ServiceProviderRefNumber = allocation.ServiceProviderRefNumber
	}
	if utils.IsEmpty(request.Intervention.String()) {
		createParams.Intervention = allocation.Intervention
	}

	newAllocationDetails = &events.AllocationEventNode{
		CaseRefNumber:                request.CaseRefNumber,
		ServiceProviderRefNumber:     request.ServiceProviderRefNumber,
		AgentRefNumber:               request.AgentRefNumber,
		ServiceProviderTeamRefNumber: newAgentDetails.Agent.TeamRefNumber,
		Intervention:                 request.Intervention,
	}

	createRrr := ca.allocationRepo.Create(ctx, &createParams, dbTxn)
	if createRrr != nil {
		dbTxn.Rollback()
		logger.Error(ctx, createRrr, "CaseService|AllocateCase|Create", logger.LogFields{"createParams": createParams})
		return createRrr
	}

	// publish allocation change event
	adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, events.AllocationChangedEvent{PreviousAllocation: previousAllocationDetails, NewAllocation: newAllocationDetails}, eventConstants.ALLOCATION_CHANGED, nil)

	allocationHistoryRepo := models.AllocationHistory{
		CaseRefNumber:            allocation.CaseRefNumber,
		AgentRefNumber:           allocation.AgentRefNumber,
		ServiceProviderRefNumber: allocation.ServiceProviderRefNumber,
		CreatedBy:                allocation.CreatedBy,
		OriginalCreatedAt:        allocation.CreatedAt,
	}
	_, createHistoryErr := ca.allocationHistoryRepo.Create(ctx, allocationHistoryRepo, dbTxn)
	if createHistoryErr != nil {
		dbTxn.Rollback()
		logger.Error(ctx, createHistoryErr, "CaseService|AllocateCase|HistoryCreate", logger.LogFields{"create_params": allocationHistoryRepo})
		return createHistoryErr
	}

	if err := dbTxn.Commit().Error; err != nil {
		dbTxn.Rollback()
		logger.Error(ctx, err, "CaseService|AllocateCase|CommitTransaction", logger.LogFields{})
	}

	return nil
}

type permifyCaseAllocDealloc struct {
	CaseRefNumber                string `json:"case_ref_number"`
	AgentRefNumber               string `json:"agent_ref_number"`
	ServiceProviderRefNumber     string `json:"service_provider_ref_number"`
	ClientRefNumber              string `json:"client_ref_number"`
	ServiceProviderTeamRefNumber string `json:"service_provider_team_ref_number"`
	ClientTeamRefNumber          string `json:"client_team_ref_number"`
}

func (ca *CaseService) DeAllocateCase(ctx context.Context, request request.CaseDeAllocationReq) error {
	logger.Info(ctx, "CaseService|DeAllocateCase|Request", logger.LogFields{"request": request})

	if request.CaseRefNumber == "" && request.ClientLoanId == "" {
		return errors.New("case ref number or client loan id is required")
	}

	if request.CaseRefNumber == "" {
		loanData, err := ca.loanRepo.FindByReferenceNumberOne(ctx, models.Loan{ClientLoanId: request.ClientLoanId})
		if err != nil {
			return err
		}
		request.CaseRefNumber = loanData.CaseRefNumber
	}

	var previousAllocationDetails *events.AllocationEventNode

	checksErr := ca.deallocationInitialChecks(ctx, request)
	if checksErr != nil {
		return checksErr
	}
	//Check Active case is Present
	where := models.Case{
		CaseRefNumber: request.CaseRefNumber,
		Status:        enum.CASE_ACTIVE,
	}
	caseData, err := ca.caseRepo.FindByReferenceNumberOne(ctx, where)
	if err != nil {
		logger.Error(ctx, err, "CaseService|DeAllocateCase|GetCase", logger.LogFields{"where": where})
		return err
	}

	if utils.IsNotEmpty(caseData.CaseRefNumber) {
		//Check existing record for allocation
		allocationWhere := models.Allocation{
			CaseRefNumber:            request.CaseRefNumber,
			ServiceProviderRefNumber: request.ServiceProviderRefNumber,
			Intervention:             request.Intervention,
			AgentRefNumber:           request.AgentRefNumber,
		}
		allocation, err := ca.allocationRepo.FindByReferenceNumberOne(ctx, allocationWhere)
		if err != nil {
			logger.Error(ctx, err, "CaseService|DeAllocateCase|GetAllocation", logger.LogFields{"where": allocationWhere})
			return err
		}

		if utils.IsNotEmpty(allocation.CaseRefNumber) {

			// copy existing entry to allocation history table before delete
			dbTxn := ca.allocationRepo.GetWriteDBConnection().Begin()
			//Delete Existing case allocation
			deleteError := ca.allocationRepo.DeleteCaseAllocation(ctx, allocationWhere, dbTxn)
			if deleteError != nil {
				dbTxn.Rollback()
				logger.Error(ctx, deleteError, "CaseService|DeAllocateCase|Delete", logger.LogFields{"where": deleteError})
				return deleteError
			}

			// fetch previous agent details
			var previousAgentDetails response.AgentInfoResponse
			if allocation.AgentRefNumber != "" {
				previousAgentDetails, err = ca.agentService.GetAgentInfo(ctx, allocation.AgentRefNumber)
				if err != nil {
					logger.Error(ctx, err, "CaseService|AllocateCase|GetAgentInfo", logger.LogFields{"agent_ref_number": allocation.AgentRefNumber})
					utils.InternalServerError(ctx, err, "error while fetching agent details")
				}
			}

			// fill previous allocation details
			previousAllocationDetails = &events.AllocationEventNode{
				CaseRefNumber:                allocation.CaseRefNumber,
				ServiceProviderRefNumber:     allocation.ServiceProviderRefNumber,
				AgentRefNumber:               allocation.AgentRefNumber,
				ServiceProviderTeamRefNumber: previousAgentDetails.Agent.TeamRefNumber,
				Intervention:                 allocation.Intervention,
			}

			// publish allocation change event
			adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, events.AllocationChangedEvent{PreviousAllocation: previousAllocationDetails, NewAllocation: nil}, eventConstants.ALLOCATION_CHANGED, nil)

			// Create entry in history table after delete
			allocationHistoryRepo := models.AllocationHistory{
				CaseRefNumber:            allocation.CaseRefNumber,
				AgentRefNumber:           allocation.AgentRefNumber,
				ServiceProviderRefNumber: allocation.ServiceProviderRefNumber,
				CreatedBy:                allocation.CreatedBy,
				OriginalCreatedAt:        allocation.CreatedAt,
			}
			if _, err := ca.allocationHistoryRepo.Create(ctx, allocationHistoryRepo, dbTxn); err != nil {
				// Rollback the transaction if there's an error during insertion
				dbTxn.Rollback()
				logger.Error(ctx, err, "CaseService|DeAllocateCase|CreateAllocationHistory", logger.LogFields{})
				return err
			}
			if err := dbTxn.Commit().Error; err != nil {
				dbTxn.Rollback()
				logger.Error(ctx, err, "CaseService|DeAllocateCase|CommitTransaction", logger.LogFields{})
			}
			// if deallocation from service provider only we need to keep old record with service provider
			if request.Object == "SERVICE_PROVIDER" {
				var newAllocationDetails *events.AllocationEventNode
				allocationParams := models.Allocation{
					ServiceProviderRefNumber: allocation.ServiceProviderRefNumber,
					CaseRefNumber:            allocation.CaseRefNumber,
					Intervention:             allocation.Intervention,
					CreatedBy:                request.CreatedBy,
				}
				allocationCreateErr := ca.allocationRepo.Create(ctx, &allocationParams, ca.allocationRepo.GetWriteDBConnection())
				if allocationCreateErr != nil {
					logger.Error(ctx, err, "CaseService|reAllallocate|insert", logger.LogFields{})
					if allocationCreateErr == gorm.ErrDuplicatedKey {
						return errors.New("already allocated with service provider")
					}
					return allocationCreateErr
				}

				newAllocationDetails = &events.AllocationEventNode{
					CaseRefNumber:            allocation.CaseRefNumber,
					ServiceProviderRefNumber: allocation.ServiceProviderRefNumber,
					Intervention:             allocation.Intervention,
				}
				// publish allocation change event
				adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, events.AllocationChangedEvent{PreviousAllocation: nil, NewAllocation: newAllocationDetails}, eventConstants.ALLOCATION_CHANGED, nil)
			}

		}
	}
	return nil
}

/*
getUpdateParams : function map model data to map interface bcoz gorm not updating 0 values filed using struct like amount
return map[string]interface{}
@author Tejas Surve
*/
func getUpdateParams(req models.Loan, collectionFor enum.CollectionFor, clientTeamRefNumber string) map[string]interface{} {

	data := make(map[string]interface{})
	data["ClientRefNumber"] = req.ClientRefNumber
	data["ClientTeamRefNumber"] = clientTeamRefNumber
	data["CustomerRefNumber"] = req.CustomerRefNumber
	data["Product"] = req.Product.String()
	data["FinancierRefNumber"] = req.ActiveFinancierRefNumber
	data["LoanRefNumber"] = req.LoanRefNumber
	data["CollectionFor"] = collectionFor
	data["MaxDpd"] = req.MaxDpd
	data["CurrentDpd"] = req.CurrentDpd
	data["TotalDue"] = req.TotalDue
	data["TotalPrincipalDue"] = req.TotalPrincipalDue
	data["TotalInterestDue"] = req.TotalInterestDue
	data["TotalFeesDue"] = req.TotalFeesDue
	data["TotalOutstanding"] = req.TotalOutstanding
	data["TotalPrincipalOutstanding"] = req.TotalPrincipalOutstanding
	data["TotalInterestOutstanding"] = req.TotalInterestOutstanding
	data["TotalFeesOutstanding"] = req.TotalFeesOutstanding
	data["TotalPrincipalPaid"] = req.TotalPrincipalPaid
	data["TotalInterestPaid"] = req.TotalInterestPaid
	data["TotalFeesPaid"] = req.TotalFeesPaid
	data["NoOfEmisPaid"] = req.NoOfEmisPaid
	data["CreatedBy"] = req.CreatedBy
	data["UpdatedBy"] = req.UpdatedBy
	data["CaseType"] = "LOAN"

	if req.TotalDue <= 0 {
		data["Status"] = "PAID"
	}
	if req.Product == enum.PRODUCT_CC {
		data["CaseType"] = "CREDIT_CARD"
	}
	dpd_bucket := config.AppConfig.Get("product_config.dpd_bucket").([]interface{})
	for _, b := range dpd_bucket {
		bucket, ok := b.(map[string]interface{})
		if ok {
			if float64(req.CurrentDpd) >= bucket["from"].(float64) && float64(req.CurrentDpd) <= bucket["to"].(float64) {
				data["Bucket"] = bucket["bucket"].(string)
			} else if (float64(req.CurrentDpd)) > 180 {
				data["Bucket"] = enum.BUCKET_4
			} else if (float64(req.CurrentDpd)) < 0 {
				data["Bucket"] = enum.PRE_DEL
			}
		}
	}

	return data
}

/*
setClientInfo: fetch client configuration and set to global key client
@return
@author Tejas Surve
*/
func (ca *CaseService) setClientInfo(ctx context.Context, clientRefNumber string) {
	clientData, err := ca.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: clientRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	} else {
		var clientConfig Client
		jsonData := []byte(clientData.Configuration)
		marshalErr := json.Unmarshal(jsonData, &clientConfig)
		if marshalErr != nil {
			logger.Error(ctx, marshalErr, "CaseService|setClientInfo|UnmarshalError", logger.LogFields{"config": jsonData})
			utils.InternalServerError(ctx, marshalErr, "")
		}
		clientInfo = &Client{CaseLevel: clientConfig.CaseLevel, ClientRefNumber: clientData.ClientRefNumber, CCCaseLevel: clientConfig.CCCaseLevel, DailyCallsLimit: clientConfig.DailyCallsLimit, DistanceCheckMeters: clientConfig.DistanceCheckMeters}
	}
}

/*
updateCaseAttributes
*/
func (ca *CaseService) InsertUpdateCaseAttributes(ctx context.Context, caseRefNumber string, params request.CaseAttributeReq) error {
	logger.Info(ctx, "CaseService|InsertUpdateCaseAttributes|request", logger.LogFields{caseRefNumber: params})

	filter := models.CaseAttribute{
		CaseRefNumber: caseRefNumber,
	}
	caseAttribute, err := ca.caseAttributeRepo.FindByReferenceNumberOne(ctx, filter)
	if err != nil && err != gorm.ErrRecordNotFound {
		logger.Error(ctx, err, "CaseService|InsertUpdateCaseAttributes|getCaseAttribute", logger.LogFields{caseRefNumber: params})
		return err

	}
	if !utils.IsEmptyStruct(caseAttribute) {
		updateData := make(map[string]interface{})
		updateData["ClientLoanIds"] = caseAttribute.ClientLoanIds
		updateData["LastDisposition"] = caseAttribute.LastDisposition
		updateData["LastDispositionFollowupDate"] = caseAttribute.LastDispositionFollowupDate
		updateData["LastDispositionDatetime"] = caseAttribute.LastDispositionDatetime
		updateData["ContactRefNumber"] = caseAttribute.ContactRefNumber
		updateData["TotalCallsAttempted"] = caseAttribute.TotalCallsAttempted
		updateData["TotalCallsConnected"] = caseAttribute.TotalCallsConnected
		updateData["TodaysCallsAttempted"] = caseAttribute.TodaysCallsAttempted
		updateData["LastCallConnectedAt"] = caseAttribute.LastCallConnectedAt
		updateData["HavingMandateInprogressPayments"] = caseAttribute.HavingMandateInprogressPayments
		updateData["HavingInprogressPayments"] = caseAttribute.HavingInprogressPayments
		updateData["DispositionType"] = caseAttribute.DispositionType
		updateData["TodaysCallsConnected"] = caseAttribute.TodaysCallsConnected
		if params.ClientLoanIds != "" {
			updateData["ClientLoanIds"] = params.ClientLoanIds
		}
		if params.LastDisposition != "" {
			updateData["LastDisposition"] = params.LastDisposition
		}
		if params.LastDispositionFollowupDate != nil && !params.LastDispositionFollowupDate.IsZero() {
			updateData["LastDispositionFollowupDate"] = params.LastDispositionFollowupDate
		}
		if params.LastDispositionDatetime != nil {
			updateData["LastDispositionDatetime"] = params.LastDispositionDatetime
		}
		if params.ContactRefNumber != "" {
			updateData["ContactRefNumber"] = params.ContactRefNumber
		}
		if params.TotalCallsAttempted != 0 {
			updateData["TotalCallsAttempted"] = params.TotalCallsAttempted
		}
		if params.TotalCallsConnected != 0 {
			updateData["TotalCallsConnected"] = params.TotalCallsConnected
		}
		if params.TodaysCallsAttempted != 0 {
			updateData["TodaysCallsAttempted"] = params.TodaysCallsAttempted
		}
		if params.TodaysCallsConnected != 0 {
			updateData["TodaysCallsConnected"] = params.TodaysCallsConnected
		}
		if params.LastCallConnectedAt != nil {
			updateData["LastCallConnectedAt"] = params.LastCallConnectedAt
		}
		if params.HavingMandateInprogressPayments {
			updateData["HavingMandateInprogressPayments"] = params.HavingMandateInprogressPayments
		}
		if params.HavingInprogressPayments {
			updateData["HavingInprogressPayments"] = params.HavingInprogressPayments
		}
		if utils.IsNotEmpty(params.DispositionType) {
			updateData["DispositionType"] = params.DispositionType
		}

		//_, err := ca.caseAttributeRepo.Update(ctx, updateData, caseRefNumber)
		updated := ca.caseAttributeRepo.UpdateWithMapInterface(ctx, updateData, models.CaseAttribute{CaseRefNumber: caseRefNumber})
		if !updated {
			logger.Error(ctx, err, "CaseService|InsertUpdateCaseAttributes|updateCaseAttribute", logger.LogFields{caseRefNumber: updated})
			return err
		}
	} else {
		dispositionType := enum.StringToDispositionType(params.LastDisposition)
		insertData := models.CaseAttribute{
			CaseRefNumber:                   caseRefNumber,
			ClientLoanIds:                   params.ClientLoanIds,
			LastDisposition:                 params.LastDisposition,
			LastDispositionFollowupDate:     params.LastDispositionFollowupDate,
			LastDispositionDatetime:         params.LastDispositionDatetime,
			ContactRefNumber:                params.ContactRefNumber,
			HavingMandateInprogressPayments: params.HavingMandateInprogressPayments,
			HavingInprogressPayments:        params.HavingInprogressPayments,
			DispositionType:                 dispositionType,
			TodaysCallsConnected:            params.TodaysCallsConnected,
		}
		_, err := ca.caseAttributeRepo.Create(ctx, insertData)
		if err != nil {
			logger.Error(ctx, err, "CaseService|InsertUpdateCaseAttributes|insertCaseAttribute", logger.LogFields{caseRefNumber: insertData})
			return err
		}
	}
	return nil
}

/*
- Case withdrawal
- return error
- @author Tejas Surve
*/
func (ca *CaseService) CaseWithdrawal(ctx context.Context, caseRefNumber string, changedBy string) error {
	logger.Info(ctx, "CaseService|LoanWithdrawal|Input", logger.LogFields{"caseRefNumber": caseRefNumber, "changedBy": changedBy})

	caseWhere := models.Case{
		CaseRefNumber: caseRefNumber,
	}
	caseData, caseErr := ca.caseRepo.FindByReferenceNumberOne(ctx, caseWhere)
	if caseErr != nil {
		return caseErr
	}
	//Update loan status
	updateCaseData := models.Case{
		Status: enum.CASE_WITHDRAWN,
	}

	dbTxn := ca.caseRepo.GetWriteDBConnection().Begin()
	_, caseUpdateErr := ca.caseRepo.Update(ctx, updateCaseData, models.Case{CaseRefNumber: caseData.CaseRefNumber})
	if caseUpdateErr != nil {
		dbTxn.Rollback()
		return caseUpdateErr
	}

	currentTime := time.Now()
	createParams := models.CaseStatusHistory{
		CaseRefNumber: caseRefNumber,
		Status:        updateCaseData.Status.String(),
		ChangedBy:     changedBy,
		ChangedDate:   &currentTime,
	}
	_, err := ca.CaseStatusHistoryRepo.Create(ctx, createParams)
	if err != nil {
		dbTxn.Rollback()
		return err
	}

	err = adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, events.CaseWithdrawnEvent{CaseRefNumber: caseRefNumber}, eventConstants.CASE_WITHDRAWN, nil)
	if err != nil {
		dbTxn.Rollback()
		logger.Error(ctx, err, "CaseService|CaseWithdrawal|PublishEvent", logger.LogFields{"case_ref_number": caseRefNumber})
	}

	if err := dbTxn.Commit().Error; err != nil {
		dbTxn.Rollback()
		logger.Error(ctx, err, "CaseService|AllocateCase|CommitTransaction", logger.LogFields{})
	}

	return nil
}

// Check if any extra parameters are present besides the mandatory cache filters
/*func hasExtraCaseListCacheParams(ctx context.Context, filter request.CaseListFilter) bool {
	return filter.ClientLoanId != "" ||
		filter.LoanRefNumber != "" ||
		filter.ClientCustomerId != "" ||
		filter.CustomerRefNumber != "" ||
		filter.CurrentDPDBucket != "" ||
		filter.CaseRefNumber != "" ||
		filter.LastDisposition != "" ||
		filter.SortByDue != "" ||
		filter.SortByBucket != "" ||
		filter.SortByLastDispositionDate != "" ||
		filter.FollowupDate != "" ||
		filter.SearchBy != "" ||
		filter.SearchKey != ""
}*/

func constructCaseListRedisKey(filter request.CaseListFilter) string {
	return fmt.Sprintf("api:%s:%s:%s:%s:%t:%s:%t:%s:%d", constants.API_CASELIST, constants.AGENT_REF_NUMBER, filter.AllocatedTo, constants.GET_PTP_CASE, filter.GetPTPCases, constants.GET_UNTOUCHED_CASE, filter.GetUntouchCases, constants.PAGE_NO, filter.PageNo)
}

// Helper function to fetch data from the repository and set it to cache
//func (s *CaseService) mapCaseListResponseAndSetToCache(ctx context.Context, filter request.CaseListFilter, caseList []dto.CaseResponse, totalPage int64, page int) (map[string]interface{}, error) {
//	finalResp := make(map[string]interface{})
//
//	// Process fetched data and construct final response
//	finalResp["cases"] = s.mapCaseListResponse(ctx, caseList)
//	finalResp["pages"] = totalPage
//	finalResp["current_page"] = page
//
//	// Store data in cache
//	result, err := json.Marshal(finalResp)
//	if err != nil {
//		return finalResp, err
//	}
//
//	redisKey := constructCaseListRedisKey(filter)
//	redisExpiry := 1 * time.Hour
//	redisService := cacheservice.GetInstance()
//	ok, err := redisService.Create(redisKey, result, "set", redisExpiry)
//	if !ok {
//		return finalResp, err
//	}
//	if err != nil {
//		return finalResp, err
//	}
//
//	return finalResp, nil
//}

func (ca *CaseService) SendPaymentLink(ctx context.Context, caseRefNumber string, req request.SendPaymentLinkReq) error {
	// get client configuration
	paymentConfig, err := getClientConfig(ctx, caseRefNumber, ca)
	if err != nil {
		return err
	}
	sendPayLinkEventPayload := generateSendPaymentLinkEvent(caseRefNumber, req)

	if paymentConfig.PaymentConfigType == "native" {
		if paymentConfig.PaymentNative.SendPaymentLinkType == "campaign" {
			sendPayLinkEventPayload.WebengageCampaignID = paymentConfig.PaymentNative.NativeSendPayment.WebengageCampaignID
			sendPayLinkEventPayload.Attributes = paymentConfig.PaymentNative.NativeSendPayment.Attributes
		}
	} else if paymentConfig.PaymentConfigType == "nonnative" {
		if paymentConfig.PaymentNonNative.SendPaymentLinkType == "campaign" {
			sendPayLinkEventPayload.WebengageCampaignID = paymentConfig.PaymentNonNative.NonnativeSendPayment.WebengageCampaignID
			sendPayLinkEventPayload.Attributes = paymentConfig.PaymentNonNative.NonnativeSendPayment.Attributes
		} else if paymentConfig.PaymentNonNative.SendPaymentLinkType == "api" {
			// hit client api
			url := paymentConfig.PaymentNonNative.SendPaymentLinkAPI.URL
			method := paymentConfig.PaymentNonNative.SendPaymentLinkAPI.Method
			err := service_calls.ClientAPI(ctx, url, method)
			if err != nil {
				utils.InternalServerError(ctx, err, "")
			}
		}
	} else {
		utils.BadRequestException(ctx, "400", "bad request", "Invalid configuration", nil)

	}
	// publish send_payment_link event
	adapter.PublishEvent(ctx, []string{constants.RMQ_COMMON_SERVICE_MAIN_QUEUE_KEY}, sendPayLinkEventPayload, "send_payment_link", nil)

	return nil
}

func getClientConfig(ctx context.Context, caseRefNumber string, ca *CaseService) (*dto.PaymentConfig, error) {
	// get case data for client ref number
	caseData, err := ca.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: caseRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}
	// get client configuration
	configRes, err := ca.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: caseData.ClientRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}
	// Unmarshal configRes.Configuration into appConfigMap
	var appConfigMap map[string]interface{}
	err = json.Unmarshal([]byte(configRes.Configuration), &appConfigMap)
	if err != nil {
		return nil, err
	}

	// Unmarshal map to AppConfig struct
	var appConfig dto.AppConfig
	err = mapstructure.Decode(appConfigMap, &appConfig)
	if err != nil {
		return nil, err
	}
	return &appConfig.PaymentConfig, nil
}

func generateSendPaymentLinkEvent(caseRefNumber string, req request.SendPaymentLinkReq) events.SendPaymentLinkEvent {
	return events.SendPaymentLinkEvent{
		CaseRefNumber: caseRefNumber,
		MobileNumber:  req.MobileNumber,
		Email:         req.Email,
	}
}

func mapCaseModelToCaseUpdatedEvent(previousCaseData *models.Case, updatedCaseData *models.Case) events.CaseUpdatedEvent {
	return events.CaseUpdatedEvent{
		CaseRefNumber:       updatedCaseData.CaseRefNumber,
		ClientRefNumber:     updatedCaseData.ClientRefNumber,
		ClientTeamRefNumber: updatedCaseData.ClientTeamRefNumber,
		CustomerRefNumber:   updatedCaseData.CustomerRefNumber,
		LoanRefNumber:       updatedCaseData.LoanRefNumber,
		CollectionFor:       updatedCaseData.CollectionFor,
		CaseLevel:           updatedCaseData.CaseLevel,
		FinancierRefNumber:  updatedCaseData.FinancierRefNumber,
		Bucket:              updatedCaseData.Bucket,
		Status:              updatedCaseData.Status,
		TotalDue:            updatedCaseData.TotalDue,
		TotalPrincipalDue:   updatedCaseData.TotalPrincipalDue,
		TotalInterestDue:    updatedCaseData.TotalInterestDue,
		TotalFeesDue:        updatedCaseData.TotalFeesDue,

		PreviousClientRefNumber:     previousCaseData.ClientRefNumber,
		PreviousClientTeamRefNumber: previousCaseData.ClientTeamRefNumber,
	}
}

func mapCaseModelToCaseCreatedEvent(caseData models.Case) events.CaseCreatedEvent {
	return events.CaseCreatedEvent{
		CaseRefNumber:       caseData.CaseRefNumber,
		ClientRefNumber:     caseData.ClientRefNumber,
		ClientTeamRefNumber: caseData.ClientTeamRefNumber,
		CustomerRefNumber:   caseData.CustomerRefNumber,
		LoanRefNumber:       caseData.LoanRefNumber,
		CollectionFor:       caseData.CollectionFor,
		CaseLevel:           caseData.CaseLevel,
		FinancierRefNumber:  caseData.FinancierRefNumber,
		Bucket:              caseData.Bucket,
		Status:              caseData.Status,
		TotalDue:            caseData.TotalDue,
		TotalPrincipalDue:   caseData.TotalPrincipalDue,
		TotalInterestDue:    caseData.TotalInterestDue,
		TotalFeesDue:        caseData.TotalFeesDue,
	}
}

func (ca *CaseService) allocationInitialChecks(ctx context.Context, request request.CaseAllocationReq) error {
	//Service Provider Columns present only case uploaded by client
	if utils.IsNotEmpty(request.ServiceProviderRefNumber) {
		providerWhere := models.ClientServiceProviders{
			ServiceProviderRefNumber: request.ServiceProviderRefNumber,
			ClientRefNumber:          request.ObjectRefNumber,
		}
		_, err := ca.clientServiceProviderMapping.FindOne(ctx, providerWhere)
		if err != nil {
			logger.Error(ctx, err, "CaseService|AllocateCase|GetProvider", logger.LogFields{"where": providerWhere})
			if err.Error() == "record not found" {
				return errors.New(constants.GetErrMsg(constants.SERVICE_PROVIDER_NOT_FOUND))
			}
			return err
		}
	}
	//Agent Columns present only case uploaded by service provider
	if utils.IsNotEmpty(request.AgentRefNumber) {
		//Check Agent is present while allocating
		agentWhere := models.Agent{
			AgentRefNumber:           request.AgentRefNumber,
			ServiceProviderRefNumber: request.ObjectRefNumber,
		}
		_, err := ca.agentRepo.FindOne(ctx, &agentWhere)
		if err != nil {
			logger.Error(ctx, err, "CaseService|AllocateCase|GetAgent", logger.LogFields{"where": agentWhere})
			if err == gorm.ErrRecordNotFound {
				return errors.New(constants.GetErrMsg(constants.AGENT_NOT_FOUND))
			}
			return err
		}
	}

	if request.Object == "CLIENT" {
		where := models.Case{
			CaseRefNumber:   request.CaseRefNumber,
			Status:          enum.CASE_ACTIVE,
			ClientRefNumber: request.ObjectRefNumber,
		}
		_, err := ca.caseRepo.FindByReferenceNumberOne(ctx, where)
		if err != nil {
			if err.Error() == "record not found" {
				return errors.New("invalid case for loan : " + request.ClientLoanId)
			}
			return err
		}
		if utils.IsNotEmpty(request.ServiceProviderRefNumber) {
			_, err := ca.clientServiceProviderMapping.FindOne(ctx, models.ClientServiceProviders{ClientRefNumber: request.ObjectRefNumber, Intervention: request.Intervention, ServiceProviderRefNumber: request.ServiceProviderRefNumber, Status: enum.STATUS_ACTIVE})
			if err != nil {
				if err.Error() == "record not found" {
					return errors.New("invalid intervention & service provider mapping : " + request.ServiceProviderRefNumber)
				}
				return err
			}
		}
	}
	if request.Object == "SERVICE_PROVIDER" {
		allocationWhere := models.Allocation{
			CaseRefNumber:            request.CaseRefNumber,
			ServiceProviderRefNumber: request.ObjectRefNumber,
		}
		allocationData, err := ca.allocationRepo.FindByReferenceNumberOne(ctx, allocationWhere)

		if err != nil {
			if err.Error() == "record not found" {
				return errors.New("invalid case : " + request.CaseRefNumber)
			}
			return err
		}
		if utils.IsNotEmpty(allocationData.AgentRefNumber) {
			return errors.New("invalid case : " + request.CaseRefNumber + " case already allocated")
		}
	}
	return nil
}

func (ca *CaseService) deallocationInitialChecks(ctx context.Context, request request.CaseDeAllocationReq) error {

	if request.Object == "CLIENT" {
		where := models.Case{
			CaseRefNumber:   request.CaseRefNumber,
			Status:          enum.CASE_ACTIVE,
			ClientRefNumber: request.ObjectRefNumber,
		}
		_, err := ca.caseRepo.FindByReferenceNumberOne(ctx, where)
		if err != nil {
			if err.Error() == "record not found" {
				return errors.New("invalid case : " + request.CaseRefNumber)
			}
			return err
		}
		if utils.IsNotEmpty(request.ServiceProviderRefNumber) {
			_, err := ca.clientServiceProviderMapping.FindOne(ctx, models.ClientServiceProviders{ClientRefNumber: request.ObjectRefNumber, Intervention: request.Intervention, ServiceProviderRefNumber: request.ServiceProviderRefNumber, Status: enum.STATUS_ACTIVE})
			if err != nil {
				if err.Error() == "record not found" {
					return errors.New("invalid intervention & service provider mapping : " + request.ServiceProviderRefNumber)
				}
				return err
			}
		}
	}
	if request.Object == "SERVICE_PROVIDER" {
		allocationWhere := models.Allocation{
			CaseRefNumber:            request.CaseRefNumber,
			AgentRefNumber:           request.AgentRefNumber,
			ServiceProviderRefNumber: request.ObjectRefNumber,
		}
		_, err := ca.allocationRepo.FindByReferenceNumberOne(ctx, allocationWhere)
		if err != nil {
			if err.Error() == "record not found" {
				return errors.New("invalid case allocation: " + request.CaseRefNumber)
			}
			return err
		}
	}
	return nil
}

/*
Update Case func
@return error
@author Tejas Surve
*/

func (ca *CaseService) UpdateCase(ctx context.Context, caseRefNumber string, update request.CaseUpdateReq) error {
	logger.Info(ctx, "CaseService|UpdateCase", logger.LogFields{"request": update})
	//In future modify code to update necessary columns

	data := make(map[string]interface{})
	data["IsBlocked"] = update.IsBlocked
	isUpdated := ca.caseRepo.UpdateWithMapInterface(ctx, data, models.Case{CaseRefNumber: caseRefNumber})
	if !isUpdated {
		return errors.New("case not updated")
	}
	return nil
}

/*
CaseAttemptList : Get case attempt list from dialer service & merge caller and customer data here and pass it to gateway
@return response.AttemptList
@Author Tejas Surve
*/
func (ca *CaseService) CaseAttemptList(ctx context.Context, params map[string]string) (response.AttemptListResponse, error) {
	logger.Info(ctx, "CaseService|CaseAttemptList", logger.LogFields{"request": params})
	// Get csat attempt list
	succesCode, successResponse, errorResponse, _, serviceErr := service_calls.GetCsatAttemptList(ctx, params)
	if serviceErr != nil {
		logger.Error(ctx, serviceErr, "CaseService|CaseAttemptList|GetCsatAttemptList", logger.LogFields{"httpCode": succesCode, "error": serviceErr, "errorResponse": errorResponse})
		return response.AttemptListResponse{}, serviceErr
	}
	//mapping service call response to our struct
	attemptList := serviceCallRespToAttemptList(ctx, successResponse)

	return response.AttemptListResponse{Attempts: ca.transformToAttemptResponse(ctx, attemptList)}, nil

}

/*
CaseSearchAPI : Based on querystring parameter search case
@return response.SearchCaseResponse
@Author Tejas Surve
*/
func (ca *CaseService) SearchCase(ctx context.Context, req request.SearchCaseReq, pagination dto.PaginationData) (response.SearchCaseResponse, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	logger.Info(ctx, "CaseService|SearchCase", logger.LogFields{"request": req})

	if pagination.CurrentPage <= 0 {
		pagination.CurrentPage = 1
	}
	pagination = dto.Init(pagination.CurrentPage)

	casesRefList := []response.CaseSearch{}
	// Get Case ref number from repo

	q := req.Query
	if len(q) < 4 {
		// throw bad request
		utils.BadRequestException(ctx, "400", "bad request", "search query should be minimum 4 characters", nil)
	}
	if utils.IsEmpty(req.ClientRefNumber) {
		return response.SearchCaseResponse{}, errors.New("client_ref_number is required")
	}
	filter := models.Case{
		ClientRefNumber: req.ClientRefNumber,
	}
	cases, totalRecords, err := ca.caseRepo.SearchCaseOnQueryString(ctx, q, filter, pagination)
	if err != nil {
		return response.SearchCaseResponse{}, err
	}
	// Calculating totalPages based on totalRecords
	totalPages := totalRecords / pagination.Limit
	if totalRecords%pagination.Limit > 0 {
		totalPages++
	}
	for i := range cases {
		caseData := response.CaseSearch{
			CaseRefNumber: cases[i].CaseRefNumber,
			LoanRefNumber: cases[i].LoanRefNumber,
			CreatedAt:     cases[i].CreatedAt.Format("2006-01-02 15:04:05"),
			Status:        cases[i].Status,
		}
		casesRefList = append(casesRefList, caseData)
	}
	return response.SearchCaseResponse{
		Cases:          casesRefList,
		PaginationData: response.PaginationData{CurrentPage: pagination.CurrentPage, Pages: totalPages},
	}, nil

}

func serviceCallRespToAttemptList(ctx context.Context, successResp *dto.SuccessResponse) []response.AttemptList {
	// Unmarshal responseData into dataInterface
	byte, err := json.Marshal(successResp.Data)
	if err != nil {
		logger.Error(ctx, err, "CaseService|serviceCallRespToAttemptList|UnmarshalError", logger.LogFields{"data": successResp})
	}
	var response response.AttemptListResponse
	err = json.Unmarshal(byte, &response)
	return response.Attempts

}

func (ca *CaseService) transformToAttemptResponse(ctx context.Context, attempts []response.AttemptList) []response.AttemptList {
	var transformedAttempts []response.AttemptList
	var attemptRefNumbers []string
	var agentRefNumbers []string

	for _, attempt := range attempts {
		attemptRefNumbers = append(attemptRefNumbers, attempt.AttemptRefNumber)
		agentRefNumbers = append(agentRefNumbers, attempt.AgentRefNumber)
		attempt := response.AttemptList{
			AttemptRefNumber:     attempt.AttemptRefNumber,
			AgentStatus:          attempt.AgentStatus,
			AgentRefNumber:       attempt.AgentRefNumber,
			ConnectedStatus:      attempt.ConnectedStatus,
			CallAttemptedDate:    attempt.CallStartDatetime,
			CustomerMobileNumber: utils.MaskMobileNumber(attempt.CustomerMobileNumber),
			CallRecordFileURL:    attempt.CallRecordFileURL,
			Mood:                 attempt.Mood,
			CallStartDatetime:    attempt.CallStartDatetime,
			CallEndDatetime:      attempt.CallEndDatetime,
			CallDuration:         attempt.CallDuration,
			Status:               attempt.Status,
		}

		transformedAttempts = append(transformedAttempts, attempt)
	}

	if len(attemptRefNumbers) > 0 {
		//Get Disposition Data
		dispositionData, err := ca.dispositionRepo.FindDispositionsFromAttemptRef(ctx, attemptRefNumbers)
		if err != nil {
			logger.Error(ctx, err, "CaseService|transformToAttemptResponse|FindDisposition", logger.LogFields{"attempt": attemptRefNumbers})
		}
		for i, attempt := range transformedAttempts {
			for _, disposition := range dispositionData {
				if attempt.AttemptRefNumber == disposition.AttemptRefNumber {
					transformedAttempts[i].Disposition = disposition.Disposition
				}
			}
		}
	}
	if len(agentRefNumbers) > 0 {
		agentsData, err := ca.agentRepo.FindAgentsWithRefNumbers(ctx, agentRefNumbers)
		if err != nil {
			logger.Error(ctx, err, "CaseService|transformToAttemptResponse|FindAgents", logger.LogFields{"attempt": agentRefNumbers})
		}
		for i, attempt := range transformedAttempts {
			for _, agent := range agentsData {
				if attempt.AgentRefNumber == agent.AgentRefNumber {
					transformedAttempts[i].AgentRefNumber = agent.AgentRefNumber
					transformedAttempts[i].AgentRole = agent.Role.String()
					transformedAttempts[i].AgentName = agent.FirstName + " " + agent.LastName
				}
			}
		}
	}

	return transformedAttempts
}

/* Get case list api without pagination
@return caseList
@author : Tejas Surve
*/

func (ca *CaseService) GetCaseList(ctx context.Context, filter request.CaseListFilter) (response.CaseList, error) {
	logger.Info(ctx, "CaseService|GetCaseList", logger.LogFields{"request": filter})
	//get active cases
	filter.Status = "ACTIVE"

	var finalResp = response.CaseList{}

	if err := validateCaseListFilter(ctx, filter); err != nil {
		logger.Error(ctx, err, "CaseService|FindCaseList|validateCaseListFilter error", logger.LogFields{"payload": filter, "error": err})
		return finalResp, err
	}

	clientTeamRefNumber, serviceProviderTeamRefNumber, agentRefNumbers := ca.casePermissionService.ExtractTeamAndUsersToBeFetched(ctx, &case_permissions.CasePermifyFilter{Object: filter.Object, ObjectRefNumber: filter.ObjectRefNumber, CaseRefNumber: filter.CaseRefNumber})

	filter.AgentRefNumbers = agentRefNumbers
	filter.ServiceProviderTeamRefNumber = serviceProviderTeamRefNumber
	filter.ClientTeamRefNumber = clientTeamRefNumber

	cases, err := ca.caseRepo.GetCaseListWithoutPaginate(ctx, filter, agentRefNumbers, serviceProviderTeamRefNumber, clientTeamRefNumber)
	if err != nil {
		return finalResp, err
	}
	finalResp = response.CaseList{Address: transformCasesToCaseList(cases)}
	return finalResp, nil

}

func transformCasesToCaseList(cases []dto.CaseResponse) []response.CustomerAddress {
	caseResponse := []response.CustomerAddress{}

	for i := range cases {
		caseData := response.CustomerAddress{
			CaseRefNumber:    cases[i].CaseRefNumber,
			TotalDueAmount:   cases[i].TotalDue,
			AddressRefNumber: cases[i].AddressRefNumber,
			Label:            cases[i].Label,
			Type:             cases[i].AddressType,
			Source:           cases[i].AddressSource,
			Address:          cases[i].Line1 + " " + cases[i].Line2 + " " + cases[i].Line3,
			Line1:            cases[i].Line1,
			Line2:            cases[i].Line2,
			Line3:            cases[i].Line3,
			Latitude:         cases[i].Lat,
			Longitude:        cases[i].Long,
			Pincode:          cases[i].Pincode,
		}

		if cases[i].IsPrimary > 0 {
			caseData.IsPrimary = true
		}
		caseResponse = append(caseResponse, caseData)
	}
	return caseResponse
}

func (ca *CaseService) GetClientCases(ctx context.Context, clientRefNumber string) (response.GetActiveCasesResp, error) {
	var finalResp = response.GetActiveCasesResp{}
	caseRefNumbers, err := ca.caseRepo.GetClientActiveCases(ctx, clientRefNumber)
	if err != nil {
		return finalResp, err
	}
	finalResp = response.GetActiveCasesResp{Cases: caseRefNumbers}
	return finalResp, nil

}

func transformModelToCaseToResponse(caseData models.Case, caseAttr models.CaseAttribute) response.Case {
	callsLeft := clientInfo.DailyCallsLimit - caseAttr.TodaysCallsAttempted
	lastDispositionFollowupDate := ""
	lastDispositionDatetime := ""
	lastCallConnectedAt := ""
	if caseAttr.LastDispositionFollowupDate != nil {
		lastDispositionFollowupDate = utils.FormatDateAsYmdhis(*caseAttr.LastDispositionFollowupDate)
	}
	if caseAttr.LastDispositionDatetime != nil {
		lastDispositionDatetime = utils.FormatDateAsYmdhis(*caseAttr.LastDispositionDatetime)
	}
	if caseAttr.LastCallConnectedAt != nil {
		lastCallConnectedAt = utils.FormatDateAsYmdhis(*caseAttr.LastCallConnectedAt)
	}

	return response.Case{
		CaseRefNumber:                   caseData.CaseRefNumber,
		ClientRefNumber:                 caseData.ClientRefNumber,
		CustomerRefNumber:               caseData.CustomerRefNumber,
		LoanRefNumber:                   caseData.LoanRefNumber,
		Bucket:                          caseData.Bucket.String(),
		MaxDpd:                          caseData.MaxDpd,
		CurrentDpd:                      caseData.CurrentDpd,
		TotalDue:                        caseData.TotalDue,
		TotalPrincipalDue:               caseData.TotalPrincipalDue,
		TotalInterestDue:                caseData.TotalInterestDue,
		TotalFeesDue:                    caseData.TotalFeesDue,
		TotalOutstanding:                caseData.TotalOutstanding,
		TotalPrincipalOutstanding:       caseData.TotalPrincipalOutstanding,
		TotalInterestOutstanding:        caseData.TotalInterestOutstanding,
		TotalFeesOutstanding:            caseData.TotalFeesOutstanding,
		NoOfEmisDue:                     caseData.NoOfEmisDue,
		NoOfLoansDue:                    caseData.NoOfLoansDue,
		Status:                          caseData.Status.String(),
		CaseType:                        caseData.CaseType,
		LastDisposition:                 caseAttr.LastDisposition,
		LastDispositionFollowupDate:     lastDispositionFollowupDate,
		LastDispositionDatetime:         lastDispositionDatetime,
		TotalCallsAttempted:             caseAttr.TotalCallsAttempted,
		TotalCallsConnected:             caseAttr.TotalCallsConnected,
		LastCallConnectedAt:             lastCallConnectedAt,
		ClientLoanIds:                   caseAttr.ClientLoanIds,
		HavingMandateInprogressPayments: caseAttr.HavingMandateInprogressPayments,
		HavingInprogressPayments:        caseAttr.HavingInprogressPayments,
		CallsLeft:                       callsLeft,
		DistanceCheckMeters:             clientInfo.DistanceCheckMeters,
	}
}

func transformModelToCustomerToResponse(customerData models.Customer, caseAttr models.CaseAttribute) response.Customer {
	return response.Customer{
		ClientCustomerId:        customerData.ClientCustomerId,
		CustomerRefNumber:       customerData.CustomerRefNumber,
		FirstName:               customerData.FirstName,
		LastName:                customerData.LastName,
		Email:                   customerData.Email,
		MobileNumber:            utils.MaskMobileNumber(customerData.MobileNumber),
		ClientRefNumber:         customerData.ClientRefNumber,
		PreferredLanguage:       customerData.PreferredLanguage,
		Age:                     utils.GetAge(customerData.Dob),
		Gender:                  customerData.Gender,
		PrimaryContactRefNumber: caseAttr.ContactRefNumber,
	}
}
