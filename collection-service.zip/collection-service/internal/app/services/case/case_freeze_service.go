package _case

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/client"
	"collection-service/internal/dto"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"context"
	"errors"
	"time"
)

type CaseFreezeService struct {
	repositories.BaseRepo
	services.BaseService
	caseRepo         repo_interfaces.ICaseRepository
	freezeReasonRepo repo_interfaces.ICaseFreezeRepository
	clientService    client.IClientService
}

func InitCaseFreezeService(ctx context.Context, caseRepo repo_interfaces.ICaseRepository, freezeReasonRepo repo_interfaces.ICaseFreezeRepository, clientService client.IClientService) *CaseFreezeService {
	service := &CaseFreezeService{
		caseRepo:         caseRepo,
		freezeReasonRepo: freezeReasonRepo,
		clientService:    clientService,
	}

	return service
}

/*
FreezeCase is a function to freeze case
Check case is active or not then update freeze status & create entry in  freeze history table
@params : ctx, request.FreezeCase
@returns : error
@author : Tejas Surve
*/

func (service CaseFreezeService) FreezeCase(ctx context.Context, request request.FreezeCase) error {
	logger.Info(ctx, "FreezeCaseService|FreezeCase", logger.LogFields{"request": request})
	_, err := service.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: request.CaseRefNumber, Status: enum.CASE_ACTIVE})
	if err != nil {
		logger.Error(ctx, err, "FreezeCaseService|FreezeCase|getCaseDetails", logger.LogFields{"caseData": request})
		return err
	}
	//Update freeze status & create entry in  freeze history table
	updated := service.caseRepo.UpdateWithMapInterface(ctx, map[string]interface{}{"IsFreezed": true}, models.Case{CaseRefNumber: request.CaseRefNumber})
	if !updated {
		return errors.New("case not freezed" + request.CaseRefNumber)
	}
	freezeModel := service.transformFreezReqToModel(request)
	createErr := service.freezeReasonRepo.Create(ctx, freezeModel)
	if createErr != nil {
		return createErr
	}
	return nil
}

/*
UnfreezeCase is a function to unfreeze case
Check case is active or freezed then update freeze status & create entry in  freeze history table
@params : ctx, request.UnFreezeCase
@returns : error
@author : Tejas Surve
*/
func (service CaseFreezeService) UnFreezeCase(ctx context.Context, request request.UnFreezeCase) error {
	logger.Info(ctx, "FreezeCaseService|UnFreezeCase", logger.LogFields{"request": request})
	_, err := service.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: request.CaseRefNumber, Status: enum.CASE_ACTIVE, IsFreezed: true})
	if err != nil {
		logger.Error(ctx, err, "FreezeCaseService|UnFreezeCase|getCaseDetails", logger.LogFields{"caseData": request})
		return err
	}
	//Update freeze status & create entry in  freeze history table
	updated := service.caseRepo.UpdateWithMapInterface(ctx, map[string]interface{}{"IsFreezed": false}, models.Case{CaseRefNumber: request.CaseRefNumber})
	if !updated {
		return errors.New("case not unfreezed" + request.CaseRefNumber)
	}
	freezeModel := service.transformUnFreezReqToModel(request)
	createErr := service.freezeReasonRepo.Create(ctx, freezeModel)
	if createErr != nil {
		return createErr
	}
	return nil
}

func (service CaseFreezeService) DailyCallslimitFreeze(ctx context.Context, input request.DailyCallsLimitFreeze) error {
	logger.Info(ctx, "FreezeCaseService|DailyCallslimitFreeze", logger.LogFields{"request": input})
	caseData, err := service.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: input.CaseRefNumber, Status: enum.CASE_ACTIVE})
	if err != nil {
		logger.Error(ctx, err, "FreezeCaseService|FreezeCase|getCaseDetails", logger.LogFields{"caseData": input})
		return err
	}
	clientConfig, err := service.clientService.GetClientConfig(ctx, caseData.ClientRefNumber, request.Config{})
	if err != nil {
		return err
	}
	// Freeze case if daily call limit reached
	reason, sendEvent := service.sendFreezeEventChecks(caseData, clientConfig)
	if sendEvent {
		input.Reason = reason
		freezeCaseEvent := service.transformDailyFreezeToFreezeCaseEvent(input)
		adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, freezeCaseEvent, "freeze_case", nil)

		unFreezeCaseEvent := service.transformDailyFreezeToUnFreezeCaseEvent(input)
		delayTime := constants.RMQ_DEAD_LETTER_QUEUE_TWELVE_HRS_TTL_MS
		if caseData.CaseAttribute.TodaysCallsAttempted == 1 {
			delayTime = constants.RMQ_DEAD_LETTER_QUEUE_THIRTY_MIN_TTL_MS
		}
		adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, unFreezeCaseEvent, "unfreeze_case", &delayTime)
	}
	return nil
}
func (service CaseFreezeService) sendFreezeEventChecks(caseData *models.Case, clientConfig *dto.AppConfig) (string, bool) {

	sendEvent := false
	reason := ""
	// Freeze case if daily call limit reached
	if caseData.CaseAttribute.TodaysCallsAttempted == 1 {
		//Freeze case for 30 min for single attempt
		sendEvent = true
		reason = constants.FREEZE_REASON_DAILY_CALLS_ATTEMPTS_LIMIT_EXCEEDED
	} else if caseData.CaseAttribute.TodaysCallsAttempted >= clientConfig.DailyCallsLimit {
		//Freeze case for 12 hrs if daily call limit reached
		sendEvent = true
		reason = constants.FREEZE_REASON_DAILY_CALLS_ATTEMPTS_LIMIT_EXCEEDED
	} else if caseData.CaseAttribute.TodaysCallsConnected >= 1 && caseData.CaseAttribute.HavingMandateInprogressPayments {
		// Freeze case if daily call limit not reached but having mandate in progress payments
		sendEvent = true
		reason = constants.FREEZE_REASON_MANDATE_INPROGRESS
	} else if (caseData.CaseAttribute.LastDisposition == "PTP" || caseData.CaseAttribute.LastDisposition == "CB") && caseData.CaseAttribute.TodaysCallsConnected >= constants.DAILY_CALLS_LIMIT_FREEZE_FOR_PTP_CB {
		// Freeze case if daily call limit not reached but having PTP or CB disposition and connected calls are more than 3
		sendEvent = true
		reason = constants.FREEZE_REASON_DAILY_CALL_CONNECTED_LIMIT_EXCEEDED
	} else if caseData.CaseAttribute.TodaysCallsConnected >= 1 {
		sendEvent = true
		reason = constants.FREEZE_REASON_DAILY_CALL_CONNECTED_LIMIT_EXCEEDED
	}
	return reason, sendEvent
}

// transformFreezReqToModel is a function to transform request to model
func (service CaseFreezeService) transformFreezReqToModel(request request.FreezeCase) models.CaseFreezeHistory {
	return models.CaseFreezeHistory{
		CaseRefNumber: request.CaseRefNumber,
		Action:        enum.FREEZE,
		Reason:        request.Reason,
		CreatedBy:     request.CreatedBy,
	}
}

// transformFreezReqToModel is a function to transform request to model
func (service CaseFreezeService) transformUnFreezReqToModel(request request.UnFreezeCase) models.CaseFreezeHistory {
	return models.CaseFreezeHistory{
		CaseRefNumber: request.CaseRefNumber,
		Action:        enum.UNFREEZE,
		Reason:        request.Reason,
		CreatedBy:     request.CreatedBy,
	}
}

// Transform to freeze case event
func (service CaseFreezeService) transformToFreezeCaseEvent(request request.FreezeCase) events.FreezeCase {
	return events.FreezeCase{
		CaseRefNumber: request.CaseRefNumber,
		Reason:        request.Reason,
		CreatedBy:     request.CreatedBy,
		CreatedAt:     time.Time{}.String(),
	}
}

// Transform to un freeze case event
func (service CaseFreezeService) transformToUnFreezeCaseEvent(request request.FreezeCase) events.FreezeCase {
	return events.FreezeCase{
		CaseRefNumber: request.CaseRefNumber,
		Reason:        request.Reason,
		CreatedBy:     request.CreatedBy,
		CreatedAt:     time.Time{}.String(),
	}
}

func (service CaseFreezeService) transformDailyFreezeToFreezeCaseEvent(request request.DailyCallsLimitFreeze) events.FreezeCase {
	return events.FreezeCase{
		CaseRefNumber: request.CaseRefNumber,
		Reason:        request.Reason,
		CreatedBy:     request.CreatedBy,
		CreatedAt:     time.Time{}.String(),
	}
}

func (service CaseFreezeService) transformDailyFreezeToUnFreezeCaseEvent(request request.DailyCallsLimitFreeze) events.UnFreezeCase {
	return events.UnFreezeCase{
		CaseRefNumber: request.CaseRefNumber,
		CreatedBy:     request.CreatedBy,
		CreatedAt:     time.Time{}.String(),
	}
}
