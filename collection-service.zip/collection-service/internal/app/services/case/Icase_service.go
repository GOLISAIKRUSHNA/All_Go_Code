package _case

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"

	//"collection-service/internal/dto/response"
	"collection-service/internal/models"
)

type ICaseService interface {
	services.IBaseService
	FindCase(ctx context.Context, caseFilter models.Case) models.Case
	GenerateCase(ctx context.Context, caseReq request.GenerateCase) (bool, error)
	FindCaseListWithPaginate(ctx context.Context, filter request.CaseListFilter) (interface{}, error)
	GetCaseLoan(ctx context.Context, filter request.CaseLoanFilter) (interface{}, error)
	AllocateCase(ctx context.Context, request request.CaseAllocationReq) error
	InsertUpdateCaseAttributes(ctx context.Context, CaseRefNumber string, request request.CaseAttributeReq) error
	DeAllocateCase(ctx context.Context, request request.CaseDeAllocationReq) error
	CaseWithdrawal(ctx context.Context, caseRefNumber string, changedBy string) error
	SendPaymentLink(ctx context.Context, caseRefNumber string, req request.SendPaymentLinkReq) error
	UpdateCase(ctx context.Context, caseRefNumber string, req request.CaseUpdateReq) error
	CaseAttemptList(ctx context.Context, params map[string]string) (response.AttemptListResponse, error)
	GetCaseList(ctx context.Context, filter request.CaseListFilter) (response.CaseList, error)
	SearchCase(ctx context.Context, req request.SearchCaseReq, pagination dto.PaginationData) (response.SearchCaseResponse, error)
	GetClientCases(ctx context.Context, clientRefNumber string) (response.GetActiveCasesResp, error)
}
