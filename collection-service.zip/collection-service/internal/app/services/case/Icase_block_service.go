package _case

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
	//"collection-service/internal/dto/response"
)

type ICaseBlockService interface {
	services.IBaseService
	BlockCase(ctx context.Context, request request.BlockCase) error
	GetCaseBlockList(ctx context.Context, request request.CaseBlockList) []response.CaseBlockList
	GetBlockListWithPagination(ctx context.Context, filter request.CaseBlockList) response.BlockListData
	UpdateCaseBlockData(ctx context.Context, request request.UpdateBlockCase, caseRefNumber string) error
	GetBlockReasonMaster(ctx context.Context, request request.CaseBlockReason) response.BlockReasonListData
	UnblockCase(ctx context.Context, caseRefNumber string) error
}
