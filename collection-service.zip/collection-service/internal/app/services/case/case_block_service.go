package _case

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"errors"
	"fmt"
	"strings"
	"time"
)

type CaseBlockService struct {
	repositories.BaseRepo
	services.BaseService
	caseRepo          repo_interfaces.ICaseRepository
	blockReasonRepo   repo_interfaces.IBlockReasonMasterRepository
	caseBlockListRepo repo_interfaces.ICaseBlockListRepository
	loanRepo          repo_interfaces.ILoanRepository
	blockReasonMaster repo_interfaces.IBlockReasonMasterRepository
	//ticketService     ticket.ITicketService
}

// Initialization of CaseBlockService with respect to the interface IcaseBlockService
// Accepts only context as a parameter and hardcodes the loanKey, searchKey and cacheEnabled from .env variables
// Returns the LoanService pointer instance to the caller
func InitCaseBlockService(ctx context.Context) *CaseBlockService {

	service := &CaseBlockService{
		caseRepo:          repositories.InitCaseRepository(ctx),
		blockReasonRepo:   repositories.InitBlockReasonRepository(ctx),
		caseBlockListRepo: repositories.InitCaseBlockListRepository(ctx),
		loanRepo:          repositories.InitLoanRepository(ctx),
		blockReasonMaster: repositories.InitBlockReasonRepository(ctx),
		//ticketService:     ticket.InitTicketService(ctx),
	}

	return service
}

/*
Block Case : based on disposition block case | func will block case from ingress or via api call
@return: error
@author: Tejas Surve
*/
func (ca *CaseBlockService) BlockCase(ctx context.Context, block request.BlockCase) error {
	logger.Info(ctx, "CaseService|BlockCase|Request", logger.LogFields{"request": block})
	isResolved := false
	createTicket := true
	blockedUntil := time.Time{}
	blockReasonMasterId := 0

	if block.Source == enum.CLIENT {
		blockMaster, err := ca.blockReasonRepo.FindOne(ctx, models.BlockReasonMaster{Reason: block.Reason, Source: block.Source})
		if err != nil {
			if err.Error() == "record not found" {
				return errors.New("client block reason not found")
			}
			return err
		}
		blockReasonMasterId = blockMaster.ID
		loan, err := ca.loanRepo.FindByReferenceNumberOne(ctx, models.Loan{ClientLoanId: block.ClientLoanId})
		if err != nil {
			return err
		}
		blockedUntil = utils.StringToDate(block.BlockedUntil)
		if block.BlockType == "REFER_TO_CSAT" {
			blockedUntil = utils.StringToDate(constants.PERMANENT_CASE_BLOCKED_DATE)
			createTicket = false
			isResolved = false
		}
		block.CaseRefNumber = loan.CaseRefNumber
	} else if block.Source == enum.AUDIT {
		if block.BlockType == "REFER_TO_CSAT" {
			blockedUntil = utils.StringToDate(constants.PERMANENT_CASE_BLOCKED_DATE)
			if block.ViolationId > 0 {
				reasonExist, err := ca.blockReasonRepo.FindOne(ctx, models.BlockReasonMaster{ViolationId: block.ViolationId, Source: enum.AUDIT})
				if err != nil {
					return err
				}
				if !reasonExist.Violation.IsCaseToBlock {
					logger.Error(ctx, nil, "case block not allowed on this violation", logger.LogFields{"request": block})
					return errors.New("case block not allowed on this violation")
				}
				blockReasonMasterId = reasonExist.ID
			}
		}
		if block.IsManualResolutionRequired {
			isResolved = false
		} else {
			isResolved = true
		}

	} else if block.Source == enum.DISPOSITION {
		blockMaster, err := ca.blockReasonRepo.FindOne(ctx, models.BlockReasonMaster{Reason: block.Reason, Source: block.Source})
		if err != nil {
			if err.Error() == "record not found" {
				return errors.New("block reason not found")
			}
			return err
		}
		blockReasonMasterId = blockMaster.ID
		if block.BlockedUntil != "" {
			blockedUntil = utils.StringToDateTime(block.BlockedUntil)
		} else {
			if blockMaster.IsManualResolutionRequired {
				blockedUntil = utils.AddDaysAndCreateNewDate(blockMaster.DaysToBlock)
				isResolved = false
			} else if blockMaster.DaysToBlock > 0 {
				blockedUntil = utils.AddDaysAndCreateNewDate(blockMaster.DaysToBlock)
				isResolved = true
			}
		}
	}

	blockedRecord, _ := ca.caseBlockListRepo.FindOneBlockedCase(ctx, models.CaseBlockList{CaseRefNumber: block.CaseRefNumber, BlockReasonMasterId: blockReasonMasterId})
	fmt.Println("blockedRecord", blockedRecord)

	if blockedRecord != nil {
		return errors.New("case already blocked")
	}

	blockListParams := models.CaseBlockList{
		CaseRefNumber:        block.CaseRefNumber,
		BlockReasonMasterId:  blockReasonMasterId,
		BlockedUntil:         blockedUntil,
		BlockedAt:            time.Now(),
		BlockedBy:            block.CreatedBy,
		IsResolved:           isResolved,
		OriginalBlockedUntil: time.Now(),
	}
	logger.Info(ctx, "CaseService|BlockCase|blockListParams", logger.LogFields{"blockListParams": blockListParams})
	blockModel, createErr := ca.caseBlockListRepo.Create(ctx, blockListParams)
	if createErr != nil {
		return createErr
	}
	//update case data
	updateParams := request.UpdateBlockCase{
		Action:        block.BlockType,
		CaseRefNumber: block.CaseRefNumber,
		BlockedUntil:  blockedUntil,
	}
	fmt.Println("updateParams===================>", updateParams)
	if blockCaseErr := ca.UpdateCaseBlockData(ctx, updateParams, block.CaseRefNumber); blockCaseErr != nil {
		return blockCaseErr
	}
	//publish event after case blocked
	if blockModel.ID > 0 {
		blockEventParam := transformModelToCaseBlockEvent(blockModel, createTicket)
		adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, blockEventParam, "case_blocked", nil)
	}
	return nil

}

/*
Get Case block list
@return case_block_list[]
@author Tejas Surve
*/
func (ca *CaseBlockService) GetCaseBlockList(ctx context.Context, req request.CaseBlockList) []response.CaseBlockList {
	logger.Info(ctx, "CaseBlockService|GetCaseBlockList", logger.LogFields{"request": req})
	caseBlockListData := []response.CaseBlockList{}
	caseBlockList, err := ca.caseBlockListRepo.Get(ctx, models.CaseBlockList{Limit: req.Limit, Offset: req.Offset, IsResolved: req.IsResolved})
	if err != nil {
		logger.Error(ctx, err, "CaseBlockService|GetCaseBlockList", logger.LogFields{"request": ""})
		return caseBlockListData
	}
	for _, model := range *caseBlockList {
		caseBlock := mapCaseBlockListModelToResponse(model)
		caseBlockListData = append(caseBlockListData, caseBlock)
	}
	return caseBlockListData
}

/*updateCaseBlockData: update case data based on caseRefNumber
 */
func (ca *CaseBlockService) UpdateCaseBlockData(ctx context.Context, update request.UpdateBlockCase, caseRefNumber string) error {
	logger.Info(ctx, "CaseService|updateCaseBlockData|Request", logger.LogFields{"caseRefNumber": caseRefNumber, "updateRequest": update})
	isBlocked := true
	maxBlockedUntil, err := ca.caseBlockListRepo.GetMaxBlockedUntil(ctx, models.CaseBlockList{CaseRefNumber: caseRefNumber})
	if err != nil {
		return err
	}
	if update.Action == "UNBLOCK" {
		_, err := ca.caseBlockListRepo.Update(ctx, models.CaseBlockList{TicketRefNumber: update.TicketRefNumber}, models.CaseBlockList{ID: maxBlockedUntil.Id})
		if err != nil {
			return err
		}
		isBlocked = false
	} else if update.Action == "PERMANENT_BLOCK" {
		_, err := ca.caseBlockListRepo.Update(ctx, models.CaseBlockList{TicketRefNumber: update.TicketRefNumber, BlockedUntil: utils.StringToDate(constants.PERMANENT_CASE_BLOCKED_DATE)}, models.CaseBlockList{ID: maxBlockedUntil.Id})
		if err != nil {
			return err
		}
		isBlocked = true
	} else if update.Action == "SET_BLOCKING_DATE" {
		_, err := ca.caseBlockListRepo.Update(ctx, models.CaseBlockList{BlockedUntil: update.BlockedUntil, TicketRefNumber: update.TicketRefNumber}, models.CaseBlockList{ID: maxBlockedUntil.Id})
		if err != nil {
			return err
		}
		isBlocked = true
	} else {
		if !maxBlockedUntil.MaxBlockedUntil.After(time.Now()) {
			isBlocked = false
		}
	}
	updateData := make(map[string]interface{})
	updateData["IsBlocked"] = isBlocked
	if update.Action == "PERMANENT_BLOCK" {
		updateData["Status"] = enum.CASE_INACTIVE
	}
	logger.Info(ctx, "CaseService|updateCaseBlockData|updateData", logger.LogFields{"updateData": updateData, "caseRefNumber": caseRefNumber, "block_until": maxBlockedUntil.MaxBlockedUntil})
	updated := ca.caseRepo.UpdateWithMapInterface(ctx, updateData, models.Case{CaseRefNumber: caseRefNumber})
	if !updated {
		return errors.New("case blocked state not updated")
	}
	if isBlocked {
		logger.Info(ctx, "CaseService|updateCaseBlockData|CaseBlockedEvent", logger.LogFields{"caseRefNumber": caseRefNumber})
		adapter.PublishEvent(ctx, []string{constants.RMQ_COMMUNICATION_SERVICE_MAIN_QUEUE_KEY}, events.CaseBlocked{CaseRefNumber: caseRefNumber}, "case_blocked", nil)
	}
	if !isBlocked {
		logger.Info(ctx, "CaseService|updateCaseBlockData|CaseUnBlockedEvent", logger.LogFields{"caseRefNumber": caseRefNumber})
		adapter.PublishEvent(ctx, []string{constants.RMQ_COMMUNICATION_SERVICE_MAIN_QUEUE_KEY}, events.CaseUnBlocked{CaseRefNumber: caseRefNumber}, "case_unblocked", nil)
	}
	return nil
}

/*
Create Ticket: when case is blocked open a ticket
@author: Tejas Surve
*/
/*func (cb *CaseBlockService) createTicket(c *gin.Context, caseRefNumber string) error {

	err := cb.ticketService.CreateTicket(c, request.CreateTicket{CaseRefNumber: caseRefNumber, Status: enum.TICKET_ACTIVE})
	return err
}*/

func (cb *CaseBlockService) GetBlockListWithPagination(ctx context.Context, req request.CaseBlockList) response.BlockListData {
	logger.Info(ctx, "CaseBlock|GetBlockListWithPagination", logger.LogFields{"request": req})
	where := models.CaseBlockList{
		BlockedBy:           req.BlockedBy,
		CaseRefNumber:       req.CaseRefNumber,
		IsResolved:          req.IsResolved,
		BlockReasonMasterId: req.BlockReasonId,
	}

	if req.BlockSource != "" {
		source, _ := enum.StringToBlockSourceEnum(req.BlockSource)
		where.BlockSource = source
	}
	list, totalRecords, err := cb.caseBlockListRepo.GetBlockListWithPaginate(ctx, where, req.Page)

	listResponse := mapToBlockCaseListResponse(list)
	if err != nil || len(list) == 0 {
		listResponse = []response.CaseBlockList{}
	}

	return response.BlockListData{BlockList: listResponse, CurrentPage: req.Page, Pages: totalRecords}
}

/*Transform models.CaseBlockList model to response.CaseBlockList
@author Tejas Surve
*/

func mapCaseBlockListModelToResponse(model models.CaseBlockList) response.CaseBlockList {

	blockList := response.CaseBlockList{
		CaseRefNumber:        model.CaseRefNumber,
		BlockReasonMasterId:  model.BlockReasonMasterId,
		OriginalBlockedUntil: utils.FormatDateAsYmdhis(model.OriginalBlockedUntil),
		BlockedSource:        model.BlockReasonMaster.Source,
		BlockReason:          model.BlockReasonMaster.Reason,
		BlockedUntil:         utils.FormatDateAsYmdhis(model.BlockedUntil),
		BlockedAt:            utils.FormatDateAsYmdhis(model.BlockedAt),
		BlockedBy:            model.BlockedBy,
		BlockedByName:        model.BlockedByData.FirstName + " " + model.BlockedByData.FirstName,
		BlockedByRole:        model.BlockedByData.Role,
		BlockedByVisibility:  model.BlockedByData.Visibility,
		IsResolved:           model.IsResolved,
		TicketRefNumber:      model.TicketRefNumber,
		CreatedAt:            utils.FormatDateAsYmdhis(model.CreatedAt),
	}
	if model.Tickets != nil {
		issueName, subIssueName, _ := utils.GetIssueAndSubIssueName(model.Tickets.IssueId, model.Tickets.SubIssueId)
		blockList.Issue = issueName
		blockList.SubIssue = subIssueName
		blockList.Comment = model.Tickets.Comment
		blockList.ResolvedAt = utils.FormatDateAsYmdhis(model.Tickets.ClosedAt)
	}
	return blockList
}

/*
Map Ticket list model response to response struct
@author: Tejas Surve
*/
func mapToBlockCaseListResponse(blockListModel []models.CaseBlockList) []response.CaseBlockList {
	var blockList []response.CaseBlockList

	for i := range blockListModel {
		caseBlock := mapCaseBlockListModelToResponse(blockListModel[i])
		blockList = append(blockList, caseBlock)
	}

	return blockList
}

/*
Tranform to event stuct: Function to transform case block data to event struct
@Author: Tejas Surve
*/
func transformModelToCaseBlockEvent(caseBlockModel *models.CaseBlockList, createTicket bool) events.CaseBlocked {
	return events.CaseBlocked{
		CaseRefNumber:        caseBlockModel.CaseRefNumber,
		BlockReasonMasterId:  caseBlockModel.BlockReasonMasterId,
		OriginalBlockedUntil: caseBlockModel.OriginalBlockedUntil,
		BlockedUntil:         caseBlockModel.BlockedUntil,
		BlockedAt:            caseBlockModel.BlockedAt,
		BlockedBy:            caseBlockModel.BlockedBy,
		IsResolved:           caseBlockModel.IsResolved,
		TicketRefNumber:      caseBlockModel.TicketRefNumber,
		CreateTicket:         createTicket,
	}
}

/*
Get Case Block Reason Master
@return block_reason_master[]
@author Tejas Surve
*/
func (ca *CaseBlockService) GetBlockReasonMaster(ctx context.Context, req request.CaseBlockReason) response.BlockReasonListData {
	logger.Info(ctx, "CaseBlockService|GetBlockReasonMaster", logger.LogFields{"request": req})
	blockReason := response.BlockReasonListData{}
	if req.BlockSource != "" {
		req.BlockSourceList = strings.Split(req.BlockSource, ",")
	}
	blockReasonList := []response.BlockReasonList{}
	blockReasonMasterList, err := ca.blockReasonRepo.Get(ctx, models.BlockReasonMaster{
		ID: req.ID,
	}, req.BlockSourceList)
	if err != nil {
		logger.Error(ctx, err, "CaseBlockService|GetBlockReasonMaster", logger.LogFields{"request": ""})
		return blockReason
	}
	for _, model := range *blockReasonMasterList {
		reason := mapBlockReasonMasterModelToResponse(model)
		blockReasonList = append(blockReasonList, reason)
	}
	blockReason.BlockReasonMasterData = blockReasonList
	return blockReason
}

/*
- Case Unblock
- return error
- @author Tejas Surve
*/
func (ca *CaseBlockService) UnblockCase(ctx context.Context, caseRefNumber string) error {
	logger.Info(ctx, "CaseBlockService|UnblockCase|Input", logger.LogFields{"caseRefNumber": caseRefNumber})

	blocked_data, err := ca.caseBlockListRepo.GetMaxBlockedUntil(ctx, models.CaseBlockList{CaseRefNumber: caseRefNumber})
	if err != nil {
		logger.Error(ctx, err, "CaseBlockService|UnblockCase|GetMaxBlockedUntilErr", logger.LogFields{"case_ref_number": caseRefNumber})
	}
	if blocked_data.MaxBlockedUntil.Before(time.Now()) && blocked_data.IsResolved {
		caseUpdateData := make(map[string]interface{})
		caseUpdateData["IsBlocked"] = 0
		updated := ca.caseRepo.UpdateWithMapInterface(ctx, caseUpdateData, models.Case{CaseRefNumber: blocked_data.CaseRefNumber})
		if !updated {
			updateError := errors.New("not able unblock case")
			logger.Error(ctx, updateError, "CaseBlockService|UnblockCase|updateErr", logger.LogFields{"case_ref_number": caseRefNumber})
			return updateError
		}
		adapter.PublishEvent(ctx, []string{constants.RMQ_COMMUNICATION_SERVICE_MAIN_QUEUE_KEY}, events.CaseUnBlocked{CaseRefNumber: caseRefNumber}, "case_unblocked", nil)
	}
	return nil
}

/*Transform models.CaseBlockList model to response.CaseBlockList
@author Tejas Surve
*/

func mapBlockReasonMasterModelToResponse(model models.BlockReasonMaster) response.BlockReasonList {
	return response.BlockReasonList{
		ID:          model.ID,
		Source:      model.Source.String(),
		Reason:      model.Reason,
		Description: model.Description,
		CreatedAt:   utils.FormatDateAsYmdhis(model.CreatedAt),
	}
}
