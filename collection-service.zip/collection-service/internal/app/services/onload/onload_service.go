package onload

import (
	config "collection-service"
	"collection-service/common/logger"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/adapter/permify"
	"collection-service/internal/app/constants"
	permifyConstants "collection-service/internal/app/constants/permify"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"fmt"
	"strings"

	//"fmt"
	"reflect"
	"time"

	//"fmt"

	"github.com/spf13/viper"
)

type OnLoadService struct {
	services.BaseService
	cacheEnabled        bool
	awsImport           aws.S3Client
	clientRepo          repo_interfaces.IClientRepository
	serviceProviderRepo repo_interfaces.IServiceProviderRepository
}

func InitOnLoadService(ctx context.Context) *OnLoadService {
	service := &OnLoadService{
		cacheEnabled:        viper.GetBool("REDIS_ENABLED"),
		awsImport:           *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
		clientRepo:          repositories.InitClientRepository(ctx),
		serviceProviderRepo: repositories.InitServiceProviderRepository(ctx),
	}
	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}
	return service

}

func (u *OnLoadService) GetPostInfoForClientPanel(ctx context.Context) (response.PostLoginOnLoadResponse, error) {
	reasonsWithFileNames := config.AppConfig.Get("upload_reasons.client").([]interface{})
	redisOnLoadClientPanelKey := "api_onload_client_panel"

	var redisExpiry = 1 * time.Hour
	redisService := cacheservice.GetInstance()

	var reasons []response.UploadReason
	var reasonResponse response.PostLoginOnLoadResponse

	cacheResult, err := u.GetCacheInstance().Read(redisOnLoadClientPanelKey, "get")
	if err != nil {
		logger.Error(ctx, err, "Onload Service|GetPostInfoForClientPanel|ReadCacheErr", logger.LogFields{})
		return reasonResponse, err
	}
	if cacheResult == "" {
		for _, val := range reasonsWithFileNames {
			fileUrl, err := u.awsImport.GetSharableURL(ctx, val.(map[string]interface{})["file_name"].(string), constants.UPLOAD_SAMPLE_FILES_AWS_BUCKET)
			if err != nil {
				logger.Error(ctx, err, "Onload Service|mapToResponseList|GetSharableURLErr", logger.LogFields{"inputFilePath": val.(map[string]interface{})["file_name"].(string)})
				return reasonResponse, err
			}
			reasonEntry := &response.UploadReason{
				Reason:        val.(map[string]interface{})["reason"].(string),
				SampleFileURL: fileUrl,
			}
			reasons = append(reasons, *reasonEntry)
		}
		reasonResponse.UploadReasons = reasons

		result, err := json.Marshal(reasonResponse)
		if err != nil {
			return reasonResponse, err
		}

		ok, err := redisService.Create(redisOnLoadClientPanelKey, result, "set", redisExpiry)
		if !ok {
			return reasonResponse, nil
		}
		if err != nil {
			return reasonResponse, err
		}
		return reasonResponse, nil

	} else {
		err := json.Unmarshal([]byte(cacheResult), &reasonResponse)
		if err != nil {
			logger.Error(ctx, err, "Onload Service|GetPostInfoForClientPanel|UnmarshalCacheErr", logger.LogFields{})
			return reasonResponse, err
		}

		return reasonResponse, nil
	}
}
func (u *OnLoadService) GetPostInfoForServiceProviders(ctx context.Context) (response.PostLoginOnLoadResponse, error) {
	reasonsWithFileNames := config.AppConfig.Get("upload_reasons.service_provider").([]interface{})
	redisOnLoadServiceProviderKey := "api_onload_service_provider"

	var redisExpiry = 1 * time.Hour
	redisService := cacheservice.GetInstance()

	var reasons []response.UploadReason
	var reasonResponse response.PostLoginOnLoadResponse
	var cacheResult string
	var err error

	if u.cacheEnabled {
		cacheResult, err = u.GetCacheInstance().Read(redisOnLoadServiceProviderKey, "get")
		if err != nil {
			logger.Error(ctx, err, "Onload Service|GetPostInfoForServiceProviders|ReadCacheErr", logger.LogFields{})
			return reasonResponse, err
		}
	}

	if cacheResult == "" {
		for _, val := range reasonsWithFileNames {
			fileUrl, err := u.awsImport.GetSharableURL(ctx, val.(map[string]interface{})["file_name"].(string), constants.UPLOAD_SAMPLE_FILES_AWS_BUCKET)
			if err != nil {
				logger.Error(ctx, err, "Onload Service|mapToResponseList|GetSharableURLErr", logger.LogFields{"inputFilePath": val.(map[string]interface{})["file_name"].(string)})
				return reasonResponse, err
			}
			reasonEntry := &response.UploadReason{
				Reason:        val.(map[string]interface{})["reason"].(string),
				SampleFileURL: fileUrl,
			}
			reasons = append(reasons, *reasonEntry)
		}
		reasonResponse.UploadReasons = reasons

		result, err := json.Marshal(reasonResponse)
		if err != nil {
			return reasonResponse, err
		}

		ok, err := redisService.Create(redisOnLoadServiceProviderKey, result, "set", redisExpiry)
		if !ok {
			return reasonResponse, nil
		}
		if err != nil {
			return reasonResponse, err
		}
		return reasonResponse, nil

	} else {
		err := json.Unmarshal([]byte(cacheResult), &reasonResponse)
		if err != nil {
			logger.Error(ctx, err, "Onload Service|GetPostInfoForServiceProviders|UnmarshalCacheErr", logger.LogFields{})
			return reasonResponse, err
		}

		return reasonResponse, nil
	}

}
func (u *OnLoadService) getFromCache(redisKey string, responseInstance interface{}) (interface{}, error) {
	redisService := cacheservice.GetInstance()

	cacheResult, err := redisService.Read(redisKey, "get")
	if err != nil {
		return nil, err
	}

	// If not in cache
	if cacheResult == "" {
		return nil, nil
	}

	// Create a new instance of the response type dynamically
	responseValue := reflect.New(reflect.TypeOf(responseInstance)).Interface()

	err = json.Unmarshal([]byte(cacheResult), responseValue)
	if err != nil {
		return nil, err
	}

	return responseValue, nil
}

func (u *OnLoadService) GetPostInfoForCollectionPanel() (response.PostLogin, error) {
	postLoginInstance := response.PostLogin{
		FieldDispositionList: config.AppConfig.Get("disposition_config.field_dispositions").([]interface{}),
		CallDispositionList:  config.AppConfig.Get("disposition_config.calling_dispositions").([]interface{}),
		SupportedLanguages:   config.AppConfig.Get("product_config.languages_supported").([]interface{}),
		IssueList:            config.AppConfig.Get("issue_list").([]interface{}),
	}
	return postLoginInstance, nil
}

func (u *OnLoadService) GetPostLoginInfo(ctx context.Context, postLoginParams *request.PostLoginParams) (interface{}, error) {
	var res interface{}

	switch postLoginParams.AppName {
	case constants.COLLECTION_PANEL_NAME, constants.CALLING_PANEL_NAME, constants.CSAT_PANEL_NAME, constants.COLLECTION_APP_NAME, constants.FIELD_APP_NAME:
		res = getPostLoginInfoForCollectionPanel(ctx, u, postLoginParams)
	case constants.CLIENT_PANEL_NAME:
		res = getPostLoginInfoForClientPanel(ctx, u, postLoginParams)
	case constants.SERVICE_PROIVDER_PANEL_NAME:
		res = getPostLoginInfoForServiceProvider(ctx, u, postLoginParams)
	case constants.AUDIT_PANEL_NAME:
		res = getPostLoginInfoForAuditPanel(ctx, u, postLoginParams)
	}

	return res, nil
}

func getPostLoginInfoForServiceProvider(ctx context.Context, u *OnLoadService, postLoginParams *request.PostLoginParams) interface{} {
	res, err := u.GetPostInfoForServiceProviders(ctx)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for service provider panel", logger.LogFields{})
		utils.InternalServerError(ctx, err, "error while fetching post login info for service provider panel")
	}

	permissionsNode, permissionsGroupNode, err := fetchUserPermissionsFromPermify(ctx, u, postLoginParams)
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching permissions from permify")
	}
	res.Permissions = permissionsNode
	res.PermissionsGroup = permissionsGroupNode

	// unmarshal res in map
	var resMap map[string]interface{}
	resBytes, err := json.Marshal(res)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{})
		utils.InternalServerError(ctx, err, "error while marshalling post login info for client panel")
	}
	err = json.Unmarshal(resBytes, &resMap)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{})
		utils.InternalServerError(ctx, err, "error while unmarshalling post login info for client panel")
	}
	awsBucketURL := viper.GetString("AWS_DEV_BUCKET_URL")
	if postLoginParams.Object == enum.USER_CLIENT_USER {
		// get client data using client ref number
		clientRes, err := u.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: postLoginParams.ClientRefNumber})
		if err != nil {
			logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{"params": postLoginParams})
			utils.InternalServerError(ctx, err, "error while fetching client data for client panel")
		}
		url := awsBucketURL + clientRes.LogoUrl
		// add clientData node in map which is struct of two fields containing name and logo_url
		clientData := map[string]interface{}{
			"name":     clientRes.Name,
			"logo_url": url,
		}
		resMap["client"] = clientData
	} else {
		// get service provider data using service provider ref number
		serviceProviderRes, err := u.serviceProviderRepo.FindOne(ctx, models.ServiceProvider{ServiceProviderRefNumber: postLoginParams.ServiceProviderRefNumber})
		if err != nil {
			logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{"params": postLoginParams})
			utils.InternalServerError(ctx, err, "error while fetching service provider data for client panel")

		}
		url := awsBucketURL + serviceProviderRes.LogoUrl
		// add serviceProviderData node in map which is struct of two fields containing name and logo_url
		serviceProviderData := map[string]interface{}{
			"name":     serviceProviderRes.Name,
			"logo_url": url,
		}
		resMap["service_provider"] = serviceProviderData

	}

	return resMap

	return res
}

func getPostLoginInfoForAuditPanel(ctx context.Context, u *OnLoadService, postLoginParams *request.PostLoginParams) interface{} {
	res := response.PostLoginOnLoadResponse{}

	permissionsNode, permissionsGroupNode, err := fetchUserPermissionsFromPermify(ctx, u, postLoginParams)
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching permissions from permify")
	}
	res.Permissions = permissionsNode
	res.PermissionsGroup = permissionsGroupNode

	// unmarshal res in map
	var resMap map[string]interface{}
	resBytes, err := json.Marshal(res)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{})
		utils.InternalServerError(ctx, err, "error while marshalling post login info for client panel")
	}
	err = json.Unmarshal(resBytes, &resMap)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{})
		utils.InternalServerError(ctx, err, "error while unmarshalling post login info for client panel")
	}
	awsBucketURL := viper.GetString("AWS_DEV_BUCKET_URL")
	if postLoginParams.Object == enum.USER_CLIENT_USER {
		// get client data using client ref number
		clientRes, err := u.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: postLoginParams.ClientRefNumber})
		if err != nil {
			logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{"params": postLoginParams})
			utils.InternalServerError(ctx, err, "error while fetching client data for client panel")
		}
		url := awsBucketURL + clientRes.LogoUrl
		// add clientData node in map which is struct of two fields containing name and logo_url
		clientData := map[string]interface{}{
			"name":     clientRes.Name,
			"logo_url": url,
		}
		resMap["client"] = clientData
	} else {
		// get service provider data using service provider ref number
		serviceProviderRes, err := u.serviceProviderRepo.FindOne(ctx, models.ServiceProvider{ServiceProviderRefNumber: postLoginParams.ServiceProviderRefNumber})
		if err != nil {
			logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{"params": postLoginParams})
			utils.InternalServerError(ctx, err, "error while fetching service provider data for client panel")

		}
		url := awsBucketURL + serviceProviderRes.LogoUrl
		// add serviceProviderData node in map which is struct of two fields containing name and logo_url
		serviceProviderData := map[string]interface{}{
			"name":     serviceProviderRes.Name,
			"logo_url": url,
		}
		resMap["service_provider"] = serviceProviderData

	}

	return resMap
}

func getPostLoginInfoForClientPanel(ctx context.Context, u *OnLoadService, postLoginParams *request.PostLoginParams) interface{} {
	res, err := u.GetPostInfoForClientPanel(ctx)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{})
		utils.InternalServerError(ctx, err, "error while fetching post login info for client panel")
	}

	permissionsNode, permissionsGroupNode, err := fetchUserPermissionsFromPermify(ctx, u, postLoginParams)
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching permissions from permify")
	}
	res.Permissions = permissionsNode
	res.PermissionsGroup = permissionsGroupNode

	// unmarshal res in map
	var resMap map[string]interface{}
	resBytes, err := json.Marshal(res)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{})
		utils.InternalServerError(ctx, err, "error while marshalling post login info for client panel")
	}
	err = json.Unmarshal(resBytes, &resMap)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{})
		utils.InternalServerError(ctx, err, "error while unmarshalling post login info for client panel")
	}
	awsBucketURL := viper.GetString("AWS_DEV_BUCKET_URL")
	if postLoginParams.Object == enum.USER_CLIENT_USER {
		// get client data using client ref number
		clientRes, err := u.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: postLoginParams.ClientRefNumber})
		if err != nil {
			logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{"params": postLoginParams})
			utils.InternalServerError(ctx, err, "error while fetching client data for client panel")
		}
		url := awsBucketURL + clientRes.LogoUrl
		// add clientData node in map which is struct of two fields containing name and logo_url
		clientData := map[string]interface{}{
			"name":     clientRes.Name,
			"logo_url": url,
		}
		resMap["client"] = clientData
	} else {
		// get service provider data using service provider ref number
		serviceProviderRes, err := u.serviceProviderRepo.FindOne(ctx, models.ServiceProvider{ServiceProviderRefNumber: postLoginParams.ServiceProviderRefNumber})
		if err != nil {
			logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for client panel", logger.LogFields{"params": postLoginParams})
			utils.InternalServerError(ctx, err, "error while fetching service provider data for client panel")

		}
		url := awsBucketURL + serviceProviderRes.LogoUrl
		// add serviceProviderData node in map which is struct of two fields containing name and logo_url
		serviceProviderData := map[string]interface{}{
			"name":     serviceProviderRes.Name,
			"logo_url": url,
		}
		resMap["service_provider"] = serviceProviderData

	}

	return resMap
}

func getPostLoginInfoForCollectionPanel(ctx context.Context, u *OnLoadService, postLoginParams *request.PostLoginParams) *response.PostLogin {
	postLoginCollectionPanelResp, err := u.GetPostInfoForCollectionPanel()
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for collection panel", logger.LogFields{"params": postLoginParams})
		utils.InternalServerError(ctx, err, "error while fetching post login info for collection panel")
	}

	permissionsNode, permissionsGroupNode, err := fetchUserPermissionsFromPermify(ctx, u, postLoginParams)
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching permissions from permify")
	}
	postLoginCollectionPanelResp.Permissions = permissionsNode
	postLoginCollectionPanelResp.PermissionsGroup = permissionsGroupNode

	awsBucketURL := viper.GetString("AWS_DEV_BUCKET_URL")

	if postLoginParams.Object == enum.USER_CLIENT_USER {
		// get client data using client ref number
		clientRes, err := u.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: postLoginParams.ClientRefNumber})
		if err != nil {
			logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for collection panel", logger.LogFields{"params": postLoginParams})
			utils.InternalServerError(ctx, err, "error while fetching client data for collection panel")
		}
		url := awsBucketURL + clientRes.LogoUrl
		// add clientData node in map which is struct of two fields containing name and logo_url
		postLoginCollectionPanelResp.Client = response.Data{
			Name:    clientRes.Name,
			LogoURL: url,
		}
	} else {
		// get service provider data using service provider ref number
		serviceProviderRes, err := u.serviceProviderRepo.FindOne(ctx, models.ServiceProvider{ServiceProviderRefNumber: postLoginParams.ServiceProviderRefNumber})
		if err != nil {
			logger.Error(ctx, err, "OnLoadService|GetPostLoginInfo for collection panel", logger.LogFields{"params": postLoginParams})
			utils.InternalServerError(ctx, err, "error while fetching service provider data for collection panel")

		}
		url := awsBucketURL + serviceProviderRes.LogoUrl
		// add serviceProviderData node in map which is struct of two fields containing name and logo_url
		postLoginCollectionPanelResp.ServiceProvider = response.Data{
			Name:    serviceProviderRes.Name,
			LogoURL: url,
		}
	}

	return &postLoginCollectionPanelResp
}

func fetchUserPermissionsFromPermify(ctx context.Context, u *OnLoadService, params *request.PostLoginParams) (map[string]interface{}, map[string]interface{}, error) {

	var entityTuple *permify.EntityTuple
	if params.Object == enum.USER_AGENT {
		entityTuple = &permify.EntityTuple{
			EntityType: "sp",
			EntityId:   params.ServiceProviderRefNumber,
		}
	} else if params.Object == enum.USER_CLIENT_USER {
		entityTuple = &permify.EntityTuple{
			EntityType: "client",
			EntityId:   params.ClientRefNumber,
		}
	}

	if entityTuple == nil || params.ObjectRefNumber == "" {
		err := fmt.Errorf("entity details not found in params")
		logger.Error(ctx, err, "OnLoadService|fetchUserPermissionsFromPermify", logger.LogFields{"params": params})
		return nil, nil, err
	}

	subjectTuple := permify.SubjectTuple{
		SubjectType: "user",
		SubjectId:   params.ObjectRefNumber,
	}

	permissionsGroupNode := make(map[string]interface{})
	permissionsNode := make(map[string]interface{})

	permissionsList, err := permify.GetPermifyClientInstance(ctx).GetPermissionsList(ctx, *entityTuple, subjectTuple, true)
	if err != nil {
		logger.Error(ctx, err, "OnLoadService|fetchUserPermissionsFromPermify unable to get permissions from permify", logger.LogFields{"params": params})
		return nil, nil, err
	}

	permissionPrefix := getPermissionPrefixBasedOnAppName(ctx, params.AppName)
	for permissionsKey, value := range permissionsList {
		if !strings.HasPrefix(permissionsKey, permissionPrefix) {
			continue
		}

		permissionSlice := strings.Split(permissionsKey, permifyConstants.PERMIFY_PERMISSIONS_DELIMITER)
		if len(permissionSlice) == 1 {
			permissionsGroupNode[permissionSlice[0]] = value
		} else if len(permissionSlice) == 2 {
			groupMap, ok := permissionsNode[permissionSlice[0]].(map[string]interface{})
			if !ok {
				permissionsNode[permissionSlice[0]] = make(map[string]interface{})
				groupMap = permissionsNode[permissionSlice[0]].(map[string]interface{})
			}
			groupMap[permissionSlice[1]] = value
			permissionsNode[permissionSlice[0]] = groupMap
		}
	}

	return permissionsNode, permissionsGroupNode, nil
}

func getPermissionPrefixBasedOnAppName(ctx context.Context, xApp string) string {
	switch xApp {
	case constants.CLIENT_PANEL_NAME:
		return permifyConstants.CLIENT_PANEL_PERMISSION_PREFIX
	case constants.COLLECTION_PANEL_NAME, constants.CALLING_PANEL_NAME:
		return permifyConstants.CALLING_PANEL_PERMISSION_PREFIX
	case constants.SERVICE_PROVIDER_PANEL_NAME:
		return permifyConstants.SERVICE_PROVIDER_PANEL_PERMISSION_PREFIX
	case constants.CSAT_PANEL_NAME:
		return permifyConstants.CSAT_PANEL_PERMISSION_PREFIX
	case constants.AUDIT_PANEL_NAME:
		return permifyConstants.AUDIT_PANEL_PERMISSION_PREFIX
	case constants.COLLECTION_APP_NAME:
		return permifyConstants.COLLECTION_APP_PERMISSION_PREFIX
	default:
		logger.Error(ctx, nil, "unknown x-app header for permission prefix", logger.LogFields{"xApp": xApp})
		return ""
	}
}
func (u *OnLoadService) GetLoadInfo(ctx context.Context) response.OnLoad {
	onLoadInstance := response.OnLoad{
		LoginMode:           config.AppConfig.GetStringSlice("product_config.login_mode"),
		SoftUpgradeVersion:  constants.SOFT_UPGRADE_VERSION,
		ForceUpgradeVersion: constants.FORCE_UPGRADE_VERSION,
	}
	return onLoadInstance
}
