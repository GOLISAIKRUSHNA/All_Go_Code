package onload

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IOnLoadService interface {
	services.IBaseService
	GetLoadInfo(ctx context.Context) response.OnLoad
	GetPostLoginInfo(ctx context.Context, postLoginParams *request.PostLoginParams) (interface{}, error)
}
