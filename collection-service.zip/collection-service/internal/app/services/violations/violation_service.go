package violations

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"

	"github.com/spf13/viper"
)

type ViolationService struct {
	services.BaseService
	violationRepo         repo_interfaces.IViolationsRepo
	blockReasonMasterRepo repo_interfaces.IBlockReasonMasterRepository
	cacheEnabled          bool
}

func InitViolationService(ctx context.Context, violationRepo repo_interfaces.IViolationsRepo) *ViolationService {
	service := &ViolationService{
		violationRepo:         violationRepo,
		blockReasonMasterRepo: repositories.InitBlockReasonRepository(ctx),
		cacheEnabled:          viper.GetBool("REDIS_ENABLED"),
	}
	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}
	return service
}

func (s *ViolationService) GetViolations(ctx context.Context, req request.GetViolationsReq) (*response.ViolationsRes, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	violations, err := s.violationRepo.GetViolations(ctx, req.ClientRefNumber, req.ID)
	if err != nil {
		return nil, err
	}
	violationsRes := transformViolationsModelResponse(violations)
	return violationsRes, nil
}

func transformViolationsModelResponse(violations []*models.Violations) *response.ViolationsRes {
	violationsRes := &response.ViolationsRes{}

	for _, violation := range violations {
		data := response.Violation{
			ID:             violation.ID,
			Violation:      violation.Violation,
			ViolationLevel: violation.ViolationLevel,
			IsCaseToBlock:  violation.IsCaseToBlock,
			CreatedAt:      violation.CreatedAt.Format("2006-01-02 15:04:05"),
		}
		violationsRes.Violations = append(violationsRes.Violations, data)
	}

	return violationsRes
}

func (s *ViolationService) CreateViolation(ctx context.Context, req request.ViolationReq) error {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	violationMap := transformRequestToViolationMap(req)
	violation, err := s.violationRepo.CreateViolation(ctx, violationMap)
	if err != nil {
		return err
	}
	if *req.IsCaseToBlock {
		blockReasonMap := transformRequestToBlockReasonMasterMap(req, violation.ID)
		s.blockReasonMasterRepo.Create(ctx, blockReasonMap)

	}

	return nil
}

func transformRequestToViolationMap(req request.ViolationReq) map[string]interface{} {
	violationMap := map[string]interface{}{
		"client_ref_number": req.ClientRefNumber,
		"violation":         req.Violation,
		"violation_level":   req.ViolationLevel,
		"is_case_to_block":  req.IsCaseToBlock,
		"created_by":        req.CreatedBy,
	}
	return violationMap
}

func (s *ViolationService) UpdateViolation(ctx context.Context, req request.UpdateViolationReq) error {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	// Check if the record exists
	violationRecord, err := s.violationRepo.GetViolationByID(ctx, req.ID)
	if err != nil {
		return err
	}
	if violationRecord.DeletedAt != nil {
		// Check if the record has been soft deleted
		utils.BadRequestException(ctx, "", "Bad Request: record doesn't exist", nil, nil)
	}

	violationMap := transformUpdateRequestToViolationMap(req)
	isUpdated, err := s.violationRepo.UpdateViolation(ctx, req.ID, violationMap)
	if err != nil {
		return err
	}
	if isUpdated {
		blockReason, findErr := s.blockReasonMasterRepo.FindOne(ctx, models.BlockReasonMaster{Source: enum.AUDIT, ViolationId: req.ID})
		if findErr != nil {
			return err
		}
		blockReasonMap := transformRequestToBlockReasonMasterUpdateMap(req)
		s.blockReasonMasterRepo.Update(ctx, blockReasonMap, models.BlockReasonMaster{ID: blockReason.ID})

		return nil
	}
	return err
}

func transformUpdateRequestToViolationMap(req request.UpdateViolationReq) map[string]interface{} {
	violationMap := map[string]interface{}{
		"client_ref_number": req.ClientRefNumber,
		"violation":         req.Violation,
		"violation_level":   req.ViolationLevel,
		"is_case_to_block":  req.IsCaseToBlock,
		"updated_by":        req.UpdatedBy,
	}
	return violationMap
}

func transformRequestToBlockReasonMasterMap(req request.ViolationReq, violationId int) map[string]interface{} {
	blockReasonMap := map[string]interface{}{
		"description":                   req.Violation,
		"source":                        enum.AUDIT,
		"is_manual_resolution_required": *req.IsCaseToBlock,
		"days_to_block":                 constants.PERMANENT_CASE_DAYS_TO_BLOCK,
		"reason":                        req.Violation,
		"violation_id":                  violationId,
	}
	return blockReasonMap
}

func transformRequestToBlockReasonMasterUpdateMap(req request.UpdateViolationReq) map[string]interface{} {
	daysToBlock := 0
	if *req.IsCaseToBlock == false {
		daysToBlock = constants.PERMANENT_CASE_DAYS_TO_BLOCK
	}
	blockReasonMap := map[string]interface{}{
		"description":                   req.Violation,
		"source":                        enum.AUDIT,
		"is_manual_resolution_required": *req.IsCaseToBlock,
		"days_to_block":                 daysToBlock,
		"reason":                        req.Violation,
	}
	return blockReasonMap
}

func (s *ViolationService) DeleteViolation(ctx context.Context, id int) error {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	// Check if the record exists and not exist throw bad request record does not exist
	violationRecord, err := s.violationRepo.GetViolationByID(ctx, id)
	if err != nil {
		return err
	}
	if violationRecord.DeletedAt != nil {
		utils.BadRequestException(ctx, "", "Bad Request: record doesn't exist", nil, nil)
	}

	_, err = s.violationRepo.DeleteViolation(ctx, models.Violations{ID: id})
	if err != nil {
		return err
	}
	return nil
}
