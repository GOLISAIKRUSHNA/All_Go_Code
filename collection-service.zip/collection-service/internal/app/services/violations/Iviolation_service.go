package violations

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IViolationService interface {
	services.IBaseService
	GetViolations(ctx context.Context, req request.GetViolationsReq) (*response.ViolationsRes, error)
	CreateViolation(ctx context.Context, req request.ViolationReq) error
	UpdateViolation(ctx context.Context, req request.UpdateViolationReq) error
	DeleteViolation(ctx context.Context, id int) error
}
