package attribute_service

import (
	"collection-service/internal/app/services"
	"context"
)

type IAttributeService interface {
	services.IBaseService
	PushAttributeEvent(ctx context.Context, caseRefNumber, specialOfferRefNumber, eventName string)
}
