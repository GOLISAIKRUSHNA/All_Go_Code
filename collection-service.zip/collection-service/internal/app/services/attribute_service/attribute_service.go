package attribute_service

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/spf13/viper"
)

type AttributeService struct {
	services.BaseService

	caseRepo           repo_interfaces.ICaseRepository
	customerRepo       repo_interfaces.ICustomerRepository
	customerInfoRepo   repo_interfaces.ICustomerInfoRepository
	loanRepo           repo_interfaces.ILoanRepository
	loanCollateralRepo repo_interfaces.ILoanCollateralRepository
	loanBorrowerRepo   repo_interfaces.ILoanBorrowerRepository
	userUrlsRepo       repo_interfaces.IUserUrlRepo
	caseAttributeRepo  repo_interfaces.ICaseAttributeRepository
	specialOfferRepo   repo_interfaces.ISpecialOfferRepository
	cacheEnabled       bool
}

func InitAttributeService(ctx context.Context) *AttributeService {
	service := &AttributeService{
		caseRepo:           repositories.InitCaseRepository(ctx),
		customerRepo:       repositories.InitCustomerRepository(ctx),
		customerInfoRepo:   repositories.InitCustomerInfoRepository(ctx),
		loanRepo:           repositories.InitLoanRepository(ctx),
		loanCollateralRepo: repositories.InitLoanCollateralRepository(ctx),
		loanBorrowerRepo:   repositories.InitLoanBorrowerRepository(ctx),
		userUrlsRepo:       repositories.InitUserURLRepo(ctx),
		caseAttributeRepo:  repositories.InitCaseAttributeRepository(ctx),
		specialOfferRepo:   repositories.InitSpecialOfferRepo(ctx),
		cacheEnabled:       viper.GetBool("REDIS_ENABLED"),
	}
	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}
	return service
}

func (s AttributeService) PushAttributeEvent(ctx context.Context, caseRefNumber, specialOfferRefNumber, eventName string) {
	// attribute specific to all events
	caseRes, err := s.caseRepo.GetCase(ctx, &models.Case{CaseRefNumber: caseRefNumber, Status: enum.CASE_ACTIVE})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	// Get Case Data using customerRefNumber
	payloadData := events.CaseAttributes{CaseRefNumber: caseRes.CaseRefNumber,
		LoanRefNumber:     &caseRes.LoanRefNumber,
		CustomerRefNumber: caseRes.CustomerRefNumber,
		ClientRefNumber:   &caseRes.ClientRefNumber,
		MaxDpd:            &caseRes.MaxDpd,
		Status:            &caseRes.Status,
		Product:           &caseRes.Product,
		CurrentDpd:        &caseRes.CurrentDpd,
		Bucket:            &caseRes.Bucket,
		TotalDue:          &caseRes.TotalDue,
		TotalPrincipalDue: &caseRes.TotalPrincipalDue,
		TotalInterestDue:  &caseRes.TotalInterestDue,
		TotalFeesDue:      &caseRes.TotalFeesDue,
		NoOfLoansDue:      &caseRes.NoOfLoansDue,
		NoOfEmisDue:       &caseRes.NoOfEmisDue,
		CaseCreatedAt:     &caseRes.CreatedAt,
	}

	switch eventName {
	case "case_created":
		updateCustomerAttributes(ctx, caseRes.CustomerRefNumber, s.customerRepo, &payloadData)
		updateCustomerInfoAttributes(ctx, caseRes.CustomerRefNumber, s.customerInfoRepo, &payloadData)
		updateCaseAttributes(ctx, caseRefNumber, s.caseAttributeRepo, &payloadData)
		updateActiveLoanAttributes(ctx, caseRes.CaseRefNumber, s.loanRepo, &payloadData)
		updateLoanCollateralAttributes(ctx, caseRes.LoanRefNumber, s.loanCollateralRepo, &payloadData)
		updateLoanBorrowerAttributes(ctx, caseRes.LoanRefNumber, s.loanBorrowerRepo, &payloadData)
		updateUserUrlsAttributes(ctx, caseRes.CaseRefNumber, s.userUrlsRepo, &payloadData)

	case "case_updated":
		updateCaseAttributes(ctx, caseRefNumber, s.caseAttributeRepo, &payloadData)
		updateActiveLoanAttributes(ctx, caseRes.CaseRefNumber, s.loanRepo, &payloadData)
		updateUserUrlsAttributes(ctx, caseRes.CaseRefNumber, s.userUrlsRepo, &payloadData)
	case "loan_updated":
		updateActiveLoanAttributes(ctx, caseRes.CaseRefNumber, s.loanRepo, &payloadData)
	case "special_offer_created":
		updateSpecialOfferAttributes(ctx, specialOfferRefNumber, s.specialOfferRepo, &payloadData)
	}
	fmt.Println("==============eventpublished", caseRes.CaseRefNumber)
	adapter.PublishEvent(ctx, []string{constants.RMQ_COMMON_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_SEGMENT_SERVICE_MAIN_QUEUE_KEY}, payloadData, "case_attribute", nil)

}

func updateCaseAttributes(ctx context.Context, caseRefNumber string, caseAttributeRepo repo_interfaces.ICaseAttributeRepository, caseAttributes *events.CaseAttributes) {
	// CaseAttribute data using caseRefNumber
	caseAttrRes, err := caseAttributeRepo.FindByReferenceNumberOne(ctx, models.CaseAttribute{CaseRefNumber: caseRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	caseAttributes.LastDisposition = &caseAttrRes.LastDisposition
	caseAttributes.LastDispositionDatetime = caseAttrRes.LastDispositionDatetime
	caseAttributes.LastDispositionFollowupDate = caseAttrRes.LastDispositionFollowupDate
}

func updateCustomerInfoAttributes(ctx context.Context, customerRefNumber string, customerInfoRepo repo_interfaces.ICustomerInfoRepository, caseAttributes *events.CaseAttributes) {
	// Get CustomerInfo Data using customerRefNumber
	customerInfoModel, err := customerInfoRepo.FindByReferenceNumberOne(ctx, models.CustomerInfo{CustomerRefNumber: customerRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	caseAttributes.EmploymentType = &customerInfoModel.EmploymentType
	caseAttributes.MonthlyIncome = &customerInfoModel.MonthlyIncome
	caseAttributes.CibilScore = &customerInfoModel.CibilScore
}

func updateCustomerAttributes(ctx context.Context, customerRefNumber string, customerRepo repo_interfaces.ICustomerRepository, caseAttributes *events.CaseAttributes) {
	// Get Customer Data using customerRefNumber
	customer, err := customerRepo.GetCustomer(ctx, &models.Customer{CustomerRefNumber: customerRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	caseAttributes.FirstName = &customer.FirstName
	caseAttributes.LastName = &customer.LastName
	caseAttributes.Email = &customer.Email
	caseAttributes.MobileNumber = &customer.MobileNumber
	caseAttributes.Gender = &customer.Gender
	caseAttributes.PreferredLanguage = &customer.PreferredLanguage
}

func updateActiveLoanAttributes(ctx context.Context, caseRefNumber string, loanRepo repo_interfaces.ILoanRepository, caseAttributes *events.CaseAttributes) {
	// Loan Data using customerRefNumber
	loanRes, err := loanRepo.GetLoan(ctx, &models.Loan{CaseRefNumber: caseRefNumber, Status: enum.LOAN_ACTIVE})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	var clientShortLink string
	if loanRes.PaymentLink != "" {
		clientShortLink, _ = generateShortURLCall(ctx, loanRes.PaymentLink, loanRes.ClientRefNumber)
	}

	caseAttributes.ClientLoanId = &loanRes.ClientLoanId
	caseAttributes.Tenure = &loanRes.Tenure
	caseAttributes.TenureType = &loanRes.TenureType
	caseAttributes.LoanAmount = &loanRes.LoanAmount
	caseAttributes.InterestRate = &loanRes.InterestRate
	caseAttributes.EmiAmount = &loanRes.EmiAmount
	caseAttributes.ActiveFinancierRefNumber = &loanRes.ActiveFinancierRefNumber
	caseAttributes.SecondaryFinancierRefNumber = &loanRes.SecondaryFinancierRefNumber
	caseAttributes.ActiveFinancierName = &loanRes.ActiveFinancier.Name
	caseAttributes.SecondaryFinancierName = &loanRes.SecondaryFinancier.Name
	caseAttributes.DisbursementDate = &loanRes.DisbursementDate
	caseAttributes.DueDate = &loanRes.DueDate
	caseAttributes.ClientShortLink = &clientShortLink
}

func updateLoanCollateralAttributes(ctx context.Context, loanRefNumber string, loanCollateralRepo repo_interfaces.ILoanCollateralRepository, caseAttributes *events.CaseAttributes) {
	// LoanCollateral data using customerRefNumber
	loanCollateralRes, err := loanCollateralRepo.FindByReferenceNumberOne(ctx, models.LoanCollateral{LoanRefNumber: loanRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	caseAttributes.LoanCollateralType = &loanCollateralRes.Type
	caseAttributes.LoanCollateralDescription = &loanCollateralRes.Description

}

func updateSpecialOfferAttributes(ctx context.Context, specialOfferRefNumber string, specialOfferRepo repo_interfaces.ISpecialOfferRepository, caseAttributes *events.CaseAttributes) {
	specialOfferModel, err := specialOfferRepo.Get(ctx, &models.SpecialOffer{SpecialOfferRefNumber: specialOfferRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	var specialOfferAttributes map[string]interface{}

	if specialOfferModel.Status == enum.OFFER_INACTIVE {
		switch specialOfferModel.OfferType {
		case enum.DUES_WAIVER:
			caseAttributes.DuesWaiverOffer = &specialOfferAttributes
		case enum.SETTLEMENT:
			caseAttributes.SettlementOffer = &specialOfferAttributes
		}
		return
	}

	specialOfferAttributes = make(map[string]interface{})
	specialOfferAttributes["start_datetime"] = specialOfferModel.StartDatetime.Format("2006-01-02 15:04:05")
	specialOfferAttributes["end_datetime"] = specialOfferModel.EndDatetime.Format("2006-01-02 15:04:05")

	specialOfferAttributes["waiver_type"] = specialOfferModel.WaiverType.String()
	specialOfferAttributes["waiver_value"] = specialOfferModel.WaiverValue

	caseAttributes.SettlementOffer = &specialOfferAttributes

}

func updateLoanBorrowerAttributes(ctx context.Context, loanRefNumber string, loanBorrowerRepo repo_interfaces.ILoanBorrowerRepository, caseAttributes *events.CaseAttributes) {
	// LoanBorrower join Customer data using loanRefNumber
	loanBorrowerRes, err := loanBorrowerRepo.FindByReferenceNumberOne(ctx, models.LoanBorrower{LoanRefNumber: loanRefNumber})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	// Loan Borrower
	coapplicantName := loanBorrowerRes.Customer.FirstName + " " + loanBorrowerRes.Customer.LastName
	caseAttributes.CoApplicantName = &coapplicantName
	caseAttributes.CoApplicantEmail = &loanBorrowerRes.Customer.Email
	caseAttributes.CoApplicantMobileNumber = &loanBorrowerRes.Customer.MobileNumber
	caseAttributes.CoApplicantRelation = &loanBorrowerRes.RelationWithPrimary

}

func updateUserUrlsAttributes(ctx context.Context, caseRefNumber string, userUrlsRepo repo_interfaces.IUserUrlRepo, caseAttributes *events.CaseAttributes) {
	// ClientUser Urls data using caseRefNumber
	userUrls, err := userUrlsRepo.FindUserURLWithUnexpiredShortUrl(ctx, &models.UserUrl{EntityRefNumber: caseRefNumber, Entity: enum.ENTITY_CASE, Reason: enum.REASON_CASE_PAYMENT})
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	caseAttributes.ShortLink = &userUrls.ShortURL

}

func generateShortURLCall(ctx context.Context, longURL string, clientRefNumber string) (string, time.Time) {
	statusCode, successResp, failureResp, success, err := service_calls.GenerateShortURL(ctx, request.CreateShortUrlReq{
		LongURL:         longURL,
		ClientRefNumber: clientRefNumber,
	})

	if !success {
		logger.Error(ctx, err, "encrypt call to short url service failed.",
			map[string]interface{}{
				"statusCode":  statusCode,
				"successResp": successResp,
				"failureResp": failureResp})
		if err == nil {
			err = errors.New("unable to generate short url")
		}
		utils.InternalServerError(ctx, err, "")
	}

	var encryptedResp response.CreateShortURLResp

	jsonBody, err := json.Marshal(successResp.Data)
	if err != nil {
		logger.Error(ctx, err, "error while marshalling short url response", logger.LogFields{
			"response": successResp,
		})
		utils.InternalServerError(ctx, err, "")
	}

	bindErr := json.Unmarshal(jsonBody, &encryptedResp)
	if bindErr != nil {
		err := errors.New("invalid short url response")
		logger.Error(ctx, err, "Invalid response received while generating short url from short url service",
			map[string]interface{}{"response": successResp, "err": bindErr})
		utils.InternalServerError(ctx, err, "")
	}

	return encryptedResp.ShortURL, encryptedResp.ExpiresAt
}
