package dialer

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IDialerService interface {
	services.IBaseService
	Click2Call(ctx context.Context, request request.Click2Call) (response.ClickToCallResponse, error)
}
