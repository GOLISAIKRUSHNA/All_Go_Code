package dialer

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/client"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"errors"
	"github.com/spf13/viper"
)

type DialerService struct {
	services.BaseService
	agentRepo        repo_interfaces.IAgentRepository
	customerContacts repo_interfaces.ICustomerContactRepository
	caseRepo         repo_interfaces.ICaseRepository
	clientService    client.IClientService
	cacheEnabled     bool
}

// Initialization of DialerService with respect to the interface IDialerService
func InitDialerService(ctx context.Context) *DialerService {
	service := &DialerService{
		agentRepo:        repositories.InitAgentRepository(ctx),
		customerContacts: repositories.InitCustomerContactRepository(ctx),
		cacheEnabled:     viper.GetBool("REDIS_ENABLED"),
		clientService:    client.InitClientService(ctx),
		caseRepo:         repositories.InitCaseRepository(ctx),
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (s DialerService) Click2Call(ctx context.Context, request request.Click2Call) (response.ClickToCallResponse, error) {
	filters := transformClick2CallRequestToAllocationModel(request)
	err := s.validateBeforeCall(ctx, request)
	if err != nil {
		utils.BadRequestException(ctx, constants.CALLS_NOT_ALLOWED, "calls not allowed:"+err.Error(), err, nil)
	}
	agentResponse, err := s.agentRepo.FindOne(ctx, &filters)
	if err != nil {
		logger.Error(ctx, err, "DialerService|Click2Call|s.allocationRepo.GetAllocationDetails", logger.LogFields{"payload": request, "error": err})
		utils.BadRequestException(ctx, constants.CASE_NOT_ALLOCATED, "case not allocated", errors.New("case not allocated"), nil)
	}
	where := models.CustomerContacts{ContactRefNumber: request.ContactRefNumber}
	customerContactResponse, err := s.customerContacts.FindOne(ctx, &where)
	if err != nil {
		return response.ClickToCallResponse{}, err
	}

	click2callResponse := transformClick2CallDialerRequest(agentResponse, customerContactResponse, request)
	statusCode, callData, errResponse, _, err := service_calls.MakeClickToCallToDialerService(ctx, click2callResponse)
	if err != nil {
		logger.Error(ctx, err, "DialerService|Click2Call|service_calls.MakeClickToCallToDialerService", logger.LogFields{"payload": request, "error": err})
		return response.ClickToCallResponse{}, err
	}
	if statusCode != 201 {
		logger.Error(ctx, err, "DialerService|Click2Call|service_calls.MakeClickToCallToDialerService", logger.LogFields{"payload": request, "error": err})
		utils.BadRequestException(ctx, constants.CALLS_NOT_ALLOWED, "call not allowed", errResponse, nil)
	}
	return s.mapCallResponse(ctx, callData), nil
}

func (d DialerService) validateBeforeCall(ctx context.Context, reqParams request.Click2Call) error {
	//Check Case & Get client ref number
	caseData, err := d.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: reqParams.CaseRefNumber})
	if err != nil {
		return err
	}
	clientConfig, err := d.clientService.GetClientConfig(ctx, caseData.ClientRefNumber, request.Config{})
	if err != nil {
		return err
	}
	if clientConfig.DailyCallsLimit <= caseData.CaseAttribute.TodaysCallsAttempted {
		return errors.New("daily call limit reached")
	}
	return nil
}

func transformClick2CallRequestToAllocationModel(request request.Click2Call) models.Agent {
	return models.Agent{
		AgentRefNumber: request.AgentRefNumber,
	}
}

func transformClick2CallDialerRequest(agent *models.Agent, customerContacts *models.CustomerContacts, requestBody request.Click2Call) request.DialerServiceClick2Call { //create new file outside response or
	response := request.DialerServiceClick2Call{
		CaseRefNumber:        requestBody.CaseRefNumber,
		CustomerRefNumber:    customerContacts.CustomerRefNumber,
		CustomerName:         customerContacts.ContactName,
		ContactRefNumber:     requestBody.ContactRefNumber,
		CustomerMobileNumber: customerContacts.ContactNumber,
		AgentRefNumber:       agent.AgentRefNumber,
		AgentName:            agent.FirstName + " " + agent.LastName,
		AgentMobileNumber:    agent.MobileNumber,
		BridgeCall:           requestBody.BridgeCall,
	}
	return response
}

func (s DialerService) mapCallResponse(ctx context.Context, successResp *dto.SuccessResponse) response.ClickToCallResponse {
	// Accessing deposit_summary from the SuccessResponse struct
	if successResp == nil {
		logger.Error(ctx, nil, "Failed to assert deposit_summary to map[string]interface{}", logger.LogFields{"data": successResp})
		return response.ClickToCallResponse{}
	}
	callData, ok := successResp.Data.(map[string]interface{})
	if !ok {
		logger.Error(ctx, nil, "Failed to assert deposit_summary to map[string]interface{}", logger.LogFields{"data": successResp})
	}

	return response.ClickToCallResponse{
		AttemptRefNumber: callData["attempt_ref_number"].(string),
		CaseRefNumber:    callData["case_ref_number"].(string),
		ContactRefNumber: callData["contact_ref_number"].(string),
		DialerRefNumber:  callData["dialer_ref_number"].(string),
		Status:           callData["status"].(string),
	}
}
