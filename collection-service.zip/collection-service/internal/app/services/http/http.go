package http

import (
	"bytes"
	"collection-service/internal/app/constants"
	"collection-service/internal/utils"
	"context"
	"encoding/base64"
	"io/ioutil"
	"net/http"
	"time"

	"github.com/spf13/viper"
	"go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp"
)

const DEFAULT_TIMEOUT time.Duration = 30

func SendPost(ctx context.Context, url string, body []byte) (int, []byte, error) {
	return SendPostRequest(ctx, url, nil, body, DEFAULT_TIMEOUT*time.Second)
}
func SendPostRequest(ctx context.Context, url string, headers map[string]string, body []byte, timeout time.Duration) (int, []byte, error) {
	var req *http.Request
	var err error

	req, err = http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewBuffer(body))
	if err != nil {
		return 0, nil, err
	}

	req.Close = true

	injectHeaders(ctx, req, headers)

	tr := http.DefaultTransport.(*http.Transport)

	client := &http.Client{Timeout: timeout, Transport: otelhttp.NewTransport(tr)}

	resp, err := client.Do(req)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()

	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return 0, nil, err
	}

	/*utilities.DebugGLog(gN, "%s", string(b))*/
	return resp.StatusCode, b, nil
}

func SendGet(ctx context.Context, url string, params map[string]string) (int, []byte, error) {
	return SendGetRequest(ctx, url, nil, params, DEFAULT_TIMEOUT*time.Second)
}
func SendGetRequest(ctx context.Context, url string, headers map[string]string, params map[string]string, timeout time.Duration) (int, []byte, error) {
	var req *http.Request
	var err error

	req, err = http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return 0, nil, err
	}

	req.Close = true

	// add query params
	q := req.URL.Query()
	for k, v := range params {
		q.Add(k, v)
	}
	req.URL.RawQuery = q.Encode()

	injectHeaders(ctx, req, headers)

	tr := http.DefaultTransport.(*http.Transport)

	client := &http.Client{Timeout: timeout, Transport: otelhttp.NewTransport(tr)}

	resp, err := client.Do(req)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()

	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return 0, nil, err
	}

	/*utilities.DebugGLog(gN, "%s", string(b))*/
	return resp.StatusCode, b, nil
}

func SendPatch(ctx context.Context, url string, body []byte) (int, []byte, error) {
	return SendPatchRequest(ctx, url, nil, body, DEFAULT_TIMEOUT*time.Second)
}
func SendPatchRequest(ctx context.Context, url string, headers map[string]string, body []byte, timeout time.Duration) (int, []byte, error) {
	var req *http.Request
	var err error

	req, err = http.NewRequestWithContext(ctx, http.MethodPatch, url, bytes.NewBuffer(body))
	if err != nil {
		return 0, nil, err
	}

	req.Close = true

	injectHeaders(ctx, req, headers)

	tr := http.DefaultTransport.(*http.Transport)

	client := &http.Client{Timeout: timeout, Transport: otelhttp.NewTransport(tr)}

	resp, err := client.Do(req)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()

	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return 0, nil, err
	}

	/*utilities.DebugGLog(gN, "%s", string(b))*/
	return resp.StatusCode, b, nil
}

func SendPut(ctx context.Context, url string, body []byte) (int, []byte, error) {
	return SendPutRequest(ctx, url, nil, body, DEFAULT_TIMEOUT*time.Second)
}
func SendPutRequest(ctx context.Context, url string, headers map[string]string, body []byte, timeout time.Duration) (int, []byte, error) {
	var req *http.Request
	var err error

	req, err = http.NewRequestWithContext(ctx, http.MethodPut, url, bytes.NewBuffer(body))
	if err != nil {
		return 0, nil, err
	}

	req.Close = true

	injectHeaders(ctx, req, headers)

	tr := http.DefaultTransport.(*http.Transport)

	client := &http.Client{Timeout: timeout, Transport: otelhttp.NewTransport(tr)}

	resp, err := client.Do(req)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()

	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return 0, nil, err
	}

	/*utilities.DebugGLog(gN, "%s", string(b))*/
	return resp.StatusCode, b, nil
}

func SendDelete(ctx context.Context, url string) (int, []byte, error) {
	return SendDeleteRequest(ctx, url, nil, DEFAULT_TIMEOUT*time.Second)
}
func SendDeleteRequest(ctx context.Context, url string, headers map[string]string, timeout time.Duration) (int, []byte, error) {
	var req *http.Request
	var err error

	req, err = http.NewRequestWithContext(ctx, http.MethodDelete, url, nil)
	if err != nil {
		return 0, nil, err
	}

	req.Close = true

	injectHeaders(ctx, req, headers)

	tr := http.DefaultTransport.(*http.Transport)

	client := &http.Client{Timeout: timeout, Transport: otelhttp.NewTransport(tr)}

	resp, err := client.Do(req)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()

	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return 0, nil, err
	}

	/*utilities.DebugGLog(gN, "%s", string(b))*/
	return resp.StatusCode, b, nil
}

func injectHeaders(ctx context.Context, req *http.Request, headers map[string]string) {
	var xApp, xAppVersion string
	reqInfo := utils.GetRequestInfoFromCtx(ctx)
	if reqInfo != nil {
		xApp = reqInfo.App
		xAppVersion = reqInfo.AppVersion
	}

	req.Header.Set(constants.CONTENT_TYPE, constants.APPLICATION_JSON)
	req.Header.Set(constants.X_APP, xApp)
	req.Header.Set(constants.X_APP_VERSION, xAppVersion)
	req.Header.Set(constants.X_REFERER, viper.GetString("SERVICE_NAME"))

	for k, v := range headers {
		req.Header.Set(k, v)
	}
}

func BasicAuth(username, password string) string {
	auth := username + ":" + password
	return "Basic " + base64.StdEncoding.EncodeToString([]byte(auth))
}
