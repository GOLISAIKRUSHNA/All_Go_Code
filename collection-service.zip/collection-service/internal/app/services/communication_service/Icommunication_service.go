package communication_service

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/response"
	"context"
)

type ICommunicationService interface {
	services.IBaseService
	GetCaseAllocationDetails(ctx context.Context, caseRefNumber string) (*response.GetCaseAllocationDetailsRes, error)
}
