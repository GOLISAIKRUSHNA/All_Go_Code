package communication_service

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"context"
)

type CommunicationService struct {
	services.BaseService
	caseRepo       repo_interfaces.ICaseRepository
	allocationRepo repo_interfaces.IAllocationRepository
	cacheEnabled   bool
}

func InitCommunicationService(ctx context.Context, caseRepo repo_interfaces.ICaseRepository, allocationRepo repo_interfaces.IAllocationRepository, cacheEnabled bool) *CommunicationService {
	service := &CommunicationService{caseRepo: caseRepo, allocationRepo: allocationRepo, cacheEnabled: cacheEnabled}
	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}
	return service
}

func (s *CommunicationService) GetCaseAllocationDetails(ctx context.Context, caseRefNumber string) (*response.GetCaseAllocationDetailsRes, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	// query in case table
	caseFilter := models.Case{CaseRefNumber: caseRefNumber}

	caseData, err := s.caseRepo.GetCase(ctx, &caseFilter)
	if err != nil {
		return nil, err
	}

	res := transformCaseToResponse(caseData)
	return res, nil
}

func transformCaseToResponse(caseModel *models.Case) *response.GetCaseAllocationDetailsRes {
	var allocatedTo []response.AllocatedTo
	data := &response.GetCaseAllocationDetailsRes{
		CaseRefNumber:     caseModel.CaseRefNumber,
		CustomerRefNumber: caseModel.CustomerRefNumber,
		ClientRefNumber:   caseModel.ClientRefNumber,
	}

	// loop through the allocations and get the allocated to
	for _, allocation := range caseModel.AllocationInfo {
		allocatedTo = append(allocatedTo, response.AllocatedTo{
			AgentRefNumber:           allocation.AgentRefNumber,
			ServiceProviderRefNumber: allocation.ServiceProviderRefNumber,
			Intervention:             allocation.Intervention,
		})
	}

	data.AllocatedTo = allocatedTo
	return data
}
