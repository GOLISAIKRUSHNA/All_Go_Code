package sqlservice

import "gorm.io/gorm"

// This interface is a dna to make all the Database class
type ISqlService interface {
	Close() error
	GetConnection() *gorm.DB
}
