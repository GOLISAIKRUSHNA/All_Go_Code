package sqlservice

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/utils"
	"context"
	"fmt"

	"github.com/spf13/viper"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	gorm_logger "gorm.io/gorm/logger"
)

type MysqlStore struct {
	ctx    context.Context
	client *gorm.DB
}

type MysqlType struct {
	read  *MysqlStore
	write *MysqlStore
}

type SqlCredentials struct {
	Host     string
	Port     string
	Username string
	Password string
	Database string
	SSLMode  bool
}

var instance = MysqlType{}

func GetInstance() MysqlType {
	return instance
}

func GetReadInstance() *MysqlStore {
	return instance.read
}

func GetWriteInstance() *MysqlStore {
	return instance.write
}

func GetMysqlClient(c context.Context, db_type constants.DatabaseType, opt *SqlCredentials) *MysqlStore {
	// Checking if client_user has been provided with credentials or not
	// If credentials are not provided then it get credentials from .env file
	if utils.IsEmptyStruct(opt) {
		db_type_str := string(db_type)
		opt = &SqlCredentials{
			Host:     viper.GetString(db_type_str + "_MYSQL_DB_HOST"),
			Port:     viper.GetString(db_type_str + "_MYSQL_DB_PORT"),
			Username: viper.GetString(db_type_str + "_MYSQL_DB_USERNAME"),
			Password: viper.GetString(db_type_str + "_MYSQL_DB_PASSWORD"),
			SSLMode:  viper.GetBool(db_type_str + "_MYSQL_DB_SSL"),
			Database: viper.GetString("MYSQL_DB_DATABASE"),
		}
	}

	// Mysql connection string is getting created from the credentials provided
	mysql_conn_string := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=True&loc=Local", opt.Username, opt.Password, opt.Host, opt.Port, opt.Database)

	// Opening a new mysql connection
	db, err := gorm.Open(mysql.Open(mysql_conn_string), &gorm.Config{Logger: gorm_logger.Default.LogMode(gorm_logger.Info), TranslateError: true})
	if err != nil {
		logger.Error(c, err, "Error opening mysql connection", nil)
		panic("Mysql failed to open/connect to the database")
	}

	// Returning the MysqlStore Instance which will be fully compatible with SqlInterface
	mysqlStore := &MysqlStore{
		ctx:    c,
		client: db,
	}
	switch db_type {
	case constants.READ_DATABASE_TYPE:
		instance.read = mysqlStore
	case constants.WRITE_DATABASE_TYPE:
		instance.write = mysqlStore
	default:
		panic("unsupported database type")
	}

	return mysqlStore
}

func (ms MysqlStore) Close() error {
	db, err := ms.client.DB()
	if err != nil {
		return err
	}
	err = db.Close()
	return err
}

func (ms *MysqlStore) GetConnection() *gorm.DB {
	if ms.client == nil {
		panic("MySql connection not created")
	}
	return ms.client
}
