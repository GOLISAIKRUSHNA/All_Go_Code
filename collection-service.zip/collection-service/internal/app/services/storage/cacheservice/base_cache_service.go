package cacheservice

import (
	"collection-service/internal/utils"
	"context"
	"errors"
	"strings"
	"time"
	"github.com/spf13/viper"
)

type BaseCacheService struct {
	cache               ICacheService
	main_key            string
	ctx                 context.Context
	expiration_duration time.Duration
}

var instance *BaseCacheService

type CacheCredentials struct {
	Host     string
	Tls      bool
	Username string
	Password string
	PoolSize int
	Database int
	Key      string
}

func GetInstance() *BaseCacheService {
	return instance
}

func GetNewCacheService(ctx context.Context, opt *CacheCredentials) *BaseCacheService {

	if utils.IsEmptyStruct(opt) {
		opt = &CacheCredentials{
			Host:     viper.GetString("REDIS_HOST"),
			Tls:      viper.GetBool("REDIS_TLS"),
			Username: viper.GetString("REDIS_USERNAME"),
			Password: viper.GetString("REDIS_PASSWORD"),
			PoolSize: viper.GetInt("REDIS_POOLSIZE"),
			Database: viper.GetInt("REDIS_DATABASE"),
			Key:      viper.GetString("REDIS_KEY"),
		}
	}

	// Establish Redis Connection
	rdstore := getRedisClient(ctx, opt)

	instance = &BaseCacheService{
		cache:    rdstore,
		main_key: opt.Key,
	}

	return instance
}

func (kvs BaseCacheService) SetMainKey(mainKey string) {
	kvs.main_key = mainKey
}

func (kvs BaseCacheService) SetKeySuffix(suffix string) BaseCacheService {
	kvs.main_key = kvs.main_key + ":" + suffix
	return kvs
}

func (kvs BaseCacheService) SetContext(ctx context.Context) BaseCacheService {
	instance.ctx = ctx
	return *instance
}

func (kvs BaseCacheService) SetExpiration(expiration_duration time.Duration) BaseCacheService {
	instance.expiration_duration = expiration_duration
	return *instance
}

func (kvs BaseCacheService) Read(key string, cache_type string) (string, error) {
	switch strings.ToLower(cache_type) {
	case "hash":
		return kvs.cache.HashGet(kvs.ctx, "", key)

	case "get":
		return kvs.cache.JSONGet(kvs.ctx,key)

	default:
		return "", errors.New("given key value type not supported, only supports hash, set")
	}
}

func (kvs BaseCacheService) Create(key string, value interface{}, cache_type string, timeOut time.Duration) (bool, error) {
	if timeOut == 0 {
		timeOut = kvs.expiration_duration
	}

	switch strings.ToLower(cache_type) {
	case "hash":
		_, err := kvs.cache.HashSet(kvs.ctx,"", key, value)
		if err != nil {
			return false, err
		}
	case "set":
		_, err := kvs.cache.JSONSet(kvs.ctx,key, value, timeOut)
		if err != nil {
			return false, err
		}
	default:
		return false, errors.New("given save type not supported, only supports hash, set")
	}

	return true, nil
}

func (kvs BaseCacheService) Update(key string, value interface{}, cache_type string) (bool, error) {
	switch strings.ToLower(cache_type) {
	case "hash":
		_, err := kvs.cache.HashSet(kvs.ctx, kvs.main_key, key, value)
		if err != nil {
			return false, err
		}
	case "set":
		_, err := kvs.cache.JSONSet(kvs.ctx, kvs.main_key+":"+key, value, kvs.expiration_duration)
		if err != nil {
			return false, err
		}
	default:
		return false, errors.New("given save type not supported, only supports hash, set")
	}

	return true, nil
}

func (kvs BaseCacheService) Delete(key string, cache_type string) error {
	switch strings.ToLower(cache_type) {
	case "hash":
		return kvs.cache.HashDelete(kvs.ctx, kvs.main_key, key)
	case "delete":
		return kvs.cache.JSONDelete(kvs.ctx,key)

	default:
		return errors.New("given save type not supported, only supports hash, set")
	}
}

func (kvs BaseCacheService) DeleteAll(cache_type string) error {
	switch strings.ToLower(cache_type) {
	case "hash":
		keys := kvs.cache.HsetKeys(kvs.ctx, kvs.main_key)
		return kvs.cache.HashDelete(kvs.ctx, kvs.main_key, keys...)
	case "set":
		keys := kvs.cache.JsonKeys(kvs.ctx, kvs.main_key)
		return kvs.cache.JSONDelete(kvs.ctx, keys...)

	default:
		return errors.New("given save type not supported, only supports hash, set")
	}
}

func (kvs BaseCacheService) DeleteKeysWithPrefix(keys ...string) error {
	for _, key := range keys {
		if err := kvs.cache.ScanAndDelete(kvs.ctx, key); err != nil {
			return err
		}
	}
	return nil
}

func (kv BaseCacheService) Close() (bool, error) {
	return kv.cache.Close()
}





