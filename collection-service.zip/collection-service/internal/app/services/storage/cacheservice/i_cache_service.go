package cacheservice

import (
	"context"

	"time"

	"github.com/redis/go-redis/v9"
)

type ICacheService interface {
	Exist(ctx context.Context, key string) (bool, error)
	JSONSet(ctx context.Context, key string, value interface{}, expiratin_time time.Duration) (interface{}, error)
	JSONGet(ctx context.Context, key string) (string, error)
	HashSet(ctx context.Context, key string, field string, value interface{}) (int64, error)
	HashGet(ctx context.Context, key string, field string) (string, error)
	JSONSetPipe(ctx context.Context, pipe redis.Pipeliner, key string, path string, value interface{}) (*redis.Cmd, error)
	HSetPipe(ctx context.Context, pipe redis.Pipeliner, key string, field string, value interface{}) (*redis.Cmd, error)
	ExecPipe(ctx context.Context, pipe redis.Pipeliner) ([]redis.Cmder, error)
	GetPipeline() (redis.Pipeliner, error)
	GetTxPipeline() (redis.Pipeliner, error)
	JSONDelete(ctx context.Context, key ...string) error
	HashDelete(ctx context.Context, key string, fields ...string) error
	JsonKeys(ctx context.Context, key string) []string
	HsetKeys(ctx context.Context, key string) []string
	ScanAndDelete(ctx context.Context,substr string) error
	Close() (bool, error)
}
