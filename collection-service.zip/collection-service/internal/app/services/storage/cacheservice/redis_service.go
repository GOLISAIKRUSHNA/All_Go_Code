package cacheservice

import (
	"collection-service/common/logger"
	"context"
	"crypto/tls"
	"fmt"
	"strings"
	"time"
	"github.com/redis/go-redis/v9"
)

// RedisStore is a wrapper struct that provide wrapper over redis command
type redisStore struct {
	//go-redis client_user used to interact with redis cluster
	rdb redis.UniversalClient
}

// NewRedisClient initialize and return a new RedisStore
func getRedisClient(ctx context.Context, opt *CacheCredentials) ICacheService {
	clusterOpt := &redis.UniversalOptions{
		Addrs:    strings.Split(opt.Host, ","),
		Username: opt.Username,
		Password: opt.Password,
		PoolSize: opt.PoolSize,
		DB:       opt.Database,
	}

	tlsVal := opt.Tls

	if bool(tlsVal) {
		clusterOpt.TLSConfig = &tls.Config{
			MinVersion:         tls.VersionTLS12,
			InsecureSkipVerify: true,
		}
	}
	clusterConn := redis.NewUniversalClient(clusterOpt)
	// redistrace.WrapClient(clusterConn, redistrace.WithServiceName(os.Getenv("SERVICE_NAME")))
	//defer clusterConn.Close()
	_, err := clusterConn.Ping(ctx).Result()
	if err != nil {
		panic(err)
	}

	return &redisStore{
		rdb: clusterConn,
	}

}

// HsetKeys implements ICacheService.
func (c *redisStore) HsetKeys(ctx context.Context, key string) []string {
	keys, err := c.rdb.Keys(ctx, key+":*").Result()

	if err != nil {
		panic(err)
	}

	if len(keys) > 0 {
		return keys
	}
	return nil
}

// JsonKeys implements ICacheService.
func (c *redisStore) JsonKeys(ctx context.Context, key string) []string {
	keys, err := c.rdb.Keys(ctx, key+":*").Result()

	if err != nil {
		panic(err)
	}

	if len(keys) > 0 {
		return keys
	}
	return nil
}

// Exist is a wrapper over redis.Exists command
func (c redisStore) Exist(ctx context.Context, key string) (bool, error) {
	i, err := c.rdb.Exists(ctx, key).Result()
	return i >= 1, err
}

// JSONSet is a wrapper over JSON.SET command
func (c redisStore) JSONSet(ctx context.Context, key string, value interface{}, expiratin_time time.Duration) (interface{}, error) {
	return c.rdb.Set(ctx, key, value, expiratin_time).Result()
}

// JSONGet is a wrapper over JSON.GET command
func (c redisStore) JSONGet(ctx context.Context, key string) (string, error) {
	cmd := c.rdb.Get(ctx, key)
	err := cmd.Err()
	switch {
	case err == redis.Nil:
		return "", nil
	case err != nil:
		return "", err
	default:
		return fmt.Sprintf("%v", cmd.Val()), nil
	}
}

// HashSet is a wrapper over HSet command
func (c redisStore) HashSet(ctx context.Context, key string, field string, value interface{}) (int64, error) {
	data, err := c.rdb.HSet(ctx, key, field, value).Result()
	return data, err
}

// HashGet is a wrapper over HGet command
func (c redisStore) HashGet(ctx context.Context, key string, field string) (string, error) {

	val, err := c.rdb.HGet(ctx, key, field).Result()
	switch {
	case err == redis.Nil:
		logger.Debug(ctx, fmt.Sprintf("Redis Key or field is absent - %s - %s", key, field), nil)
		return "", nil
	case err != nil:
		return "", err
	default:
		return val, nil
	}
}

// JSONSetPipe is a wrapper to add a JSON.SET command to an existing redis.pipeline
func (c redisStore) JSONSetPipe(ctx context.Context, pipe redis.Pipeliner, key string, path string, value interface{}) (*redis.Cmd, error) {
	switch v := value.(type) {
	case string:
		value = fmt.Sprintf("\"%v\"", value)
	case float64:
		fmt.Println(key, value, v)
	}
	return pipe.Do(ctx, "JSON.SET", key, path, value), nil
}

// HSetPipe is a wrapper to add a HSET command to an existing redis.pipeline
func (c redisStore) HSetPipe(ctx context.Context, pipe redis.Pipeliner, key string, field string, value interface{}) (*redis.Cmd, error) {
	return pipe.Do(ctx, "HSET", key, field, value), nil
}

// ExecPipe is wrapper function that execute the given redis.Pipeline
func (c redisStore) ExecPipe(ctx context.Context, pipe redis.Pipeliner) ([]redis.Cmder, error) {
	return pipe.Exec(ctx)
}

// GetPipeline is wrapper function that return new redis.Pipeline
func (c redisStore) GetPipeline() (redis.Pipeliner, error) {
	return c.rdb.Pipeline(), nil
}

// GetTxPipeline is wrapper function that return new redis.Pipeline with transaction support
func (c redisStore) GetTxPipeline() (redis.Pipeliner, error) {
	return c.rdb.TxPipeline(), nil
}

func (c redisStore) HashDelete(ctx context.Context, key string, fields ...string) error {
	cmd := c.rdb.HDel(ctx, key, fields...)
	err := cmd.Err()
	switch {
	case err == redis.Nil:
		return nil
	case err != nil:
		return err
	default:
		return nil
	}
}

// JSONDelete is a wrapper over Del command
func (c redisStore) JSONDelete(ctx context.Context, key ...string) error {
	cmd := c.rdb.Del(ctx, key...)
	err := cmd.Err()
	switch {
	case err == redis.Nil:
		return nil
	case err != nil:
		return err
	default:
		return nil
	}
}

func (c redisStore) ScanAndDelete(ctx context.Context, substr string) error {
	var cursor uint64
	for {
		keys, cur, err := c.rdb.Scan(ctx, cursor, "*", 100).Result()
		if err != nil {
			return err
		}
		for _, key := range keys {
			if strings.Contains(key, substr) {
				if err := c.rdb.Del(ctx, key).Err(); err != nil {
					return err
				}
			}
		}
		cursor = cur
		if cursor == 0 {
			break
		}
	}
	return nil
}

// Close is used to close the connection with redis cluster
func (c redisStore) Close() (bool, error) {
	err := c.rdb.Close()
	return err == nil, err
}
