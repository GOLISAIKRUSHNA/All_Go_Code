package upload

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
	"mime/multipart"
)

type IuploadService interface {
	services.IBaseService
	UploadFile(ctx context.Context, file *multipart.FileHeader, uploadReq request.BulkUploadRequest) (bool, error)
	ProcessUpload(ctx context.Context, process request.ProcessUploadRequest) error
	GetBulkUploadList(ctx context.Context, request request.BulkUploadListRequest) response.BulkUploadListData
	GetBulkUploadDetails(ctx context.Context, uploadRefNumber string) response.BulkUploadDetails
}
