package upload

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/adapter/rabbit_mq"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/agent"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/app/services/special_offer"
	"collection-service/internal/dto"
	"collection-service/internal/dto/bulkupload"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"mime/multipart"
	"os"
	"reflect"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/go-playground/validator/v10"

	"github.com/PeteProgrammer/go-automapper"
	"github.com/tealeg/xlsx"
	"gorm.io/gorm"
)

type UploadService struct {
	services.BaseService
	uploadRepo repo_interfaces.IUploadRepository
	awsImport  aws.S3Client
	//specialOfferService services.
	loanService             loan.ILoanService
	caseService             _case.ICaseService
	customerService         customer.ICustomerService
	agentService            agent.IAgentService
	loanPaymentService      loan.ILoanPaymentService
	specialOfferService     special_offer.ISpecialOfferService
	customerDocumentService customer.ICustomerDocumentService
	caseBlockService        _case.ICaseBlockService
	clientRepo              repo_interfaces.IClientRepository
}

func InitUploadService(ctx context.Context, loanService loan.ILoanService, caseService _case.ICaseService,
	specialOfferService special_offer.ISpecialOfferService) *UploadService {
	service := &UploadService{
		uploadRepo:              repositories.InitUploadRepository(ctx),
		awsImport:               *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
		loanService:             loanService,
		caseService:             caseService,
		customerService:         customer.InitCustomerService(ctx),
		agentService:            agent.InitAgentService(ctx),
		loanPaymentService:      loan.InitLoanPaymentService(ctx, loanService),
		specialOfferService:     specialOfferService,
		customerDocumentService: customer.InitCustomerDocumentService(ctx),
		caseBlockService:        _case.InitCaseBlockService(ctx),
		clientRepo:              repositories.InitClientRepository(ctx),
	}

	return service
}

/*
UploadFile : Func will create entry & upload file to s3 & publish events for fileUpload
@request [file, upload reason]
@return bool true/false
@author Tejas Surve
*/

func (i *UploadService) UploadFile(ctx context.Context, file *multipart.FileHeader, uploadReq request.BulkUploadRequest) (bool, error) {
	logger.Info(ctx, "UploadService|UploadFile|Req", logger.LogField{"request": uploadReq})
	uploadSucess := false
	currentTime := time.Now()
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	if !i.valiateUploadAllowedReasons(uploadReq.Reason) {
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "", "Invalid Uploaded reason", nil)
	}

	// Create upload entry
	uniqueFileRef := utils.GenerateRandomString(6, uploadReq.Reason+"_")
	filePath := strings.ToLower(uploadReq.TypeRefNumber + "/" + currentTime.Format("2006-01-02") + "/" + uniqueFileRef + "_" + uploadReq.FileName)
	uploadInput := models.Upload{
		Reason:          uploadReq.Reason,
		FileName:        uploadReq.FileName,
		Status:          "UPLOADED",
		InputFilePath:   filePath,
		UploadedBy:      uploadReq.UploadedBy,
		Object:          uploadReq.Type,
		ObjectRefNumber: uploadReq.TypeRefNumber,
	}
	upload, err := i.uploadRepo.Create(ctx, uploadInput)
	if err != nil {
		logger.Error(ctx, err, "UploadService|UploadFile|InsertErr", logger.LogFields{"uploadInput": uploadInput})
		return false, err
	}

	//Upload file to S3
	if utils.IsNotEmpty(upload.UploadRefNumber) {

		fileContent, errFile := file.Open()
		if errFile != nil {
			logger.Error(ctx, errFile, "UploadService|UploadFile|err in opening file", logger.LogFields{"uploadInput": uploadInput})
			return false, errFile
		}
		defer fileContent.Close()

		contentType := file.Header.Get("Content-Type")
		s3Err := i.awsImport.UploadFile(ctx, filePath, constants.BULK_UPLOAD_AWS_BUCKET, fileContent, contentType)
		if s3Err != nil {
			logger.Error(ctx, s3Err, "UploadService|UploadFile|err", logger.LogFields{"uploadInput": uploadInput})
			return false, s3Err
		}
		//Publish Bulkupload Event
		bulkUploadEvent := events.BulkUploadEvent{
			UploadRefNumber: upload.UploadRefNumber,
			Reason:          upload.Reason,
			Type:            uploadReq.Type,
			TypeRefNumber:   uploadReq.TypeRefNumber,
			UploadedBy:      upload.UploadRefNumber,
		}
		automapper.MapLoose(upload, &bulkUploadEvent)
		i.publishBulkUploadEvent(ctx, bulkUploadEvent)

		uploadSucess = true
	}
	return uploadSucess, nil
}

/*
valiateUploadAllowedReasons : Validate uploaded reasons
@return bool true/false
@author: Tejas Surve
*/
func (i *UploadService) valiateUploadAllowedReasons(uploadedReason string) bool {
	allowedReasons := []string{"LOAN_UPLOAD", "CUSTOMER_UPLOAD", "AGENT_CASE_ALLOCATION", "CONSOLIDATED_LOAN_UPLOAD", "SERVICE_PROVIDER_CASE_ALLOCATION", "SERVICE_PROVIDER_CASE_DEALLOCATION", "AGENT_CASE_DEALLOCATION", "AGENT_UPLOAD", "PAYMENT_UPLOAD", "CREDITLOAN_UPLOAD", "LOAN_WITHDRAWAL",
		"SPECIAL_OFFERS", "CUSTOMER_DOCUMENTS", "BLOCK_CASE"}
	validate := false
	for reason := range allowedReasons {
		if allowedReasons[reason] == uploadedReason {
			validate = true
		}
	}
	return validate
}

/*
ProcessUpload : processUploaded file
- Consume uploaded events | Fetch files from s3 using input, process records and update status
@return bool true/false
@author Tejas Surve
*/
func (up *UploadService) ProcessUpload(ctx context.Context, processReq request.ProcessUploadRequest) error {
	logger.Info(ctx, "UploadService|ProcessUpload|Input", logger.LogFields{"Input": processReq})
	searchFilter := models.Upload{
		UploadRefNumber: processReq.UploadRefNumber,
	}
	upload, err := up.uploadRepo.FindByReferenceNumberOne(ctx, searchFilter)
	if err != nil {
		logger.Error(ctx, err, "UploadService|ProcessUpload|Err", logger.LogFields{})
		utils.InternalServerError(ctx, err, "")
	}
	uploadInput := models.Upload{
		Status: "PROCESSING",
	}
	update, updateErr := up.uploadRepo.Update(ctx, uploadInput, models.Upload{UploadRefNumber: upload.UploadRefNumber})
	logger.Info(ctx, "UploadService|ProcessUpload|Update", logger.LogFields{"updated": update})
	if updateErr != nil {
		utils.InternalServerError(ctx, err, "")
	}

	processReq.InputFilePath = upload.InputFilePath

	switch upload.Reason {
	case "CUSTOMER_UPLOAD":
		up.uploadCustomer(ctx, processReq)
	case "LOAN_UPLOAD":
		return up.uploadLoans(ctx, processReq)
	case "CREDITLOAN_UPLOAD":
		up.uploadLoans(ctx, processReq)
	case "CONSOLIDATED_LOAN_UPLOAD":
		up.uploadLoans(ctx, processReq)
	case "SERVICE_PROVIDER_CASE_ALLOCATION":
		up.processCaseAllocation(ctx, processReq)
	case "AGENT_CASE_ALLOCATION":
		up.processCaseAllocation(ctx, processReq)
	case "SERVICE_PROVIDER_CASE_DEALLOCATION":
		up.processCaseDeallocation(ctx, processReq)
	case "AGENT_CASE_DEALLOCATION":
		up.processCaseDeallocation(ctx, processReq)
	case "AGENT_UPLOAD":
		up.uploadAgents(ctx, processReq)
	case "PAYMENT_UPLOAD":
		up.uploadPayments(ctx, processReq)
	case "LOAN_WITHDRAWAL":
		up.processLoanWithdrawal(ctx, processReq)
	case "SPECIAL_OFFERS":
		up.SpecialOffers(ctx, processReq)
	case "CUSTOMER_DOCUMENTS":
		return up.uploadCustomerDocuments(ctx, processReq)
	case "BLOCK_CASE":
		return up.uploadBlockedCase(ctx, processReq)
	default:
		// Handle any unexpected reason
		fmt.Printf("Unhandled upload reason: %s\n", upload.Reason)
	}
	return nil
}

/*
GetBulkUploadList:
return []response.BulkUploadList
@autor Tejas Surve
*/
func (up *UploadService) GetBulkUploadList(ctx context.Context, req request.BulkUploadListRequest) response.BulkUploadListData {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)
	logger.Info(ctx, "UploadService|GetBulkUploadList|Input", logger.LogFields{"Input": req})
	where := models.Upload{
		Reason:     req.Reason,
		Status:     req.Status,
		UploadedBy: req.UploadedBy,
	}
	pageNo, _ := strconv.Atoi(req.PageNo)
	list, totalRecords, _ := up.uploadRepo.GetUploadList(ctx, where, pageNo)
	listResponse, err := up.mapToResponseList(ctx, list)
	if err != nil || len(listResponse) == 0 {
		listResponse = []response.BulkUploadList{}
	}

	return response.BulkUploadListData{Uploads: listResponse, CurrentPage: pageNo, Pages: totalRecords}
}

/*
GetBulkUploadList:
return []response.BulkUploadList
@autor Tejas Surve
*/
func (up *UploadService) GetBulkUploadDetails(ctx context.Context, uploadRefNumber string) response.BulkUploadDetails {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	logger.Info(ctx, "UploadService|GetBulkUploadDetails|Input", logger.LogFields{"Input": uploadRefNumber})
	responseDetails := response.BulkUploadDetails{}
	where := models.Upload{
		UploadRefNumber: uploadRefNumber,
	}
	uploadDetails, err := up.uploadRepo.FindByReferenceNumberOne(ctx, where)
	if err != nil && err != gorm.ErrRecordNotFound {
		logger.Error(ctx, err, "UploadService|GetBulkUploadDetails|dbError", logger.LogFields{"where": uploadRefNumber})
	}
	if !utils.IsEmptyStruct(uploadDetails) {
		responseDetails, mapError := up.mapUploadDetailsResponse(ctx, uploadDetails)
		if mapError != nil {
			utils.InternalServerError(ctx, mapError, "")
		}
		return responseDetails
	}

	return responseDetails
}

/*
uploadLoans: func will read file from s3 and process data, transform data into loan request
this functions handle 3 files data loan_upload, consolidated_loan_upload, creditcard_loan_upload
@author:Tejas Surve
*/
func (upload *UploadService) uploadLoans(ctx context.Context, uploadInput request.ProcessUploadRequest) error {
	logger.Info(ctx, "UploadService|uploadLoans|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	clientConfig, err := upload.getClientInfo(ctx, uploadInput.TypeRefNumber)
	if err != nil {
		return err
	}
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0

	// Batch size for concurrent processing
	batchSize := 5000
	sheet := data.Sheets[0]
	totalRecords = len(sheet.Rows) - 1
	totalRows := len(data.Sheets[0].Rows)

	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|uploadLoans|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
		return errResSheet
	}
	processStartTime := time.Now()
	var wg sync.WaitGroup
	//Add header row
	headerRow := responseSheet.AddRow()
	for _, header := range sheet.Rows[0].Cells {
		headerCell := headerRow.AddCell()
		headerCell.Value = header.String()
	}
	responseSheetRowCell := headerRow.AddCell()
	responseSheetRowCell.Value = "Upload Status"
	// Iterate through rows in batches
	for i := 1; i < totalRows; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRows {
			endIndex = totalRows
		}

		wg.Add(1)

		go func(start, end int) {
			defer wg.Done()

			for j := start; j < end; j++ {
				row := sheet.Rows[j]
				if utils.IsRowEmpty(row) {
					logger.Error(ctx, errors.New("empty row found"), "UploadService|UploadLoans|Loop breaked, empty row found", logger.LogFields{})
					totalRecords = processedRecords
					upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
					return // current go routine will stop &  count values will updated
				}
				processedRecords++
				responseSheetRow := responseSheet.AddRow()
				for _, cell := range row.Cells {
					//uploaded files row setting to response file
					responseSheetRowCell := responseSheetRow.AddCell()
					responseSheetRowCell.Value = cell.String()
				}
				var loanRequest bulkupload.LoanUpload
				var creditLoanRequest bulkupload.CreditCardLoanUpload
				var consolidatedLoanRequest bulkupload.ConsolodatedLoanUpload

				validateErrSring := ""
				loanData := request.CreateUpdateLoanRequest{}
				if uploadInput.Reason == "LOAN_UPLOAD" {
					rowToStruct(row, &loanRequest)
					loanData = upload.mapUploadLoanInput(loanRequest, uploadInput.UploadedBy, uploadInput.TypeRefNumber)

					customerErr := loanRequest.LoanValidate(clientConfig)
					if customerErr != nil {
						validateErrSring = validateErrSring + " " + customerErr.Error()
					}

				} else if uploadInput.Reason == "CONSOLIDATED_LOAN_UPLOAD" {
					rowToStruct(row, &consolidatedLoanRequest)
					loanData = upload.mapUploadConsolidatedLoanInput(consolidatedLoanRequest, uploadInput.UploadedBy, uploadInput.TypeRefNumber)

					customerErr := consolidatedLoanRequest.ConsolidateValidate(clientConfig)
					if customerErr != nil {
						validateErrSring = validateErrSring + " " + customerErr.Error()
					}
				} else if uploadInput.Reason == "CREDITLOAN_UPLOAD" {
					rowToStruct(row, &creditLoanRequest)
					loanData = upload.mapUploadCreditLoanInput(creditLoanRequest, uploadInput.UploadedBy, uploadInput.TypeRefNumber)
					// Validate the struct
					customerErr := creditLoanRequest.CreditValidate()
					if customerErr != nil {
						validateErrSring = validateErrSring + " " + customerErr.Error()
					}
				}
				if validateErrSring != "" {
					newErrorCell := responseSheetRow.AddCell()
					newErrorCell.Value = validateErrSring
					failedRecordsCount++
				} else {
					//_, err := upload.loanService.Create(ctx, loanData
					err := upload.handleCreateLoan(ctx, loanData)

					if err != nil {
						failedRecordsCount++
						// Add a new cell with an error message to each row
						newErrorCell := responseSheetRow.AddCell()
						newErrorCell.Value = err.Error()
					} else {
						successRecordsCount++
						newErrorCell := responseSheetRow.AddCell()
						newErrorCell.Value = "SUCCESS"
					}
				}
			}
			//upload each batch status count
			totalRecords = processedRecords
			upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
		}(i, endIndex)

	}
	wg.Wait()
	processEndTime := time.Now()
	elapsed := processEndTime.Sub(processStartTime)
	logger.Info(ctx, "UploadService|UploadCustomers|Benchmark", logger.LogFields{"start_time": processStartTime, "end_time": processEndTime, "elapsed_time_sec": elapsed.Seconds(), "total_records": totalRecords, "processed_records": processedRecords})

	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|uploadLoans|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return err
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := strings.ToLower(pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx")
	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{
		OutputFilePath:        uploadFilePath,
		Status:                "COMPLETED",
		TotalRecordsCount:     int32(totalRecords),
		ProcessedRecordsCount: int32(processedRecords),
		SuccessCount:          int32(successRecordsCount),
		FailedCount:           int32(failedRecordsCount),
	}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
	return nil
}

func (upload *UploadService) SpecialOffers(ctx context.Context, uploadInput request.ProcessUploadRequest) error {
	logger.Info(ctx, "UploadService|SpecialOffers|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0

	// Batch size for concurrent processing
	batchSize := 5000
	sheet := data.Sheets[0]
	totalRecords = len(sheet.Rows) - 1
	totalRows := len(data.Sheets[0].Rows)

	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|SpecialOffers|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
		return errResSheet
	}

	processStartTime := time.Now()
	var wg sync.WaitGroup
	//Add header row
	// Create a mapping of column names to indices
	columnMapping := getHeaderRow(sheet, responseSheet)
	// Iterate through rows in batches
	for i := 1; i < totalRows; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRows {
			endIndex = totalRows
		}
		wg.Add(1)
		go func(start, end int) {
			defer wg.Done()
			for j := start; j < end; j++ {
				processedRecords++
				row := sheet.Rows[j]
				if utils.IsRowEmpty(row) {
					logger.Error(ctx, errors.New("empty row found"), "UploadService|SpecialOffer|Loop breaked, empty row found", logger.LogFields{})
					totalRecords = processedRecords
					upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
					return // current go routine will stop &  count values will updated
				}
				var specialOffer bulkupload.SpecialOffer
				validateErrString := ""

				responseSheetRow := responseSheet.AddRow()
				bindErr := upload.bindRowToSpecialOffersData(row, &specialOffer, columnMapping, responseSheetRow)
				if bindErr != nil {
					validateErrString = bindErr.Error()
				}

				customerErr := specialOffer.SpecialOfferValidate()
				if customerErr != nil {
					validateErrString = validateErrString + " " + customerErr.Error()
				}
				statusCell := responseSheetRow.Cells[len(responseSheetRow.Cells)-1]
				if validateErrString != "" {
					statusCell.Value = validateErrString
					failedRecordsCount++
					continue
				}

				createSpecialOffer, err := upload.mapSpecialOfferInput(ctx, specialOffer, uploadInput.UploadedBy, uploadInput.TypeRefNumber)
				if err != nil {
					statusCell.Value = err.Error()
					failedRecordsCount++
					continue
				}

				err = upload.handleSpecialOffer(ctx, *createSpecialOffer)
				if err != nil {
					failedRecordsCount++
					statusCell.Value = err.Error()
				} else {
					successRecordsCount++
					statusCell.Value = "SUCCESS"
				}

			}
			//upload each batch status count
			upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
		}(i, endIndex)

	}
	wg.Wait()
	processEndTime := time.Now()
	elapsed := processEndTime.Sub(processStartTime)
	logger.Info(ctx, "UploadService|UploadCustomers|Benchmark", logger.LogFields{"start_time": processStartTime, "end_time": processEndTime, "elapsed_time_sec": elapsed.Seconds(), "total_records": totalRecords, "processed_records": processedRecords})

	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|uploadLoans|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return err
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := strings.ToLower(pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx")
	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{
		OutputFilePath:        uploadFilePath,
		Status:                "COMPLETED",
		TotalRecordsCount:     int32(totalRecords),
		ProcessedRecordsCount: int32(processedRecords),
		SuccessCount:          int32(successRecordsCount),
		FailedCount:           int32(failedRecordsCount),
	}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
	return nil
}

func AddCellVal(responseSheetRow *xlsx.Row, val string) {
	newErrorCell := responseSheetRow.AddCell()
	newErrorCell.Value = val
}

/*createLoan : func will handle panic from service and return error for excel
 */
func (upload *UploadService) handleCreateLoan(ctx context.Context, loanData request.CreateUpdateLoanRequest) (err error) {
	//defer func() {
	//	if r := recover(); r != nil {
	//		if ce, ok := r.(utils.CustomError); ok {
	//			errCode := ce.StatusCode
	//			resp := ce.Data
	//			fmt.Println("^^^^^^^^^^^^^^^^^^^^^^^^^", errCode, resp)
	//		}
	//		err = fmt.Errorf("recovered from panic: %v", r)
	//	}
	//}()
	_, serviceErr := upload.loanService.Create(ctx, loanData)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

func (upload *UploadService) handleSpecialOffer(ctx context.Context, specialOfferReq request.CreateSpecialOffer) (err error) {
	defer func() {
		if r := recover(); r != nil {
			if ce, ok := r.(utils.CustomError); ok {
				errCode := ce.StatusCode
				resp := ce.Data
				logger.Info(ctx, "error from handleSpecialOffer", logger.LogFields{
					"errCode":  errCode,
					"response": resp,
				})

				err = getErrorMessageFromRequestError(ce)
				if err != nil {
					return
				}
			}
			err = fmt.Errorf("recovered from panic: %v", r)
		}
	}()

	_, serviceErr := upload.specialOfferService.Create(ctx, &specialOfferReq, nil)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

func getErrorMessageFromRequestError(ce utils.CustomError) error {
	if ser, ok := ce.Data.(dto.ServerErrorResponse); ok {
		return errors.New(ser.Error.Message)
	}

	if ser, ok := ce.Data.(dto.BadRequestResponse); ok {
		return errors.New(ser.Error.Message)
	}

	if ser, ok := ce.Data.(dto.NotFoundResponse); ok {
		return errors.New(ser.Error.Message)

	}

	if ser, ok := ce.Data.(dto.ServerErrorResponse); ok {
		return errors.New(ser.Error.Message)
	}
	return nil
}

func (upload *UploadService) uploadCustomer(ctx context.Context, uploadInput request.ProcessUploadRequest) {

	logger.Info(ctx, "UploadService|uploadCustomer|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0

	var wg sync.WaitGroup

	// Batch size for concurrent processing
	batchSize := 1000
	sheet := data.Sheets[0]
	totalRecords = len(sheet.Rows) - 1
	totalRows := len(data.Sheets[0].Rows)
	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|uploadCustomer|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
	}
	processStartTime := time.Now()

	// Create a mapping of column names to indices
	columnMapping := getHeaderRow(sheet, responseSheet)

	// Iterate through rows in batches
	for i := 1; i < totalRows; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRows {
			endIndex = totalRows
		}

		// Increment the wait group counter
		wg.Add(1)
		go func(start, end int) {
			defer wg.Done()
			for j := start; j < end; j++ {
				row := sheet.Rows[j]
				if utils.IsRowEmpty(row) {
					logger.Error(ctx, errors.New("empty row found"), "UploadService|UploadLoans|Loop breaked, empty row found", logger.LogFields{})
					totalRecords = processedRecords
					upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
					return // current go routine will stop &  count values will updated
				}
				processedRecords++
				var customerRequest bulkupload.CustomerUpload
				validateErrSring := ""
				responseSheetRow := responseSheet.AddRow()
				bindErr := upload.bindRowToCustomerData(row, &customerRequest, columnMapping, responseSheetRow)
				if bindErr != nil {
					validateErrSring = bindErr.Error()
				}
				if customErr := customerRequest.CustomerValidate(); customErr != nil {
					validateErrSring = validateErrSring + customErr.Error()
				}
				if validateErrSring == "" {
					customerData := upload.mapUploadCustomerInput(customerRequest, uploadInput.UploadedBy, uploadInput.TypeRefNumber)
					err := upload.handleCreateCustomer(ctx, customerData)
					if err != nil {
						newErrorCell := responseSheetRow.Cells[len(responseSheetRow.Cells)-1]
						newErrorCell.Value = validateErrSring + err.Error()
						failedRecordsCount++
					} else {
						newErrorCell := responseSheetRow.Cells[len(responseSheetRow.Cells)-1]
						newErrorCell.Value = "SUCCESS"
						successRecordsCount++
					}
				} else {
					newErrorCell := responseSheetRow.Cells[len(responseSheetRow.Cells)-1]
					newErrorCell.Value = validateErrSring
					failedRecordsCount++
				}
				fmt.Println("==========================", row)
			}
		}(i, endIndex)
		upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
	}
	// wait still all
	wg.Wait()
	processEndTime := time.Now()
	elapsed := processEndTime.Sub(processStartTime)
	logger.Info(ctx, "UploadService|UploadCustomers|Benchmark", logger.LogFields{"start_time": processStartTime, "end_time": processEndTime, "elapsed_time_sec": elapsed.Seconds(), "total_records": totalRecords, "processed_records": processedRecords})

	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|customerUpload|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx"
	fmt.Println("###############", responseFilePath)
	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{
		OutputFilePath:        uploadFilePath,
		Status:                "COMPLETED",
		TotalRecordsCount:     int32(totalRecords),
		ProcessedRecordsCount: int32(processedRecords),
		SuccessCount:          int32(successRecordsCount),
		FailedCount:           int32(failedRecordsCount),
	}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
}

/*createLoan : func will handle panic from service and return error for excel
 */
func (upload *UploadService) handleCreateCustomer(ctx context.Context, customerData request.CustomerAndCustomerInfoReq) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("recovered from panic: %v", r)
		}
	}()
	_, serviceErr := upload.customerService.CreateCustomerWithInfo(ctx, customerData)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

/*
processAllocation: func will read file from s3 and process data for case allocation
@author : Tejas Surve
*/
func (upload *UploadService) processCaseAllocation(ctx context.Context, uploadInput request.ProcessUploadRequest) {
	logger.Info(ctx, "UploadService|processAllocation|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0

	var wg sync.WaitGroup
	// Batch size for concurrent processing
	batchSize := 1000
	sheet := data.Sheets[0]
	totalRecords = len(sheet.Rows) - 1
	totalRows := len(data.Sheets[0].Rows)
	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|uploadCustomer|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
	}
	processStartTime := time.Now()

	//Add header row
	columnMapping := getHeaderRow(sheet, responseSheet)

	for i := 1; i < totalRows; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRows {
			endIndex = totalRows
		}

		// Increment the wait group counter
		wg.Add(1)
		go func(start, end int) {
			defer wg.Done()
			for j := start; j < end; j++ {
				row := sheet.Rows[j]
				if utils.IsRowEmpty(row) {
					logger.Error(ctx, errors.New("empty row found"), "UploadService|processCaseAllocation|Loop breaked, empty row found", logger.LogFields{})
					totalRecords = processedRecords
					upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
					return // current go routine will stop &  count values will updated
				}
				processedRecords++
				responseSheetRow := responseSheet.AddRow()
				var agentAllocationUpload bulkupload.AgentAllocationUpload
				var serviceProviderAllocationUpload bulkupload.ServiceProviderAllocationUpload
				validateErrString := ""
				//assigning & validating data
				allocationData := request.CaseAllocationReq{}
				if uploadInput.Reason == "AGENT_CASE_ALLOCATION" {
					bindErr := upload.bindRowToAllocateToAgent(row, &agentAllocationUpload, columnMapping, responseSheetRow)
					if bindErr != nil {
						validateErrString = validateErrString + bindErr.Error()
					}
					allocationValidationErr := agentAllocationUpload.AgentLoanAllocationValidate()
					if allocationValidationErr != nil {
						validateErrString = validateErrString + " " + allocationValidationErr.Error()
					}
					allocationData = upload.mapUploadAllocateToAgent(ctx, agentAllocationUpload, uploadInput)
				} else if uploadInput.Reason == "SERVICE_PROVIDER_CASE_ALLOCATION" {
					bindErr := upload.bindRowToAllocateToProvider(row, &serviceProviderAllocationUpload, columnMapping, responseSheetRow)
					if bindErr != nil {
						validateErrString = validateErrString + bindErr.Error()
					}
					allocationValidationErr := serviceProviderAllocationUpload.SpLoanAllocationValidate()
					if allocationValidationErr != nil {
						validateErrString = validateErrString + " " + allocationValidationErr.Error()
					}

					allocationData, bindErr = upload.mapUploadAllocateToServiceProcider(ctx, serviceProviderAllocationUpload, uploadInput)
					if bindErr != nil {
						validateErrString = validateErrString + " " + bindErr.Error()
					}
				}
				statusCell := responseSheetRow.Cells[len(responseSheetRow.Cells)-1]
				if validateErrString == "" {
					err := upload.handleAllocateCase(ctx, allocationData)
					if err != nil {
						validateErrString = validateErrString + " " + err.Error()
					} else {
						successRecordsCount++
						statusCell.Value = "SUCCESS"
					}
				}
				if validateErrString != "" {
					failedRecordsCount++
					statusCell.Value = validateErrString
				}
			}
			totalRecords = processedRecords
			upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
		}(i, endIndex)
	}
	wg.Wait()
	processEndTime := time.Now()
	elapsed := processEndTime.Sub(processStartTime)
	logger.Info(ctx, "UploadService|UploadCustomers|Benchmark", logger.LogFields{"start_time": processStartTime, "end_time": processEndTime, "elapsed_time_sec": elapsed.Seconds(), "total_records": totalRecords, "processed_records": processedRecords})
	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|processCaseAllocation|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx"
	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{OutputFilePath: uploadFilePath, Status: "COMPLETED", TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
}

/*createLoan : func will handle panic from service and return error for excel
 */
func (upload *UploadService) handleAllocateCase(ctx context.Context, allocationData request.CaseAllocationReq) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("recovered from panic: %v", r)
		}
	}()

	serviceErr := upload.caseService.AllocateCase(ctx, allocationData)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

/*
processDeallocation: func will read file from s3 and process data
Delete allocated cases
@author Tejas Surve
*/
func (upload *UploadService) processCaseDeallocation(ctx context.Context, uploadInput request.ProcessUploadRequest) {
	logger.Info(ctx, "UploadService|processCaseDeallocation|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0
	var wg sync.WaitGroup
	// Batch size for concurrent processing
	batchSize := 1000
	// Iterate through sheets and rows or read only single sheet
	sheet := data.Sheets[0]
	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|processCaseDeallocation|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
	}
	//Add header row
	columnMapping := getHeaderRow(sheet, responseSheet)

	totalRecords = len(sheet.Rows)
	for i := 1; i < totalRecords; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRecords {
			endIndex = totalRecords
		}
		wg.Add(1) // Increment the wait group counter
		go func(start, end int) {
			defer wg.Done()
			for j := start; j < end; j++ {
				row := sheet.Rows[j]
				if utils.IsRowEmpty(row) {
					logger.Error(ctx, errors.New("empty row found"), "UploadService|processCaseDeAllocation|Loop breaked, empty row found", logger.LogFields{})
					totalRecords = processedRecords
					upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
					return // current go routine will stop &  count values will updated
				}
				processedRecords++
				responseSheetRow := responseSheet.AddRow()
				var caseDeAllocationUpload bulkupload.CaseDeallocationUpload
				var agentDeAllocationUpload bulkupload.AgentCaseDeallocationUpload
				//assigning & validating data
				deAllocationData := request.CaseDeAllocationReq{}
				validateString := ""
				if uploadInput.Reason == "AGENT_CASE_DEALLOCATION" {
					bindErr := upload.bindRowToDeAllocateFromAgent(row, &agentDeAllocationUpload, columnMapping, responseSheetRow)
					if bindErr != nil {
						validateString = validateString + " " + bindErr.Error()
					}
					err := agentDeAllocationUpload.AgentCaseDeallocationValidate()
					if err != nil {
						validateString = validateString + " " + err.Error()
					}
					deAllocationData = upload.mapUploadDeAllocateFromAgent(ctx, agentDeAllocationUpload, uploadInput)
				} else {
					bindErr := upload.bindRowToDeAllocateFromProvider(row, &caseDeAllocationUpload, columnMapping, responseSheetRow)
					if bindErr != nil {
						validateString = validateString + " " + bindErr.Error()
					}
					deAllocationData, bindErr = upload.mapUploadDeAllocateFromServiceProcider(ctx, caseDeAllocationUpload, uploadInput)
					if bindErr != nil {
						validateString = validateString + " " + bindErr.Error()
					}
				}

				statusCell := responseSheetRow.Cells[len(responseSheetRow.Cells)-1]
				if validateString != "" {
					failedRecordsCount++
					statusCell.Value = validateString
				}
				if validateString == "" {
					err := upload.handleDeAllocateCase(ctx, deAllocationData)
					if err != nil {
						failedRecordsCount++
						//Add a new cell with an error message to each row
						statusCell.Value = err.Error()
					} else {
						successRecordsCount++
						statusCell.Value = "SUCCESS"
					}
				}
			}
			totalRecords = processedRecords
			upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
		}(i, endIndex)
	}
	wg.Wait()
	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|processCaseDeallocation|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx"
	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{OutputFilePath: uploadFilePath, Status: "COMPLETED", TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
}

/*createLoan : func will handle panic from service and return error for excel
 */
func (upload *UploadService) handleDeAllocateCase(ctx context.Context, allocationData request.CaseDeAllocationReq) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("recovered from panic: %v", r)
		}
	}()
	serviceErr := upload.caseService.DeAllocateCase(ctx, allocationData)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

/*
uploadAgents: func will read file from s3 and process data for upload agents
@author:  Tejas Surve
*/
func (upload *UploadService) uploadAgents(ctx context.Context, uploadInput request.ProcessUploadRequest) {
	validate := validator.New()
	logger.Info(ctx, "UploadService|uploadAgents|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0
	// Iterate through sheets and rows or read only single sheet
	sheet := data.Sheets[0]
	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|uploadAgents|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
	}
	totalRecords = len(sheet.Rows) - 1 // avoid header row
	for i, row := range sheet.Rows {
		responseSheetRow := responseSheet.AddRow()
		for _, cell := range row.Cells {
			//uploaded files row setting to response file
			responseSheetRowCell := responseSheetRow.AddCell()
			responseSheetRowCell.Value = cell.String()
		}
		var agentUpload bulkupload.AgentUpload

		if i != 0 {
			processedRecords++
			//assigning & validating data
			validateErrSring := ""
			var agentData = request.CreateAgentReq{}

			rowToStructErr := rowToStruct(row, &agentUpload)
			if rowToStructErr != nil {
				validateErrSring = validateErrSring + " " + rowToStructErr.Error()
				logger.Error(ctx, rowToStructErr, "UploadService|uploadAgents|AllocationErr", logger.LogFields{})
			}
			if validateErrSring == "" {
				customerErr := agentUpload.Validate()
				if customerErr != nil {
					validateErrSring = validateErrSring + " " + customerErr.Error()
				}
				agentData = transformUploadInputToAgenReq(agentUpload, uploadInput.UploadedBy)
				if validateErr := validate.Struct(agentUpload); validateErr != nil {
					validateErrSring = validateErr.Error()
				}
			}
			if validateErrSring != "" {
				failedRecordsCount++
				newErrorCell := responseSheetRow.AddCell()
				newErrorCell.Value = validateErrSring
			} else {
				err := upload.createAgent(ctx, agentData)
				if err != nil {
					failedRecordsCount++
					//Add a new cell with an error message to each row
					newErrorCell := responseSheetRow.AddCell()
					newErrorCell.Value = err.Error()
				} else {
					successRecordsCount++
					newErrorCell := responseSheetRow.AddCell()
					newErrorCell.Value = "SUCCESS"
				}
			}
		}

	}
	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|uploadAgents|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx"
	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{
		OutputFilePath:        uploadFilePath,
		Status:                "COMPLETED",
		TotalRecordsCount:     int32(totalRecords),
		ProcessedRecordsCount: int32(processedRecords),
		SuccessCount:          int32(successRecordsCount),
		FailedCount:           int32(failedRecordsCount),
	}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
}

/*
createAgent: func will defer panic
@author:  Tejas Surve
*/
func (upload *UploadService) createAgent(ctx context.Context, agentData request.CreateAgentReq) (err error) {
	defer func() {
		if r := recover(); r != nil {
			if ce, ok := r.(utils.CustomError); ok {
				errCode := ce.StatusCode
				resp := ce.Data
				logger.Info(ctx, "error from handleSpecialOffer", logger.LogFields{
					"errCode":  errCode,
					"response": resp,
				})

				err = getErrorMessageFromRequestError(ce)
				if err != nil {
					return
				}
			}
			err = fmt.Errorf("recovered from panic: %v", r)
		}
	}()
	_, serviceErr := upload.agentService.Create(ctx, agentData)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

/*
uploadPayments: func will read file from s3 and process payment data for create loanpayments
@author:  Tejas Surve
*/
func (upload *UploadService) uploadPayments(ctx context.Context, uploadInput request.ProcessUploadRequest) {
	logger.Info(ctx, "UploadService|uploadPayments|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0
	var wg sync.WaitGroup
	var mu sync.Mutex // Mutex for synchronization
	batchSize := 1000 // Batch size for concurrent processing
	sheet := data.Sheets[0]
	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|uploadPayments|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
	}

	columnMapping := getHeaderRow(sheet, responseSheet)

	totalRecords = len(sheet.Rows) - 1 // Exclude header row
	for i := 1; i <= totalRecords; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRecords {
			endIndex = totalRecords
		}
		// Increment the wait group counter
		wg.Add(1)
		go func(start, end int) {
			defer wg.Done()
			for j := start; j <= end; j++ {
				row := sheet.Rows[j]
				if utils.IsRowEmpty(row) {
					logger.Error(ctx, errors.New("empty row found"), "UploadService|UploadLoans|Loop breaked, empty row found", logger.LogFields{})
					mu.Lock()
					totalRecords = processedRecords
					upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
					mu.Unlock()
					return // current go routine will stop & count values will updated
				}
				mu.Lock()
				processedRecords++
				mu.Unlock()
				responseSheetRow := responseSheet.AddRow()
				for _, cell := range row.Cells {
					// uploaded files row setting to response file
					responseSheetRowCell := responseSheetRow.AddCell()
					responseSheetRowCell.Value = cell.String()
				}
				validateErrString := ""
				var paymentUpload bulkupload.PaymentUpload
				var paymentData request.LoanPayment

				// Use column mapping to bind data to struct
				bindErr := upload.bindRowToPaymentData(row, &paymentUpload, columnMapping, responseSheetRow)
				if bindErr != nil {
					validateErrString = validateErrString + " " + bindErr.Error()
				}
				paymentValidateErr := paymentUpload.PaymentUploadValidate()
				if paymentValidateErr != nil {
					validateErrString = validateErrString + " " + paymentValidateErr.Error()
				}
				paymentData = transformUploadInputLoanPaymentReq(ctx, paymentUpload)
				statusCell := responseSheetRow.AddCell()
				if validateErrString != "" {
					mu.Lock()
					failedRecordsCount++
					mu.Unlock()
					statusCell.Value = validateErrString
				} else {
					err := upload.handleLoanPayment(ctx, paymentData)
					if err != nil {
						mu.Lock()
						failedRecordsCount++
						mu.Unlock()
						statusCell.Value = err.Error()
					} else {
						mu.Lock()
						successRecordsCount++
						mu.Unlock()
						statusCell.Value = "SUCCESS"
					}
				}

			}
			mu.Lock()
			totalRecords = processedRecords
			upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
			mu.Unlock()
		}(i, endIndex)
	}
	wg.Wait()
	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|uploadPayments|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return
	}

	// Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx"
	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path & status
	updateBulkUpload := models.Upload{
		OutputFilePath:        uploadFilePath,
		Status:                "COMPLETED",
		TotalRecordsCount:     int32(totalRecords),
		ProcessedRecordsCount: int32(processedRecords),
	}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
}

/*
createAgent: func will defer panic
@author:  Tejas Surve
*/
func (upload *UploadService) handleLoanPayment(ctx context.Context, payment request.LoanPayment) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("recovered from panic: %v", r)
		}
	}()
	_, serviceErr := upload.loanPaymentService.CreateLoanPayment(ctx, payment)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

/*
processCaseWithdrawal: func will read file from s3 and process data
Delete allocated cases
@author Tejas Surve
*/
func (upload *UploadService) processLoanWithdrawal(ctx context.Context, uploadInput request.ProcessUploadRequest) {
	logger.Info(ctx, "UploadService|processCaseWithdrawal|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0
	var wg sync.WaitGroup
	// Batch size for concurrent processing
	batchSize := 1000
	sheet := data.Sheets[0] // Iterate through sheets and rows or read only single sheet
	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|processCaseWithdrawal|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
	}
	//Add header row
	columnMapping := getHeaderRow(sheet, responseSheet)

	totalRecords = len(sheet.Rows)
	for i := 1; i < totalRecords; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRecords {
			endIndex = totalRecords
		}

		// Increment the wait group counter
		wg.Add(1)
		go func(start, end int) {
			defer wg.Done()
			for j := start; j < end; j++ {
				row := sheet.Rows[j]
				if utils.IsRowEmpty(row) {
					logger.Error(ctx, errors.New("empty row found"), "UploadService|UploadLoans|Loop breaked, empty row found", logger.LogFields{})
					totalRecords = processedRecords
					upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
					return // current go routine will stop &  count values will updated
				}
				processedRecords++
				valiateString := ""
				responseSheetRow := responseSheet.AddRow()

				var withdrawalUpload bulkupload.LoanWithdrawal
				//assigning & validating data
				withdrawalData := request.LoanWithdrawalReq{}
				bindErr := upload.bindRowToLoanWithdrawal(row, &withdrawalUpload, columnMapping, responseSheetRow)
				if bindErr != nil {
					valiateString = valiateString + bindErr.Error()
				}
				validationErr := withdrawalUpload.LoanWithdrawalValidate()
				if validationErr != nil {
					valiateString = valiateString + validationErr.Error()
				}
				statusCell := responseSheetRow.Cells[len(responseSheetRow.Cells)-1]
				if valiateString != "" {
					failedRecordsCount++
					statusCell.Value = validationErr.Error()
					failedRecordsCount++
				} else {
					withdrawalData = request.LoanWithdrawalReq{
						ClientLoanId: withdrawalUpload.ClientLoanId,
						Reason:       withdrawalUpload.Reason,
						OtherReason:  withdrawalUpload.OtherReason,
						CreatedBy:    uploadInput.UploadedBy,
					}
					err := upload.handleLoanWithdrawal(ctx, withdrawalData)
					if err != nil {
						failedRecordsCount++
						statusCell.Value = err.Error()
					} else {
						successRecordsCount++
						statusCell.Value = "SUCCESS"
					}
				}
			}
			totalRecords = processedRecords
			upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
		}(i, endIndex)
	}
	wg.Wait()
	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|processCaseDeallocation|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx"
	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{OutputFilePath: uploadFilePath, Status: "COMPLETED", TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords)}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
}

/*
HandleLoanWithdrwal: func will defer panic
@author:  Tejas Surve
*/
func (upload *UploadService) handleLoanWithdrawal(ctx context.Context, loan request.LoanWithdrawalReq) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("recovered from panic: %v", r)
		}
	}()
	serviceErr := upload.loanService.LoanWithdrawal(ctx, loan)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

func (upload *UploadService) uploadBlockedCase(ctx context.Context, uploadInput request.ProcessUploadRequest) error {

	logger.Info(ctx, "UploadService|uploadBlockedCase|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	data := upload.awsImport.ReadXlsx(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0

	var wg sync.WaitGroup
	// Batch size for concurrent processing
	batchSize := 1000
	sheet := data.Sheets[0]
	totalRecords = len(sheet.Rows) - 1
	totalRows := len(data.Sheets[0].Rows)
	responseSheet, errResSheet := responseFile.AddSheet(sheet.Name)
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|uploadBlockedCase|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
	}
	processStartTime := time.Now()

	//Add header row
	columnMapping := getHeaderRow(sheet, responseSheet)

	// Iterate through rows in batches
	for i := 1; i < totalRows; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRows {
			endIndex = totalRows
		}

		// Increment the wait group counter
		wg.Add(1)
		go func(start, end int) {
			defer wg.Done()
			for j := start; j < end; j++ {
				row := sheet.Rows[j]
				if utils.IsRowEmpty(row) {
					logger.Error(ctx, errors.New("empty row found"), "UploadService|UploadLoans|Loop breaked, empty row found", logger.LogFields{})
					totalRecords = processedRecords
					upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
					return // current go routine will stop &  count values will updated
				}
				processedRecords++

				validateErrString := ""
				responseSheetRow := responseSheet.AddRow()

				var blockRequest bulkupload.BlockCaseUpload

				bindErr := upload.bindRowToBlockCase(row, &blockRequest, columnMapping, responseSheetRow)
				if bindErr != nil {
					validateErrString = validateErrString + bindErr.Error()
				}
				blockData := upload.mapUploadBlockInput(blockRequest, uploadInput.UploadedBy, uploadInput.TypeRefNumber)
				if validateErr := blockRequest.CaseBlockValidate(); validateErr != nil {
					validateErrString = validateErr.Error()
				}

				statusCell := responseSheetRow.Cells[len(responseSheetRow.Cells)-1]
				statusCell.Value = validateErrString
				if validateErrString == "" {
					err := upload.handleBlockCase(ctx, blockData)
					if err != nil {
						statusCell.Value = validateErrString + err.Error()
						failedRecordsCount++
					} else {
						statusCell.Value = "SUCCESS"
						successRecordsCount++
					}
				} else {
					failedRecordsCount++
				}

			}
			totalRecords = processedRecords
			upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
		}(i, endIndex)
	}
	// wait still all
	wg.Wait()
	processEndTime := time.Now()
	elapsed := processEndTime.Sub(processStartTime)
	logger.Info(ctx, "UploadService|UploadCustomers|Benchmark", logger.LogFields{"start_time": processStartTime, "end_time": processEndTime, "elapsed_time_sec": elapsed.Seconds(), "total_records": totalRecords, "processed_records": processedRecords})

	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|customerUpload|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return errors.New("error in saving response file of block case")
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx"

	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{
		OutputFilePath:        uploadFilePath,
		Status:                "COMPLETED",
		TotalRecordsCount:     int32(totalRecords),
		ProcessedRecordsCount: int32(processedRecords),
		SuccessCount:          int32(successRecordsCount),
		FailedCount:           int32(failedRecordsCount),
	}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
	return nil
}

/*handleBlockCase : func will handle panic from service and return error for excel
 */
func (upload *UploadService) handleBlockCase(c context.Context, blockData request.BlockCase) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("recovered from panic: %v", r)
		}
	}()
	blockData.Source = enum.CLIENT
	serviceErr := upload.caseBlockService.BlockCase(c, blockData)
	if serviceErr != nil {
		return serviceErr
	}
	return nil
}

/*
uploadCustomerDocuments: fun will read image file and upload against customomer
@author:  Tejas Surve
*/
func (upload *UploadService) uploadCustomerDocuments(ctx context.Context, uploadInput request.ProcessUploadRequest) error {

	logger.Info(ctx, "UploadService|uploadCustomerDocuments|Request", logger.LogFields{"path": uploadInput.InputFilePath, "upload_ref_number": uploadInput.UploadRefNumber})
	files, err := upload.awsImport.ReadZipFromS3(ctx, constants.BULK_UPLOAD_AWS_BUCKET, uploadInput.InputFilePath)
	if err != nil {
		return err
	}
	responseFilePath := "docs/" + uploadInput.UploadRefNumber + "_" + "response.xlsx"
	responseFile := xlsx.NewFile()
	totalRecords := 0
	processedRecords := 0
	successRecordsCount := 0
	failedRecordsCount := 0

	var wg sync.WaitGroup

	// Batch size for concurrent processing
	batchSize := 1000
	totalRecords = len(files)
	totalRows := len(files)
	fmt.Println("********************", len(files))
	responseSheet, errResSheet := responseFile.AddSheet("response")
	if errResSheet != nil {
		logger.Error(ctx, errResSheet, "UploadService|uploadCustomer|Response File", logger.LogFields{"upload_ref_number": uploadInput.UploadRefNumber})
	}
	processStartTime := time.Now()

	//Add header row
	headerRow := responseSheet.AddRow()
	responseSheetRowCell := headerRow.AddCell()
	responseSheetRowCell.Value = "CLIENT CUSTOMER ID"
	responseSheetRowCell = headerRow.AddCell()
	responseSheetRowCell.Value = "DOCUMENT TYPE"
	responseSheetRowCell = headerRow.AddCell()
	responseSheetRowCell.Value = "UPLOAD STATUS"

	// Iterate through rows in batches
	for i := 0; i <= totalRows; i += batchSize {
		endIndex := i + batchSize
		if endIndex > totalRows {
			endIndex = totalRows
		}

		// Increment the wait group counter
		wg.Add(1)
		go func(start, end int) {
			defer wg.Done()
			for j := start; j < end; j++ {

				getCustomerId := strings.Split(files[j].Name, ".")
				docRequest := request.CustomerDocumentRequest{
					ClientCustomerId: getCustomerId[0],
					DocumentType:     "photo",
					ClientRefNumber:  uploadInput.TypeRefNumber,
					CreatedBy:        uploadInput.UploadedBy,
				}
				row := responseSheet.AddRow()
				responseSheetRowCell := row.AddCell()
				responseSheetRowCell.Value = docRequest.ClientCustomerId
				responseSheetRowCell = row.AddCell()
				responseSheetRowCell.Value = docRequest.DocumentType

				processedRecords++
				err := upload.customerDocumentService.UploadCustomerDocuments(ctx, files[j].Content, docRequest)
				if err != nil {
					responseSheetRowCell = row.AddCell()
					responseSheetRowCell.Value = err.Error()
					failedRecordsCount++
				} else {
					responseSheetRowCell = row.AddCell()
					responseSheetRowCell.Value = "SUCCESS"
					successRecordsCount++
				}

			}
		}(i, endIndex)
		upload.uploadRepo.Update(ctx, models.Upload{TotalRecordsCount: int32(totalRecords), ProcessedRecordsCount: int32(processedRecords), SuccessCount: int32(successRecordsCount), FailedCount: int32(failedRecordsCount)}, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
	}
	// wait still all
	wg.Wait()
	processEndTime := time.Now()
	elapsed := processEndTime.Sub(processStartTime)
	logger.Info(ctx, "UploadService|UploadCustomers|Benchmark", logger.LogFields{"start_time": processStartTime, "end_time": processEndTime, "elapsed_time_sec": elapsed.Seconds(), "total_records": totalRecords, "processed_records": processedRecords})

	// Save the new file in local
	if err := responseFile.Save(responseFilePath); err != nil {
		logger.Error(ctx, err, "UploadService|customerUpload|error in saving response file", logger.LogFields{"uploadRefNumber": uploadInput.UploadRefNumber})
		return err
	}

	//Upload response file to s3
	pathSplit := strings.Split(uploadInput.InputFilePath, "/")
	uploadFilePath := pathSplit[0] + "/" + pathSplit[1] + "/" + uploadInput.UploadRefNumber + "_response.xlsx"

	upload.uploadLocalResponseFileToS3(ctx, responseFilePath, uploadFilePath)

	// update response file path  & status
	updateBulkUpload := models.Upload{
		OutputFilePath:        uploadFilePath,
		Status:                "COMPLETED",
		TotalRecordsCount:     int32(totalRecords),
		ProcessedRecordsCount: int32(processedRecords),
		SuccessCount:          int32(successRecordsCount),
		FailedCount:           int32(failedRecordsCount),
	}
	upload.uploadRepo.Update(ctx, updateBulkUpload, models.Upload{UploadRefNumber: uploadInput.UploadRefNumber})
	return nil
}

// uploadLoacalResponseFileToS3 : upload locally stored response file to s3 & remove local file
func (i *UploadService) uploadLocalResponseFileToS3(ctx context.Context, localFilePath string, uploadFilePath string) bool {
	file, err := os.Open(localFilePath)
	if err != nil {
		logger.Error(ctx, err, "UploadService|uploadLoacalFileToS3|Error opening file", logger.LogFields{"filepath": localFilePath})
		return false
	}
	pathSplit := strings.Split(localFilePath, ".")
	defer file.Close()

	//Need to improve content type should read automatically
	conTentType := pathSplit[1]
	awsUploadErr := i.awsImport.UploadFile(ctx, uploadFilePath, constants.BULK_UPLOAD_AWS_BUCKET, file, conTentType)
	if awsUploadErr != nil {
		logger.Error(ctx, err, "UploadService|uploadLoacalFileToS3|Error in upload file", logger.LogFields{"filepath": uploadFilePath})
		return false
	}
	//Remove local generated file after upload
	removeFileErr := os.Remove(localFilePath)
	if removeFileErr != nil {
		logger.Error(ctx, err, "UploadService|uploadLoacalFileToS3|removeLocalFileErr", logger.LogFields{"filepath": localFilePath})
		panic(removeFileErr)
	}
	return true
}

/*
publishBulkUploadEvent : published bulk upload events
@author Tejas Surve
*/
func (i *UploadService) publishBulkUploadEvent(ctx context.Context, event events.BulkUploadEvent) bool {
	success := false
	eventData := adapter.NewMessage(ctx, "bulk_upload", event, "")
	bulkUploadEventData, erf := json.Marshal(eventData)
	if erf != nil {
		logger.Error(ctx, erf, "UploadService|publishBulkUploadEvent|err", logger.LogFields{"events": eventData})

	}

	rabbit_mq.GetRabbitMQClientInstance(ctx).Publish(ctx,
		constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE,
		[]string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY},
		bulkUploadEventData,
		nil,
	)
	return success
}

/*
transformUploadInputToAgenReq: convert row data to Agent Request
@author:  Tejas Surve
*/
func transformUploadInputToAgenReq(agentUploadReq bulkupload.AgentUpload, createdBy string) request.CreateAgentReq {
	lngStringSlice := strings.Split(agentUploadReq.LanguagesSupported, ",")
	var lngSlice []string
	lngSlice = append(lngSlice, lngStringSlice...)
	return request.CreateAgentReq{
		FirstName:                 utils.CapitalizeFirstLetter(agentUploadReq.FirstName),
		LastName:                  utils.CapitalizeFirstLetter(agentUploadReq.LastName),
		MobileNumber:              agentUploadReq.MobileNumber,
		Email:                     agentUploadReq.Email,
		Username:                  agentUploadReq.Username,
		Password:                  utils.Base64Encode(agentUploadReq.Password),
		CashCollectionLimit:       agentUploadReq.CashCollectionLimit,
		CashDepositByDays:         agentUploadReq.CashDepositByDays,
		ReportingManagerRefNumber: agentUploadReq.ReportingManagerRefNumber,
		LanguagesSupported:        lngSlice,
		Designation:               agentUploadReq.Designation,
		ServiceProviderRefNumber:  agentUploadReq.ServiceProviderRefNumber,
		AgentRole:                 enum.StringToAgentRole(agentUploadReq.Role),
		AgentVisibility:           enum.StringToAgentVisibility(agentUploadReq.Visibility),
		CreatedBy:                 createdBy,
	}
}

func transformUploadInputLoanPaymentReq(ctx context.Context, paymentUploadReq bulkupload.PaymentUpload) request.LoanPayment {
	/*paymentDate, err := utils.DateStringAsYmd(paymentUploadReq.PaymentRecieptDate)
	if err != nil {
		logger.Error(ctx, err, "UploadService|transformUploadInputLoanPaymentReq|parsedateErr", logger.LogFields{})
	}*/
	return request.LoanPayment{
		ClientPaymentId: paymentUploadReq.PaymentId,
		ClientLoanId:    paymentUploadReq.ClientLoanId,
		PaymentDatetime: paymentUploadReq.PaymentReceiptDate,
		PaymentGateway:  paymentUploadReq.PaymentReceiptMode, // need to discuss
		PaymentAmount:   paymentUploadReq.PaymentAmount,
	}
}

/*
mapUploadCustomerInput : transform row data to customer request
@author:Tejas Surve
*/

func (upload *UploadService) mapUploadCustomerInput(uploadReq bulkupload.CustomerUpload, UploadedBy string, clientRefNumber string) request.CustomerAndCustomerInfoReq {
	dob, _ := utils.ParseDate(uploadReq.Dob)
	return request.CustomerAndCustomerInfoReq{
		Customer: request.CustomerReq{
			FirstName:         utils.CapitalizeFirstLetter(uploadReq.FirstName),
			LastName:          utils.CapitalizeFirstLetter(uploadReq.LastName),
			ClientCustomerId:  uploadReq.ClientCustomerId,
			ClientRefNumber:   clientRefNumber,
			MobileNumber:      uploadReq.MobileNumber,
			PreferredLanguage: utils.CapitalizeFirstLetterAfterComma(uploadReq.PreferredLanguage),
			Email:             uploadReq.Email,
			Dob:               dob,
			Gender:            uploadReq.Gender,
			CreatedBy:         UploadedBy,
		},
		CustomerInfo: request.CustomerInfo{
			EmploymentType: uploadReq.EmploymentType,
			EmployerName:   uploadReq.EmployerName,
			MonthlyIncome:  uploadReq.MonthlyIncome,
			Occupation:     uploadReq.Occupation,
			CibilScore:     uploadReq.CibilScore,
		},
	}
}

func (upload *UploadService) mapUploadBlockInput(uploadReq bulkupload.BlockCaseUpload, UploadedBy string, clientRefNumber string) request.BlockCase {
	return request.BlockCase{
		ClientLoanId: uploadReq.ClientLoanId,
		Source:       enum.CLIENT,
		Reason:       uploadReq.Reason,
		BlockedUntil: uploadReq.BlockedUntil,
		BlockType:    uploadReq.BlockType,
		CreatedBy:    UploadedBy,
	}
}

/*
mapUploadLoanInput: Its mapping rowdata to loanrequest
@author:Tejas Surve
*/
func (upload *UploadService) mapUploadLoanInput(uploadReq bulkupload.LoanUpload, UploadedBy string, clientRefNumber string) request.CreateUpdateLoanRequest {

	tenureType, _ := enum.StringToTenureTypeEnum(uploadReq.TenureType)
	if tenureType == 0 {
		tenureType = enum.TENURE_MONTHLY
	}
	//	loanStatus, _ := enum.StringToLoanStatusEnum(uploadReq.Status)
	loanProduct, _ := enum.StringToLoanProductEnum(uploadReq.Product)

	return request.CreateUpdateLoanRequest{
		CreatedBy:       UploadedBy,
		ClientRefNumber: clientRefNumber,
		Customer: request.Customer{
			ClientCustomerId: uploadReq.ClientCustomerId,
		},
		Loan: request.Loan{
			ClientLoanId: uploadReq.ClientLoanId,
			LoanAmount:   uploadReq.LoanAmount,
			Tenure:       uploadReq.Tenure,
			TenureType:   tenureType,
			InterestRate: uploadReq.InterestRate,
			EmiAmount:    uploadReq.EmiAmount,
			Status:       enum.LOAN_ACTIVE,
			Product:      loanProduct,
			SubProduct:   uploadReq.SubProduct,
			//ActiveFinancierName: uploadReq.ActiveFinancierName,
			DisbursementAmount:        uploadReq.DisbursementAmount,
			DisbursementDate:          uploadReq.DisbursementDate,
			DueDate:                   uploadReq.DueDate,
			FirstEmiDate:              uploadReq.FirstEmiDate,
			LastEmiDate:               uploadReq.LastEmiDate,
			EarliestUnpaidEmiDate:     uploadReq.EarliestUnpaidEmiDate,
			TotalDue:                  uploadReq.TotalDue,
			TotalPrincipalDue:         uploadReq.TotalPrincipalDue,
			TotalInterestDue:          uploadReq.TotalInterestDue,
			TotalFeesDue:              uploadReq.TotalFeesDue,
			TotalOutstanding:          uploadReq.TotalOutstanding,
			TotalPrincipalOutstanding: uploadReq.TotalPrincipalOutstanding,
			TotalInterestOutstanding:  uploadReq.TotalPrincipalOutstanding,
			TotalFeesOutstanding:      uploadReq.TotalFeesOutstanding,
			TotalPrincipalPaid:        uploadReq.TotalPrincipalPaid,
			TotalInterestPaid:         uploadReq.TotalInterestPaid,
			TotalFeesPaid:             uploadReq.TotalFeesPaid,
			NoOfEmisPaid:              uploadReq.NoOfEmisPaid,
			CurrentDpd:                uploadReq.CurrentDpd,
			MaxDpd:                    uploadReq.MaxDpd,
			ActiveFinancierRefNumber:  uploadReq.ActiveFinancierRefNumber,
			MandateRazorpayCustomerID: uploadReq.MandateRazorpayCustomerID,
			MandateRazorpayToken:      uploadReq.MandateRazorpayToken,
			BankName:                  uploadReq.BankName,
			BankAccountNo:             uploadReq.BankAccountNo,
			PaymentLink:               uploadReq.PaymentLink,
		},
		ClientTeamRefNumber: uploadReq.ClientTeamRefNumber,
	}
}

func (upload *UploadService) mapSpecialOfferInput(ctx context.Context, uploadReq bulkupload.SpecialOffer, UploadedBy string, clientRefNumber string) (*request.CreateSpecialOffer, error) {

	offerType := enum.StringToOfferType(uploadReq.OfferType)
	if offerType == 0 {
		return nil, fmt.Errorf("invalid offer Type value: %s", uploadReq.OfferType)
	}

	waiverType := enum.StringToWaiverType(uploadReq.WaiverType)
	if offerType == 0 {
		return nil, fmt.Errorf("invalid waiver Type value: %s", uploadReq.WaiverType)
	}

	specialOfferStatus := enum.StringToOfferStatus(uploadReq.Status)
	if specialOfferStatus == 0 {
		return nil, fmt.Errorf("invalid offer status value: %s", uploadReq.Status)
	}

	if uploadReq.StartDateTime == "" || uploadReq.EndDateTime == "" {
		return nil, fmt.Errorf("start date time and end date time are mandatory")
	}

	layout := "2006-01-02 15:04:05"

	// Parse the time string into a time.Time object
	startDateTime, err := time.Parse(layout, uploadReq.StartDateTime)
	if err != nil {
		logger.Error(ctx, err, "UploadService|mapSpecialOfferInput|parsedateErr", nil)
		return nil, fmt.Errorf("invalid time format entered")
	}

	endDateTime, err := time.Parse(layout, uploadReq.EndDateTime)
	if err != nil {
		logger.Error(ctx, err, "UploadService|mapSpecialOfferInput|parsedateErr", nil)
		return nil, fmt.Errorf("invalid time format entered")
	}

	return &request.CreateSpecialOffer{
		ClientLoanId:         uploadReq.ClientLoanId,
		OfferType:            offerType,
		WaiverType:           waiverType,
		WaiverValue:          uploadReq.WaiverValue,
		MinimumPaymentAmount: uploadReq.MinimumPaymentAmount,
		Status:               specialOfferStatus,
		StartDatetime:        startDateTime,
		EndDatetime:          endDateTime,
		CreatedBy:            UploadedBy,
		ActivationSource:     enum.SRC_INGRESS,
		ClientRefNumber:      clientRefNumber,
	}, nil
}

func (upload *UploadService) mapUploadAllocateToAgent(ctx context.Context, agentAllocationUpload bulkupload.AgentAllocationUpload, uploadInput request.ProcessUploadRequest) request.CaseAllocationReq {
	return request.CaseAllocationReq{
		CaseRefNumber:   agentAllocationUpload.CaseRefNumber,
		AgentRefNumber:  agentAllocationUpload.AgentRefNumber,
		CreatedBy:       uploadInput.UploadedBy,
		Object:          uploadInput.Type,
		ObjectRefNumber: uploadInput.TypeRefNumber,
	}
}

func (upload *UploadService) mapUploadAllocateToServiceProcider(ctx context.Context, input bulkupload.ServiceProviderAllocationUpload, uploadInput request.ProcessUploadRequest) (request.CaseAllocationReq, error) {
	intervention, err := enum.StringToInterventionEnum(input.Intervention)
	if err != nil {
		return request.CaseAllocationReq{}, err
	}
	return request.CaseAllocationReq{
		ServiceProviderRefNumber: input.ServiceProviderRefNumber,
		ClientLoanId:             input.ClientLoanId,
		Intervention:             intervention,
		CreatedBy:                uploadInput.UploadedBy,
		Object:                   uploadInput.Type,
		ObjectRefNumber:          uploadInput.TypeRefNumber,
	}, nil
}

func (upload *UploadService) mapUploadDeAllocateFromAgent(ctx context.Context, input bulkupload.AgentCaseDeallocationUpload, uploadInput request.ProcessUploadRequest) request.CaseDeAllocationReq {
	return request.CaseDeAllocationReq{
		CaseRefNumber:            input.CaseRefNumber,
		AgentRefNumber:           input.AgentRefNumber,
		ServiceProviderRefNumber: uploadInput.TypeRefNumber,
		CreatedBy:                uploadInput.UploadedBy,
		Object:                   uploadInput.Type,
		ObjectRefNumber:          uploadInput.TypeRefNumber,
	}
}

func (upload *UploadService) mapUploadDeAllocateFromServiceProcider(ctx context.Context, input bulkupload.CaseDeallocationUpload, uploadInput request.ProcessUploadRequest) (request.CaseDeAllocationReq, error) {
	intervention, err := enum.StringToInterventionEnum(input.Intervention)
	if err != nil {
		return request.CaseDeAllocationReq{}, err
	}
	if utils.IsEmpty(input.ClientLoanId) || len(input.ClientLoanId) <= 3 {
		return request.CaseDeAllocationReq{}, errors.New("Client Loan Id is mandatory")
	}
	return request.CaseDeAllocationReq{
		ServiceProviderRefNumber: input.ServiceProviderRefNumber,
		ClientLoanId:             input.ClientLoanId,
		Intervention:             intervention,
		CreatedBy:                uploadInput.UploadedBy,
		Object:                   uploadInput.Type,
		ObjectRefNumber:          uploadInput.TypeRefNumber,
	}, nil
}

func (upload *UploadService) bindRowToPaymentData(row *xlsx.Row, paymentUpload *bulkupload.PaymentUpload, columnMapping map[string]int, responseSheetRow *xlsx.Row) error {
	cellValues := make(map[string]string)
	// Store cell values based on header indices
	for header, idx := range columnMapping {
		if idx < len(row.Cells) {
			cellValues[header] = row.Cells[idx].String()
		}
	}

	for key, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(key)
		switch columnKey {
		case "client_loan_id":
			paymentUpload.ClientLoanId = value
		case "payment_id":
			paymentUpload.PaymentId = value
		case "payment_receipt_date":
			paymentUpload.PaymentReceiptDate = value
		case "payment_receipt_mode":
			paymentUpload.PaymentReceiptMode = value
		case "total_payment_amount":
			amount, err := strconv.ParseFloat(value, 64)
			if err != nil {
				return fmt.Errorf("invalid payment amount: %v", err)
			}
			paymentUpload.PaymentAmount = amount
		}
	}
	// Create a slice to store values in the order of headers
	orderedValues := make([]string, len(columnMapping))
	for header, idx := range columnMapping {
		if idx < len(orderedValues) {
			orderedValues[idx] = cellValues[header]
		}
	}

	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}
	return nil
}

// Bind row to customer data
func (upload *UploadService) bindRowToCustomerData(row *xlsx.Row, customerUpload *bulkupload.CustomerUpload, headerMapping map[string]int, responseSheetRow *xlsx.Row) error {
	// Create a map to store cell values
	cellValues := make(map[string]string)

	// Store cell values based on header indices
	for header, idx := range headerMapping {
		if idx < len(row.Cells) {
			cellValues[header] = row.Cells[idx].String()
		}
	}
	// Create a slice to store values in the order of headers
	orderedValues := getOrderValues(cellValues, headerMapping)

	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}

	// Populate customerUpload fields based on header mapping
	for header, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(header)
		switch columnKey {
		case "customer_id":
			customerUpload.ClientCustomerId = value
		case "borrower_type":
			customerUpload.BorrowerType = value
		case "first_name":
			customerUpload.FirstName = value
		case "last_name":
			customerUpload.LastName = value
		case "mobile_number":
			customerUpload.MobileNumber = value
		case "email":
			customerUpload.Email = value
		case "dob":
			customerUpload.Dob = value
		case "gender":
			customerUpload.Gender = value
		case "preferred_language":
			customerUpload.PreferredLanguage = value
		case "monthly_income":
			monthlyIncome, err := strconv.ParseFloat(value, 64)
			if err != nil {
				return fmt.Errorf("invalid monthly income: %v", err)
			}
			customerUpload.MonthlyIncome = monthlyIncome
		case "occupation":
			customerUpload.Occupation = value
		case "cibil_score":
			cibilScore, err := strconv.Atoi(value)
			if err != nil {
				return fmt.Errorf("invalid cibil score: %v", err)
			}
			customerUpload.CibilScore = cibilScore
		case "employment_type":
			customerUpload.EmploymentType = value
		case "employer_name":
			customerUpload.EmployerName = value
		}
	}

	return nil
}

// Bind row to Allocation data
func (upload *UploadService) bindRowToAllocateToProvider(row *xlsx.Row, allocation *bulkupload.ServiceProviderAllocationUpload, headerMapping map[string]int, responseSheetRow *xlsx.Row) error {
	// Create a map to store cell values
	cellValues := getCellValues(row, headerMapping)
	// Create a slice to store values in the order of headers
	orderedValues := getOrderValues(cellValues, headerMapping)

	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}
	// Populate customerUpload fields based on header mapping
	for header, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(header)
		switch columnKey {
		case "client_loan_id":
			allocation.ClientLoanId = value
		case "intervention":
			allocation.Intervention = value
		case "service_provider_reference_number":
			allocation.ServiceProviderRefNumber = value
		}
	}

	return nil
}

// Bind row to DeAllocate From Provider
func (upload *UploadService) bindRowToDeAllocateFromProvider(row *xlsx.Row, allocation *bulkupload.CaseDeallocationUpload, headerMapping map[string]int, responseSheetRow *xlsx.Row) error {
	// Create a map to store cell values
	cellValues := getCellValues(row, headerMapping)

	// Populate customerUpload fields based on header mapping
	for header, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(header)
		switch columnKey {
		case "client_loan_id":
			allocation.ClientLoanId = value
		case "intervention":
			allocation.Intervention = value
		case "service_provider_reference_number":
			allocation.ServiceProviderRefNumber = value
		}
	}

	// Create a slice to store values in the order of headers
	orderedValues := make([]string, len(headerMapping))
	for header, idx := range headerMapping {
		if idx < len(orderedValues) {
			orderedValues[idx] = cellValues[header]
		}
	}
	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}
	return nil
}

// Bind row to DeAllocate From Provider
func (upload *UploadService) bindRowToDeAllocateFromAgent(row *xlsx.Row, allocation *bulkupload.AgentCaseDeallocationUpload, headerMapping map[string]int, responseSheetRow *xlsx.Row) error {
	// Create a map to store cell values
	cellValues := getCellValues(row, headerMapping)

	// Create a slice to store values in the order of headers
	orderedValues := getOrderValues(cellValues, headerMapping)
	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}
	// Populate customerUpload fields based on header mapping
	for header, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(header)
		switch columnKey {
		case "case_ref_number":
			allocation.CaseRefNumber = value
		case "agent_ref_number":
			allocation.AgentRefNumber = value
		}
	}

	return nil
}

// Bind row to Agent Allocation Data
func (upload *UploadService) bindRowToAllocateToAgent(row *xlsx.Row, allocation *bulkupload.AgentAllocationUpload, headerMapping map[string]int, responseSheetRow *xlsx.Row) error {
	// Create a map to store cell values
	cellValues := getCellValues(row, headerMapping)
	// Create a slice to store values in the order of headers
	orderedValues := getOrderValues(cellValues, headerMapping)
	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}
	// Populate customerUpload fields based on header mapping
	for header, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(header)
		switch columnKey {
		case "case_ref_number":
			allocation.CaseRefNumber = value
		case "agent_ref_number":
			allocation.AgentRefNumber = value
		}
	}

	return nil
}

// Bind row to Loan Withdrawal request
func (upload *UploadService) bindRowToLoanWithdrawal(row *xlsx.Row, input *bulkupload.LoanWithdrawal, headerMapping map[string]int, responseSheetRow *xlsx.Row) error {
	// Create a map to store cell values
	cellValues := getCellValues(row, headerMapping)
	// Create a slice to store values in the order of headers
	orderedValues := getOrderValues(cellValues, headerMapping)
	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}
	// Populate customerUpload fields based on header mapping
	for header, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(header)
		switch columnKey {
		case "client_loan_id":
			input.ClientLoanId = value
		case "withdraw_reason":
			input.Reason = value
		case "other_withdraw_reason":
			input.OtherReason = value
		}
	}

	return nil
}

// Bind row to Block Case request
func (upload *UploadService) bindRowToBlockCase(row *xlsx.Row, input *bulkupload.BlockCaseUpload, headerMapping map[string]int, responseSheetRow *xlsx.Row) error {
	// Create a map to store cell values
	cellValues := getCellValues(row, headerMapping)
	// Create a slice to store values in the order of headers
	orderedValues := getOrderValues(cellValues, headerMapping)

	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}
	// Populate customerUpload fields based on header mapping
	for header, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(header)
		switch columnKey {
		case "client_loan_id":
			input.ClientLoanId = value
		case "block_type":
			input.BlockType = value
		case "block_until_date":
			input.BlockedUntil = value
		case "block_reason":
			input.Reason = value
		}
	}

	return nil
}

func getCellValues(row *xlsx.Row, headerMapping map[string]int) map[string]string {
	cellValues := make(map[string]string)
	for header, idx := range headerMapping {
		if idx < len(row.Cells) {
			cellValues[header] = row.Cells[idx].String()
		}
	}
	return cellValues
}

/*
mapCreditUploadLoanInput: Its mapping rowdata to loanrequest
@author:Tejas Surve
*/
func (upload *UploadService) mapUploadCreditLoanInput(uploadReq bulkupload.CreditCardLoanUpload, UploadedBy string, clientRefNumber string) request.CreateUpdateLoanRequest {
	loanStatus, _ := enum.StringToLoanStatusEnum(uploadReq.Status)
	loanProduct, _ := enum.StringToLoanProductEnum(uploadReq.Product)
	return request.CreateUpdateLoanRequest{
		CreatedBy:       UploadedBy,
		ClientRefNumber: clientRefNumber,
		Customer: request.Customer{
			ClientCustomerId:  uploadReq.ClientCustomerId,
			FirstName:         utils.CapitalizeFirstLetter(uploadReq.FirstName),
			LastName:          utils.CapitalizeFirstLetter(uploadReq.LastName),
			MobileNumber:      uploadReq.MobileNumber,
			PreferredLanguage: utils.CapitalizeFirstLetterAfterComma(uploadReq.PreferredLanguage),
			Email:             uploadReq.Email,
			Dob:               uploadReq.Dob,
			Gender:            uploadReq.Gender,
		},
		Loan: request.Loan{
			ClientLoanId:                uploadReq.ClientLoanId,
			LoanAmount:                  uploadReq.BillTotalPaymentDue,
			InterestRate:                uploadReq.InterestRate,
			Status:                      loanStatus,
			Product:                     loanProduct,
			SubProduct:                  uploadReq.SubProduct,
			DueDate:                     uploadReq.DueDate,
			TotalDue:                    uploadReq.TotalDue,
			TotalInterestDue:            uploadReq.TotalInterestDue,
			TotalFeesDue:                uploadReq.TotalFeesDue,
			CurrentDpd:                  uploadReq.CurrentDpd,
			CreditCardNo:                uploadReq.CreditCardNo,
			BillTotalPaymentDue:         uploadReq.BillTotalPaymentDue,
			BillMinPaymentDue:           uploadReq.BillMinPaymentDue,
			BillStatementGenerationDate: uploadReq.BillStatementGenerationDate,
			CreatedBy:                   UploadedBy,
		},
		ClientTeamRefNumber: uploadReq.ClientTeamRefNumber,
		/*Borrowers: []request.Borrowers{
			{
				FirstName:           utils.CapitalizeFirstLetter(uploadReq.FirstName),
				LastName:            utils.CapitalizeFirstLetter(uploadReq.LastName),
				MobileNumber:        uploadReq.MobileNumber,
				Type:                "PRIMARY",
				RelationWithPrimary: "SELF", // need to discuss we dont have enum
			},
		},*/
	}
}

/*
mapUploadLoanInput: Its mapping rowdata to loanrequest with customer
@author:Tejas Surve
*/
func (upload *UploadService) mapUploadConsolidatedLoanInput(uploadReq bulkupload.ConsolodatedLoanUpload, createdBy string, clientRefNumber string) request.CreateUpdateLoanRequest {
	tenureType, _ := enum.StringToTenureTypeEnum(uploadReq.TenureType)
	//loanStatus, _ := enum.StringToLoanStatusEnum(uploadReq.Status)
	loanProduct, _ := enum.StringToLoanProductEnum(uploadReq.Product)

	//dueDate := utils.StringToDate(uploadReq.DueDate)
	//earliestUnpaidEmiDate := utils.StringToDate(uploadReq.EarliestUnpaidEmiDate)
	return request.CreateUpdateLoanRequest{
		CreatedBy:       createdBy,
		ClientRefNumber: clientRefNumber,
		Loan: request.Loan{
			ClientLoanId:              uploadReq.ClientLoanId,
			LoanAmount:                uploadReq.LoanAmount,
			Tenure:                    uploadReq.Tenure,
			TenureType:                tenureType,
			InterestRate:              uploadReq.InterestRate,
			EmiAmount:                 uploadReq.EmiAmount,
			Status:                    enum.LOAN_ACTIVE,
			Product:                   loanProduct,
			SubProduct:                uploadReq.SubProduct,
			DisbursementAmount:        uploadReq.DisbursementAmount,
			DisbursementDate:          uploadReq.DisbursementDate,
			DueDate:                   uploadReq.DueDate,
			FirstEmiDate:              uploadReq.FirstEmiDate,
			LastEmiDate:               uploadReq.LastEmiDate,
			EarliestUnpaidEmiDate:     uploadReq.EarliestUnpaidEmiDate,
			TotalDue:                  uploadReq.TotalDue,
			TotalPrincipalDue:         uploadReq.TotalPrincipalDue,
			TotalInterestDue:          uploadReq.TotalInterestDue,
			TotalFeesDue:              uploadReq.TotalFeesDue,
			CurrentDpd:                uploadReq.CurrentDpd,
			ActiveFinancierRefNumber:  uploadReq.ActiveFinancier,
			MandateRazorpayCustomerID: uploadReq.MandateRazorpayCustomerID,
			MandateRazorpayToken:      uploadReq.MandateRazorpayToken,
			BankName:                  uploadReq.BankName,
			BankAccountNo:             uploadReq.BankAccountNo,
			PaymentLink:               uploadReq.PaymentLink,
		},
		Customer: request.Customer{
			ClientCustomerId:  uploadReq.ClientCustomerId,
			FirstName:         utils.CapitalizeFirstLetter(uploadReq.FirstName),
			LastName:          utils.CapitalizeFirstLetter(uploadReq.LastName),
			MobileNumber:      uploadReq.MobileNumber,
			PreferredLanguage: utils.ValidateLanguagesSupported(strings.Split(uploadReq.PreferredLanguage, ",")),
			Email:             uploadReq.Email,
			Dob:               uploadReq.Dob,
			Gender:            uploadReq.Gender,
		},
		Addresses: []request.Addresses{
			{
				Line1:     uploadReq.Line1,
				Line2:     uploadReq.Line2,
				Line3:     uploadReq.Line3,
				Label:     enum.StringToAddressLabel(uploadReq.Label),
				Source:    enum.StringToAddressSource(uploadReq.Source),
				Medium:    enum.CLIENT_DATA_INGRESS,
				Landmark:  uploadReq.Landmark,
				Pincode:   uploadReq.Pincode,
				State:     uploadReq.State,
				City:      uploadReq.City,
				CreatedBy: createdBy,
			},
		},
		ClientTeamRefNumber: uploadReq.ClientTeamRefNumber,
		/*Borrowers: []request.Borrowers{
			{
				FirstName:           utils.CapitalizeFirstLetter(uploadReq.FirstName),
				LastName:            utils.CapitalizeFirstLetter(uploadReq.LastName),
				MobileNumber:        uploadReq.MobileNumber,
				Type:                "PRIMARY",
				RelationWithPrimary: "SELF", // need to discuss we dont have enum
			},
		},*/
	}

}

/*
mapToResponseList :
@author Tejas Surve
*/

func (up *UploadService) mapToResponseList(ctx context.Context, uploads []models.Upload) ([]response.BulkUploadList, error) {
	var responseUploads []response.BulkUploadList

	for _, upload := range uploads {
		uploadedFile, err := up.awsImport.GetSharableURL(ctx, upload.InputFilePath, constants.BULK_UPLOAD_AWS_BUCKET)
		if err != nil {
			logger.Error(ctx, err, "UploadService|mapToResponseList|GetSharableURLErr", logger.LogFields{"inputFilePath": upload.InputFilePath})
			uploadedFile = ""
		}
		responseFile, err := up.awsImport.GetSharableURL(ctx, upload.OutputFilePath, constants.BULK_UPLOAD_AWS_BUCKET)
		if err != nil {
			logger.Error(ctx, err, "UploadService|mapToResponseList|GetSharableURLErr", logger.LogFields{"outputFilePath": upload.InputFilePath})
			responseFile = ""
		}
		uploadedByName := utils.CapitalizeFirstLetter(upload.UploadedByInfo.FirstName) + " " + utils.CapitalizeFirstLetter(upload.UploadedByInfo.LastName)
		if upload.Object == "CLIENT" {
			uploadedByName = utils.CapitalizeFirstLetter(upload.UploadedByClientUser.FirstName) + " " + utils.CapitalizeFirstLetter(upload.UploadedByClientUser.LastName)
		}
		responseUpload := response.BulkUploadList{
			UploadRefNumber:       upload.UploadRefNumber,
			Reason:                upload.Reason,
			InputFileName:         upload.FileName,
			InputFilePath:         uploadedFile,
			OutputFilePath:        responseFile,
			TotalRecordsCount:     upload.TotalRecordsCount,
			ProcessedRecordsCount: upload.ProcessedRecordsCount,
			SuccessCount:          upload.SuccessCount,
			FailedCount:           upload.FailedCount,
			Status:                upload.Status,
			CreatedAt:             utils.FormatDateAsYmdhis(upload.CreatedAt),
			UploadedBy:            upload.UploadedBy,
			UploadedByName:        uploadedByName,
		}
		responseUploads = append(responseUploads, responseUpload)
	}

	return responseUploads, nil
}

/*
mapUploadDetailsResponse :
@author Tejas Surve
*/
func (up *UploadService) mapUploadDetailsResponse(ctx context.Context, upload *models.Upload) (response.BulkUploadDetails, error) {
	uploadedFile, err := up.awsImport.GetSharableURL(ctx, upload.InputFilePath, constants.BULK_UPLOAD_AWS_BUCKET)
	if err != nil {
		logger.Error(ctx, err, "UploadService|mapUploadDetailsResponse|GetSharableURLErr", logger.LogFields{"inputFilePath": upload.InputFilePath})
		uploadedFile = ""
	}
	responseFile, err := up.awsImport.GetSharableURL(ctx, upload.OutputFilePath, constants.BULK_UPLOAD_AWS_BUCKET)
	if err != nil {
		logger.Error(ctx, err, "UploadService|mapUploadDetailsResponse|GetSharableURLErr", logger.LogFields{"outpuFilePath": upload.OutputFilePath})
	}
	uploadedByName := utils.CapitalizeFirstLetter(upload.UploadedByInfo.FirstName) + " " + utils.CapitalizeFirstLetter(upload.UploadedByInfo.LastName)
	if upload.Object == "CLIENT" {
		uploadedByName = utils.CapitalizeFirstLetter(upload.UploadedByClientUser.FirstName) + " " + utils.CapitalizeFirstLetter(upload.UploadedByClientUser.LastName)
	}
	response := response.BulkUploadDetails{
		UploadRefNumber:       upload.UploadRefNumber,
		Reason:                upload.Reason,
		InputFileName:         upload.FileName,
		InputFilePath:         uploadedFile,
		OutputFilePath:        responseFile,
		TotalRecordsCount:     upload.TotalRecordsCount,
		ProcessedRecordsCount: upload.ProcessedRecordsCount,
		SuccessCount:          upload.SuccessCount,
		FailedCount:           upload.FailedCount,
		Status:                upload.Status,
		UploadedBy:            upload.UploadedBy,
		CreatedAt:             utils.FormatDateAsYmdhis(upload.CreatedAt),
		UploadedByName:        uploadedByName,
	}

	return response, nil
}

/*
rowToStruct : Comman function to convert row data to struct
@author Tejas Surve
*/

func (up *UploadService) getClientInfo(ctx context.Context, clientRefNumber string) (dto.AppConfig, error) {
	clientData, err := up.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: clientRefNumber})
	if err != nil {
		return dto.AppConfig{}, nil
	}
	var clientConfig dto.AppConfig
	jsonData := []byte(clientData.Configuration)
	marshalErr := json.Unmarshal(jsonData, &clientConfig)
	if marshalErr != nil {
		logger.Error(ctx, marshalErr, "UploadService|getClientInfo|UnmarshalError", logger.LogFields{"config": jsonData})
		return clientConfig, marshalErr
	}
	//clientInfo := Client{CaseLevel: clientConfig.CaseLevel, ClientRefNumber: clientData.ClientRefNumber, CCCaseLevel: clientConfig.CCCaseLevel, DailyCallsLimit: clientConfig.DailyCallsLimit, DistanceCheckMeters: clientConfig.DistanceCheckMeters}

	return clientConfig, nil
}

func rowToStruct(row *xlsx.Row, dest interface{}) (err error) {

	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("panic occurred: %v", r)
		}
	}()
	v := reflect.ValueOf(dest).Elem()

	for i := 0; i < v.NumField(); i++ {
		fieldName := v.Type().Field(i).Tag.Get("xlsx")
		if fieldName != "" {
			cell := row.Cells[i]
			switch v.Field(i).Kind() {
			case reflect.String:
				v.Field(i).SetString(strings.TrimSpace(cell.String()))
			case reflect.Int:
				val, _ := cell.Int()
				v.Field(i).SetInt(int64(val))
			case reflect.Float64:
				val, _ := cell.Float()
				v.Field(i).SetFloat(val)
			case reflect.Struct:
				if v.Field(i).Type().String() == "time.Time" {
					timeVal, _ := cell.GetTime(false)
					v.Field(i).Set(reflect.ValueOf(timeVal))
				}
				// Add more cases as needed
			}
		}
	}
	return nil

}

func (upload *UploadService) bindRowToSpecialOffersData(row *xlsx.Row, customerUpload *bulkupload.SpecialOffer, headerMapping map[string]int, responseSheetRow *xlsx.Row) error {
	// Create a map to store cell values
	cellValues := make(map[string]string)

	// Store cell values based on header indices
	for header, idx := range headerMapping {
		if idx < len(row.Cells) {
			cellValues[header] = row.Cells[idx].String()
		}
	}

	// Create a slice to store values in the order of headers
	orderedValues := getOrderValues(cellValues, headerMapping)

	// Add values to responseSheetRow in the correct order
	for _, value := range orderedValues {
		responseSheetRow.AddCell().Value = value
	}

	// Populate customerUpload fields based on header mapping
	for header, value := range cellValues {
		columnKey := utils.ConvertToSnakeCase(header)
		switch columnKey {
		case "client_loan_id":
			customerUpload.ClientLoanId = value
		case "offer_type":
			customerUpload.OfferType = value
		case "waiver_type":
			customerUpload.WaiverType = value
		case "waiver_value":
			waiverValue, err := strconv.ParseFloat(value, 64)
			if err != nil {
				return fmt.Errorf("invalid waiver value: %v", err)
			}
			customerUpload.WaiverValue = waiverValue
		case "minimum_payment_amount":
			minimumPaymentAmount, err := strconv.ParseFloat(value, 64)
			if err != nil {
				return fmt.Errorf("invalid minimum payment amount: %v", err)
			}
			customerUpload.MinimumPaymentAmount = minimumPaymentAmount
		case "offer_status":
			customerUpload.Status = value
		case "start_datetime":
			customerUpload.StartDateTime = value
		case "end_datetime":
			customerUpload.EndDateTime = value
		}
	}

	return nil
}
func getOrderValues(cellValues map[string]string, headerMapping map[string]int) []string {
	// Create a slice to store values in the order of headers
	// Length of the slice is the maximum index value found in headerMapping + 1
	maxIndex := 0
	for _, idx := range headerMapping {
		if idx > maxIndex {
			maxIndex = idx
		}
	}
	orderedValues := make([]string, maxIndex+1)

	// Populate the orderedValues slice based on headerMapping
	for header, idx := range headerMapping {
		if idx < len(orderedValues) {
			orderedValues[idx] = cellValues[header]
		}
	}

	return orderedValues
}

func getHeaderRow(sheet *xlsx.Sheet, responseSheet *xlsx.Sheet) map[string]int {
	headerMapping := make(map[string]int)
	headerRow := responseSheet.AddRow()
	for idx, header := range sheet.Rows[0].Cells {
		headerName := header.String()
		if !utils.IsEmpty(headerName) {
			headerCell := headerRow.AddCell()
			headerCell.Value = headerName
			headerMapping[headerName] = idx
		}
	}
	// Add the "Upload Status" header
	statusHeader := "UPLOAD STATUS"
	headerCell := headerRow.AddCell()
	headerCell.Value = statusHeader
	headerMapping[statusHeader] = len(headerRow.Cells) - 1

	return headerMapping
}

func headerColumnMapping(row *xlsx.Row) map[string]int {
	columnMapping := make(map[string]int)
	for idx, cell := range row.Cells {
		columnMapping[cell.String()] = idx
	}
	return columnMapping
}
