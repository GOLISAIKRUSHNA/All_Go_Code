package ticket

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"

	//"collection-service/internal/dto/response"

)

type ITicketService interface {
	services.IBaseService
	CreateTicket(ctx context.Context, request request.CreateTicket) error
	UpdateTicket(ctx context.Context, ticketRefNumber string, request request.UpdateTicket) error
	GetTicketsWithPagination(ctx context.Context, request request.TicketListReq) response.TicketListData
	AllocateTicketToAgent(ctx context.Context, request request.AllocateTicket) error
}
