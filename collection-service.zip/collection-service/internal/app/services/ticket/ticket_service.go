package ticket

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"errors"
	"strings"
	"time"

	"gorm.io/datatypes"
	"gorm.io/gorm"
)

type ClientConfig struct {
	ClientRefNumber   string `json:"client_ref_number"`
	CaseLevel         string `json:"case_level"`
	ApplyPaymentLogic string `json:"apply_payment_logic"`
	LogoUrl           string `json:"logo_url"`
	Name              string `json:"name"`
	DailyCallsLimit   int    `json:"daily_calls_limit"`
}
type TicketService struct {
	repositories.BaseRepo
	services.BaseService
	ticketRepo                repo_interfaces.ITicketRepository
	agentRepo                 repo_interfaces.IAgentRepository
	caseBlockService          _case.ICaseBlockService
	caseRepo                  repo_interfaces.ICaseRepository
	clientServiceProviderRepo repo_interfaces.IClientServiceProviderRepository
	lastAllocatedAgentIndex   int
}

func InitTicketService(ctx context.Context) *TicketService {

	service := &TicketService{
		ticketRepo:                repositories.InitTicketRepository(ctx),
		agentRepo:                 repositories.InitAgentRepository(ctx),
		caseBlockService:          _case.InitCaseBlockService(ctx),
		caseRepo:                  repositories.InitCaseRepository(ctx),
		clientServiceProviderRepo: repositories.InitClientServiceProviderRepository(ctx),
	}

	return service
}

/*
Create Ticket : when case is blocked ticket will get created
@return: error
@author: Tejas Surve
*/
func (t *TicketService) CreateTicket(ctx context.Context, ticketReq request.CreateTicket) error {
	logger.Info(ctx, "TicketService|CreateTicket|Request", logger.LogFields{"request": ticketReq})

	ticket, err := t.ticketRepo.FindOne(ctx, models.Tickets{CaseRefNumber: ticketReq.CaseRefNumber, Status: enum.TICKET_ACTIVE})
	if err != nil && err != gorm.ErrRecordNotFound {
		return err
	} else if err == nil && !utils.IsEmpty(ticket.TicketRefNumber) {
		return errors.New("ticket already created for this case:" + ticketReq.CaseRefNumber)
	}

	createTicket := models.Tickets{
		CaseRefNumber:    ticketReq.CaseRefNumber,
		AgentRefNumber:   ticketReq.AgentRefNumber,
		Status:           enum.TICKET_ACTIVE,
		Action:           ticketReq.Action,
		ExtendedDatetime: ticketReq.ExtendedDatetime,
		Comment:          ticketReq.Comment, // need to create comment in comment service and save id here
	}
	ticketModel, createErr := t.ticketRepo.Create(ctx, &createTicket)
	if createErr != nil {
		return err
	}

	allocateTicket := request.AllocateTicket{
		TicketRefNumber: ticketModel.TicketRefNumber,
		CaseRefNumber:   ticketModel.CaseRefNumber,
		Status:          ticketModel.Status.String(),
	}
	t.AllocateTicketToAgent(ctx, allocateTicket)
	return nil
}

/*
Update Ticket: ticket info will get updated by agent
@return: error
@author: Tejas Surve
*/
func (t *TicketService) UpdateTicket(ctx context.Context, ticketRefNumber string, ticketReq request.UpdateTicket) error {
	logger.Info(ctx, "TicketService|UpdateTicket|Request", logger.LogFields{"request": ticketReq})
	ticketStatus := enum.TICKET_ACTIVE
	ticket, err := t.ticketRepo.FindOne(ctx, models.Tickets{TicketRefNumber: ticketRefNumber, Status: enum.TICKET_ACTIVE})
	if err != nil {
		return err
	}
	if ticketReq.Action.String() != "" {
		if validateErr := ticketReq.Validate(); validateErr != nil {
			return validateErr
		}
		blockedUntil := time.Time{}
		if ticketReq.ExtendedDatetime != "" {
			blockedUntil = utils.StringToDateTime(ticketReq.ExtendedDatetime)
		}
		updateCaseBlockParams := request.UpdateBlockCase{
			CaseRefNumber:   ticket.CaseRefNumber,
			BlockedUntil:    blockedUntil,
			Action:          ticketReq.Action.String(),
			TicketRefNumber: ticketRefNumber,
		}
		updateCaseBlockErr := t.caseBlockService.UpdateCaseBlockData(ctx, updateCaseBlockParams, ticket.CaseRefNumber)
		if updateCaseBlockErr != nil {
			return updateCaseBlockErr
		}
		ticketStatus = enum.TICKET_CLOSED
	}

	updateTicketParams := models.Tickets{
		Status:           ticketStatus,
		Action:           ticketReq.Action,
		ExtendedDatetime: utils.StringToDateTime(ticketReq.ExtendedDatetime),
		Comment:          ticketReq.Comment,
		IssueId:          ticketReq.IssueId,
		SubIssueId:       ticketReq.SubIssueId,
		ClosedAt:         time.Now(),
		ClosedBy:         ticketReq.AgentRefNumber,
	}
	_, ticketErr := t.ticketRepo.Update(ctx, &updateTicketParams, models.Tickets{TicketRefNumber: ticketRefNumber})

	if ticketErr != nil {
		return ticketErr
	}
	// publish ticket created_event
	updateTicketParams.TicketRefNumber = ticketRefNumber
	adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, updateTicketParams, "ticket_updated", nil)

	return nil
}

/*
Get Case block list
@return case_block_list[]
@author Tejas Surve
*/
func (t *TicketService) GetTicketsWithPagination(ctx context.Context, req request.TicketListReq) response.TicketListData {
	logger.Info(ctx, "TicketService|GetTicketsWithPagination", logger.LogFields{"request": req})
	where := models.Tickets{
		AgentRefNumber:  req.AgentRefNumber,
		CaseRefNumber:   req.CaseRefNumber,
		TicketRefNumber: req.TicketRefNumber,
		Status:          enum.TICKET_ACTIVE,
	}

	extraFilter := request.TicketListFilter{
		PageNo:               req.PageNo,
		SortByBlockedDate:    req.SortByBlockedDate,
		SortByTotalDueAmount: req.SortByTotalDueAmount,
		IsIssueFilled:        req.IsIssueFilled,
		IsSubIssueFilled:     req.IsSubIssueFilled,
		Default:              req.Default,
	}
	if req.SubIssueIds != "" {
		extraFilter.SubIssueIds = utils.ConvertCommaSeperatedStringToIntSlice(req.SubIssueIds)
	}
	if req.IssueIds != "" {
		extraFilter.IssueIds = utils.ConvertCommaSeperatedStringToIntSlice(req.IssueIds)
	}
	if req.Reason != "" {
		extraFilter.BlockedReason = utils.ConvertCommaSeperatedStringToIntSlice(req.Reason)
	}
	if req.Source != "" {
		extraFilter.BlockedSource = strings.Split(req.Source, ",")
	}
	list, totalRecords, err := t.ticketRepo.GetTicketListWithPaginate(ctx, where, extraFilter)

	listResponse := t.mapToResponseList(ctx, list)
	if err != nil || len(list) == 0 {
		listResponse = []response.TicketList{}
	}

	return response.TicketListData{Tickets: listResponse, CurrentPage: req.PageNo, Pages: totalRecords}
}

/*
Map Ticket list model response to response struct
@author: Tejas Surve
*/
func (t *TicketService) mapToResponseList(ctx context.Context, tickets []models.Tickets) []response.TicketList {
	var ticketList []response.TicketList

	for i := range tickets {
		clientConfig := ClientJsonConfigInStruct(ctx, tickets[i].Case.Client.Configuration)
		responseTicket := response.TicketList{
			Ticket: response.Ticket{
				TicketRefNumber:     tickets[i].TicketRefNumber,
				BlockedReason:       tickets[i].CaseBlockList.BlockReasonMaster.Reason,
				BlockSource:         tickets[i].CaseBlockList.BlockReasonMaster.Source.String(),
				BlockedDate:         utils.FormatDateAsYmdhis(tickets[i].CaseBlockList.BlockedAt),
				BlockedBy:           tickets[i].CaseBlockList.BlockedBy,
				BlockedByName:       tickets[i].CaseBlockList.BlockedByData.FirstName + " " + tickets[i].CaseBlockList.BlockedByData.LastName,
				BlockedByRole:       tickets[i].CaseBlockList.BlockedByData.Role,
				BlockedByVisibility: tickets[i].CaseBlockList.BlockedByData.Visibility,
				IssueId:             tickets[i].IssueId,
				SubIssueId:          tickets[i].SubIssueId,
				Action:              tickets[i].Action.String(),
				Mood:                "", // need to get mood from attempt
				CreatedAt:           utils.FormatDateAsYmdhis(tickets[i].CreatedAt),
			},
			Customer: response.Customer{
				CustomerRefNumber:       tickets[i].Case.Customer.CustomerRefNumber,
				ClientCustomerId:        tickets[i].Case.Customer.ClientCustomerId,
				FirstName:               tickets[i].Case.Customer.FirstName,
				LastName:                tickets[i].Case.Customer.LastName,
				PreferredLanguage:       tickets[i].Case.Customer.PreferredLanguage,
				Gender:                  tickets[i].Case.Customer.Gender,
				Age:                     utils.GetAge(tickets[i].Case.Customer.Dob),
				PrimaryContactRefNumber: tickets[i].Case.CaseAttribute.ContactRefNumber,
				Email:                   utils.MaskEmail(tickets[i].Case.Customer.Email),
				MobileNumber:            utils.MaskMobileNumber(tickets[i].Case.Customer.MobileNumber),
			},
			Case: response.Case{
				CaseRefNumber:     tickets[i].Case.CaseRefNumber,
				ClientRefNumber:   tickets[i].Case.ClientRefNumber,
				CustomerRefNumber: tickets[i].Case.CustomerRefNumber,
				Status:            tickets[i].Case.Status.String(),
				CallsLeft:         clientConfig.DailyCallsLimit - tickets[i].Case.CaseAttribute.TodaysCallsAttempted,
				TotalDue:          tickets[i].Case.TotalDue,
				Bucket:            tickets[i].Case.Bucket.String(),
				Product:           tickets[i].Case.Product,
			},
		}
		ticketList = append(ticketList, responseTicket)
	}

	return ticketList
}

func ClientJsonConfigInStruct(ctx context.Context, jsonClientConfig datatypes.JSON) ClientConfig {
	var clientConfig ClientConfig
	jsonData := []byte(jsonClientConfig)
	marshalErr := json.Unmarshal(jsonData, &clientConfig)
	if marshalErr != nil {
		logger.Error(ctx, marshalErr, "TicketService|ClientJsonConfigInStruct|UnmarshalError", logger.LogFields{"config": clientConfig})
		utils.InternalServerError(ctx, marshalErr, "")
	}
	return clientConfig
}

func (t *TicketService) AllocateTicketToAgent(ctx context.Context, ticketReq request.AllocateTicket) error {
	logger.Info(ctx, "TicketService|AllocateTicketToAgent|Request", logger.LogFields{"request": ticketReq})

	// Temp added
	caseData, caseErr := t.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: ticketReq.CaseRefNumber, Status: enum.CASE_ACTIVE})
	if caseErr != nil {
		return caseErr
	}
	clientServiceProvider, providerErr := t.clientServiceProviderRepo.FindOne(ctx, models.ClientServiceProviders{ClientRefNumber: caseData.ClientRefNumber, Intervention: enum.INTREVENTION_CSAT})
	if providerErr != nil {
		return errors.New("client service provider not found")
	}
	ticket, err := t.ticketRepo.FindOne(ctx, models.Tickets{TicketRefNumber: ticketReq.TicketRefNumber, Status: enum.TICKET_ACTIVE})
	if err != nil {
		return err
	}

	// distribute tickeAllocateTicketToAgentt to agent
	activeAgents, agentErr := t.agentRepo.GetAllAgents(ctx, models.Agent{Status: enum.ACTIVE, Role: enum.AGENT_ROLE_CSAT_CALLER, ServiceProviderRefNumber: clientServiceProvider.ServiceProviderRefNumber})
	if agentErr != nil {
		return agentErr
	}
	agentRefNumber := t.getAgentToAllocate(ctx, ticket.TicketRefNumber, activeAgents)
	updateTicket := &models.Tickets{
		AgentRefNumber: agentRefNumber,
	}
	_, updateErr := t.ticketRepo.Update(ctx, updateTicket, models.Tickets{TicketRefNumber: ticketReq.TicketRefNumber})
	if updateErr != nil {
		return updateErr
	}
	return nil
}

/*
getAgentToAllocate: Function to get agent ref which has the fewest tickets assigned
@param: ctx context.Context, ticketRefNumber string, activeAgents []models.Agent
@return: string agentRefNumber
@Author: Tejas Surve
*/
func (t *TicketService) getAgentToAllocate(ctx context.Context, ticketRefNumber string, activeAgents []models.Agent) string {
	logger.Info(ctx, "TicketService|getAgentToAllocate|Request", logger.LogFields{"ticketRefNumber": ticketRefNumber, "activeAgents": len(activeAgents)})
	// Find the agents with the fewest tickets assigned
	var minTicketAgents []string
	var minTicketCount int64
	for i := range activeAgents {
		ticketCount, countErr := t.ticketRepo.GetTicketCountForAgent(ctx, models.Tickets{AgentRefNumber: activeAgents[i].AgentRefNumber})
		if countErr != nil {
			logger.Error(ctx, countErr, "TicketService|getAgentToAllocate|GetTicketCountForAgent", logger.LogFields{"agentRefNumber": activeAgents[i].AgentRefNumber})
		} else {
			if ticketCount < minTicketCount || len(minTicketAgents) == 0 {
				minTicketCount = ticketCount
				minTicketAgents = []string{activeAgents[i].AgentRefNumber}
			} else if ticketCount == minTicketCount {
				minTicketAgents = append(minTicketAgents, activeAgents[i].AgentRefNumber)
			}
		}
	}

	// Allocate agents in a round-robin manner
	if len(minTicketAgents) > 0 {
		// Get the index of the last allocated agent
		lastAllocatedIndex := t.getLastAllocatedAgentIndex()

		// Calculate the index of the next agent to allocate
		nextIndex := (lastAllocatedIndex + 1) % len(minTicketAgents)

		// Update the last allocated agent index
		t.updateLastAllocatedAgentIndex(nextIndex)

		// Return the reference number of the selected agent
		return minTicketAgents[nextIndex]
	}

	// Handle the case when there are no agents with the fewest tickets assigned
	return "" // or return an error
}

/*
Tranform to event stuct: Function to transform ticket data to event struct
@Author: Tejas Surve
*/

func transformModelToTicketEvent(ticketModel models.Tickets) events.TicketCreated {
	return events.TicketCreated{
		TicketRefNumber: ticketModel.TicketRefNumber,
		CaseRefNumber:   ticketModel.CaseRefNumber,
		AgentRefNumber:  ticketModel.AgentRefNumber,
		Status:          ticketModel.Status.String(),
		Comment:         ticketModel.Comment,
	}
}

// getLastAllocatedAgentIndex returns the index of the last allocated agent.
func (t *TicketService) getLastAllocatedAgentIndex() int {
	return t.lastAllocatedAgentIndex
}

// updateLastAllocatedAgentIndex updates the index of the last allocated agent.
func (t *TicketService) updateLastAllocatedAgentIndex(index int) {
	t.lastAllocatedAgentIndex = index
}
