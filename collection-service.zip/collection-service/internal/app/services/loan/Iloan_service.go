package loan

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type ILoanService interface {
	services.IBaseService

	FindLoan(ctx context.Context, user_id string) map[string]interface{}
	Create(ctx context.Context, loanReq request.CreateUpdateLoanRequest) (response.Loan, error)
	ApplyPaymentToLoan(ctx context.Context, payment dto.ApplyPayment) bool
	LoanWithdrawal(ctx context.Context, loan request.LoanWithdrawalReq) error
}
