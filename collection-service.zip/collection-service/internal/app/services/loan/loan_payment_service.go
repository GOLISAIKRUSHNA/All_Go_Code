package loan

import (
	"collection-service/common/logger"
	"encoding/json"
	"fmt"
	"math"
	"strings"

	"collection-service/internal/adapter/aws"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/special_offer"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"

	"github.com/spf13/viper"
	"gorm.io/gorm"
)

type LoanPaymentService struct {
	services.BaseService
	repo                repo_interfaces.ILoanPaymentRepository
	cacheEnabled        bool
	loanRepo            repo_interfaces.ILoanRepository
	caseRepo            repo_interfaces.ICaseRepository
	customerRepo        repo_interfaces.ICustomerRepository
	clientRepo          repo_interfaces.IClientRepository
	loanService         ILoanService
	specialOfferService special_offer.ISpecialOfferService
	awsImport           aws.S3Client
}
type ClientConfig struct {
	ClientRefNumber   string `json:"client_ref_number"`
	CaseLevel         string `json:"case_level"`
	ApplyPaymentLogic string `json:"apply_payment_logic"`
	LogoUrl           string `json:"logo_url"`
	Name              string `json:"name"`
}

// Initialization of LoanPaymentService with respect to the interface ILoanPaymentService
// Accepts only context as a parameter and hardcodes the loanKey, searchKey and cacheEnabled from .env variables
// Returns the LoanPaymentService pointer instance to the caller
func InitLoanPaymentService(ctx context.Context, loanService ILoanService) *LoanPaymentService {
	service := &LoanPaymentService{
		repo:                repositories.InitLoanPaymentRepository(ctx),
		cacheEnabled:        viper.GetBool("REDIS_ENABLED"),
		loanRepo:            repositories.InitLoanRepository(ctx),
		clientRepo:          repositories.InitClientRepository(ctx),
		caseRepo:            repositories.InitCaseRepository(ctx),
		customerRepo:        repositories.InitCustomerRepository(ctx),
		loanService:         loanService,
		awsImport:           *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
		specialOfferService: special_offer.InitSpecialOfferService(ctx, repositories.InitSpecialOfferRepo(ctx), repositories.InitSpecialOffersMasterRepo(ctx), repositories.InitLoanRepository(ctx)),
	}

	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}
	return service
}

/*
CreateLoanPayment: Entry in loan payment table and calculate apply logic
@Return : response.LoanPayment
@author : Tejas Surve
*/
func (lp *LoanPaymentService) CreateLoanPayment(ctx context.Context, loanPaymentReq request.LoanPayment) (response.LoanPayment, error) {
	logger.Info(ctx, "LoanPaymentService|CreateLoanPayment|Input", logger.LogFields{"input": loanPaymentReq})

	res := response.LoanPayment{}

	//Check payment exist with ClientPaymentId
	var paymentSearch = models.LoanPayment{
		ClientPaymentId:  loanPaymentReq.ClientPaymentId,
		PaymentRefNumber: loanPaymentReq.PaymentRefNumber,
	}

	result, err := lp.repo.FindByReferenceNumberOne(ctx, &paymentSearch)

	if err != nil {
		if err != gorm.ErrRecordNotFound {
			logger.Info(ctx, "LoanPaymentService|CreateLoanPayment|DBerr", logger.LogFields{"error": err})
			utils.InternalServerError(ctx, err, "")
		}
	}
	if utils.IsNotEmpty(result.ClientPaymentId) {
		logger.Info(ctx, "LoanPaymentService|CreateLoanPayment|Loan Payment already exist", logger.LogFields{"result": result})
		res = mapToLoanPaymentResponse(result)
	} else {

		// Prepare loanpayment request info and create loanpayment record
		var loanSearch = models.Loan{
			ClientLoanId:  loanPaymentReq.ClientLoanId,
			LoanRefNumber: loanPaymentReq.LoanRefNumber,
		}
		loanResult, err := lp.loanRepo.FindByReferenceNumberOne(ctx, loanSearch)
		if err != nil {
			return response.LoanPayment{}, err
		}
		// check any offers on loan

		if loanPaymentReq.PaymentReason == "SETTLEMENT" || loanPaymentReq.PaymentReason == "DUES_WAIVER" {
			offers, _ := lp.specialOfferService.GetSpecialOffers(ctx, loanResult.CaseRefNumber)
			//offers will apply only payment via ramp payment system
			if len(offers.SpecialOffers) > 0 && utils.IsNotEmpty(loanPaymentReq.PaymentRefNumber) {
				loanPaymentReq.LoanRefNumber = loanResult.LoanRefNumber
				loanPaymentReq.ClientRefNumber = loanResult.ClientRefNumber
				lp.handleOfferPayment(ctx, loanPaymentReq, offers.SpecialOffers)
			} else {
				lp.processPayment(ctx, loanPaymentReq, loanResult.LoanRefNumber, false)
			}
		} else {

			lp.processPayment(ctx, loanPaymentReq, loanResult.LoanRefNumber, false)
		}

	}
	return res, nil
}

func (lp *LoanPaymentService) handleOfferPayment(ctx context.Context, loanPaymentReq request.LoanPayment, offers []response.SpecialOfferRespInfo) (offerApplied bool) {
	offerApplied = false
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("recovered from panic: %v", r)
			logger.Error(ctx, err, "loanPaymentService|handleOfferPayment|panic", logger.LogFields{})
			offerApplied = false
		}
	}()
	for i := range offers {
		paymentDateTime := utils.StringToDateTime(loanPaymentReq.PaymentDatetime)
		if (paymentDateTime.Before(utils.StringToDateTime(offers[i].StartDatetime)) || paymentDateTime.After(utils.StringToDateTime(offers[i].EndDatetime))) && offers[i].LoanRefNumber != loanPaymentReq.LoanRefNumber {
			logger.Info(ctx, "loanPaymentService|handleOfferPayment|offerNotMatched", logger.LogFields{"loan_ref_number": loanPaymentReq.LoanRefNumber, "offer": offers[0].SpecialOfferRefNumber})
			return false
		}
		logger.Info(ctx, "loanPaymentService|handleOfferPayment|offer_data", logger.LogFields{"offer": offers[i]})
		if offers[i].OfferType == enum.DUES_WAIVER.String() {
			if loanPaymentReq.PaymentAmount == offers[i].TotalDueDiscounted || isPaymentNearby(loanPaymentReq.PaymentAmount, offers[i].TotalDueDiscounted) {
				paymentAmount := loanPaymentReq.PaymentAmount
				fmt.Println("***************paymentAmount", paymentAmount)
				//now create & apply discounted payment
				wavierPayment := offers[i].TotalDue - offers[i].TotalDueDiscounted
				if wavierPayment > 0 {
					loanPaymentReq.ClientPaymentId = utils.GenerateRandomString(8, "OF")
					loanPaymentReq.AppliedTowardsFees = wavierPayment
					loanPaymentReq.IsWaiver = true
					lp.processPayment(ctx, loanPaymentReq, loanPaymentReq.LoanRefNumber, true)
				}
				remainingPayment := offers[i].TotalDue - wavierPayment // or offers[i].TotalDue - waierPayment

				//create & apply recived payment
				if remainingPayment > 0 {
					loanPaymentReq.PaymentAmount = remainingPayment
					fmt.Println("***************remainingpay", remainingPayment)
					lp.processPayment(ctx, loanPaymentReq, loanPaymentReq.LoanRefNumber, false)
				}

				offerApplied = true

			}
		} else if offers[i].OfferType == enum.SETTLEMENT.String() && offers[i].LoanRefNumber == loanPaymentReq.LoanRefNumber {
			if loanPaymentReq.PaymentAmount == offers[i].TotalDueDiscounted || isPaymentNearby(loanPaymentReq.PaymentAmount, offers[i].TotalDueDiscounted) {
				paymentAmount := loanPaymentReq.PaymentAmount
				fmt.Println("***************paymentAmount", paymentAmount)
				//now first apply recived payment
				lp.processPayment(ctx, loanPaymentReq, loanPaymentReq.LoanRefNumber, false)

				//apply waiver payment
				wavierPayment := offers[i].TotalDue - paymentAmount
				if wavierPayment > 0 {
					loanPaymentReq.ClientPaymentId = utils.GenerateRandomString(8, "OF")
					loanPaymentReq.PaymentAmount = wavierPayment
					loanPaymentReq.IsWaiver = true
					lp.processPayment(ctx, loanPaymentReq, loanPaymentReq.LoanRefNumber, false)

				}

				offerApplied = true
			}
		}
		if !offerApplied { //map payment as it is
			//lp.processPayment(ctx, loanPaymentReq, loanPaymentReq.LoanRefNumber, false)
		}
	}
	return offerApplied
}

func (lp *LoanPaymentService) processPayment(ctx context.Context, loanPaymentReq request.LoanPayment, loanRefNumber string, specificApply bool) {
	// Save loan payment
	loanPaymentModel := mapRequestToLoanPaymentModel(loanPaymentReq, loanRefNumber)
	resultData, err := lp.repo.Create(ctx, loanPaymentModel)
	if err != nil {
		logger.Error(ctx, err, "LoanPaymentService|insertPayment|Loan Payment Not Created", logger.LogFields{"create_input": resultData})
		utils.InternalServerError(ctx, err, "")
	}
	/* Calculate data for payment apply and update loanpayment and loan */
	payment := mapLoanPaymentModelToApplyPayment(loanPaymentModel, loanRefNumber, specificApply)
	lp.ApplyPayment(ctx, payment)
}

/*
ApplyPayment : Func calculate -- Payment amount will apply applied_towards_principal,applied_towards_interest,applied_towards_fees,
update calculated IPD again loan payment & loan
@Return dto.ApplyPayment
@author Tejas Surve
*/
func (lp *LoanPaymentService) ApplyPayment(ctx context.Context, payment dto.ApplyPayment) dto.ApplyPayment {
	logger.Info(ctx, "LoanPaymentService|ApplyPayment|Input", logger.LogFields{"input": payment})
	response := payment
	//Get Loan data for loan information
	loanSearch := models.Loan{
		LoanRefNumber: payment.LoanRefNumber,
	}
	loan, err := lp.loanRepo.FindByReferenceNumberOne(ctx, loanSearch)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}
	// check sum of ineterest, principal, fees matching with payment amount
	ipdTotal := payment.AppliedTowardsInterest + payment.AppliedTowardsPrincipal + payment.AppliedTowardsFees
	if ipdTotal != payment.PaymentAmount {
		response.ClientPaymentId = payment.ClientPaymentId
		response.LoanRefNumber = payment.LoanRefNumber
		response.PaymentAmount = payment.PaymentAmount

		client, err := lp.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: loan.ClientRefNumber})
		if err != nil {
			utils.InternalServerError(ctx, err, "")
		}
		//if !utils.IsNotEmpty(client.Configuration) {
		//	panic("Client Configuration is not present")
		//}
		var clientConfig ClientConfig
		jsonData := []byte(client.Configuration)
		marshalErr := json.Unmarshal(jsonData, &clientConfig)
		if marshalErr != nil {
			logger.Error(ctx, marshalErr, "LoanPaymentService|ApplyPayment|UnmarshalError", logger.LogFields{"config": client.Configuration})
			utils.InternalServerError(ctx, marshalErr, "")
		}
		// calculatedIPD func calculate interest, principal, dues based on ApplyPaymentLogic input

		calculatedIPD := lp.ApplyPaymentLogic(ctx, payment, *loan, clientConfig.ApplyPaymentLogic)
		// Update new calculated data to loan payment
		where := models.LoanPaymentWhereParams{
			ClientPaymentId: payment.ClientPaymentId,
		}
		loanPaymentModel := models.LoanPayment{
			AppliedTowardsPrincipal: calculatedIPD.AppliedTowardsPrincipal,
			AppliedTowardsInterest:  calculatedIPD.AppliedTowardsInterest,
			AppliedTowardsFees:      calculatedIPD.AppliedTowardsFees,
		}
		lp.repo.Update(ctx, loanPaymentModel, where)

		//Updating response fields
		response = calculatedIPD
	} else {
		calculatedIPD := lp.ApplyPaymentLogic(ctx, payment, *loan, "PID")
		response = calculatedIPD
	}
	// update new calculated data to loan
	lp.loanService.ApplyPaymentToLoan(ctx, response)

	return response
}

/*
ApplyPaymentLogic : Based on client apply logic calculate apply towards interest, principal,dues amount
@response : response.ApplyPayment
@author Tejas Surve
*/
func (lp *LoanPaymentService) ApplyPaymentLogic(ctx context.Context, payment dto.ApplyPayment, loan models.Loan, logic string) dto.ApplyPayment {
	logger.Info(ctx, "LoanPaymentService|ApplyPaymentLogic|Input", logger.LogFields{"input": payment, "logic": logic})
	response := dto.ApplyPayment{
		ClientPaymentId: payment.ClientPaymentId,
		LoanRefNumber:   payment.LoanRefNumber,
		PaymentAmount:   payment.PaymentAmount,
		ClientRefNumber: payment.ClientRefNumber,
	}

	applylogic := []rune(logic)
	balanceAmount := payment.PaymentAmount
	// Calulation based on applylogic IPD, PID
	for _, applyOn := range applylogic {
		// Check if there's any interest due
		if loan.TotalInterestDue > 0 && string(applyOn) == "I" {
			if balanceAmount >= loan.TotalInterestDue {
				balanceAmount -= loan.TotalInterestDue
				response.AppliedTowardsInterest = loan.TotalInterestDue
			} else {
				response.AppliedTowardsInterest = balanceAmount
				balanceAmount = 0
			}
		}

		// If there's any balance amount left after paying interest, reduce the principal
		if balanceAmount > 0 && loan.TotalPrincipalDue > 0 && string(applyOn) == "P" {
			if balanceAmount >= loan.TotalPrincipalDue {
				balanceAmount -= loan.TotalPrincipalDue
				response.AppliedTowardsPrincipal = loan.TotalPrincipalDue
			} else {
				response.AppliedTowardsPrincipal = balanceAmount
				balanceAmount = 0
			}
		}
		// If there's any balance amount left after paying principal, reduce the total fees
		if balanceAmount > 0 && loan.TotalFeesDue > 0 && string(applyOn) == "D" {
			if balanceAmount >= loan.TotalFeesDue {
				balanceAmount -= loan.TotalFeesDue
				response.AppliedTowardsFees = loan.TotalFeesDue
			} else {
				response.AppliedTowardsFees = balanceAmount
				balanceAmount = 0
			}
		}
	}
	logger.Info(ctx, "LoanPaymentService|ApplyPaymentLogic|CalculatedAmount", logger.LogFields{"response": response, "logic": logic})
	return response
}

/*
GetPayableDetails : Fetch payable details based on filter [CaseRefNumber, LoanRefNumber]
@response : response.PayableData
@author Tejas Surve
*/
func (lp *LoanPaymentService) GetPayableDetails(ctx context.Context, request request.PayableDetails) response.PayableData {
	logger.Info(ctx, "LoanPaymentService|GetPayableDetails|Input", logger.LogFields{"input": request})

	response := response.PayableData{}

	//Get Customer info for loan or case
	customer := lp.GetCustomerInfo(ctx, request)
	if utils.IsNotEmpty(customer.CustomerRefNumber) {

		//Get Client Info
		clientWhere := &models.Client{
			ClientRefNumber: customer.ClientRefNumber,
		}
		client, clErr := lp.clientRepo.FindByReferenceNumberOne(ctx, clientWhere)
		if clErr != nil {
			logger.Error(ctx, clErr, "LoanPaymentService|GetPayableDetails|getClient", logger.LogFields{"where": clientWhere})
		}

		where := models.Loan{
			CaseRefNumber: request.CaseRefNumber,
			LoanRefNumber: request.LoanRefNumber,
		}
		loans, err := lp.loanRepo.Get(ctx, where)
		if err != nil {
			logger.Info(ctx, "LoanPaymentService|GetPayableDetails", logger.LogFields{"err": err})
		}
		response := lp.mapToPayableDetails(ctx, customer, client, loans)
		return response
	}
	return response
}

func (lp *LoanPaymentService) mapToPayableDetails(ctx context.Context, customer response.Customer, client *models.Client, loans []models.Loan) response.PayableData {

	logoUrl, err := lp.awsImport.GetSharableURL(ctx, client.LogoUrl, constants.CLIENT_AWS_BUCKET)
	if err != nil {
		logger.Error(ctx, err, "LoanPaymentService|mapToPayableDetails|err", logger.LogFields{})
	}
	payableDetails := response.PayableDetails{
		ClientRefNumber:      client.ClientRefNumber,
		ClientName:           client.Name,
		LogoUrl:              logoUrl,
		ClientCustomerId:     customer.ClientCustomerId,
		CustomerName:         customer.FirstName + " " + customer.LastName,
		CustomerMobileNumber: utils.MaskMobileNumber(customer.MobileNumber),
		CustomerEmail:        customer.Email,
	}
	//Calculate Total amount of Payable, Principal, Interest, Fees
	for i := range loans {
		payableDetails.PayableAmount = payableDetails.PayableAmount + loans[i].TotalDue
		payableDetails.PrincipalAmount = payableDetails.PrincipalAmount + loans[i].TotalPrincipalDue
		payableDetails.InterestAmount = payableDetails.InterestAmount + loans[i].TotalInterestDue
		payableDetails.FeesAmount = payableDetails.FeesAmount + loans[i].TotalFeesDue
		loansData := response.Loans{
			ClientLoanId:      loans[i].ClientLoanId,
			LoanRefNumber:     loans[i].LoanRefNumber,
			CaseRefNumber:     loans[i].CaseRefNumber,
			TotalDue:          loans[i].TotalDue,
			NoOfEmisUnpaid:    loans[i].NoOfEmisUnpaid,
			TotalPrincipalDue: loans[i].TotalPrincipalDue,
			TotalInterestDue:  loans[i].TotalInterestDue,
			TotalFeesDue:      loans[i].TotalFeesDue,
		}
		payableDetails.Loans = append(payableDetails.Loans, loansData)
	}
	return response.PayableData{
		PayableDetails: payableDetails,
	}
}

/*
GetCustomerInfo : Get customer information based on filter
filter [CaseRefNumber, LoanRefNumber]
@return : response.Customer
@author Tejas Surve
*/
func (lp *LoanPaymentService) GetCustomerInfo(ctx context.Context, filter request.PayableDetails) response.Customer {
	logger.Info(ctx, "LoanPaymentService|GetCustomerInfo|Input", logger.LogFields{"input": filter})

	customerResponse := response.Customer{}
	customerWhere := models.CustomerWhereParams{}

	if utils.IsNotEmpty(filter.CaseRefNumber) {
		//Get Case information
		caseWhere := models.Case{
			CaseRefNumber: filter.CaseRefNumber,
		}
		caseResp, err := lp.caseRepo.FindByReferenceNumberOne(ctx, caseWhere)
		if err != nil {
			logger.Info(ctx, "LoanPaymentService|GetCustomerInfo|Error", logger.LogFields{"err": err, "input": caseWhere})
		}
		customerWhere.CustomerRefNumber = caseResp.CustomerRefNumber
	} else if utils.IsNotEmpty(filter.LoanRefNumber) {
		//Get Loan information
		loanWhere := models.Loan{
			LoanRefNumber: filter.LoanRefNumber,
		}
		loanResp, err := lp.loanRepo.FindByReferenceNumberOne(ctx, loanWhere)
		if err != nil {
			logger.Info(ctx, "LoanPaymentService|GetCustomerInfo|Error", logger.LogFields{"err": err, "input": loanWhere})
		}
		customerWhere.CustomerRefNumber = loanResp.CustomerRefNumber
	}

	//Get Customer information
	if utils.IsNotEmpty(customerWhere.CustomerRefNumber) {
		customer, err := lp.customerRepo.FindOne(ctx, customerWhere)
		if err != nil {
			logger.Info(ctx, "LoanPaymentService|GetCustomerInfo|Error", logger.LogFields{"input": customerWhere, "error": err})
		}
		customerResponse = transformToCustomerResponse(customer)
	}
	return customerResponse
}

/*
HandlePaymentEvent : Handle Payment success event and create loan payment
@return : error
@author Tejas Surve
*/
func (lp *LoanPaymentService) HandleLoanPayment(ctx context.Context, paymentReq events.PaymentStatusEvent) error {
	logger.Info(ctx, "LoanPaymentService|handleLoanPayment|input", logger.LogFields{"request": paymentReq})
	//loanpayment required client_payment_id // ramp payment dont have that so generating
	uniquePaymentId, err := utils.GenerateRandomBytes(8)
	if err != nil {
		return err
	}
	if (paymentReq.PaymentReason == "LOAN_PAYMENT" || paymentReq.PaymentReason == "SETTLEMENT" || paymentReq.PaymentReason == "DUES_WAIVER") && paymentReq.Status == "SUCCESS" {
		if paymentReq.PaymentFor == "LOAN" {

			loanPaymentReq := request.LoanPayment{
				ClientPaymentId:  strings.ToUpper("FPAY" + uniquePaymentId),
				PaymentRefNumber: paymentReq.PaymentRefNumber,
				LoanRefNumber:    paymentReq.PaymentForRefNumber,
				PaymentReason:    paymentReq.PaymentReason,
				PaymentGateway:   paymentReq.Partner,
				PaymentAmount:    paymentReq.Amount,
				PaymentDatetime:  utils.FormatDateTime(paymentReq.FinalStatusDatetime),
				CreatedBy:        paymentReq.CreatedBy,
			}
			_, paymentErr := lp.CreateLoanPayment(ctx, loanPaymentReq)
			if paymentErr != nil {
				return paymentErr
			}
		} else if paymentReq.PaymentFor == "CASE" {
			//Get loans from case
			loans, loanErr := lp.loanRepo.Get(ctx, models.Loan{CaseRefNumber: paymentReq.PaymentForRefNumber})
			if loanErr != nil {
				return loanErr
			}
			paymentAmount := paymentReq.Amount
			var amountToApply float64
			loanRefNumber := ""
			// Calculate the sum of columns
			for _, loan := range loans {
				if paymentAmount > 0 && paymentAmount <= loan.TotalDue {
					amountToApply = paymentAmount
					loanRefNumber = loan.LoanRefNumber
					paymentAmount = 0 // here we are aplying all payment to loan
				} else if paymentAmount > 0 && paymentAmount > loan.TotalDue {
					amountToApply = loan.TotalDue
					paymentAmount = paymentAmount - loan.TotalDue
					loanRefNumber = loan.LoanRefNumber
				}
				if amountToApply > 0 && loanRefNumber != "" {
					loanPaymentReq := request.LoanPayment{
						ClientPaymentId:  "FPAY" + uniquePaymentId,
						PaymentRefNumber: paymentReq.PaymentRefNumber,
						PaymentReason:    paymentReq.PaymentReason,
						LoanRefNumber:    loanRefNumber,
						PaymentGateway:   paymentReq.Partner,
						PaymentAmount:    amountToApply,
						PaymentDatetime:  utils.FormatDateTime(paymentReq.FinalStatusDatetime),
						CreatedBy:        paymentReq.CreatedBy,
					}
					_, paymentErr := lp.CreateLoanPayment(ctx, loanPaymentReq)
					if paymentErr != nil {
						return paymentErr
					}
				}
			}
		}
	}
	return nil
}

func transformToCustomerResponse(customer *models.Customer) response.Customer {
	custResp := response.Customer{
		ClientCustomerId:  customer.ClientCustomerId,
		CustomerRefNumber: customer.CustomerRefNumber,
		ClientRefNumber:   customer.ClientRefNumber,
		FirstName:         customer.FirstName,
		LastName:          customer.LastName,
		CustomerName:      customer.FirstName + " " + customer.LastName,
		PreferredLanguage: customer.PreferredLanguage,
		MobileNumber:      customer.MobileNumber,
		Email:             customer.Email,
		CreatedBy:         customer.CreatedBy,
	}

	return custResp
}

func mapToLoanPaymentResponse(loanPayment *models.LoanPayment) response.LoanPayment {
	return response.LoanPayment{
		LoanPaymentRefNumber:    loanPayment.LoanPaymentRefNumber,
		ClientPaymentId:         loanPayment.ClientPaymentId,
		PaymentRefNumber:        loanPayment.PaymentRefNumber,
		LoanRefNumber:           loanPayment.LoanRefNumber,
		PaymentDatetime:         loanPayment.PaymentDatetime,
		PaymentAmount:           loanPayment.PaymentAmount,
		AppliedTowardsPrincipal: loanPayment.AppliedTowardsPrincipal,
		AppliedTowardsInterest:  loanPayment.AppliedTowardsInterest,
		AppliedTowardsFees:      loanPayment.AppliedTowardsFees,
	}
}

func mapRequestToLoanPaymentModel(lpRequest request.LoanPayment, loanRefNumber string) models.LoanPayment {
	return models.LoanPayment{
		ClientPaymentId:         lpRequest.ClientPaymentId,
		PaymentRefNumber:        lpRequest.PaymentRefNumber,
		LoanRefNumber:           loanRefNumber,
		PaymentGateway:          lpRequest.PaymentGateway,
		PaymentDatetime:         lpRequest.PaymentDatetime,
		PaymentAmount:           lpRequest.PaymentAmount,
		AppliedTowardsPrincipal: lpRequest.AppliedTowardsPrincipal,
		AppliedTowardsInterest:  lpRequest.AppliedTowardsInterest,
		AppliedTowardsFees:      lpRequest.AppliedTowardsFees,
		IsWaiver:                lpRequest.IsWaiver,
	}
}

func mapLoanPaymentModelToApplyPayment(lpModel models.LoanPayment, ClientRefNumber string, specificApply bool) dto.ApplyPayment {
	return dto.ApplyPayment{
		ClientPaymentId:         lpModel.ClientPaymentId,
		LoanRefNumber:           lpModel.LoanRefNumber,
		PaymentAmount:           lpModel.PaymentAmount,
		AppliedTowardsPrincipal: lpModel.AppliedTowardsPrincipal,
		AppliedTowardsInterest:  lpModel.AppliedTowardsInterest,
		AppliedTowardsFees:      lpModel.AppliedTowardsFees,
		ClientRefNumber:         ClientRefNumber,
		IsSpecificApply:         specificApply,
	}
}

func isPaymentNearby(paymentAmount float64, offerAmount float64) bool {
	diff := math.Abs(paymentAmount - offerAmount)
	return diff <= 5
}
