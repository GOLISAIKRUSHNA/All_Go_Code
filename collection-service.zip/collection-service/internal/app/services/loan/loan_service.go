package loan

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/aws"
	"collection-service/internal/adapter/rabbit_mq"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/spf13/viper"
	"gorm.io/gorm"
)

type LoanService struct {
	services.BaseService
	repo                   repo_interfaces.ILoanRepository
	loanKey                string
	searchKey              string
	cacheEnabled           bool
	customerService        customer.ICustomerService
	caseService            _case.ICaseService
	customerInfoRepo       repo_interfaces.ICustomerInfoRepository
	collateralRepo         repo_interfaces.ILoanCollateralRepository
	borrowersRepo          repo_interfaces.ILoanBorrowerRepository
	addressRepo            repo_interfaces.ICustomerAddressRepository
	referenceRepo          repo_interfaces.ILoanReferenceRepository
	finRepo                repo_interfaces.IFinancierRepository
	documentRepo           repo_interfaces.ICustomerDocsRepository
	awsS3                  aws.S3Client
	customerContactService customer.ICustomerContactService
	customerAddressService customer.ICustomerAddressService
}

type ExtraParams struct {
	LoanRefNumber     string
	CustomerRefNumber string
	CreatedBy         string
}

// Initialization of LoanService with respect to the interface ILoanService
// Accepts only context as a parameter and hardcodes the loanKey, searchKey and cacheEnabled from .env variables
// Returns the LoanService pointer instance to the caller
func InitLoanService(ctx context.Context, caseService _case.ICaseService) *LoanService {
	service := &LoanService{
		repo:                   repositories.InitLoanRepository(ctx),
		loanKey:                "loan",
		searchKey:              "loan_search",
		cacheEnabled:           viper.GetBool("REDIS_ENABLED"),
		customerService:        customer.InitCustomerService(ctx),
		caseService:            caseService,
		customerInfoRepo:       repositories.InitCustomerInfoRepository(ctx),
		collateralRepo:         repositories.InitLoanCollateralRepository(ctx),
		borrowersRepo:          repositories.InitLoanBorrowerRepository(ctx),
		addressRepo:            repositories.InitCustomerAddressRepository(ctx),
		referenceRepo:          repositories.InitLoanReferenceRepository(ctx),
		finRepo:                repositories.InitFinancierRepository(ctx),
		awsS3:                  *aws.InitS3Client(ctx, aws.InitAWSSession(ctx)),
		documentRepo:           repositories.InitCustomerDocsRepository(ctx),
		customerContactService: customer.InitCustomerContactService(ctx),
		customerAddressService: customer.InitCustomerAddressService(ctx),
	}

	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}
	return service
}

func (s *LoanService) FindLoan(ctx context.Context, loan_reference_number string) map[string]interface{} {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "LoanService.FindLoan"); span != nil {
		defer span.End()
	}

	result, err := s.repo.FindById(ctx, loan_reference_number, constants.READ_DATABASE_TYPE)
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			utils.ValidationError(ctx, []dto.RequestDetails{
				{
					Field:   "Loan ID",
					Message: "Loan ID is not valid",
				},
			})
		}
		panic(err)
	}

	return result
}

/*
- This func accept request.CreateUpdateLoanRequest, Create Customer, Loan, collaterals, borrowers, references as per input
- return 201
- @author Tejas Surve
*/
func (s *LoanService) Create(ctx context.Context, loanReq request.CreateUpdateLoanRequest) (response.Loan, error) {
	logger.Info(ctx, "LoanService|Create|Input", logger.LogFields{"input": loanReq})
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	response := response.Loan{}

	if err := s.validateLoanRequest(loanReq); err != nil {
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, constants.GetErrMsg(constants.VALIDATION_ERROR_CODE), err, nil)
	}
	//Create and Update Customer
	isMapped, custRefNo := s.mapCustomer(ctx, loanReq, "customer")

	if !isMapped {
		cuError := errors.New("customer is not created")
		logger.Error(ctx, cuError, "LoanService|Create|mapCustomer|Err", logger.LogFields{"input": loanReq.Customer})
		return response, cuError
	}

	//Checking loan entry present with requested ClientLoanId
	var loanSearch = models.Loan{
		ClientLoanId:    loanReq.Loan.ClientLoanId,
		ClientRefNumber: loanReq.ClientRefNumber,
	}
	result, err := s.repo.FindByReferenceNumberOne(ctx, loanSearch)

	if err != nil {
		if err != gorm.ErrRecordNotFound {
			return response, err
		}
	}
	if utils.IsNotEmpty(result.ClientLoanId) {

		// Record present update Loan values
		params := models.Loan{
			ClientLoanId: loanReq.Loan.ClientLoanId,
		}
		//Transforming request to model (struct binding)
		loanModel := s.getLoanModelFromRequest(ctx, loanReq, "UPDATE")
		isUpdated, err := s.repo.Update(ctx, loanModel, params)
		if err != nil {
			return response, err
		}
		if isUpdated {
			//Publish events after loan update
			loanEvent := events.LoanEvent{
				CustomerRefNumber:   result.CustomerRefNumber,
				LoanRefNumber:       result.LoanRefNumber,
				ClientRefNumber:     loanReq.ClientRefNumber,
				CollectionFor:       loanModel.CollectionFor,
				ClientTeamRefNumber: loanReq.ClientTeamRefNumber,
			}
			s.publishLoanEvent(ctx, "loan_updated", loanEvent)
			//Create or Update other info of loan [customer, borrower, collateral, address]
			extraParams := ExtraParams{
				LoanRefNumber:     result.LoanRefNumber,
				CustomerRefNumber: result.CustomerRefNumber,
			}
			//s.SaveCustomerInfo(ctx, loanReq, extraParams)
			s.SaveLoanReferences(ctx, loanReq, extraParams)
			s.SaveLoanBorrowers(ctx, loanReq, extraParams)
			s.SaveLoanCollaterals(ctx, loanReq, extraParams)
			s.SaveLoanAddress(ctx, loanReq, extraParams)
			s.saveCustomerDocuments(ctx, loanReq, extraParams)
		}
	} else {
		//Create new loan entry
		if isMapped {
			loanReq.Customer.CustomerRefNumber = custRefNo
		}
		//Transforming request to model (struct binding)
		loanModel := s.getLoanModelFromRequest(ctx, loanReq, "CREATE")
		resultData, err := s.repo.Create(ctx, loanModel)
		if err != nil {
			return response, err
		}
		if utils.IsNotEmpty(resultData.ClientLoanId) {

			//Publish events after loan creation
			loanEvent := events.LoanEvent{
				CustomerRefNumber:         resultData.CustomerRefNumber,
				LoanRefNumber:             resultData.LoanRefNumber,
				ClientRefNumber:           resultData.ClientRefNumber,
				CollectionFor:             loanModel.CollectionFor,
				MandateRazorpayCustomerID: loanReq.Loan.MandateRazorpayCustomerID,
				MandateRazorpayToken:      loanReq.Loan.MandateRazorpayToken,
				BankName:                  loanReq.Loan.BankName,
				BankAccountNo:             loanReq.Loan.BankAccountNo,
				ClientTeamRefNumber:       loanReq.ClientTeamRefNumber,
			}

			s.publishLoanEvent(ctx, "loan_created", loanEvent)
			//Create or Update other info of loan [customer, borrower, collateral, address]
			extraParams := ExtraParams{
				LoanRefNumber:     resultData.LoanRefNumber,
				CustomerRefNumber: resultData.CustomerRefNumber,
			}
			s.SaveCustomerInfo(ctx, loanReq, extraParams)
			s.SaveLoanReferences(ctx, loanReq, extraParams)
			s.SaveLoanBorrowers(ctx, loanReq, extraParams)
			s.SaveLoanCollaterals(ctx, loanReq, extraParams)
			s.SaveLoanAddress(ctx, loanReq, extraParams)
		}
	}
	return response, nil
}

/*
mapCustomer : Calling customerService create/update func for customer operation
@author Tejas Surve
*/
func (l *LoanService) mapCustomer(ctx context.Context, input request.CreateUpdateLoanRequest, customerType string) (bool, string) {

	logger.Info(ctx, "LoanService|mapCustomer|Input", logger.LogFields{"input": input.Customer})
	isMapped := false
	customerRefNo := ""

	//Check customer entry present for requested client_ref_number
	searchCustomer := models.CustomerWhereParams{
		ClientCustomerId: input.Customer.ClientCustomerId,
		ClientRefNumber:  input.ClientRefNumber,
	}

	customer, err := l.customerService.GetCustomer(ctx, searchCustomer)
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			logger.Error(ctx, err, "LoanService|mapCustomer|Get Customer call", logger.LogFields{"err": err, "customer": customer})
			utils.InternalServerError(ctx, err, "")
		}
		logger.Info(ctx, "LoanService|mapCustomer|Get Customer call", logger.LogFields{"err": err, "customer": customer})
	}
	customerReq := request.CustomerReq{
		ClientCustomerId:  input.Customer.ClientCustomerId,
		ClientRefNumber:   input.ClientRefNumber,
		FirstName:         input.Customer.FirstName,
		LastName:          input.Customer.LastName,
		MobileNumber:      input.Customer.MobileNumber,
		PreferredLanguage: utils.CapitalizeFirstLetterAfterComma(input.Customer.PreferredLanguage),
		Email:             input.Customer.Email,
		Dob:               utils.StringToDate(input.Customer.Dob),
		Gender:            input.Customer.Gender,
		CreatedBy:         input.CreatedBy,
	}
	if customer.CustomerRefNumber != "" && err == nil {
		//Update customer
		customerRefNo = customer.CustomerRefNumber
		l.customerService.Update(ctx, customerReq, customer.ClientCustomerId)

		//create & update customer contact
		if customerType == "customer" {
			contactReq := transformRequestToCustomerContact(customer)
			l.customerContactService.AddCustomerContact(ctx, contactReq)
		}

		isMapped = true
	} else if err == gorm.ErrRecordNotFound && len(input.Customer.MobileNumber) != 0 {
		//Create New Customer
		customer, err := l.customerService.Create(ctx, customerReq)
		if err != nil {
			isMapped = false
			logger.Error(ctx, err, "LoanService|mapCustomer|Create Customer Error", logger.LogFields{"input": customerReq})
		} else {

			//create & update customer contact
			if customerType == "customer" {
				contactReq := transformRequestToCustomerContact(customer)
				l.customerContactService.AddCustomerContact(ctx, contactReq)
			}

			isMapped = true
			customerRefNo = customer.CustomerRefNumber
		}
	}

	return isMapped, customerRefNo
}

/*
SaveCustomerInfo : Store customer information
@author Tejas Surve
*/
func (s *LoanService) SaveCustomerInfo(ctx context.Context, input request.CreateUpdateLoanRequest, exParams ExtraParams) {
	logger.Info(ctx, "LoanService|SaveCustomerInfo|Input", logger.LogFields{"input": input})

	if utils.IsNotEmpty(input.CustomerInfo.EmploymentType) && utils.IsNotEmpty(input.CustomerInfo.EmployerName) && input.CustomerInfo.CibilScore > 0 {
		customerInfoReq := models.CustomerInfo{
			CustomerRefNumber: exParams.CustomerRefNumber,
			LoanRefNumber:     exParams.LoanRefNumber,
			EmploymentType:    input.CustomerInfo.EmploymentType,
			EmployerName:      input.CustomerInfo.EmployerName,
			MonthlyIncome:     input.CustomerInfo.MonthlyIncome,
			Occupation:        input.CustomerInfo.Occupation,
			CibilScore:        input.CustomerInfo.CibilScore,
		}
		s.customerInfoRepo.Create(ctx, customerInfoReq)
	}
}

/*
Save Loan references from loan
@author Tejas Surve
*/
func (s *LoanService) SaveLoanReferences(ctx context.Context, input request.CreateUpdateLoanRequest, exParams ExtraParams) {
	logger.Info(ctx, "LoanService|SaveLoanReferences|Input", logger.LogFields{"input": input.References})
	for _, ref := range input.References {
		where := models.LoanReference{
			ContactNumber: ref.ContactNumber,
			LoanRefNumber: exParams.LoanRefNumber,
		}
		refReq := models.LoanReference{
			CustomerRefNumber: exParams.CustomerRefNumber,
			LoanRefNumber:     exParams.LoanRefNumber,
			FirstName:         ref.FirstName,
			LastName:          ref.LastName,
			ContactNumber:     ref.ContactNumber,
			Relation:          ref.Relation,
			CreatedBy:         input.CreatedBy,
		}
		referenceExist, err := s.referenceRepo.FindByReferenceNumberOne(ctx, where)
		if err != nil {
			if err != gorm.ErrRecordNotFound {
				logger.Error(ctx, err, "LoanService|SaveLoanReferences|FetchReferenceError", logger.LogFields{"request": refReq})
				utils.InternalServerError(ctx, err, "")
			}
		}
		if referenceExist.LoanRefNumber != "" {
			s.referenceRepo.Update(ctx, refReq, where)
		} else {
			s.referenceRepo.Create(ctx, refReq)
		}
	}
}

/*
SaveLoanBorrowers: Create/Update loan Borrowers
-- Create customer entry using borrower mobilenumber
@author Tejas Surve
*/
func (s *LoanService) SaveLoanBorrowers(ctx context.Context, input request.CreateUpdateLoanRequest, exParams ExtraParams) {
	logger.Info(ctx, "LoanService|SaveLoanBorrowers|Input", logger.LogFields{"input": input.Borrowers})

	//List of borrowers will create entry indivisually
	for _, borrower := range input.Borrowers {
		BorrowerCustomerRefNumber := ""

		// We are creating customer from borrower details
		input.Customer.FirstName = borrower.FirstName
		input.Customer.LastName = borrower.LastName
		input.Customer.MobileNumber = borrower.MobileNumber
		input.Customer.ClientCustomerId = ""
		created, custRefNumber := s.mapCustomer(ctx, input, "borrower")

		if created {
			BorrowerCustomerRefNumber = custRefNumber
			where := models.LoanBorrower{
				LoanRefNumber:             exParams.LoanRefNumber,
				BorrowerCustomerRefNumber: BorrowerCustomerRefNumber,
			}
			borrowerReq := models.LoanBorrower{
				BorrowerCustomerRefNumber: BorrowerCustomerRefNumber,
				LoanRefNumber:             exParams.LoanRefNumber,
				Type:                      borrower.Type,
				RelationWithPrimary:       borrower.RelationWithPrimary,
				CreatedBy:                 input.CreatedBy,
			}
			//Check borrower record
			borroweExist, err := s.borrowersRepo.FindByReferenceNumberOne(ctx, where)
			if err != nil {
				if err != gorm.ErrRecordNotFound {
					logger.Error(ctx, err, "LoanService|SaveLoanBorrowers|Error while fetching borrowers", logger.LogFields{"input": borrowerReq})
					utils.InternalServerError(ctx, err, "")
				}
			}
			if utils.IsNotEmpty(borroweExist.BorrowerCustomerRefNumber) {
				//Updating borrower details if already present
				s.borrowersRepo.Update(ctx, borrowerReq, where)
			} else {
				//Creating new borrower
				s.borrowersRepo.Create(ctx, borrowerReq)
			}
		}
	}
}

/*
SaveLoanCollaterals :
Create/Update collatarel entries for LoanRefNumber and PrimaryIdentifierType
@author Tejas Surve
*/
func (s *LoanService) SaveLoanCollaterals(ctx context.Context, input request.CreateUpdateLoanRequest, exParams ExtraParams) {
	logger.Info(ctx, "LoanService|SaveLoanCollaterals|Input", logger.LogFields{"input": input.Collaterals})

	for _, collateral := range input.Collaterals {
		where := models.LoanCollateral{
			LoanRefNumber:         exParams.LoanRefNumber,
			CustomerRefNumber:     exParams.CustomerRefNumber,
			PrimaryIdentifierType: collateral.PrimaryIdentifierType,
			PrimaryIdentifier:     collateral.PrimaryIdentifier,
		}
		collateralReq := models.LoanCollateral{
			CustomerRefNumber:        exParams.CustomerRefNumber,
			LoanRefNumber:            exParams.LoanRefNumber,
			Type:                     collateral.Type,
			Value:                    collateral.Value,
			Description:              collateral.Description,
			PrimaryIdentifierType:    collateral.PrimaryIdentifierType,
			PrimaryIdentifier:        collateral.PrimaryIdentifier,
			AdditionalIdentifierType: collateral.AdditionalIdentifierType,
			AdditionalIdentifier:     collateral.AdditionalIdentifier,
			MakeAndModel:             collateral.MakeAndModel,
			CreatedBy:                input.CreatedBy,
		}

		//Check Collateral record is present
		collateralExist, err := s.collateralRepo.FindByReferenceNumberOne(ctx, where)
		if err != nil {
			if err != gorm.ErrRecordNotFound {
				logger.Error(ctx, err, "LoanService|SaveLoanCollaterals|Erro", logger.LogFields{"input": collateralReq})
				utils.InternalServerError(ctx, err, "")
			}
		}
		if collateralExist.LoanRefNumber != "" {
			s.collateralRepo.Update(ctx, collateralReq, where)
		} else {
			s.collateralRepo.Create(ctx, collateralReq)
		}
	}
}

/*
Save Customer Documents
- Upload document on s3 & save path in table
@author Tejas Surve
*/
func (l *LoanService) saveCustomerDocuments(ctx context.Context, input request.CreateUpdateLoanRequest, exParams ExtraParams) {
	//logger.Info(ctx, "LoanService|saveCustomerDocuments|Input", logger.LogFields{"input": input.Documents})

	for _, doc := range input.Documents {

		//Check existing document
		where := models.CustomerDocument{
			LoanRefNumber:     exParams.LoanRefNumber,
			CustomerRefNumber: exParams.CustomerRefNumber,
			Type:              doc.Photo,
		}
		documentExist, err := l.documentRepo.FindCustomerDocument(ctx, where)
		if err != gorm.ErrRecordNotFound && err != nil {
			logger.Error(ctx, err, "LoanService|saveCustomerDocuments|DBError", logger.LogFields{"input": where.CustomerRefNumber})
		}

		//Create/Update Input
		docReq := models.CustomerDocument{
			CustomerRefNumber: exParams.CustomerRefNumber,
			LoanRefNumber:     exParams.LoanRefNumber,
			Type:              doc.Photo,
			CreatedBy:         exParams.CreatedBy,
		}

		contentType, errTypeErr := utils.GetBase64ContentType(doc.Base64Encode)
		if errTypeErr != nil {
			logger.Error(ctx, err, "LoanService|saveCustomerDocuments|contentTypeError", logger.LogFields{"filepath": doc.Photo})
		}
		extention := strings.Split(contentType, "/")
		docReq.FilePath = exParams.CustomerRefNumber + "/" + utils.GenerateRandomString(6, doc.Photo+"_") + "." + extention[1]
		if err == gorm.ErrRecordNotFound {
			uploadErr := l.awsS3.UploadBase64Image(ctx, docReq.FilePath, constants.CUSTOMER_DOCUMENTS_AWS_BUCKET, doc.Base64Encode, contentType)
			if uploadErr == nil {
				l.documentRepo.Create(ctx, docReq)
			} else {
				logger.Error(ctx, err, "LoanService|saveCustomerDocuments|create.uploadError", logger.LogFields{"file": doc.Base64Encode})
			}
		}
		if utils.IsNotEmpty(documentExist.DocumentRefNumber) {
			// Get existing document
			s3Base64Encode, s3Err := l.awsS3.GetImageBase64Encode(ctx, constants.CUSTOMER_DOCUMENTS_AWS_BUCKET, documentExist.FilePath)
			if s3Err != nil {
				logger.Error(ctx, err, "LoanService|saveCustomerDocuments|Error", logger.LogFields{"filepath": documentExist.FilePath})
			} else {
				if s3Base64Encode != doc.Base64Encode {
					uploadErr := l.awsS3.UploadBase64Image(ctx, docReq.FilePath, constants.CUSTOMER_DOCUMENTS_AWS_BUCKET, doc.Base64Encode, contentType)
					if uploadErr == nil {
						where.DocumentRefNumber = documentExist.DocumentRefNumber
						l.documentRepo.Update(ctx, docReq, where)
					} else {
						logger.Error(ctx, err, "LoanService|saveCustomerDocuments|update.uploadError", logger.LogFields{"file": doc.Base64Encode})
					}
				}
			}
		}
	}
}

/*
Payment Map to loan
Update loan record based on applylogic
*/
func (l *LoanService) ApplyPaymentToLoan(ctx context.Context, payment dto.ApplyPayment) bool {
	logger.Info(ctx, "LoanService|ApplyPaymentToLoan|Input", logger.LogFields{"input": payment})
	applied := false

	//Fetch loan details
	where := models.Loan{
		LoanRefNumber: payment.LoanRefNumber,
	}
	loans, err := l.repo.FindByReferenceNumberOne(ctx, where)
	if err != nil {
		panic(err)
	}

	logger.Info(ctx, "LoanService|ApplyPaymentToLoan|loans", logger.LogFields{"loans": loans})

	//Update loan data as per input
	updateParams := make(map[string]interface{})
	totalDue := loans.TotalDue
	if payment.AppliedTowardsInterest > 0 && loans.TotalInterestDue > 0 {
		updateParams["TotalInterestDue"] = loans.TotalInterestDue - payment.AppliedTowardsInterest
		totalDue = totalDue - payment.AppliedTowardsInterest
	}
	if payment.AppliedTowardsPrincipal > 0 && loans.TotalPrincipalDue > 0 {
		updateParams["TotalPrincipalDue"] = loans.TotalPrincipalDue - payment.AppliedTowardsPrincipal
		totalDue = totalDue - payment.AppliedTowardsPrincipal
	}
	if payment.AppliedTowardsFees > 0 && loans.TotalFeesDue > 0 {
		updateParams["TotalFeesDue"] = loans.TotalFeesDue - payment.AppliedTowardsFees
		totalDue = totalDue - payment.AppliedTowardsFees
	}
	updateParams["TotalDue"] = totalDue
	loanUpdate := l.repo.UpdateWithMap(ctx, updateParams, where)
	if loanUpdate {
		applied = true
		loanEvent := events.LoanEvent{
			CustomerRefNumber: loans.CustomerRefNumber,
			LoanRefNumber:     loans.LoanRefNumber,
			ClientRefNumber:   loans.ClientRefNumber,
			Status:            loans.Status,
			CollectionFor:     enum.FOR_TOTAL_DUE,
		}
		adapter.PublishEvent(ctx, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY}, loanEvent, "loan_updated", nil)
	} else {
		utils.InternalServerError(ctx, "Error while applying payment to loan", "")
	}

	//After update we can call events OR sync case
	caseRequest := request.GenerateCase{
		CustomerRefNumber: loans.CustomerRefNumber,
		ClientRefNumber:   loans.ClientRefNumber,
		Level:             "LOAN", //need to be configure
	}
	l.caseService.GenerateCase(ctx, caseRequest)
	return applied
}

/* SaveLoanAddress : Save Address list save from request
 */
func (s *LoanService) SaveLoanAddress(ctx context.Context, input request.CreateUpdateLoanRequest, exParams ExtraParams) {
	logger.Info(ctx, "LoanService|SaveLoanAddress|Input", logger.LogFields{"input": input.Addresses, "extra_params": exParams})

	for _, addr := range input.Addresses {

		//need to generate location fromm address value

		customerAddrReq := request.CreateAddressRequest{
			CustomerRefNumber: exParams.CustomerRefNumber,
			LoanRefNumber:     exParams.LoanRefNumber,
			Label:             addr.Label,
			Type:              addr.Type,
			ResidentType:      addr.ResidentType,
			Source:            addr.Source,
			Line1:             addr.Line1,
			Line2:             addr.Line2,
			Line3:             addr.Line3,
			Landmark:          addr.Landmark,
			Pincode:           addr.Pincode,
			AddressMedium:     addr.Medium,
			AddressQuality:    addr.Quality,
			City:              addr.City,
			State:             addr.State,
			Country:           addr.Country,
			CreatedBy:         input.CreatedBy,
			UpdatedBy:         input.CreatedBy,
			Latitude:          addr.Lat,
			Longitude:         addr.Long,
			IsPrimary:         true,
		}
		_, err := s.customerAddressService.CreateAddress(ctx, customerAddrReq)
		if err != nil {
			logger.Error(ctx, err, "LoanService|SaveLoanAddress", logger.LogFields{"address_event": customerAddrReq})
		}

	}
}

func (s *LoanService) getLoanModelFromRequest(ctx context.Context, req request.CreateUpdateLoanRequest, action string) models.Loan {

	req.Loan.CollectionFor = enum.FOR_TOTAL_DUE
	earliestUnpaidEmiDate, err := utils.ParseDate(req.Loan.EarliestUnpaidEmiDate)
	if err != nil {
		logger.Error(ctx, err, "LoanService|getLoanModelFromRequest|dateParseErr", logger.LogFields{})
	}
	earliestUnpaidEmiDate, dpd := calculateDpdAndUnpaidEmaiDate(ctx, req.Loan.CurrentDpd, earliestUnpaidEmiDate)
	//calculateEMIsDue
	firstEmiDate, err := utils.ParseDate(req.Loan.FirstEmiDate)
	if err != nil {
		logger.Error(ctx, err, "LoanService|getLoanModelFromRequest|firstEmiDateDateParseErr", logger.LogFields{})
	}
	emisDue := calculateEMIsDue(ctx, firstEmiDate, earliestUnpaidEmiDate, req.Loan.Tenure, req.Loan.TenureType)
	//for credit card loans
	dueDateAsString := utils.StringToDate(req.Loan.DueDate)
	if req.Loan.Product == enum.PRODUCT_CC {
		if earliestUnpaidEmiDate == (time.Time{}) {
			earliestUnpaidEmiDate = dueDateAsString
		}
		creditCardColumnsCalculation(req.Loan.CurrentDpd, &req.Loan)
	}

	data := models.Loan{
		ClientLoanId:                req.Loan.ClientLoanId,
		CreditCardNo:                req.Loan.CreditCardNo,
		ClientRefNumber:             req.ClientRefNumber,
		CustomerRefNumber:           req.Customer.CustomerRefNumber,
		LoanAmount:                  req.Loan.LoanAmount,
		Tenure:                      req.Loan.Tenure,
		TenureType:                  req.Loan.TenureType,
		InterestRate:                req.Loan.InterestRate,
		EmiAmount:                   req.Loan.EmiAmount,
		Product:                     req.Loan.Product,
		SubProduct:                  req.Loan.SubProduct,
		DisbursementAmount:          req.Loan.DisbursementAmount,
		DisbursementDate:            req.Loan.DisbursementDate,
		DueDate:                     dueDateAsString,
		FirstEmiDate:                req.Loan.FirstEmiDate,
		LastEmiDate:                 req.Loan.LastEmiDate,
		EarliestUnpaidEmiDate:       earliestUnpaidEmiDate,
		BillTotalPaymentDue:         req.Loan.BillTotalPaymentDue,
		BillMinPaymentDue:           req.Loan.BillMinPaymentDue,
		BillStatementGenerationDate: req.Loan.BillStatementGenerationDate,
		CreditLimit:                 req.Loan.CreditLimit,
		AvailableCreditLimit:        req.Loan.AvailableCreditLimit,
		Status:                      req.Loan.Status,
		TotalDue:                    req.Loan.TotalDue,
		TotalPrincipalDue:           req.Loan.TotalPrincipalDue,
		TotalInterestDue:            req.Loan.TotalInterestDue,
		TotalFeesDue:                req.Loan.TotalFeesDue,
		TotalOutstanding:            req.Loan.TotalOutstanding,
		TotalPrincipalOutstanding:   req.Loan.TotalPrincipalOutstanding,
		TotalInterestOutstanding:    req.Loan.TotalInterestOutstanding,
		TotalFeesOutstanding:        req.Loan.TotalFeesOutstanding,
		TotalPrincipalPaid:          req.Loan.TotalPrincipalPaid,
		TotalInterestPaid:           req.Loan.TotalInterestPaid,
		TotalFeesPaid:               req.Loan.TotalFeesPaid,
		NoOfEmisPaid:                req.Loan.NoOfEmisPaid,
		NoOfEmisUnpaid:              emisDue,
		CurrentDpd:                  dpd,
		MaxDpd:                      req.Loan.MaxDpd,
		PaymentLink:                 req.Loan.PaymentLink,
		CreatedBy:                   req.CreatedBy,
		UpdatedBy:                   req.CreatedBy,
		CollectionFor:               req.Loan.CollectionFor,
		ActiveFinancierRefNumber:    req.Loan.ActiveFinancierRefNumber,
	}
	if action == "CREATE" {
		data.LoanRefNumber = utils.GenerateRandomString(6, "LO")
	}
	if utils.IsNotEmpty(req.Loan.ActiveFinancierName) && utils.IsEmpty(req.Loan.ActiveFinancierRefNumber) {
		finSearch := models.Financier{
			Name: req.Loan.ActiveFinancierName,
		}
		activeFin, errAf := s.finRepo.FindByReferenceNumberOne(ctx, finSearch)
		if errAf != nil {
			logger.Info(ctx, "Error while fetching active financier", logger.LogFields{"input": finSearch, "error": errAf})
		}
		if utils.IsNotEmpty(activeFin.FinancierRefNumber) {
			data.ActiveFinancierRefNumber = activeFin.FinancierRefNumber
		}
	}
	if utils.IsNotEmpty(req.Loan.SecondaryFinancierName) {
		finSearch := models.Financier{
			Name: req.Loan.SecondaryFinancierName,
		}
		secondFin, errSf := s.finRepo.FindByReferenceNumberOne(ctx, finSearch)
		if errSf != nil {
			logger.Info(ctx, "Error while fetching active financier", logger.LogFields{"input": finSearch, "error": errSf})
		}
		if utils.IsNotEmpty(secondFin.FinancierRefNumber) {
			data.SecondaryFinancierRefNumber = secondFin.FinancierRefNumber
		}
	}
	return data
}

func creditCardColumnsCalculation(currentDpd int, loan *request.Loan) {
	loan.LoanAmount = loan.BillTotalPaymentDue
	loan.EmiAmount = loan.BillTotalPaymentDue
	//DPD calculation will changed based on client config
	if currentDpd >= 1 && currentDpd <= 30 {
		loan.TotalPrincipalDue = loan.BillMinPaymentDue
		loan.TotalPrincipalOutstanding = loan.BillTotalPaymentDue
		loan.TotalFeesDue = 234                                                            //calculate daily basis on the total_principal_outstading
		loan.TotalDue = loan.TotalPrincipalDue + loan.TotalInterestDue + loan.TotalFeesDue // loan.TotalInterestDue = 0 because its already added in fees
		loan.CollectionFor = enum.FOR_TOTAL_DUE
	} else if currentDpd > 30 {
		loan.TotalPrincipalDue = loan.BillTotalPaymentDue
		loan.TotalPrincipalOutstanding = loan.BillTotalPaymentDue
		loan.TotalFeesDue = 500                                                            //calculate daily basis on the total_principal_outstading
		loan.TotalDue = loan.TotalPrincipalDue + loan.TotalInterestDue + loan.TotalFeesDue // loan.TotalInterestDue = 0 because its already added in fees
		loan.CollectionFor = enum.FOR_TOTAL_OUTSTANDING
	}

}

func (s *LoanService) validateLoanRequest(req request.CreateUpdateLoanRequest) error {
	errorMessage := errors.New("validation Error: ")
	fmt.Println()
	if req.Loan.Product == enum.PRODUCT_CC && (req.Loan.BillTotalPaymentDue == 0 || req.Loan.BillMinPaymentDue == 0 || req.Loan.BillStatementGenerationDate == "") {
		newErrorMessage := "BillTotalPaymentDue, BillMinPaymentDue, BillStatementDate, CreditLimit is required when product is CC"
		errorMessage = fmt.Errorf("%w %s", errorMessage, newErrorMessage)
		return errorMessage
	} else {
		return nil
	}
}

/*
- This func accept request.LoanWithdrwalReq
- For now we are assuming one loan have only one case
- return error
- @author Tejas Surve
*/
func (l *LoanService) LoanWithdrawal(ctx context.Context, loanReq request.LoanWithdrawalReq) error {
	logger.Info(ctx, "LoanService|LoanWithdrawal|Input", logger.LogFields{"input": loanReq})

	loanWhere := models.Loan{
		ClientLoanId: loanReq.ClientLoanId,
		Status:       enum.LOAN_ACTIVE,
	}
	loan, loanErr := l.repo.FindByReferenceNumberOne(ctx, loanWhere)
	if loanErr != nil {
		logger.Error(ctx, loanErr, "LoanService|LoanWithdrawal|dbErr", logger.LogFields{"loanId": loanReq.ClientLoanId})
		return loanErr
	}
	//Update loan status
	updateData := models.Loan{
		Status: enum.LOAN_CLOSED,
	}
	_, loanUpdateErr := l.repo.Update(ctx, updateData, models.Loan{LoanRefNumber: loan.LoanRefNumber})
	if loanUpdateErr != nil {
		logger.Error(ctx, loanErr, "LoanService|LoanWithdrawal|dbUpdateErr", logger.LogFields{"loanId": loanReq.ClientLoanId})
		return loanUpdateErr
	}

	//Update case status
	caseErr := l.caseService.CaseWithdrawal(ctx, loan.CaseRefNumber, loanReq.CreatedBy)
	if caseErr != nil {
		return caseErr
	}
	return nil
}

/*
publishGenerateCase : published loan event
publishGenerateCase : published loan events
@author Tejas Surve
*/
func (i *LoanService) publishLoanEvent(ctx context.Context, eventName string, event events.LoanEvent) bool {
	success := false
	eventData := adapter.NewMessage(ctx, eventName, event, "")
	loanEventData, erf := json.Marshal(eventData)
	if erf != nil {
		logger.Error(ctx, erf, "LoanService|publishLoanEvent|err", logger.LogFields{"events": eventData})
	}

	error := rabbit_mq.GetRabbitMQClientInstance(ctx).Publish(ctx,
		constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE,
		[]string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY,
			constants.RMQ_PAYMENT_SERVICE_MAIN_QUEUE_KEY},
		loanEventData,
		nil,
	)
	if error != nil {
		logger.Error(ctx, erf, "LoanService|publishLoanEvent|publishErr", logger.LogFields{"events": eventData})
	}
	return success
}

func transformRequestToCustomerContact(customer response.Customer) request.AddContact {
	return request.AddContact{
		CustomerRefNumber: customer.CustomerRefNumber,
		ContactNumber:     customer.MobileNumber,
		ContactName:       customer.FirstName + " " + customer.LastName,
		ContactOf:         enum.SELF,
		ContactType:       enum.APPLICANT,
		IsPrimary:         true,
		CreatedBy:         customer.CreatedBy,
	}
}

// calculate dpd & earliest emi unpaid date

func calculateDpdAndUnpaidEmaiDate(ctx context.Context, dpd int, earliestUnpaidEMIDate time.Time) (unpaidEMIDate time.Time, dpdFromDate int) {
	currentDate := time.Now()
	// Check if both earliest unpaid EMI date and dpd are present
	if !earliestUnpaidEMIDate.IsZero() && dpd > 0 {
		// Calculate DPD based on earliest unpaid EMI date
		dpdFromDate := int(currentDate.Sub(earliestUnpaidEMIDate).Hours() / 24)

		logger.Info(ctx, "LoanService|calculateDpdAndUnpaidEmaiDate|DPD based on earliest unpaid EMI date:", logger.LogFields{"dpdFromDate": dpdFromDate})
		return earliestUnpaidEMIDate, dpdFromDate

	} else if earliestUnpaidEMIDate.IsZero() && dpd > 0 {
		// Calculate earliest unpaid EMI date
		unpaidEMIDate := time.Now().AddDate(0, 0, -dpd)
		logger.Info(ctx, "LoanService|calculateDpdAndUnpaidEmiDate|earliestUnpaidEMIDate based on dpd:", logger.LogFields{"earliestUnpaidEMIDate": unpaidEMIDate})
		return unpaidEMIDate, dpd
	} else if !earliestUnpaidEMIDate.IsZero() && dpd <= 0 {
		// Calculate DPD based on earliest unpaid EMI date
		daysDifference := int(currentDate.Sub(earliestUnpaidEMIDate).Hours() / 24)

		return earliestUnpaidEMIDate, daysDifference
	}
	return earliestUnpaidEMIDate, dpd
}

func calculateEMIsDue(ctx context.Context, firstEmiDate time.Time, earliestUnpaidEmiDate time.Time, tenure int, tenureType enum.LoanTenure) int {
	logger.Info(ctx, "LoanService|calculateEmisDue|Input", logger.LogFields{"firstEmiDate": firstEmiDate, "earliestUnpaidEmiDate": earliestUnpaidEmiDate, "tenure": tenure, "tenureType": tenureType})

	// Check if earliestUnpaidEmiDate is in the future
	if earliestUnpaidEmiDate.Before(firstEmiDate) {
		logger.Error(ctx, errors.New("earlier unpaid EMI date is greater than the first EMI date"), "LoanService|calculateEMIsDue", logger.LogFields{})
		return 0
	}

	// Initialize duration based on tenure type
	var duration time.Duration
	switch tenureType {
	case enum.TENURE_MONTHLY:
		duration = 30 * 24 * time.Hour
	case enum.TENURE_WEEKLY:
		duration = 7 * 24 * time.Hour
	case enum.TENURE_DAILY:
		duration = 24 * time.Hour
	case enum.TENURE_FORTNIGHTLY:
		duration = 14 * 24 * time.Hour
	case enum.TENURE_BULLET:
		return tenure // For bullet type, all EMIs are due upfront
	default:
		return 0
	}

	// Calculate the difference in duration from the earliest unpaid EMI date to the first EMI date
	diff := earliestUnpaidEmiDate.Sub(firstEmiDate)

	// Calculate number of EMIs due
	emisDue := int(diff/duration) + 1 // Add 1 for the current EMI

	return emisDue
}
