package loan

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type ILoanPaymentService interface {
	services.IBaseService
	CreateLoanPayment(ctx context.Context, loanPaymentReq request.LoanPayment) (response.LoanPayment, error)
	GetPayableDetails(ctx context.Context, payableReq request.PayableDetails) response.PayableData
	HandleLoanPayment(ctx context.Context, paymentData events.PaymentStatusEvent) error
}
