package teams

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type ITeamService interface {
	services.IBaseService
	CreateTeam(ctx context.Context, req request.CreateTeamReq) (*response.CreateTeamRes, error)
	AddUserToTeam(ctx context.Context, req request.AddUserToTeamReq) error
	GetTeams(ctx context.Context, req request.GetTeamsReq) (*response.GetTeamsRes, error)
	RemoveUserFromTeam(ctx context.Context, req request.RemoveUserFromTeamReq) error
}
