package teams

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"errors"

	"github.com/spf13/viper"
)

type TeamService struct {
	services.BaseService
	teamRepo       repo_interfaces.ITeamRepository
	clientUserRepo repo_interfaces.IClientUserRepository
	agentRepo      repo_interfaces.IAgentRepository
	cacheEnabled   bool
}

func InitTeamService(ctx context.Context, teamRepo repo_interfaces.ITeamRepository, clientUserRepo repo_interfaces.IClientUserRepository, agentRepo repo_interfaces.IAgentRepository) *TeamService {
	service := &TeamService{teamRepo: teamRepo, clientUserRepo: clientUserRepo, agentRepo: agentRepo, cacheEnabled: viper.GetBool("REDIS_ENABLED")}
	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}
	return service
}

func (s *TeamService) CreateTeam(ctx context.Context, req request.CreateTeamReq) (*response.CreateTeamRes, error) {
	// create team
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)
	teamModel := transformRequestToTeamModel(req)
	team, err := s.teamRepo.CreateTeam(ctx, teamModel)
	if err != nil {
		utils.InternalServerError(ctx, err, "")
	}

	teamRes := transformTeamResponse(team)
	return teamRes, nil
}

func transformTeamResponse(team *models.Teams) *response.CreateTeamRes {
	teamData := response.TeamDetails{
		TeamRefNumber: team.TeamRefNumber,
		Name:          team.Name,
	}

	return &response.CreateTeamRes{Team: teamData}
}

func transformRequestToTeamModel(req request.CreateTeamReq) *models.Teams {
	data := &models.Teams{
		Name:            req.Name,
		Object:          req.Object,
		ObjectRefNumber: req.ObjectRefNumber,
		CreatedBy:       req.CreatedBy,
	}
	return data
}

func (s *TeamService) AddUserToTeam(ctx context.Context, req request.AddUserToTeamReq) error {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	// if  ClientUsers  is not empty then update team ref number in ClientUsers table
	if len(req.ClientUsers) > 0 {
		// check if client user already added to team or not
		isPresent, err := s.clientUserRepo.CheckIsPresentInTeam(ctx, req.ClientUsers)
		if err != nil {
			utils.InternalServerError(ctx, err, "")
		}
		if isPresent {
			utils.BadRequestException(ctx, "", "Client user already added to team", nil, nil)
		}
		_, err = s.clientUserRepo.UpdateClientUserTeamRefNumber(ctx, req.ClientUsers, req.TeamRefNumber)
		if err != nil {
			utils.InternalServerError(ctx, err, "")
		}
	}

	// if  agents  is not empty then update team ref number in agent table
	if len(req.Agents) > 0 {
		// check if agent already added to team or not
		isPresent, err := s.agentRepo.CheckIsPresentInTeam(ctx, req.Agents)
		if err != nil {
			utils.InternalServerError(ctx, err, "")

		}
		if isPresent {
			utils.BadRequestException(ctx, "", "Agent already added to team", nil, nil)
		}
		_, err = s.agentRepo.UpdateAgentTeamRefNumber(ctx, req.Agents, req.TeamRefNumber)
		if err != nil {
			utils.InternalServerError(ctx, err, "")
		}
	}

	return nil
}

func (s *TeamService) GetTeams(ctx context.Context, req request.GetTeamsReq) (*response.GetTeamsRes, error) {
	// Set database connection type to READ
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	// Transform request to team model
	teamModel := transformToTeamModel(req)

	// Fetch teams from repository
	teams, err := s.teamRepo.GetTeams(ctx, teamModel)
	if err != nil {
		return nil, err
	}

	// Fetch users by team reference numbers based on the object type
	teamRefNumbers := make([]string, len(teams))
	for i, team := range teams {
		teamRefNumbers[i] = team.TeamRefNumber
	}

	var clientUsersMap map[string][]models.ClientUser
	var agentsMap map[string][]models.Agent

	if req.Object == enum.OBJECT_CLIENT {
		clientUsers, err := s.clientUserRepo.FindClientUsersByTeamRefNumbers(ctx, teamRefNumbers)
		if err != nil {
			return nil, err
		}
		clientUsersMap = mapClientUsersToTeams(clientUsers)
	} else if req.Object == enum.OBJECT_SERVICE_PROVIDER {
		agents, err := s.agentRepo.FindAgentsByTeamRefNumbers(ctx, teamRefNumbers)
		if err != nil {
			return nil, err
		}
		agentsMap = mapAgentsToTeams(agents)
	} else {
		return nil, errors.New("invalid object type")
	}

	// Transform teams response
	teamRes := transformTeamsResponse(teams, clientUsersMap, agentsMap, req)
	return teamRes, nil
}

func mapClientUsersToTeams(users []models.ClientUser) map[string][]models.ClientUser {
	usersMap := make(map[string][]models.ClientUser)
	for _, user := range users {
		usersMap[user.ClientTeamRefNumber] = append(usersMap[user.ClientTeamRefNumber], user)
	}
	return usersMap
}

func mapAgentsToTeams(agents []models.Agent) map[string][]models.Agent {
	agentsMap := make(map[string][]models.Agent)
	for _, agent := range agents {
		agentsMap[agent.ServiceProviderTeamRefNumber] = append(agentsMap[agent.ServiceProviderTeamRefNumber], agent)
	}
	return agentsMap
}

func transformTeamsResponse(teams []models.Teams, clientUsersMap map[string][]models.ClientUser, agentsMap map[string][]models.Agent, req request.GetTeamsReq) *response.GetTeamsRes {
	var teamData []response.Team
	for _, team := range teams {
		var clientUsers []response.ClientUserRes
		var agents []response.AgentUserRes

		if req.Object == enum.OBJECT_CLIENT {
			for _, user := range clientUsersMap[team.TeamRefNumber] {
				clientUsers = append(clientUsers, response.ClientUserRes{
					ClientUserRefNumber: user.ClientUserRefNo,
					Name:                user.FirstName + " " + user.LastName,
					Email:               user.Email,
				})
			}
		} else if req.Object == enum.OBJECT_SERVICE_PROVIDER {
			for _, agent := range agentsMap[team.TeamRefNumber] {
				agents = append(agents, response.AgentUserRes{
					AgentRefNumber: agent.AgentRefNumber,
					Name:           agent.FirstName + " " + agent.LastName,
					Email:          agent.Email,
				})
			}
		}

		teamData = append(teamData, response.Team{
			TeamRefNumber: team.TeamRefNumber,
			Name:          team.Name,
			CreatedAt:     team.CreatedAt.Format("2006-01-02 15:04:05"),
			ClientUsers:   clientUsers,
			Agents:        agents,
		})
	}

	return &response.GetTeamsRes{Teams: teamData}
}

func transformToTeamModel(req request.GetTeamsReq) *models.Teams {
	data := &models.Teams{
		Object:          req.Object,
		ObjectRefNumber: req.ObjectRefNumber,
	}
	return data

}

func (s *TeamService) RemoveUserFromTeam(ctx context.Context, req request.RemoveUserFromTeamReq) error {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	// check if user exist or not
	if len(req.ClientUsers) > 0 {
		_, err := s.clientUserRepo.UpdateClientUserTeamRefNumber(ctx, req.ClientUsers, "")
		if err != nil {
			utils.InternalServerError(ctx, err, "")
		}
	}

	// check if agent exist or not
	if len(req.Agents) > 0 {
		_, err := s.agentRepo.UpdateAgentTeamRefNumber(ctx, req.Agents, "")
		if err != nil {
			utils.InternalServerError(ctx, err, "")
		}
	}

	return nil
}
