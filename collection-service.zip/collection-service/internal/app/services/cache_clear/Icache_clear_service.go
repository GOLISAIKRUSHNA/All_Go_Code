package cacheclear

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/events"
	"context"
)

type ICacheClearService interface {
	services.IBaseService
	ClearCacheForLoanUpdateEvent(ctx context.Context, event events.LoanEvent)
	ClearCacheForLoanCreateEvent(ctx context.Context, event events.LoanEvent)
	ClearDispositionCache(ctx context.Context, request events.Disposition)
	ClearContactEventCache(ctx context.Context, request events.CustomerContactCreated)
}
