package cacheclear

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/events"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
)

type CacheClearService struct {
	services.BaseService
	cacheEnabled   bool
	loanRepo       repo_interfaces.ILoanRepository
	allocationRepo repo_interfaces.IAllocationRepository
}

func InitClearCacheService(ctx context.Context) *CacheClearService {
	service := &CacheClearService{
		cacheEnabled:   viper.GetBool("REDIS_ENABLED"),
		loanRepo:       repositories.InitLoanRepository(ctx),
		allocationRepo: repositories.InitAllocationRepository(ctx),
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}
	return service
}

func clearCaseLoanCache(ctx context.Context, request events.LoanEvent, cc CacheClearService) error {
	filter := models.Loan{
		LoanRefNumber: request.LoanRefNumber,
	}
	loan, err := cc.loanRepo.FindByReferenceNumberOne(ctx, filter)
	if err != nil {
		logger.Error(ctx, err, "CacheClearService|ClearCaseLoanCache|FindByReferenceNumberOne error", logger.LogFields{"event_payload": request, "where": filter, "error": err})
		return err
	}

	redisKey := fmt.Sprintf("api:%s:%s:%s", constants.API_CASELOAN, constants.CASE_REF_NUMBER, loan.CaseRefNumber)
	if err := cc.GetCacheInstance().Delete(redisKey, "delete"); err != nil {
		logger.Error(ctx, err, "CacheClearService|ClearCaseLoanCache|LoanRepo|redisService.Delete error", logger.LogFields{"event_payload": request, "redis_key": redisKey, "error": err})
		return err
	}
	return nil
}

func clearCaseListCache(ctx context.Context, request events.LoanEvent, cc CacheClearService) error {
	loanFilter := models.Loan{
		LoanRefNumber: request.LoanRefNumber,
	}

	loan, err := cc.loanRepo.FindByReferenceNumberOne(ctx, loanFilter)
	if err != nil {
		logger.Error(ctx, err, "CacheClearService|ClearCaseListCache|LoanRepo|FindByReferenceNumberOne error", logger.LogFields{"event_payload": request, "where": loanFilter, "error": err})
		return err
	}

	allocationFilter := models.Allocation{
		CaseRefNumber: loan.CaseRefNumber,
	}

	agent, err := cc.allocationRepo.FindByReferenceNumberOne(ctx, allocationFilter)
	if err != nil {
		logger.Error(ctx, err, "CacheClearService|ClearCaseListCache|AllocationRepo|FindByReferenceNumberOne error", logger.LogFields{"event_payload": request, "where": allocationFilter, "error": err})
		return err
	}

	redisKey := fmt.Sprintf("api:%s:%s:%s", constants.API_CASELIST, constants.AGENT_REF_NUMBER, agent.AgentRefNumber)
	if err := cc.GetCacheInstance().DeleteKeysWithPrefix(redisKey); err != nil {
		logger.Error(ctx, err, "CacheClearService|ClearCaseListCache|redisService.DeleteKeysWithPrefix error", logger.LogFields{"event_payload": request, "redis_key": redisKey, "error": err})
		return err
	}
	return nil
}

func clearDispositionListWithCustomerRefNumberCache(ctx context.Context, request events.Disposition, cc CacheClearService) error {
	redisKey := fmt.Sprintf("api:%s:%s:%s", constants.API_DISPOSITION_LIST, constants.CUSTOMER_REF_NUMBER, request.CustomerRefNumber)
	if err := cc.GetCacheInstance().DeleteKeysWithPrefix(redisKey); err != nil {
		logger.Error(ctx, err, "CacheClearService|clearDispositionListWithCustomerRefNumberCache|DeleteKeysWithPrefix error", logger.LogFields{"event_payload": request, "redis_key": redisKey, "error": err})
		return err
	}
	return nil
}

func clearDispositionListWithCaseRefNumberCache(ctx context.Context, request events.Disposition, cc CacheClearService) error {
	redisKey := fmt.Sprintf("api:%s:%s:%s", constants.API_DISPOSITION_LIST, constants.CASE_REF_NUMBER, request.CaseRefNumber)
	if err := cc.GetCacheInstance().DeleteKeysWithPrefix(redisKey); err != nil {
		logger.Error(ctx, err, "CacheClearService|clearDispositionListWithCaseRefNumberCache|DeleteKeysWithPrefix error", logger.LogFields{"event_payload": request, "redis_key": redisKey, "error": err})
		return err
	}
	return nil
}

func (cc CacheClearService) ClearCacheForLoanUpdateEvent(ctx context.Context, event events.LoanEvent) {
	ginCtx, _ := gin.CreateTestContext(nil)
	ginCtx.Request = &http.Request{}

	clearCaseLoanCache(ginCtx, event, cc)
	clearCaseListCache(ginCtx, event, cc)
}

func (cc CacheClearService) ClearCacheForLoanCreateEvent(ctx context.Context, event events.LoanEvent) {
	ginCtx, _ := gin.CreateTestContext(nil)
	ginCtx.Request = &http.Request{}

	clearCaseLoanCache(ginCtx, event, cc)
	clearCaseListCache(ginCtx, event, cc)
}

func (cc CacheClearService) ClearDispositionCache(ctx context.Context, request events.Disposition) {
	ginCtx, _ := gin.CreateTestContext(nil)
	ginCtx.Request = &http.Request{}

	clearDispositionListWithCaseRefNumberCache(ginCtx, request, cc)
	clearDispositionListWithCustomerRefNumberCache(ginCtx, request, cc)
	cc.clearCaseListCacheOnCaseRef(ginCtx, request.CaseRefNumber)
}

func (cc *CacheClearService) clearCaseListCacheOnCaseRef(ctx context.Context, caseRefNumber string) error {
	allocationFilter := models.Allocation{
		CaseRefNumber: caseRefNumber,
	}
	agent, err := cc.allocationRepo.FindByReferenceNumberOne(ctx, allocationFilter)
	if err != nil {
		logger.Error(ctx, err, "CacheClearService|ClearCaseListCache|AllocationRepo|FindByReferenceNumberOne error", logger.LogFields{"case_ref_number": caseRefNumber})
		return err
	}
	redisKey := fmt.Sprintf("api:%s:%s:%s", constants.API_CASELIST, constants.AGENT_REF_NUMBER, agent.AgentRefNumber)
	if err := cc.GetCacheInstance().DeleteKeysWithPrefix(redisKey); err != nil {
		logger.Error(ctx, err, "CacheClearService|ClearCaseListCache|redisService.DeleteKeysWithPrefix error", logger.LogFields{"case_ref_number": caseRefNumber, "redis_key": redisKey, "error": err})
		return err
	}
	return nil
}

func (cc CacheClearService) ClearContactEventCache(ctx context.Context, request events.CustomerContactCreated) {
	if span := tracing.TraceSpan(ctx, "MQService.consumeCaseCreatedEvent"); span != nil {
		defer span.End()
	}

	redisKey := fmt.Sprintf("api:%s:%s:%s", constants.API_CONTACT_LIST, constants.CUSTOMER_REF_NUMBER, request.CustomerRefNumber)
	if err := cc.GetCacheInstance().DeleteKeysWithPrefix(redisKey); err != nil {
		logger.Error(ctx, err, "CacheClearService|ClearContactEventCache|DeleteKeysWithPrefix error", logger.LogFields{"event_payload": request, "redis_key": redisKey, "error": err})
	}
}
