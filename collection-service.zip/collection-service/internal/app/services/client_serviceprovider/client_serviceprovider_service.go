package client_serviceprovider

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/dto/request"
	"collection-service/internal/models"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"context"
)

type ClientServiceProviderService struct {
	services.BaseService
	clientServiceProviderRepo repo_interfaces.IClientServiceProviderRepository
}

func InitClientServiceProviderService(ctx context.Context, clientServiceProviderRepo repo_interfaces.IClientServiceProviderRepository) *ClientServiceProviderService {
	service := &ClientServiceProviderService{clientServiceProviderRepo: clientServiceProviderRepo}
	return service

}

func (s *ClientServiceProviderService) UpdateClientServiceProvider(ctx context.Context, req request.UpdateClientServiceProviderReq) error {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	logger.Info(ctx, "UpdateClientServiceProvider", map[string]interface{}{"req": req})
	filter := transformRequestToModel(req)
	err := s.clientServiceProviderRepo.UpdateClientServiceProvider(ctx, filter, &models.ClientServiceProviders{Status: req.Status})
	if err != nil {
		return err
	}
	return nil
}

func transformRequestToModel(req request.UpdateClientServiceProviderReq) *models.ClientServiceProviders {
	data := &models.ClientServiceProviders{
		ClientRefNumber:          req.ClientRefNumber,
		ServiceProviderRefNumber: req.ServiceProviderRefNumber,
	}
	return data
}
