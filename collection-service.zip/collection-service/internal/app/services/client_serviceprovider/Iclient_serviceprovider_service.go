package client_serviceprovider

import (
	"collection-service/internal/dto/request"
	"context"
)

type IClientServiceProviderService interface {
	UpdateClientServiceProvider(ctx context.Context, req request.UpdateClientServiceProviderReq) error
}
