package services

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services/storage/cacheservice"
)

type BaseService struct {
	cache *cacheservice.BaseCacheService
}

func (s *BaseService) SetCacheInstance(cache *cacheservice.BaseCacheService) {
	if cache == nil {
		panic(constants.CACHE_IS_EMPTY)
	}
	s.cache = cache
}

func (s *BaseService) GetCacheInstance() *cacheservice.BaseCacheService {
	if s.cache == nil {
		panic(constants.CACHE_NOT_FOUND)
	}
	return s.cache
}
