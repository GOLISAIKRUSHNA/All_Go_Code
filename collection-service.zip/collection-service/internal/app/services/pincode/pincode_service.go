package pincode

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto/response"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"context"

	"github.com/spf13/viper"
)

type PincodeService struct {
	services.BaseService
	pincodeRepo repo_interfaces.IPincodeMasterRepository

	cacheEnabled bool
}

func InitPincodeService(ctx context.Context) *PincodeService {
	service := &PincodeService{
		pincodeRepo:  repositories.InitPincodeMasterRepository(ctx),
		cacheEnabled: viper.GetBool("REDIS_ENABLED"),
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (p PincodeService) GetPincodeDetails(ctx context.Context, pincode int) (response.PincodeDetailsResponse, error) {
	logger.Info(ctx, "PincodeService|GetPincodeDetails|Request", logger.LogFields{"pincode": pincode})
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	pincodeModel, err := p.pincodeRepo.FindByPincode(ctx, pincode)
	if err != nil {
		logger.Error(ctx, err, "PincodeService|GetPincodeDetails|Error", logger.LogFields{"error": err})
		return response.PincodeDetailsResponse{}, err
	}
	return response.PincodeDetailsResponse{
		PincodeDetails: response.PincodeDetails{
			Pincode: pincodeModel.Pincode,
			CityId:  pincodeModel.CityId,
			StateId: pincodeModel.StateId,
			City:    pincodeModel.City.Name,
			State:   pincodeModel.State.Name,
		},
	}, nil

}
