package pincode

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto/response"
	"context"
)

type IPincodeService interface {
	services.IBaseService
	GetPincodeDetails(ctx context.Context, pincode int) (response.PincodeDetailsResponse, error)
}
