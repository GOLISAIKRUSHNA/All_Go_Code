package disposition

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IDispositionService interface {
	services.IBaseService
	CreateDisposition(ctx context.Context, disposition request.Disposition) error
	GetDispositionsList(ctx context.Context, req request.GetDisposition, pagination dto.PaginationData) (response.GetDispositionResp, error)
}
