package disposition

import (
	"collection-service/common/logger"
	"collection-service/internal/adapter"
	"collection-service/internal/adapter/rabbit_mq"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/service_calls"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto"
	"collection-service/internal/dto/events"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/spf13/viper"
)

type DispositionService struct {
	services.BaseService
	dispositionRepo repo_interfaces.IDispositionRepository
	customerRepo    repo_interfaces.ICustomerRepository
	caseRepo        repo_interfaces.ICaseRepository
	dispositionKey  string
	searchKey       string
	cacheEnabled    bool
}

// Initialization of DispositionService with respect to the interface IDispositionService
// Accepts only context as a parameter and hardcodes the DispositionKey, searchKey and cacheEnabled from .env variables
// Returns the DispositionService pointer instance to the caller
func InitDispositionService(ctx context.Context) *DispositionService {
	service := &DispositionService{
		dispositionRepo: repositories.InitDispositionRepository(ctx),
		customerRepo:    repositories.InitCustomerRepository(ctx),
		caseRepo:        repositories.InitCaseRepository(ctx),
		dispositionKey:  "disposition",
		searchKey:       "disposition_search",
		cacheEnabled:    viper.GetBool("REDIS_ENABLED"),
	}

	if service.cacheEnabled {
		service.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (d DispositionService) CreateDisposition(ctx context.Context, disposition request.Disposition) error {
	span := tracing.TraceSpan(ctx, "DispositionService.CreateDisposition")
	if span != nil {
		defer span.End()
	}
	dispositionType, err := isValidDisposition(ctx, disposition)
	if err != nil {
		logger.Error(ctx, err, "CreateDisposition || isValidDisposition", logger.LogFields{"disposition": disposition})
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "validation error", err, nil)
	}

	if err := validateFollowupDatetime(ctx, disposition); err != nil {
		logger.Error(ctx, err, "CreateDisposition || validateFollowupDatetime", logger.LogFields{"preferred_language": disposition.PreferredLanguage})
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "follow_up_datetime mandatory", err, nil)
	}

	if strings.TrimSpace(disposition.PreferredLanguage) == "" {
		if err := preferredLanguageMandatory(ctx, disposition); err != nil {
			logger.Error(ctx, err, "CreateDisposition || preferred language error", logger.LogFields{"preferred_language": disposition.PreferredLanguage})
			utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "validation error", err, nil)
		}
	}

	if disposition.Source == enum.FIELD {
		if disposition.Location.Latitude == 0 || disposition.Location.Longitude == 0 || disposition.SelfieFilePath == "" || disposition.AddressRefNumber == "" {
			logger.Error(ctx, nil, "CreateDisposition", logger.LogFields{"error": "location, selfie_base64string, address_ref_number are required if source = FIELD"})
			utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "validation error", "location, selfie_base64string, address_ref_number are required if source = FIELD", nil)
		}
	}

	caseData, caseFetchErr := d.caseRepo.FindByReferenceNumberOne(ctx, models.Case{CaseRefNumber: disposition.CaseRefNumber})
	if caseFetchErr != nil {
		logger.Error(ctx, caseFetchErr, "CreateDisposition", logger.LogFields{"case_fetch_err": disposition.CaseRefNumber})
		utils.BadRequestException(ctx, constants.VALIDATION_ERROR_CODE, "validation error", "case ref number not found", nil)
	}

	dispositionModel := mapDispositionDtoToModel(disposition, dispositionType)
	if err := d.dispositionRepo.CreateDispositionRecord(ctx, &dispositionModel); err != nil {
		logger.Error(ctx, err, "CreateDisposition || dispositionRepo.CreateDispositionRecord ", logger.LogFields{"case_ref_number": disposition.CaseRefNumber})
		return err
	}

	if err := d.updateCustomerPreferredLanguage(ctx, disposition); err != nil {
		logger.Error(ctx, err, "CreateDisposition || dispositionRepo.updateCustomerPreferredLanguage ", logger.LogFields{"case_ref_number": disposition.CaseRefNumber})
		return err
	}

	if err := d.createComment(ctx, dispositionModel, disposition); err != nil {
		logger.Error(ctx, err, "CreateDisposition || createComment ", logger.LogFields{"case_ref_number": disposition.CaseRefNumber})
		return err
	}

	if disposition.Disposition == "CP" {
		d.sendPaymentProofLink(ctx, caseData.ClientRefNumber, disposition)
	}

	dispositionEvent := mapEventFromDispositionModel(dispositionModel, disposition.AttemptRefNumber)
	publishDispositionEvent(ctx, dispositionEvent)
	return nil
}

func (d DispositionService) updateCustomerPreferredLanguage(ctx context.Context, disposition request.Disposition) error {
	updateCustomerLanguages := models.Customer{
		PreferredLanguage: disposition.PreferredLanguage,
	}
	whereCustRefNo := models.CustomerWhereParams{
		CustomerRefNumber: disposition.CustomerRefNumber,
	}

	_, err := d.customerRepo.Update(ctx, updateCustomerLanguages, whereCustRefNo)
	if err != nil {
		logger.Error(ctx, err, "Error while updating preferred language", logger.LogFields{"updateParams": updateCustomerLanguages, "where": whereCustRefNo})
	}
	return err
}

func (d DispositionService) createComment(ctx context.Context, dispositionModel models.Disposition, disposition request.Disposition) error {
	createCommentReq := transformCommentReq(dispositionModel.DispositionRefNumber, disposition)
	_, _, _, _, err := service_calls.CreateCommentRequest(ctx, createCommentReq)
	if err != nil {
		msg := "unable to call common service for creating comments"
		logger.Error(ctx, errors.New(msg), msg, nil)
	}
	return err
}

func transformCommentReq(dispositionRefNumber string, disposition request.Disposition) request.CreateCommentReq {
	return request.CreateCommentReq{
		CaseRefNumber:        disposition.CaseRefNumber,
		Comment:              disposition.Comment,
		Disposition:          disposition.Disposition,
		DispositionRefNumber: dispositionRefNumber,
		CreatedBy:            disposition.AgentRefNumber,
		CreatedByName:        disposition.AgentName,
	}
}

func isValidDisposition(ctx context.Context, disposition request.Disposition) (string, error) {
	// Log the source for debugging
	fmt.Printf("Validating Source: %s\n", disposition.Source.String())

	// Read the config file
	jsonData, err := os.ReadFile("config.json")
	if err != nil {
		return "", fmt.Errorf("error reading config file: %w", err)
	}

	var config map[string]interface{}
	err = json.Unmarshal(jsonData, &config)
	if err != nil {
		return "", fmt.Errorf("error unmarshalling config JSON: %w", err)
	}

	viper.Set("disposition_names", getNames(config, disposition.Source))

	dispositionValue := viper.GetStringSlice("disposition_names")
	if len(dispositionValue) == 0 {
		return "", errors.New("disposition value empty")
	}

	if disposition.Disposition == "" {
		return "", errors.New("disposition cannot be empty")
	}

	if (disposition.Disposition != "CP" && disposition.Disposition != "PPS" && disposition.Disposition != "PPA" && disposition.Disposition != "PPR") && disposition.AgentRefNumber == "" {
		return "", errors.New("AgentRefNumber is required when disposition is not CP, PPS, PPA, PPR")
	}

	dispositionStatus, err := getDispositionStatus(config, disposition.Disposition, disposition.Source)
	if err != nil {
		return "", fmt.Errorf("error in valid disposition: %w", err)
	}

	return dispositionStatus, nil
}

func getDispositionStatus(config map[string]interface{}, disposition string, source enum.Source) (string, error) {
	dispositionConfig, ok := config["disposition_config"].(map[string]interface{})
	if !ok {
		return "", errors.New("disposition_config not found in config")
	}

	var dispositions []interface{}
	switch source {
	case enum.FIELD, enum.FIELD_TELECALLING:
		dispositions, ok = dispositionConfig["field_dispositions"].([]interface{})
	case enum.TELECALLING:
		dispositions, ok = dispositionConfig["calling_dispositions"].([]interface{})
	case enum.AUTODIALER:
		dispositions, _ = config["disposition_config"].(map[string]interface{})["autodialer_dispositions"].([]interface{})
	case enum.SYSTEM:
		dispositions, _ = config["disposition_config"].(map[string]interface{})["system_dispositions"].([]interface{})
	}
	if !ok {
		return "", errors.New("dispositions not found or invalid in config")
	}

	for _, entry := range dispositions {
		dispositionEntry, ok := entry.(map[string]interface{})
		if !ok {
			continue // Skip invalid entries
		}
		if name, ok := dispositionEntry["name"].(string); ok && name == disposition {
			if status, ok := dispositionEntry["disposition_status"].(string); ok {
				return status, nil
			}
			return "", fmt.Errorf("disposition status not found for %s", disposition)
		}
	}
	return "", fmt.Errorf("disposition %s not found", disposition)
}

func mapDispositionDtoToModel(disposition request.Disposition, dispositionType string) models.Disposition {
	dispositionTypeEnum := enum.StringToDispositionType(dispositionType)
	dispositionModel := models.Disposition{
		AttemptRefNumber:  disposition.AttemptRefNumber,
		Source:            disposition.Source,
		CaseRefNumber:     disposition.CaseRefNumber,
		CustomerRefNumber: disposition.CustomerRefNumber,
		AgentRefNumber:    disposition.AgentRefNumber,
		Disposition:       disposition.Disposition,
		DispositionType:   dispositionTypeEnum,
		Comment:           disposition.Comment,
		FollowupDatetime:  disposition.FollowupDatetime,
		Latitude:          disposition.Location.Latitude,
		Longitude:         disposition.Location.Longitude,
		SelfieFilePath:    disposition.SelfieFilePath,
		AddressRefNumber:  disposition.AddressRefNumber,
		ContactRefNumber:  disposition.ContactRefNumber,
		CreatedBy:         disposition.AgentRefNumber,
	}
	if disposition.Source == enum.SYSTEM {
		dispositionModel.AgentRefNumber = constants.SYSTEM_AGENT_REF_NUMBER
		dispositionModel.CreatedBy = constants.SYSTEM_AGENT_REF_NUMBER

	}
	return dispositionModel
}

func mapEventFromDispositionModel(dispositionModel models.Disposition, attemptRefNumber string) events.Disposition {
	eventDTO := events.Disposition{

		AttemptRefNumber:     attemptRefNumber,
		DispositionRefNumber: dispositionModel.DispositionRefNumber,
		Source:               dispositionModel.Source,
		CaseRefNumber:        dispositionModel.CaseRefNumber,
		CustomerRefNumber:    dispositionModel.CustomerRefNumber,
		AgentRefNumber:       dispositionModel.AgentRefNumber,
		Disposition:          dispositionModel.Disposition,
		Comment:              dispositionModel.Comment,
		FollowupDatetime:     dispositionModel.FollowupDatetime,
		//Location:             events.Location(dispositionModel.Location),
		//SelfieFilePath:   dispositionModel.SelfieFilePath,
		AddressRefNumber: dispositionModel.AddressRefNumber,
		ContactRefNumber: dispositionModel.ContactRefNumber,
		DispositionType:  dispositionModel.DispositionType.String(),
	}
	return eventDTO
}

func publishDispositionEvent(ctx context.Context, event events.Disposition) bool {
	data := adapter.NewMessage(ctx, "disposition_create", event, "")
	payload, err := json.Marshal(data)

	if err != nil {
		logger.Error(ctx, err, "DisPositionService|publishDispositionEvent|MarshalError", logger.LogFields{"disposition_event": event})
		return false
	}

	if err := rabbit_mq.GetRabbitMQClientInstance(ctx).Publish(ctx, constants.RMQ_COLLECTION_APP_DEFAULT_DELAYED_EXCHANGE, []string{constants.RMQ_COLLECTION_SERVICE_MAIN_QUEUE_KEY, constants.RMQ_DIALER_SERVICE_MAIN_QUEUE_KEY}, payload, nil); err != nil {
		logger.Error(ctx, err, "DisPositionService|publishDispositionEvent", logger.LogFields{"disposition_event": event})
		return false
	}
	return true
}

func getNames(config map[string]interface{}, source enum.Source) []string {
	var names []string
	var dispositions []interface{}
	switch source {
	case enum.TELECALLING:
		dispositions, _ = config["disposition_config"].(map[string]interface{})["calling_dispositions"].([]interface{})
	case enum.FIELD, enum.FIELD_TELECALLING:
		dispositions, _ = config["disposition_config"].(map[string]interface{})["field_dispositions"].([]interface{})
	case enum.AUTODIALER:
		dispositions, _ = config["disposition_config"].(map[string]interface{})["autodialer_dispositions"].([]interface{})
	case enum.SYSTEM:
		dispositions, _ = config["disposition_config"].(map[string]interface{})["system_dispositions"].([]interface{})
	}
	for _, entry := range dispositions {
		name := entry.(map[string]interface{})["name"].(string)
		names = append(names, name)
	}
	return names
}

// Checking preferref language mandatory for disposition
func preferredLanguageMandatory(ctx context.Context, request request.Disposition) error {
	// Load configuration
	data, err := os.ReadFile("config.json")
	if err != nil {
		return fmt.Errorf("error loading configuration file: %v", err)
	}

	var config map[string]interface{}
	err = json.Unmarshal(data, &config)
	if err != nil {
		return fmt.Errorf("error unmarshalling configuration JSON: %v", err)
	}

	// Check if disposition configuration is present
	dispositionConfig, ok := config["disposition_config"].(map[string]interface{})
	if !ok {
		return fmt.Errorf("disposition configuration not found in configuration file")
	}

	var dispositions []interface{}
	source := request.Source.String()
	switch source {
	case "FIELD":
		fieldDispositions, ok := dispositionConfig["field_dispositions"].([]interface{})
		if !ok {
			return fmt.Errorf("field_dispositions key not found or not a valid array in configuration")
		}
		dispositions = fieldDispositions
	case "TELECALLING":
		callingDispositions, ok := dispositionConfig["calling_dispositions"].([]interface{})
		if !ok {
			return fmt.Errorf("calling_dispositions key not found or not a valid array in configuration")
		}
		dispositions = callingDispositions
	case "AUTODIALER":
		// No checks needed for DIALER source, simply return nil
		return nil
	case "SYSTEM":
		// No checks needed for DIALER source, simply return nil
		return nil
	case "FIELD_TELECALLING":
		// No checks needed for DIALER source, simply return nil
		return nil
	default:
		return fmt.Errorf("invalid source value: %s", source)
	}

	// Check if the disposition exists in the configuration
	dispositionName := request.Disposition
	var foundDisposition bool
	for _, d := range dispositions {
		disposition, ok := d.(map[string]interface{})
		if !ok {
			return fmt.Errorf("invalid disposition configuration format")
		}

		name, ok := disposition["name"].(string)
		if !ok {
			return fmt.Errorf("name field missing or not a string in disposition configuration")
		}

		if name == dispositionName {
			foundDisposition = true
			mandatoryFields, ok := disposition["mandatory_fields"].([]interface{})
			if ok {
				for _, field := range mandatoryFields {
					if field == "preferred_language" {
						if request.PreferredLanguage == "" {
							return fmt.Errorf("preferred language is mandatory for disposition %s", dispositionName)
						}
						break
					}
				}
			}
			break
		}
	}
	if !foundDisposition {
		return fmt.Errorf("disposition '%s' not found in configuration", dispositionName)
	}

	return nil
}

func validateFollowupDatetime(ctx context.Context, req request.Disposition) error {
	// Load and parse the configuration file
	data, err := os.ReadFile("config.json")
	if err != nil {
		return fmt.Errorf("error loading configuration file: %v", err)
	}

	var config map[string]interface{}
	if err = json.Unmarshal(data, &config); err != nil {
		return fmt.Errorf("error unmarshalling configuration JSON: %v", err)
	}

	// Retrieve the disposition configuration
	dispositionConfig, ok := config["disposition_config"].(map[string]interface{})
	if !ok {
		return fmt.Errorf("disposition configuration not found in configuration file")
	}

	// Determine the correct disposition array based on the source
	var dispositionArray []interface{}
	switch req.Source {
	case enum.FIELD:
		dispositionArray, ok = dispositionConfig["field_dispositions"].([]interface{})
	case enum.TELECALLING:
		dispositionArray, ok = dispositionConfig["calling_dispositions"].([]interface{})
	case enum.FIELD_TELECALLING, enum.AUTODIALER, enum.SYSTEM:
		return nil
	default:
		return fmt.Errorf("invalid source: %s", req.Source)
	}

	if !ok {
		return fmt.Errorf("%s dispositions not found in configuration", req.Source)
	}

	// Check if FollowupDatetime is mandatory for the specified disposition
	for _, disposition := range dispositionArray {
		dispositionMap, ok := disposition.(map[string]interface{})
		if !ok {
			continue // Skip invalid entries
		}

		if name, nameOk := dispositionMap["name"].(string); nameOk && name == req.Disposition {
			if mandatoryFields, ok := dispositionMap["mandatory_fields"].([]interface{}); ok {
				for _, field := range mandatoryFields {
					if fieldStr, fieldOk := field.(string); fieldOk && fieldStr == "follow_up_date" {
						if req.FollowupDatetime == "" {
							return fmt.Errorf("FollowupDatetime is mandatory for disposition %s", req.Disposition)
						}
						if !utils.IsValidFutureDate(req.FollowupDatetime) {
							return fmt.Errorf("FollowupDatetime must be a future date")
						}
						return nil
					}
				}
			}
			return nil
		}
	}

	// If the disposition is not found, return an error
	return fmt.Errorf("disposition %s not found in %s dispositions", req.Disposition, req.Source)
}

func (d *DispositionService) sendPaymentProofLink(ctx context.Context, clientRefNumber string, disposition request.Disposition) bool {

	paymentLinkRequest := service_calls.PaymentProofLink{
		ClientRefNumber:   clientRefNumber,
		AgentRefNumber:    disposition.AgentRefNumber,
		CustomerRefNumber: disposition.CustomerRefNumber,
		CaseRefNumber:     disposition.CaseRefNumber,
	}
	_, _, _, isSuccess, err := service_calls.SendPaymentProofLink(ctx, paymentLinkRequest)
	if err != nil || !isSuccess {
		logger.Error(ctx, err, "sendPaymentProofLink|Error while sending payment proof link", logger.LogFields{"request": paymentLinkRequest})
		return false
	}
	return true
}

func (s *DispositionService) GetDispositionsList(ctx context.Context, req request.GetDisposition, pagination dto.PaginationData) (response.GetDispositionResp, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	if pagination.CurrentPage <= 0 {
		pagination.CurrentPage = 1
	}
	pagination = dto.Init(pagination.CurrentPage)

	finalResponse := response.GetDispositionResp{}

	dispositions := models.Disposition{
		CustomerRefNumber: req.CustomerRefNumber,
		CaseRefNumber:     req.CaseRefNumber,
	}

	//  generate the cache key
	redisDispositionKey := ""

	if req.CaseRefNumber != "" {
		redisDispositionKey = constructDispositionListRedisKeyForCaseRefNumber(req, pagination.CurrentPage)
	} else if req.CustomerRefNumber != "" {
		redisDispositionKey = constructDispositionListRedisKeyForCustomerRefNumber(req, pagination.CurrentPage)
	}

	var redisExpiry = 1 * time.Minute

	// Reading from cache
	cacheResponse, err := s.GetCacheInstance().Read(redisDispositionKey, "get")
	if err != nil {
		return finalResponse, err
	}

	// If Not in Cache
	if cacheResponse == "" {
		disposition, totalRecords, err := s.dispositionRepo.FindDispositionList(ctx, dispositions, pagination)
		if err != nil {
			return finalResponse, err
		}

		// Calculating totalPages based on totalRecords
		totalPages := totalRecords / pagination.Limit
		if totalRecords%pagination.Limit > 0 {
			totalPages++
		}

		// getting disposition response model
		resp := transformDispositionResponse(disposition)
		for i := range resp {
			resp[i].ContactNumber = maskContactNumber(resp[i].ContactNumber)
		}
		finalResponse = response.GetDispositionResp{Dispositions: resp, PaginationData: response.PaginationData{CurrentPage: pagination.CurrentPage, Pages: totalPages}}

		// marshaling the data
		result, err := json.Marshal(finalResponse)
		if err != nil {
			return finalResponse, err
		}

		// Create the record in Cache
		ok, err := s.GetCacheInstance().Create(redisDispositionKey, result, "set", redisExpiry)
		if !ok {
			return finalResponse, nil
		}
		if err != nil {
			return finalResponse, err
		}
		return finalResponse, nil
	}

	// Unmarshalling the data
	err = json.Unmarshal([]byte(cacheResponse), &finalResponse)
	if err != nil {
		return finalResponse, err
	}

	return finalResponse, nil
}

// generating disposition response model
func transformDispositionResponse(disposition []models.Disposition) []response.Disposition {
	var res []response.Disposition
	for i := range disposition {
		d := disposition[i]

		res = append(res, response.Disposition{
			DispositionRefNumber: d.DispositionRefNumber,
			Source:               d.Source,
			CaseRefNumber:        d.CaseRefNumber,
			CustomerRefNumber:    d.CustomerRefNumber,
			CustomerName:         d.CustomerInfo.FirstName + " " + d.CustomerInfo.LastName,
			AgentRefNumber:       d.AgentRefNumber,
			AgentName:            d.AgentInfo.FirstName + " " + d.AgentInfo.LastName,
			Disposition:          d.Disposition,
			ContactNumber:        d.ContactInfo.ContactNumber,
			Comment:              d.Comment,
			Latitude:             d.Latitude,
			Longitude:            d.Longitude,
			FollowupDatetime:     utils.FormatDateTime(d.FollowupDatetime),
			Address:              d.AddressInfo.Line1 + " " + d.AddressInfo.Line2 + " " + d.AddressInfo.Line3 + " " + d.AddressInfo.Landmark + " " + strconv.Itoa(d.AddressInfo.Pincode) + " " + d.AddressInfo.City + " " + d.AddressInfo.State + " " + d.AddressInfo.Country,
			CreatedAt:            utils.FormatDateAsYmdhis(d.CreatedAt),
			AttemptRefNumber:     d.AttemptRefNumber,
		})
	}
	return res
}

func maskContactNumber(contactNumber string) string {
	if len(contactNumber) < 4 {
		return contactNumber
	}

	maskedPart := "XXXXXX"
	lastFourDigits := contactNumber[len(contactNumber)-4:]

	return maskedPart + lastFourDigits
}

func constructDispositionListRedisKeyForCustomerRefNumber(req request.GetDisposition, pageNo int64) string {
	return fmt.Sprintf("api:%s:%s:%s:%s:%d", constants.API_DISPOSITION_LIST, constants.CUSTOMER_REF_NUMBER, req.CustomerRefNumber, constants.PAGE_NO, pageNo)
}

func constructDispositionListRedisKeyForCaseRefNumber(req request.GetDisposition, pageNo int64) string {
	return fmt.Sprintf("api:%s:%s:%s:%s:%d", constants.API_DISPOSITION_LIST, constants.CASE_REF_NUMBER, req.CaseRefNumber, constants.PAGE_NO, pageNo)
}
