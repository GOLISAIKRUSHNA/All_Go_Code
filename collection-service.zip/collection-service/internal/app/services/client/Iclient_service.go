package client

import (
	"collection-service/internal/app/services"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"context"
)

type IClientService interface {
	services.IBaseService
	GetClientConfig(ctx context.Context, clientRefNumber string, filter request.Config) (*dto.AppConfig, error)
	GetClientNames(ctx context.Context, clientRefNumber []string) (response.GetClientNamesResp, error)
	GetClientsForServiceProvider(ctx context.Context, request request.ClientServiceProviderReq) (response.ClientsResp, error)
	GetServiceProvidersForClient(ctx context.Context, request request.ClientServiceProviderReq) (response.ServiceProvidersResp, error)
	UpdateClientConfig(ctx context.Context, clientRefNumber string, configReq map[string]interface{}) (bool, error)
	GetClientAttributes(ctx context.Context, clientRefNumber string) (*response.AttributesResp, error)
}
