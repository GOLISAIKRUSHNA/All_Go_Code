package client

import (
	config "collection-service"
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/mitchellh/mapstructure"

	"github.com/spf13/viper"
)

type ClientService struct {
	services.BaseService
	clientRepo                 repo_interfaces.IClientRepository
	clientServiceProvidersRepo repo_interfaces.IClientServiceProviderRepository
	cacheEnabled               bool
}

func (s ClientService) GetClientAttributes(ctx context.Context, clientRefNumber string) (*response.AttributesResp, error) {
	// Fetching client configuration from database
	configRes, err := s.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: clientRefNumber})
	if err != nil {
		utils.BadRequestException(ctx, constants.NOT_FOUND_ERROR_CODE, "client reference number not found", nil, nil)
		return nil, err
	}

	var attributeResp *response.AttributesResp

	err = json.Unmarshal([]byte(configRes.Configuration), &attributeResp)
	if err != nil {
		logger.Error(ctx, err, "error while unmarshalling client attributes", nil)
		return nil, err
	}

	return attributeResp, nil
}

func InitClientService(ctx context.Context) *ClientService {
	service := &ClientService{
		clientRepo:                 repositories.InitClientRepository(ctx),
		clientServiceProvidersRepo: repositories.InitClientServiceProviderRepository(ctx),
		cacheEnabled:               viper.GetBool("REDIS_ENABLED"),
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (s ClientService) GetClientConfig(ctx context.Context, clientRefNumber string, filter request.Config) (*dto.AppConfig, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	// Unmarshalling config data
	var appConfigMap map[string]interface{}
	err := config.AppConfig.UnmarshalKey(filter.ConfigName, &appConfigMap)
	if err != nil {
		return nil, err
	}

	// Fetching client configuration from database
	configRes, err := s.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: clientRefNumber})
	if err != nil {
		utils.BadRequestException(ctx, constants.NOT_FOUND_ERROR_CODE, "client reference number not found", nil, nil)
		return nil, err
	}

	// Unmarshal configRes.Configuration into appConfigMap
	err = json.Unmarshal([]byte(configRes.Configuration), &appConfigMap)
	if err != nil {
		return nil, err
	}

	// Unmarshal map to AppConfig struct
	var appConfig dto.AppConfig
	err = mapstructure.Decode(appConfigMap, &appConfig)
	if err != nil {
		return nil, err
	}

	return &appConfig, nil
}

func (s ClientService) UpdateClientConfig(ctx context.Context, clientRefNumber string, configReq map[string]interface{}) (bool, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.WRITE_DATABASE_TYPE)

	// Fetching client configuration from database
	configRes, err := s.clientRepo.FindByReferenceNumberOne(ctx, &models.Client{ClientRefNumber: clientRefNumber})
	if err != nil {
		utils.BadRequestException(ctx, constants.NOT_FOUND_ERROR_CODE, "client reference number not found", nil, nil)
		return false, err
	}

	// Unmarshaling configRes.Configuration into appConfigMap
	var appConfigMap map[string]interface{}
	err = json.Unmarshal([]byte(configRes.Configuration), &appConfigMap)
	if err != nil {
		return false, err
	}

	// Function to update nested keys
	var updateNestedKeys func(map[string]interface{}, map[string]interface{})
	updateNestedKeys = func(appConfigMap map[string]interface{}, configReq map[string]interface{}) {
		for key, value := range configReq {
			if nestedMap, ok := appConfigMap[key].(map[string]interface{}); ok && value != nil {
				if reqMap, ok := value.(map[string]interface{}); ok {
					updateNestedKeys(nestedMap, reqMap)
				} else {
					appConfigMap[key] = value
				}
			} else {
				appConfigMap[key] = value
			}
		}
	}

	// Updating the nested keys
	updateNestedKeys(appConfigMap, configReq)

	// Marshaling updated appConfigMap
	updatedConfig, err := json.Marshal(appConfigMap)
	if err != nil {
		return false, err
	}

	// Updating the client configuration in the database
	err = s.clientRepo.UpdateClientConfig(ctx, clientRefNumber, string(updatedConfig))
	if err != nil {
		return false, err
	}

	return true, nil
}

func (s ClientService) GetClientNames(ctx context.Context, clientRefNumbers []string) (response.GetClientNamesResp, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	var clientNamesResp response.GetClientNamesResp

	clientRefNumbersString := strings.Join(clientRefNumbers, "-")
	redisClientNamesKey := constructClientNamesListRedisKey(ctx, clientRefNumbersString)

	// Reading from cache
	cacheResponse, err := s.GetCacheInstance().Read(redisClientNamesKey, "get")
	if err != nil {
		utils.InternalServerError(ctx, err, "error while fetching client names form redis")
	}

	// If Not in Cache
	if cacheResponse == "" {
		var redisExpiry = 24 * time.Hour
		clientModels, err := s.clientRepo.FindAllByClientRefNumbers(ctx, clientRefNumbers)
		if err != nil {
			utils.InternalServerError(ctx, err, fmt.Sprintf("error while fetching clients via client ref numbers %s", clientRefNumbers))
		}

		clientNamesResp = extractClientNamesResp(ctx, clientModels)

		// marshaling the data
		result, err := json.Marshal(clientNamesResp)
		if err != nil {
			utils.InternalServerError(ctx, err, "error while marshalling client names")
		}

		// Create the record in Cache
		ok, err := s.GetCacheInstance().Create(redisClientNamesKey, result, "set", redisExpiry)
		if !ok || err != nil {
			msg := "unable to set client names redis record"

			logger.Warn(ctx, msg+" "+err.Error(), nil)
		}

		return clientNamesResp, nil
	}

	// Unmarshalling the data
	err = json.Unmarshal([]byte(cacheResponse), &clientNamesResp)
	if err != nil {
		msg := "error while unmarshalling cache response"
		logger.Error(ctx, err, msg, nil)
		utils.InternalServerError(ctx, err, msg)
	}

	return clientNamesResp, nil
}

func constructClientNamesListRedisKey(ctx context.Context, clientRefNumbersString string) string {
	return fmt.Sprintf("api:%s:%s:%s", constants.API_CLIENT_NAMES_LIST, "crn", clientRefNumbersString)
}

func extractClientNamesResp(ctx context.Context, clientModels []models.Client) response.GetClientNamesResp {

	var clientNamesInfo []response.ClientNamesInfo
	for i := range clientModels {
		clientNamesInfo = append(clientNamesInfo, response.ClientNamesInfo{ClientName: clientModels[i].Name, ClientRefNumber: clientModels[i].ClientRefNumber})
	}

	return response.GetClientNamesResp{ClientNamesInfo: clientNamesInfo}
}

func (cl ClientService) GetClientsForServiceProvider(ctx context.Context, filter request.ClientServiceProviderReq) (response.ClientsResp, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	// Initialize clientList as an empty slice
	clientList := []response.ClientList{}

	// Fetch clients for the service provider
	clients, err := cl.clientServiceProvidersRepo.FindAll(ctx, models.ClientServiceProviders{ServiceProviderRefNumber: filter.ServiceProviderRefNumber})
	if err != nil {
		return response.ClientsResp{}, err
	}

	// Iterate through clients and construct response
	for _, client := range clients {
		clientList = append(clientList, response.ClientList{
			ClientRefNumber: client.ClientRefNumber,
			Name:            client.Client.Name,
			Intervention:    client.Intervention.String(),
			Status:          client.Status,
		})
	}

	// Prepare response
	clientsResp := response.ClientsResp{ClientList: clientList}
	return clientsResp, nil
}

func (cl ClientService) GetServiceProvidersForClient(ctx context.Context, filter request.ClientServiceProviderReq) (response.ServiceProvidersResp, error) {
	ctx = context.WithValue(ctx, constants.CTX_DB_CONNECTION_TYPE, constants.READ_DATABASE_TYPE)

	// Initialize serviceProviderList as an empty slice
	serviceProviderList := []response.ServiceProviderList{}

	// Fetch service providers
	providers, err := cl.clientServiceProvidersRepo.FindAll(ctx, models.ClientServiceProviders{ClientRefNumber: filter.ClientRefNumber})
	if err != nil {
		return response.ServiceProvidersResp{ServiceProviderList: serviceProviderList}, err
	}

	// Iterate through providers and construct response
	for _, provider := range providers {
		serviceProviderList = append(serviceProviderList, response.ServiceProviderList{
			ServiceProviderRefNumber: provider.ServiceProviderRefNumber,
			Name:                     provider.ServiceProvider.Name,
			Intervention:             provider.Intervention.String(),
			Status:                   provider.Status,
		})
	}

	// Prepare response
	serviceProviderResp := response.ServiceProvidersResp{ServiceProviderList: serviceProviderList}
	return serviceProviderResp, nil
}
