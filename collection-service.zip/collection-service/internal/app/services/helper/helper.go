package helper

import (
	"collection-service/common/logger"
	"collection-service/internal/app/services"
	"collection-service/internal/app/services/attribute_service"
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"collection-service/internal/utils"
	"context"

	"github.com/spf13/viper"
)

type HelperService struct {
	services.BaseService
	caseRepo         repo_interfaces.ICaseRepository
	loanRep          repo_interfaces.ILoanRepository
	attributeService attribute_service.IAttributeService
	cacheEnabled     bool
}

// Initialization of HelperService with respect to the interface IDialerService
func InitHelperService(ctx context.Context) *HelperService {
	service := &HelperService{
		attributeService: attribute_service.InitAttributeService(ctx),
		caseRepo:         repositories.InitCaseRepository(ctx),
		cacheEnabled:     viper.GetBool("REDIS_ENABLED"),
	}

	if service.cacheEnabled {
		service.BaseService.SetCacheInstance(cacheservice.GetInstance())
	}

	return service
}

func (s *HelperService) SyncLoanAttributes(ctx context.Context) error {

	cases, err := s.caseRepo.GetCaseList(ctx, models.Case{Status: enum.CASE_ACTIVE})
	if err != nil {
		utils.InternalServerError(ctx, err, "Error while fetching cases")
	}
	for _, caseObj := range cases {
		publishAttribute(s, ctx, caseObj.CaseRefNumber, "", "case_created")
	}

	return nil
}

func publishAttribute(s *HelperService, ctx context.Context, caseRefNumber, specialOfferRefNumber, eventName string) {

	defer func() {
		if r := recover(); r != nil {
			logger.Warn(ctx, "helper|publishAttribute|panic", logger.LogFields{})
		}
	}()

	s.attributeService.PushAttributeEvent(ctx, caseRefNumber, specialOfferRefNumber, eventName)

}
