package pusher

import (
	"context"
)

type IPusherService interface {
	Notify(ctx context.Context, objectRefNumber string) error
}
