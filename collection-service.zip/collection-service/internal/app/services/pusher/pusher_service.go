package pusher

import (
	"collection-service/internal/app/services"
	"context"
	"fmt"
	"time"

	"github.com/pusher/pusher-http-go/v5"
)

type PusherService struct {
	services.BaseService
	pusher pusher.Client
}

func InitPusherService(ctx context.Context) *PusherService {
	service := PusherService{}
	return &service
}

func (u *PusherService) Notify(ctx context.Context, objectRefNumber string) error {
	pusherClient := pusher.Client{
		AppID:   "1811083",
		Key:     "eb3357e51daf912e1fcd",
		Secret:  "4ea0caee8be82c5a5c92",
		Cluster: "ap2",
		Secure:  true,
	}
	// Create the notification content
	notificationContent := NotificationContent{
		Subject: "Payment Paid for RAMP_TP_ab_005",
		Body:    "Loan ID: RAMP_TP_ab_005 has made a payment of amount 3000.00. Click here to know more.",
		Date:    time.Now().Format(time.RFC3339),
	}
	// Create the data node
	dataNode := map[string]interface{}{
		"case_ref_number":   "CR0Q8XAC",
		"client_ref_number": "CL00000001",
		"communication_id":  "",
	}
	// Create the notification data
	notificationData := NotificationData{
		Content:  notificationContent,
		DataNode: dataNode,
	}
	err := pusherClient.SendToUser(objectRefNumber, "notification", notificationData)
	if err != nil {
		fmt.Println(err.Error())
	}
	return nil
}

type NotificationContent struct {
	Subject string `json:"subject"`
	Body    string `json:"body"`
	Date    string `json:"date"`
}

type NotificationData struct {
	Content  NotificationContent    `json:"content"`
	DataNode map[string]interface{} `json:"data_node"`
}
