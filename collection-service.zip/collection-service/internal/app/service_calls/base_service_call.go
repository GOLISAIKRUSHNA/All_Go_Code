package service_calls

import (
	"collection-service/common/logger"
	"collection-service/internal/dto"
	"context"
	"encoding/json"
)

func MarshalStandardResponse(ctx context.Context, url string, statusCode int, err error, responseBody []byte) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	if statusCode >= 200 && statusCode < 300 {
		successResp := dto.SuccessResponse{}
		err = json.Unmarshal(responseBody, &successResp)
		if err != nil {
			logger.Error(ctx, err, "unable to unmarshal success response",
				map[string]interface{}{"resp": responseBody, "url": url, "statusCode": statusCode})
			return 0, nil, nil, false, err
		}
		return statusCode, &successResp, nil, true, nil
	} else {
		logger.Error(ctx, err, "failure response received",
			map[string]interface{}{"resp": string(responseBody), "url": url, "statusCode": statusCode})

		failureResp := dto.ServerErrorResponse{}
		err = json.Unmarshal(responseBody, &failureResp)
		if err != nil {
			logger.Error(ctx, err, "unable to unmarshal failure response",
				map[string]interface{}{"resp": responseBody, "url": url, "statusCode": statusCode})
			return 0, nil, nil, false, err
		}

		return statusCode, nil, &failureResp, false, nil
	}
}
