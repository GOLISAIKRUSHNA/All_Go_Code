package service_calls

import (
	"collection-service/common/logger"
	"collection-service/internal/app/services/http"
	"collection-service/internal/dto"
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/viper"
)

type PaymentProofLink struct {
	CaseRefNumber     string `json:"case_ref_number"`
	AgentRefNumber    string `json:"agent_ref_number"`
	CustomerRefNumber string `json:"customer_ref_number"`
	ClientRefNumber   string `json:"client_ref_number"`
}

func GetPaymentSummary(ctx context.Context, agentRefNumber string) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("PAYMENT_SERVICE_BASE_URL")

	m := make(map[string]string)
	m["agent_ref_number"] = agentRefNumber

	url := fmt.Sprintf("%s/api/v1/payments/summary", baseUrl)

	statusCode, response, err := http.SendGet(ctx, url, m)
	if err != nil {
		logger.Error(ctx, err, "error while calling auth service for getting user info",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}

func SendPaymentProofLink(ctx context.Context, request PaymentProofLink) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("PAYMENT_SERVICE_BASE_URL")

	url := fmt.Sprintf("%s/api/v1/payment-proof/send-link", baseUrl)
	// Convert data to JSON

	requestBody, err := json.Marshal(request)
	if err != nil {
		logger.Error(ctx, err, "ServiceCalls|PaymentServiceCall|SendPaymentProofLink", logger.LogFields{"payload": request, "error": err})
		return 0, nil, nil, false, err
	}
	statusCode, response, err := http.SendPost(ctx, url, requestBody)
	if err != nil {
		logger.Error(ctx, err, "error while calling payment service for sending payment proof link",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}
