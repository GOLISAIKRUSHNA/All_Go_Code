package service_calls

import (
	"collection-service/common/logger"
	http_calls "collection-service/internal/app/services/http"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/viper"
)

func MakeClickToCallToDialerService(ctx context.Context, request request.DialerServiceClick2Call) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("DIALER_SERVICE_BASE_URL")
	endpoint := "/api/v1/call"
	// Convert data to JSON
	jsonData, err := json.Marshal(request)
	if err != nil {
		logger.Error(ctx, err, "ServiceCalls|DialerServiceCall", logger.LogFields{"payload": request, "error": err})
		return 0, nil, nil, false, err
	}
	// Make POST request
	code, callResp, httpErr := http_calls.SendPost(ctx, baseUrl+endpoint, jsonData)
	if httpErr != nil {
		logger.Error(ctx, httpErr, "ServiceCalls|DialerServiceCall", logger.LogFields{"payload": request, "error": httpErr})
		return 0, nil, nil, false, err
	}
	// Unmarshal the byte slice into the struct
	return MarshalStandardResponse(ctx, baseUrl+endpoint, code, httpErr, callResp)

}

func MakeAttemptListToDialerService(ctx context.Context, attemptRefNumbers string) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("DIALER_SERVICE_BASE_URL")
	endpoint := fmt.Sprintf("/api/v1/attempts/list?attempt_ref_number=%s", attemptRefNumbers)

	// Make POST request
	code, callResp, httpErr := http_calls.SendGet(ctx, baseUrl+endpoint, nil)
	if httpErr != nil {
		logger.Error(ctx, httpErr, "ServiceCalls|DialerServiceCall", logger.LogFields{"error": httpErr})
		return 0, nil, nil, false, httpErr
	}
	// Unmarshal the byte slice into the struct
	return MarshalStandardResponse(ctx, baseUrl+endpoint, code, httpErr, callResp)
}

/*
Get CSAT Attempt List
* @param c *gin.Context, request request.AttemptListRequest
* @return error
@author Tejas Surve
*/
func GetCsatAttemptList(ctx context.Context, urlParams map[string]string) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("DIALER_SERVICE_BASE_URL")

	url := fmt.Sprintf("%s/api/v1/csat/attempts", baseUrl)
	statusCode, response, err := http_calls.SendGet(ctx, url, urlParams)
	if err != nil {
		logger.Error(ctx, err, "dialerServiceCall|GetCsatAttemptList|error while calling dialer service for getting csat attempt list", logger.LogFields{"url": url})
		return MarshalStandardResponse(ctx, url, statusCode, err, response)
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}
