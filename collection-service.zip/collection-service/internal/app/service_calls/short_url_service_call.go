package service_calls

import (
	"collection-service/common/logger"
	"collection-service/internal/app/services/http"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/viper"
)

func GenerateShortURL(ctx context.Context, req request.CreateShortUrlReq) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("SHORT_URL_SERVICE_BASE_URL")

	reqBody, err := json.Marshal(req)
	if err != nil {
		return 0, nil, nil, false, err
	}

	url := fmt.Sprintf("%s/api/v1/short-url/generate", baseUrl)

	statusCode, response, err := http.SendPost(ctx, url, reqBody)
	if err != nil {
		logger.Error(ctx, err, "error while calling short url service",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}
