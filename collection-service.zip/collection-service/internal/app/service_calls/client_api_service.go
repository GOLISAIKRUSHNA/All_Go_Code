package service_calls

import (
	"collection-service/common/logger"
	"collection-service/internal/app/services/http"
	"collection-service/internal/dto/request"
	"context"
	"encoding/json"
	"time"
)

func ClientAPI(ctx context.Context, url string, method string) error {
	externalGatewayAPILogFields := logger.LogFields{"url": url}
	req := request.ClientAPIReq{URL: url, Method: method, ClientRefNumber: "CL000004"}
	reqBody, err := json.Marshal(req)
	if err != nil {
		logger.Error(ctx, nil, "Marshal error from client api request.",
			externalGatewayAPILogFields)
		return err
	}
	status, apiResponse, err := http.SendPostRequest(ctx, url, nil, reqBody, http.DEFAULT_TIMEOUT*time.Second)
	if err != nil {
		return err
	}

	// failure resp.
	if status < 200 || status > 299 {
		externalGatewayAPILogFields["status"] = status
		logger.Error(ctx, nil, "Error response received from external gateway api."+string(apiResponse),
			externalGatewayAPILogFields)

		if err != nil {
			logger.Error(ctx, err, "unable to unmarshal from external gateway api error response",
				externalGatewayAPILogFields)
			return err
		}

	}
	return nil
}
