package service_calls

import (
	"collection-service/internal/app/services/http"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/viper"
)

func CreateCommentRequest(ctx context.Context, req request.CreateCommentReq) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("COMMON_SERVICE_BASE_URL")

	reqBody, err := json.Marshal(req)
	if err != nil {
		return 0, nil, nil, false, err
	}

	url := fmt.Sprintf("%s/api/v1/comments", baseUrl)

	statusCode, response, err := http.SendPost(ctx, url, reqBody)
	if err != nil {
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}

func CallAuditsResponseSubmit(ctx context.Context, param request.CallAuditParam, requestBody request.CallAuditCommonServiceRequest) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("COMMON_SERVICE_BASE_URL")

	reqBody, err := json.Marshal(requestBody)
	if err != nil {
		return 0, nil, nil, false, err
	}
	// Format the URL with the audit_ref_number from param
	url := fmt.Sprintf("%s/api/v1/audit/%s/response", baseUrl, param.AuditRefNumber)

	statusCode, response, err := http.SendPost(ctx, url, reqBody)
	if err != nil {
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}
