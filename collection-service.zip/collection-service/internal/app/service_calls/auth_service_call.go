package service_calls

import (
	"collection-service/common/logger"
	"collection-service/internal/app/services/http"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/viper"
)

func CreateUser(ctx context.Context, req request.CreateUserReq) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("AUTH_SERVICE_BASE_URL")

	reqBody, err := json.Marshal(req)
	if err != nil {
		return 0, nil, nil, false, err
	}

	url := fmt.Sprintf("%s/api/v1/users", baseUrl, reqBody)

	statusCode, response, err := http.SendPost(ctx, url, reqBody)
	if err != nil {
		logger.Error(ctx, err, "error while calling auth service for creating user",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}

func UserExists(ctx context.Context, req request.UserExistsReq) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("AUTH_SERVICE_BASE_URL")

	reqBody, err := json.Marshal(req)
	if err != nil {
		return 0, nil, nil, false, err
	}

	url := fmt.Sprintf("%s/api/v1/users/username/exists", baseUrl)
	statusCode, response, err := http.SendPost(ctx, url, reqBody)
	if err != nil {
		logger.Error(ctx, err, "error while calling auth service for checking user existence",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}

func UserExistsExceptSelf(ctx context.Context, req request.UserExistsReq, objectRefNumber string) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("AUTH_SERVICE_BASE_URL")

	reqBody, err := json.Marshal(req)
	if err != nil {
		return 0, nil, nil, false, err
	}

	url := fmt.Sprintf("%s/api/v1/users/%s/username/exists", baseUrl, objectRefNumber)
	statusCode, response, err := http.SendPost(ctx, url, reqBody)
	if err != nil {
		logger.Error(ctx, err, "error while calling auth service for checking user existence",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}

func UpdateUser(ctx context.Context, req request.UpdateUserReq) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("AUTH_SERVICE_BASE_URL")

	reqBody, err := json.Marshal(req)
	if err != nil {
		return 0, nil, nil, false, err
	}

	url := fmt.Sprintf("%s/api/v1/users", baseUrl, reqBody)

	statusCode, response, err := http.SendPatch(ctx, url, reqBody)
	if err != nil {
		logger.Error(ctx, err, "error while calling auth service for updating user",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}

func GetUserInfo(ctx context.Context, objectRefNumber string) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("AUTH_SERVICE_BASE_URL")

	m := make(map[string]string)

	m["object_ref_number"] = objectRefNumber

	url := fmt.Sprintf("%s/api/v1/users", baseUrl)

	statusCode, response, err := http.SendGet(ctx, url, m)
	if err != nil {
		logger.Error(ctx, err, "error while calling auth service for getting user info",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}

func EncryptString(ctx context.Context, req request.EncryptReq) (int, *dto.SuccessResponse, *dto.ServerErrorResponse, bool, error) {
	baseUrl := viper.GetString("AUTH_SERVICE_BASE_URL")

	reqBody, err := json.Marshal(req)
	if err != nil {
		return 0, nil, nil, false, err
	}

	url := fmt.Sprintf("%s/api/v1/encrypt", baseUrl)

	statusCode, response, err := http.SendPost(ctx, url, reqBody)
	if err != nil {
		logger.Error(ctx, err, "error while calling auth service for creating user",
			map[string]interface{}{"url": url})
		return 0, nil, nil, false, err
	}

	return MarshalStandardResponse(ctx, url, statusCode, err, response)
}
