package handlers

import (
	"collection-service/internal/utils"
	"github.com/gin-gonic/gin"
)

func NotFoundHandler(c *gin.Context) {
	utils.NotFoundError(c, "This api endpoint is not available")
}
