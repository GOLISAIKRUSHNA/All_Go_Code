package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/client"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"strings"

	"github.com/gin-gonic/gin"
)

type ClientHandler struct {
	handlers.BaseHandler
	clientService client.IClientService
}

func InitClientHandler(ctx context.Context) *ClientHandler {
	handler := ClientHandler{
		clientService: client.InitClientService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *ClientHandler) GetClientConfig(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientHandler.GetClientConfig"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	configReq := request.Config{
		ConfigName: c.Query("config"),
	}

	res, err := u.clientService.GetClientConfig(ctx, c.Param("client_ref_number"), configReq)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, res)

}

func (u *ClientHandler) GetClientNames(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientHandler.GetClientNames"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	clientRefNumbers := strings.Split(c.Query("client_ref_number"), ",")

	res, err := u.clientService.GetClientNames(ctx, clientRefNumbers)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, res)
}

// Function will return service_providers for a client
func (u *ClientHandler) GetServiceProvidersForClient(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientHandler.GetClientServiceProviders"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	clientRefNumber := c.Param("client_ref_number")
	params := c.Request.URL.Query()
	m := make(map[string]string)
	for k, v := range params {
		m[k] = v[0]
	}
	requestParams := request.ClientServiceProviderReq{
		ClientRefNumber: clientRefNumber,
		Status:          "ACTIVE",
	}
	res, err := u.clientService.GetServiceProvidersForClient(ctx, requestParams)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}
	u.ResponseSuccess(c, res)
}

func (u *ClientHandler) UpdateClientConfig(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientHandler.UpdateClientConfig"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	configReq := make(map[string]interface{})
	if err := c.ShouldBindJSON(&configReq); err != nil {
		u.ResponseError(c, err.Error())
		return
	}
	res, err := u.clientService.UpdateClientConfig(ctx, c.Param("client_ref_number"), configReq)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, res)

}

func (u *ClientHandler) GetClientAttributes(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientHandler.GetClientAttributes"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	clientRefNumber := c.Param("client_ref_number")
	res, err := u.clientService.GetClientAttributes(ctx, clientRefNumber)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, res)
}
