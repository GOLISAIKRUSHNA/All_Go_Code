package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type AddressHandler struct {
	handlers.BaseHandler
	customerAddressService customer.ICustomerAddressService
}

func InitAddressHandler(ctx context.Context) *AddressHandler {
	handler := AddressHandler{
		customerAddressService: customer.InitCustomerAddressService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *AddressHandler) GetAddresses(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AddressHandler.GetAddresses"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	addresses, err := u.customerAddressService.GetAddresses(ctx, c.Query("customer_ref_number"))
	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, response.CustomerAddressesResp{Addresses: addresses})
}

func (u *AddressHandler) CreateAddresses(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AddressHandler.CreateAddresses"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var createAddressRequest request.CreateAddressRequest

	utils.ValidatePostRequest(c, &createAddressRequest)

	res, err := u.customerAddressService.CreateAddress(ctx, createAddressRequest)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}

	u.ResponseSuccess(c, res)
}
