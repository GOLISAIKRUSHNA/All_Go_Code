package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type ContactHandler struct {
	handlers.BaseHandler
	customerContactService customer.ICustomerContactService
}

func InitContactHandler(ctx context.Context) *ContactHandler {
	handler := ContactHandler{
		customerContactService: customer.InitCustomerContactService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *ContactHandler) AddContacts(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ContactHandler.AddContacts"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var contactReq request.AddContact
	utils.ValidatePostRequest(c, &contactReq)

	contacts, err := u.customerContactService.AddCustomerContact(ctx, contactReq)
	if err != nil {
		u.ResponseError(c, err.Error())
	} else {
		u.ResponseCreated(c, contacts)
	}

}

// this is handler function for customer contact list
func (u *ContactHandler) CustomerContactList(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ContactHandler.CustomerContactList"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	filter := request.CustomerContactListFilter{
		CaseRefNumber:     c.Query("case_ref_number"),
		CustomerRefNumber: c.Query("customer_ref_number"),
	}
	// Calling customer contact function in service
	contactList, err := u.customerContactService.CustomerContactList(ctx, filter)
	if err != nil {
		u.ResponseError(c, err.Error())
	} else {
		// If data is empty, return empty response with status code 200
		if len(contactList.Contacts) == 0 || contactList.Contacts == nil {
			contactList.Contacts = []response.Contacts{}
		}
		u.ResponseSuccess(c, contactList)
	}

}
