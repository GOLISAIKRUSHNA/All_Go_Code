package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/violations"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

type ViolationHandler struct {
	handlers.BaseHandler
	violationService violations.IViolationService
}

func InitViolationHandler(ctx context.Context, violationService violations.IViolationService) *ViolationHandler {
	handler := ViolationHandler{
		violationService: violationService,
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *ViolationHandler) GetViolations(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ViolationHandler.GetViolations"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	var id []string
	idParam, exists := c.GetQuery("id")
	if exists && idParam != "" {
		id = strings.Split(idParam, ",")
	}

	req := request.GetViolationsReq{
		ID:              id,
		ClientRefNumber: c.Query("client_ref_number"),
	}

	res, err := u.violationService.GetViolations(ctx, req)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}

	u.ResponseSuccess(c, res)
}

func (u *ViolationHandler) CreateViolation(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ViolationHandler.CreateViolation"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var req request.ViolationReq
	utils.ValidatePostRequest(c, &req)

	err := u.violationService.CreateViolation(ctx, req)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}

	u.ResponseSuccess(c, nil)
}

func (u *ViolationHandler) UpdateViolation(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ViolationHandler.UpdateViolation"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var req request.UpdateViolationReq
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		u.ResponseError(c, "Invalid ID")
		return
	}
	req.ID = id
	utils.ValidatePostRequest(c, &req)

	err = u.violationService.UpdateViolation(ctx, req)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}

	u.ResponseSuccess(c, nil)
}

func (u *ViolationHandler) DeleteViolation(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ViolationHandler.DeleteViolation"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		u.ResponseError(c, "Invalid ID")
		return
	}

	err = u.violationService.DeleteViolation(ctx, id)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}

	u.ResponseSuccess(c, nil)
}
