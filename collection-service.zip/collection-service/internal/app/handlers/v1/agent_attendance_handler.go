package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/agent"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type AgentAttendanceHandler struct {
	handlers.BaseHandler
	agentAttendanceService agent.IAgentAttendanceService
}

func InitAgentAttendanceHandler(ctx context.Context, agentAttendanceService agent.IAgentAttendanceService) *AgentAttendanceHandler {
	handler := AgentAttendanceHandler{
		agentAttendanceService: agentAttendanceService,
	}
	handler.SetContext(ctx)
	return &handler
}

func (a *AgentAttendanceHandler) MarkAttendance(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentAttendanceHandler.MarkAttendance"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var attReq request.MarkAttendanceReq
	utils.ValidatePostRequest(c, &attReq)
	_, err := a.agentAttendanceService.MarkAttendance(ctx, attReq)
	if err != nil {
		a.ResponseError(c, err.Error())
	}
	a.ResponseSuccess(c, nil)
}

// GetAttendanceList
func (u *AgentAttendanceHandler) GetAttendanceList(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentAttendanceHandler.GetAttendanceList"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	attendanceRequestScope := enum.StringToHierarchyScopeEnum(c.Query("attendance_request_scope"))

	req := request.GetAttendanceReq{
		AgentRefNumber:         c.Query("agent_ref_number"),
		ApprovalStatus:         c.Query("approval_status"),
		AttendanceRequestScope: attendanceRequestScope,
	}
	res, err := u.agentAttendanceService.GetAttendance(ctx, req)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}
	u.ResponseSuccess(c, res)

}

func (a *AgentAttendanceHandler) UpdateAttendances(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentAttendanceHandler.UpdateAttendances"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var attReq request.AttendanceUpdateReq

	utils.ValidatePostRequest(c, &attReq)

	_, err := a.agentAttendanceService.UpdateAttendances(ctx, attReq)
	if err != nil {
		a.ResponseError(c, err.Error())
	}
	a.ResponseSuccess(c, nil)
}
