package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/pincode"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

type PincodeHandler struct {
	handlers.BaseHandler
	pincodeService pincode.IPincodeService
}

func InitPincodeHandler(ctx context.Context) *PincodeHandler {
	handler := PincodeHandler{
		pincodeService: pincode.InitPincodeService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (p *PincodeHandler) GetPincodeDetails(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "PincodeHandler.GetPincodeDetails"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	// If pincode is empty
	if c.Param("pincode") == "" {
		utils.MissingParamsException(c,
			[]string{fmt.Sprintf("%s ", c.Param("pincode"))})
	}

	pincode, err := strconv.Atoi(c.Param("pincode"))
	if err != nil {
		p.ResponseError(c, "conversion error string to int")
		return
	}

	res, err := p.pincodeService.GetPincodeDetails(ctx, pincode)
	if err != nil {
		p.ResponseError(c, err.Error())
		return
	}
	p.ResponseSuccess(c, res)
}
