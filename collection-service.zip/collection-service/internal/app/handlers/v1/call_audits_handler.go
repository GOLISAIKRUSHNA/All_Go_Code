package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/call_audits"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"strconv"

	"github.com/gin-gonic/gin"
)

type CallAuditsHandler struct {
	handlers.BaseHandler
	caseAuditsService call_audits.ICallAuditsService
}

func InitCallAuditsHandler(ctx context.Context, caseAuditsService call_audits.ICallAuditsService) *CallAuditsHandler {
	handler := CallAuditsHandler{
		caseAuditsService: caseAuditsService,
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *CallAuditsHandler) CreateCallAudits(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CallAuditsHandler.CreateCallAudits"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var request request.CallAudits
	utils.ValidatePostRequest(c, &request)
	err := u.caseAuditsService.CreateCallAudits(ctx, request)
	if err != nil {
		panic(err)
	}
	u.ResponseCreated(c, nil)
}

func (u *CallAuditsHandler) CallAuditsList(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CallAuditsHandler.CallAuditsList"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	pageNo := c.Query("page_no")
	page, _ := strconv.Atoi(pageNo)

	queryRequest := request.CallAuditsList{
		AuditAgentRefNumber: c.Query("audit_agent_ref_number"),
		AuditRefNumber:      c.Query("audit_ref_number"),
		Search:              c.Query("search"),
		Status:              c.Query("status"),
		Sort:                c.Query("sort"),
		PageNo:              page,
	}

	response, err := u.caseAuditsService.CallAuditsList(ctx, queryRequest)
	if err != nil {
		panic(err)
	}

	u.ResponseSuccess(c, response)
}

func (u *CallAuditsHandler) CallAuditResponseSubmit(c *gin.Context) {
	if span := tracing.TraceSpan(c, "CallAuditsHandler.CallAuditsList"); span != nil {
		defer span.End()
	}

	var requestBody request.CallAuditSubmit
	utils.ValidatePostRequest(c, &requestBody)
	param := request.CallAuditParam{
		AuditRefNumber: c.Param("audit_ref_number"),
	}
	response, err := u.caseAuditsService.CallAuditSubmitResponse(c, requestBody, param)
	if err != nil {
		panic(err)
	}
	u.ResponseSuccess(c, response)
}

func (u *CallAuditsHandler) AuditAgentAllocate(c *gin.Context) {
	if span := tracing.TraceSpan(c, "CallAuditsHandler.AllocateAgentForCallAudits"); span != nil {
		defer span.End()
	}

	var requestBody request.AuditAgentAllocate
	utils.ValidatePostRequest(c, &requestBody)
	err := u.caseAuditsService.AuditAgentAllocate(c, requestBody)
	if err != nil {
		panic(err)
	}
	u.ResponseSuccess(c, nil)
}
