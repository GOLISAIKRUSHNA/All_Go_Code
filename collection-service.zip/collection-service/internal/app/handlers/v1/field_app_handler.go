package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/fieldapp"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"context"

	"github.com/gin-gonic/gin"
)

type FieldAppHandler struct {
	handlers.BaseHandler
	fieldAppService fieldapp.IFieldAppService
}

func InitFieldAppHandler(ctx context.Context, service fieldapp.IFieldAppService) *FieldAppHandler {
	return &FieldAppHandler{
		fieldAppService: service,
	}
}

func (h *FieldAppHandler) HomePage(c *gin.Context) {

	var homePageRequest request.HomePageRequest
	ctx := utils.FetchRequestCtx(c)

	utils.ValidatePostRequest(c, &homePageRequest)

	homePageData, err := h.fieldAppService.GetHomePageData(ctx, homePageRequest)
	if err != nil {
		h.ResponseError(c, err.Error())
		return
	}

	if !utils.IsEmptyStruct(homePageData) {
		h.ResponseSuccess(c, homePageData)
	} else {
		h.ResponseSuccess(c, homePageData)
	}
}
