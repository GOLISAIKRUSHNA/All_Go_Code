package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/helper"
	"collection-service/internal/utils"

	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type HelperHandler struct {
	handlers.BaseHandler
	helperService *helper.HelperService
}

func InitHelperHandler(ctx context.Context) *HelperHandler {
	handler := HelperHandler{
		helperService: helper.InitHelperService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *HelperHandler) SyncActiveLoan(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "HelperHandler.SyncActiveLoan"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	err := u.helperService.SyncLoanAttributes(ctx)
	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, nil)
}
