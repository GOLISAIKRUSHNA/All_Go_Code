package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/dialer"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type DialerHandler struct {
	handlers.BaseHandler
	dialerService dialer.IDialerService
}

func InitDialerHandler(ctx context.Context) *DialerHandler {
	handler := DialerHandler{
		dialerService: dialer.InitDialerService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (u DialerHandler) Click2Call(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "DialerHandler.Click2Call"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var request request.Click2Call
	utils.ValidatePostRequest(c, &request)
	callResponse, err := u.dialerService.Click2Call(ctx, request)
	if err != nil {
		panic(err)
	}
	u.ResponseCreated(c, callResponse)
}
