package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/client"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"github.com/gin-gonic/gin"
)

type ServiceProviderHandler struct {
	handlers.BaseHandler
	clientService client.IClientService
}

func InitServiceProviderHandler(ctx context.Context) *ServiceProviderHandler {
	handler := ServiceProviderHandler{
		clientService: client.InitClientService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

// Function will return service_providers for a client
func (u *ServiceProviderHandler) GetClientForServiceProviders(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientHandler.GetServiceProvidersForClient"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	serviceProviderRefNumber := c.Param("service_provider_ref_number")
	params := c.Request.URL.Query()
	m := make(map[string]string)
	for k, v := range params {
		m[k] = v[0]
	}
	requestParams := request.ClientServiceProviderReq{
		ServiceProviderRefNumber: serviceProviderRefNumber,
		Status:                   "ACTIVE",
	}
	res, err := u.clientService.GetClientsForServiceProvider(ctx, requestParams)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}
	u.ResponseSuccess(c, res)
}
