package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/special_offer"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type SpecialOfferHandler struct {
	handlers.BaseHandler
	specialOfferService special_offer.ISpecialOfferService
}

func InitSpecialOfferHandler(c context.Context, specialOfferService special_offer.ISpecialOfferService) *SpecialOfferHandler {
	handler := SpecialOfferHandler{
		specialOfferService: specialOfferService,
	}
	handler.SetContext(c)

	return &handler
}

func (a *SpecialOfferHandler) GetSpecialOffers(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentHandler.GetSpecialOffers"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	caseRefNumber := c.Param("case_ref_number")

	agentInfo, err := a.specialOfferService.GetSpecialOffers(ctx, caseRefNumber)
	if err != nil {
		a.ResponseError(c, err.Error())
		return
	}

	a.ResponseSuccess(c, agentInfo)

}

func (a *SpecialOfferHandler) GetEligibleSpecialOffers(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "SpecialOfferHandler.GetEligibleSpecialOffers"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	caseRefNumber := c.Param("case_ref_number")
	queueType := c.Query("queue_type")

	queueTypeEnum := enum.StringToQueueType(queueType)

	agentInfo, err := a.specialOfferService.GetEligibleSpecialOffers(ctx, caseRefNumber, queueTypeEnum)
	if err != nil {
		a.ResponseError(c, err.Error())
		return
	}

	a.ResponseSuccess(c, agentInfo)

}

func (a *SpecialOfferHandler) ActivateSpecialOffer(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "SpecialOfferHandler.ActivateSpecialOffer"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	caseRefNumber := c.Param("case_ref_number")

	var activateSpecialOfferReq request.ActivateSpecialOfferReq
	utils.ValidatePostRequest(c, &activateSpecialOfferReq)

	err := a.specialOfferService.ActivateSpecialOffer(ctx, caseRefNumber, activateSpecialOfferReq)
	if err != nil {
		a.ResponseError(c, err.Error())
		return
	}

	a.ResponseSuccess(c, nil)

}

func (a *SpecialOfferHandler) DeactivateSpecialOffer(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "SpecialOfferHandler.DeactivateSpecialOffer"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var deactivateSpecialOfferReq request.DeactivateSpecialOfferReq

	utils.ValidatePostRequest(c, &deactivateSpecialOfferReq)

	err := a.specialOfferService.DeactivateSpecialOffer(ctx, &deactivateSpecialOfferReq)
	if err != nil {
		a.ResponseError(c, err.Error())
		return
	}

	a.ResponseSuccess(c, nil)
}

func (a *SpecialOfferHandler) CreateSpecialOffer(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "SpecialOfferHandler.CreateSpecialOffer"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var createSpecialOffer request.PostCreateSpecialOffer

	utils.ValidatePostRequest(c, &createSpecialOffer)

	resp, err := a.specialOfferService.CreateSP(ctx, &createSpecialOffer)
	if err != nil {
		a.ResponseError(c, err.Error())
		return
	}

	a.ResponseSuccess(c, resp)
}
