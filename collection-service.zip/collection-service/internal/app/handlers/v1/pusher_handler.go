package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/pusher"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type PusherHandler struct {
	handlers.BaseHandler
	pusherService pusher.IPusherService
}

func InitPusherHandler(ctx context.Context, pusherService pusher.IPusherService) *PusherHandler {
	handler := PusherHandler{pusherService: pusherService}
	handler.SetContext(ctx)

	return &handler
}

func (u *PusherHandler) Notify(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "PusherHandler.Notify"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	objectRefNumber := c.Query("object_ref_number")
	err := u.pusherService.Notify(ctx, objectRefNumber)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}
	u.ResponseSuccess(c, nil)
}
