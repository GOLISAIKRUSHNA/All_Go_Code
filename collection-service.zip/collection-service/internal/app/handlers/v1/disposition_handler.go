package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/disposition"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

type DispositionHandler struct {
	handlers.BaseHandler
	dispositionService disposition.IDispositionService
}

func InitDispositionHandler(ctx context.Context) *DispositionHandler {
	handler := DispositionHandler{
		dispositionService: disposition.InitDispositionService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *DispositionHandler) GenerateDisposition(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "DispositionHandler.Create"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var disposition request.Disposition
	utils.ValidatePostRequest(c, &disposition)

	err := u.dispositionService.CreateDisposition(ctx, disposition)
	if err != nil {
		panic(err)
	}
	res := map[string]string{"message": "created successfully"}
	u.ResponseCreated(c, res)
}

func (u *DispositionHandler) GetCustomerDispositionsList(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "DispositionHandler.GetCustomerDispositionsList"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	// If customer reference number is empty
	if c.Param("customer_ref_number") == "" {
		utils.MissingParamsException(c,
			[]string{fmt.Sprintf("%s ", c.Param("customer_ref_number"))})
	}
	filter := request.GetDisposition{
		CustomerRefNumber: c.Param("customer_ref_number"),
	}

	pageNo := c.Query("page_no")
	page, _ := strconv.ParseInt(pageNo, 10, 64)
	pagination := dto.PaginationData{
		CurrentPage: page,
	}
	res, err := u.dispositionService.GetDispositionsList(ctx, filter, pagination)
	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, res)
}

func (u *DispositionHandler) GetCaseDispositionsList(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "DispositionHandler.GetCaseDispositionsList"); span != nil {
		defer span.End()
	}
	// If customer reference number is empty
	if c.Param("case_ref_number") == "" {
		utils.MissingParamsException(c,
			[]string{fmt.Sprintf("%s ", c.Param("case_ref_number"))})
	}

	pageNo := c.Query("page_no")

	page, _ := strconv.ParseInt(pageNo, 10, 64)

	pagination := dto.PaginationData{
		CurrentPage: page,
	}

	filter := request.GetDisposition{
		CaseRefNumber: c.Param("case_ref_number"),
	}
	res, err := u.dispositionService.GetDispositionsList(c, filter, pagination)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}

	u.ResponseSuccess(c, res)
}
