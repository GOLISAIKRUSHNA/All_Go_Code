package handlers_v1

import (
	"collection-service/internal/app/handlers"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/customer"
	"context"
)

type CustomerHandler struct {
	handlers.BaseHandler
	customerService customer.ICustomerService
	caseService     _case.ICaseService
}

func InitCustomerHandler(ctx context.Context, caseService _case.ICaseService) *CustomerHandler {
	handler := CustomerHandler{
		customerService: customer.InitCustomerService(ctx),
		caseService:     caseService,
	}
	handler.SetContext(ctx)

	return &handler
}
