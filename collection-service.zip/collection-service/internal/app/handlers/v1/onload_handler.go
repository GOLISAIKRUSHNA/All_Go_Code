package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/onload"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type OnLoadHandler struct {
	handlers.BaseHandler
	onLoadSvc onload.IOnLoadService
}

func InitOnLoadHandler(ctx context.Context) *OnLoadHandler {
	handler := OnLoadHandler{
		onLoadSvc: onload.InitOnLoadService(ctx),
	}
	handler.SetContext(ctx)
	return &handler
}

func (u *OnLoadHandler) PostLoginInfo(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "PostLogin"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	postLoginParams := &request.PostLoginParams{
		AppName:                  c.GetHeader("X-App"),
		Object:                   enum.StringToUserObject(c.Query("object")),
		ObjectRefNumber:          c.Query("object_ref_number"),
		ClientRefNumber:          c.Query("client_ref_number"),
		ServiceProviderRefNumber: c.Query("service_provider_ref_number"),
	}

	postLoginInfo, err := u.onLoadSvc.GetPostLoginInfo(ctx, postLoginParams)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, postLoginInfo)
}

func (u *OnLoadHandler) OnLoad(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "OnLoadHandler.GetLoadInfo"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	loadInfo := u.onLoadSvc.GetLoadInfo(ctx)
	u.ResponseSuccess(c, loadInfo)
}
