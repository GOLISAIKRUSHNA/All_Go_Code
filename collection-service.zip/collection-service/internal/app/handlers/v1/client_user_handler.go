package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/client_user"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

type ClientUserHandler struct {
	handlers.BaseHandler
	clientUserService client_user.IClientUserService
}

func InitClientUserHandler(ctx context.Context) *ClientUserHandler {
	handler := ClientUserHandler{
		clientUserService: client_user.InitClientUserService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

// Create client user handler
func (u *ClientUserHandler) Create(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientUserHandler.Create"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var clientUserReq request.CreateClientUserReq

	utils.ValidatePostRequest(c, &clientUserReq)

	err := u.clientUserService.Create(ctx, clientUserReq)
	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, nil)
}

// GetAll client-user handler
func (u *ClientUserHandler) GetClientUsers(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientUserHandler.GetClientUsers"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	clientUserStatus := c.Query("status")
	status := enum.StringToStatus(clientUserStatus)

	pageNo := c.Query("page_no")

	page, _ := strconv.ParseInt(pageNo, 10, 64)

	pagination := dto.PaginationData{
		CurrentPage: page,
	}
	req := request.GetClientUserQueryParam{
		ClientRefNumber:     c.Query("client_ref_number"),
		ClientUserRefNumber: c.Query("client_user_ref_number"),
		MobileNumber:        c.Query("mobile_number"),
		Email:               c.Query("email"),
		Status:              status,
		Search:              c.Query("search"),
	}
	res, err := u.clientUserService.FindClientUserList(ctx, req, pagination)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, res)
}

// Get single client-user handler
func (u *ClientUserHandler) GetClientUser(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientUserHandler.GetClientUser"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	clientUserRefNumber := c.Param("client_user_ref_number")

	res, err := u.clientUserService.GetClientUser(ctx, clientUserRefNumber)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, res)
}

// Update client user handler
func (u *ClientUserHandler) Update(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientUserHandler.Update"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var clientUserReq request.UpdateClientUserReq

	utils.ValidatePostRequest(c, &clientUserReq)
	_, err := u.clientUserService.Update(ctx, clientUserReq, c.Param("client_user_ref_number"))

	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, nil)

}

func (u *ClientUserHandler) AutoSuggestClientUsers(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientUserHandler.AutoSuggestClientUsers"); span != nil {
		defer span.End()
	}

	ctx := utils.FetchRequestCtx(c)
	pageNo := c.Query("page_no")
	page, _ := strconv.ParseInt(pageNo, 10, 64)
	pagination := dto.PaginationData{
		CurrentPage: page,
	}
	//access the url params from context.
	req := request.AutoSuggestClientUserReq{
		Name:            c.Query("name"),
		ClientRefNumber: c.Query("client_ref_number"),
		TeamRefNumber:   c.Query("team_ref_number"),
	}
	utils.ValidateParamRequest(c, &req)

	res, err := u.clientUserService.GetAllTheClientUsersWithMatchingName(ctx, req, pagination)

	if err != nil {
		fmt.Println(err)
		return
	}

	u.ResponseSuccess(c, res)

}
