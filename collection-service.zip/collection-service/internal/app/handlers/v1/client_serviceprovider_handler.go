package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/client_serviceprovider"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type ClientServiceProviderHandler struct {
	handlers.BaseHandler
	clientServiceProviderService client_serviceprovider.IClientServiceProviderService
}

func InitClientServiceProviderHandler(ctx context.Context, clientServiceProviderService client_serviceprovider.IClientServiceProviderService) *ClientServiceProviderHandler {
	handler := ClientServiceProviderHandler{clientServiceProviderService: clientServiceProviderService}
	handler.SetContext(ctx)
	return &handler
}

func (u *ClientServiceProviderHandler) UpdateClientServiceProvider(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "ClientServiceProviderHandler.UpdateClientServiceProvider"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	req := request.UpdateClientServiceProviderReq{
		ClientRefNumber:          c.Param("client_ref_number"),
		ServiceProviderRefNumber: c.Param("service_provider_ref_number"),
	}

	utils.ValidatePostRequest(c, &req)

	err := u.clientServiceProviderService.UpdateClientServiceProvider(ctx, req)

	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, nil)
}
