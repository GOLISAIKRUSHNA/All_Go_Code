package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/communication_service"
	"collection-service/internal/utils"
	"context"
	"github.com/gin-gonic/gin"
)

type CommunicationHandler struct {
	handlers.BaseHandler
	communicationService communication_service.ICommunicationService
}

func InitCommunicationHandler(ctx context.Context, communicationService communication_service.ICommunicationService) *CommunicationHandler {
	handler := CommunicationHandler{communicationService: communicationService}
	handler.SetContext(ctx)
	return &handler
}

// get case allocation details
func (u CommunicationHandler) GetCaseAllocationDetails(c *gin.Context) {
	ctx := utils.FetchRequestCtx(c)

	resp, err := u.communicationService.GetCaseAllocationDetails(ctx, c.Param("case_ref_number"))
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}

	u.ResponseSuccess(c, resp)
}
