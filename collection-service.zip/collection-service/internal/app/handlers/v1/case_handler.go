package handlers_v1

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/app/handlers"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"strconv"

	"github.com/gin-gonic/gin"
)

type CaseHandler struct {
	handlers.BaseHandler
	caseService _case.ICaseService
}

func InitCaseHandler(ctx context.Context, caseService _case.ICaseService) *CaseHandler {
	handler := CaseHandler{
		caseService: caseService,
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *CaseHandler) GenerateCase(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CaseHandler.ReadOne"); span != nil {
		defer span.End()
	}

	ctx := utils.FetchRequestCtx(c)

	var caseReq request.GenerateCase
	utils.ValidatePostRequest(c, &caseReq)
	caseResp, err := u.caseService.GenerateCase(ctx, caseReq)
	if err != nil {
		panic(err)
	}
	u.ResponseCreated(c, caseResp)
}

func (u *CaseHandler) GetCaseListWithPaginate(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CaseHandler.GetCaseList"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	getPTPCaseStr := c.Query("get_ptp_case")
	getUntouchedcases := c.Query("get_untouched_case")
	pageNo := c.Query("page_no")

	page, _ := strconv.Atoi(pageNo)
	getPtpCase, _ := strconv.ParseBool(getPTPCaseStr)
	getUntouchedCases, _ := strconv.ParseBool(getUntouchedcases)
	defaultSort, _ := strconv.ParseBool(c.Query("default"))

	var allocatedTo *string
	allocatedToVal, exists := c.GetQuery("allocated_to")
	if exists {
		allocatedTo = &allocatedToVal
	}

	filter := request.CaseListFilter{
		AllocatedTo:               allocatedTo,
		CustomerRefNumber:         c.Query("customer_ref_number"),
		CaseRefNumber:             c.Query("case_ref_number"),
		LoanRefNumber:             c.Query("loan_ref_number"),
		ClientLoanId:              c.Query("client_loan_id"),
		ClientCustomerId:          c.Query("client_customer_id"),
		GetPTPCases:               getPtpCase,
		GetUntouchCases:           getUntouchedCases,
		CurrentDPDBucket:          c.Query("bucket"),
		LastDisposition:           c.Query("last_disposition"),
		SortByDue:                 c.Query("sort_by_due"),
		SortByBucket:              c.Query("sort_by_bucket"),
		SortByLastDispositionDate: c.Query("sort_by_last_disposition_date"),
		FollowupDate:              c.Query("followup_date"),
		SearchBy:                  c.Query("search_by"),
		SearchKey:                 c.Query("search_key"),
		PageNo:                    page,
		ClientRefNumber:           c.Query("client_ref_number"),
		ServiceProviderRefNumber:  c.Query("service_provider_ref_number"),
		Object:                    enum.StringToUserObject(c.Query("object")),
		ObjectRefNumber:           c.Query("object_ref_number"),
		Default:                   defaultSort,
		XApp:                      c.GetHeader(constants.X_APP),
	}

	response, err := u.caseService.FindCaseListWithPaginate(ctx, filter)
	if err != nil {
		panic(err)
	}
	u.ResponseSuccess(c, response)

}

func (u *CaseHandler) GetCaseLoan(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CaseHandler.GetCaseLoanForAgents"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	caseRefNumber := c.Param("case_ref_number")
	status := c.Query("status")
	serviceProviderRefNumber := c.Query("service_provider_ref_number")

	filter := request.CaseLoanFilter{
		CaseRefNumber:            caseRefNumber,
		Status:                   status,
		ServiceProviderRefNumber: serviceProviderRefNumber,
		Object:                   enum.StringToUserObject(c.Query("object")),
		ObjectRefNumber:          c.Query("object_ref_number"),
		ClientRefNumber:          c.Query("client_ref_number"),
		XApp:                     c.GetHeader(constants.X_APP),
	}

	res, err := u.caseService.GetCaseLoan(ctx, filter)
	if err != nil {
		panic(err)
	}

	u.ResponseSuccess(c, res)
}

/*
AllocateCase :
*/
func (u *CaseHandler) AllocateCase(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CaseHandler.AllocateCase"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var request request.CaseAllocationReq
	utils.ValidatePostRequest(c, &request)
	err := u.caseService.AllocateCase(ctx, request)
	if err != nil {
		utils.InternalServerError(c, err, "")
	}
	type EmptyData interface{}
	var data EmptyData
	u.ResponseSuccess(c, data)
}

/*
DeAllocateCase :
*/
func (u *CaseHandler) DeAllocateCase(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CaseHandler.DeAllocateCase"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var request request.CaseDeAllocationReq
	utils.ValidatePostRequest(c, &request)
	err := u.caseService.DeAllocateCase(ctx, request)
	if err != nil {
		utils.InternalServerError(c, err, "")
	}
	type EmptyData interface{}
	var data EmptyData
	u.ResponseSuccess(c, data)
}

func (u *CaseHandler) SendPaymentLink(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CaseHandler.SendPaymentLink"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var sendPaymentLinkReq request.SendPaymentLinkReq

	utils.ValidatePostRequest(c, &sendPaymentLinkReq)

	caseRefNumber := c.Param("case_ref_number")
	err := u.caseService.SendPaymentLink(ctx, caseRefNumber, sendPaymentLinkReq)
	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, nil)
}

/*
CaseListApi :with filter and no paginations - mainly used for map location
@request : c *gin.Context
@response : CaseListResponse
@author:Tejas Surve
*/
func (u *CaseHandler) GetCaseList(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CaseHandler.GetCaseList"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	getPTPCaseStr := c.Query("get_ptp_case")
	getUntouchedcases := c.Query("get_untouched_case")
	getPtpCase, _ := strconv.ParseBool(getPTPCaseStr)
	getUntouchedCases, _ := strconv.ParseBool(getUntouchedcases)
	var allocatedTo *string
	allocatedToVal, exists := c.GetQuery("allocated_to")
	if exists {
		allocatedTo = &allocatedToVal
	}

	filter := request.CaseListFilter{
		AllocatedTo:               allocatedTo,
		CustomerRefNumber:         c.Query("customer_ref_number"),
		CaseRefNumber:             c.Query("case_ref_number"),
		LoanRefNumber:             c.Query("loan_ref_number"),
		ClientLoanId:              c.Query("client_loan_id"),
		ClientCustomerId:          c.Query("client_customer_id"),
		GetPTPCases:               getPtpCase,
		GetUntouchCases:           getUntouchedCases,
		CurrentDPDBucket:          c.Query("bucket"),
		LastDisposition:           c.Query("last_disposition"),
		SortByDue:                 c.Query("sort_by_due"),
		SortByBucket:              c.Query("sort_by_bucket"),
		SortByLastDispositionDate: c.Query("sort_by_last_disposition_date"),
		FollowupDate:              c.Query("followup_date"),
		SearchBy:                  c.Query("search_by"),
		SearchKey:                 c.Query("search_key"),
		ClientRefNumber:           c.Query("client_ref_number"),
		ServiceProviderRefNumber:  c.Query("service_provider_ref_number"),
		Object:                    enum.StringToUserObject(c.Query("object")),
		ObjectRefNumber:           c.Query("object_ref_number"),
		XApp:                      c.GetHeader(constants.X_APP),
	}

	response, err := u.caseService.GetCaseList(ctx, filter)
	if err != nil {
		u.ResponseError(c, "Case list not found")
		return
	}
	u.ResponseSuccess(c, response)
}

/*
CaseListApi :with filter and no paginations - mainly used for map location
@request : c *gin.Context
@response : CaseListResponse
@author:Tejas Surve
*/
func (u *CaseHandler) CsatAttemptList(c *gin.Context) {
	if span := tracing.TraceSpan(c, "CaseHandler.GetCaseList"); span != nil {
		defer span.End()
	}
	params := c.Request.URL.Query()
	caseRefNumber := c.Param("case_ref_number")
	m := make(map[string]string)
	for k, v := range params {
		m[k] = v[0]
	}
	m["case_ref_number"] = caseRefNumber
	ctx := utils.FetchRequestCtx(c)

	response, err := u.caseService.CaseAttemptList(ctx, m)
	if err != nil {
		u.ResponseError(c, "Csat Attempt list not found")
		return
	}
	u.ResponseSuccess(c, response)
}

/*
Case search api:
@request : c *gin.Context, q="CASHSHDSK01"
@response : [{case1},{case2}] or []
@Author:Tejas Surve
*/
func (u *CaseHandler) SearchCase(c *gin.Context) {
	if span := tracing.TraceSpan(c, "CaseHandler.SearchCase"); span != nil {
		defer span.End()
	}
	req := request.SearchCaseReq{
		ClientRefNumber: c.Query("client_ref_number"),
		Query:           c.Query("q"),
	}
	ctx := utils.FetchRequestCtx(c)
	pageNo := c.Query("page_no")
	page, _ := strconv.ParseInt(pageNo, 10, 64)
	pagination := dto.PaginationData{
		CurrentPage: page,
	}
	response, err := u.caseService.SearchCase(ctx, req, pagination)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}
	u.ResponseSuccess(c, response)
}

func (u *CaseHandler) GetClientCases(c *gin.Context) {
	if span := tracing.TraceSpan(c, "CaseHandler.GetClientActiveCases"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	clientRefNumber := c.Param("client_ref_number")
	response, err := u.caseService.GetClientCases(ctx, clientRefNumber)
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}
	u.ResponseSuccess(c, response)
}
