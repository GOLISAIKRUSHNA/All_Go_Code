package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type LoanPaymentHandler struct {
	handlers.BaseHandler
	loanPaymentService loan.ILoanPaymentService
}

func InitLoanPaymentHandler(ctx context.Context, loanService loan.ILoanService) *LoanPaymentHandler {
	handler := LoanPaymentHandler{
		loanPaymentService: loan.InitLoanPaymentService(ctx, loanService),
	}
	handler.SetContext(ctx)

	return &handler
}

/*
Create loan payment entry
@Params: PaymentRequest
@return : data
@author : Tejas Surve
*/

func (l *LoanPaymentHandler) CreateLoanPayment(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "LoanPaymentHandler.CreateLoanPayment"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var loanPaymentReq request.LoanPayment
	utils.ValidatePostRequest(c, &loanPaymentReq)
	l.loanPaymentService.CreateLoanPayment(ctx, loanPaymentReq)
	var response struct{}
	l.ResponseCreated(c, response)
}

/*
Payable details api based on case, loan, customer
@Params: null
@return : data
@author : Tejas Surve
*/

func (l *LoanPaymentHandler) GetPayableDetails(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "LoanPaymentHandler.GetPayableDetails"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	payableDetails := request.PayableDetails{
		CaseRefNumber:            c.Query("case_ref_number"),
		LoanRefNumber:            c.Query("loan_ref_number"),
		ServiceProviderRefNumber: c.Query("service_provider_ref_number"),
	}
	payableResponse := l.loanPaymentService.GetPayableDetails(ctx, payableDetails)
	if utils.IsNotEmpty(payableResponse.PayableDetails.ClientCustomerId) {
		l.ResponseSuccess(c, payableResponse)
	} else {
		var resp interface{} = nil
		l.ResponseSuccess(c, resp)
	}

}
