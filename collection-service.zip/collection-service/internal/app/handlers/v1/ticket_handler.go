package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/ticket"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"strconv"

	"github.com/gin-gonic/gin"
)

type TicketHandler struct {
	handlers.BaseHandler
	ticketService ticket.ITicketService
}

func InitTicketHandler(ctx context.Context) *TicketHandler {
	handler := TicketHandler{
		ticketService: ticket.InitTicketService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (t *TicketHandler) GetTicketListWithPaginate(c *gin.Context) {
	if span := tracing.TraceSpan(c, "TicketHandler|GetTicketListWithPaginate"); span != nil {
		defer span.End()
	}
	pageNo, _ := strconv.Atoi(c.Query("page"))
	isIssueFilled, _ := strconv.ParseBool(c.Query("is_issue_filled"))
	isSubIssueFilled, _ := strconv.ParseBool(c.Query("is_sub_issue_filled"))
	issueId, _ := strconv.Atoi(c.Query("issue_id"))
	subissueId, _ := strconv.Atoi(c.Query("sub_issue_id"))
	defalutSort, _ := strconv.ParseBool(c.Query("default"))
	listParams := request.TicketListReq{
		PageNo:               pageNo,
		AgentRefNumber:       c.Query("agent_ref_number"),
		CaseRefNumber:        c.Query("case_ref_number"),
		TicketRefNumber:      c.Query("ticket_ref_number"),
		SortByBlockedDate:    c.Query("sort_by_blocked_date"),
		IsIssueFilled:        isIssueFilled,
		IsSubIssueFilled:     isSubIssueFilled,
		Source:               c.Query("source"),
		Reason:               c.Query("reason"),
		SortByTotalDueAmount: c.Query("sort_by_total_due_amount"),
		IssueId:              issueId,
		SubIssueId:           subissueId,
		IssueIds:             c.Query("issue_ids"),
		SubIssueIds:          c.Query("sub_issue_ids"),
		Default:              defalutSort,
	}
	list := t.ticketService.GetTicketsWithPagination(c, listParams)

	t.ResponseSuccess(c, list)
}

/*
Update ticket : update ticket details
update issue and ticket resolution
*/
func (u *TicketHandler) UpdateTicket(c *gin.Context) {
	if span := tracing.TraceSpan(c, "CallAuditsHandler.CallAuditsList"); span != nil {
		defer span.End()
	}
	ticketRefNumber := c.Param("ticket_ref_number")
	ctx := utils.FetchRequestCtx(c)

	var request request.UpdateTicket
	utils.ValidatePostRequest(c, &request)

	err := u.ticketService.UpdateTicket(ctx, ticketRefNumber, request)
	if err != nil {
		panic(err)
	}
	u.ResponseSuccess(c, nil)
}
