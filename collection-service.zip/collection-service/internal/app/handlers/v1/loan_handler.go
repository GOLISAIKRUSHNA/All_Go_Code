package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type LoanHandler struct {
	handlers.BaseHandler
	loanService loan.ILoanService
}

func InitLoanHandler(ctx context.Context, loanService loan.ILoanService) *LoanHandler {
	handler := LoanHandler{
		loanService: loanService,
	}
	handler.SetContext(ctx)

	return &handler
}

func (l *LoanHandler) ReadOne(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "LoanHandler.ReadOne"); span != nil {
		defer span.End()
	}

	loan_reference_number := c.Param("loan_reference_number")

	loan := l.loanService.FindLoan(c, loan_reference_number)
	l.ResponseSuccess(c, loan)
}

/*
Create & update Loan API
  - This api accept request.CreateUpdateLoanRequest Request, request contains loans, customer, collaterals, borrowers etc
  - Create loans and generate case based on loans
  - Return 201
  - @Author Tejas Surve
*/
func (l *LoanHandler) CreateAndUpdate(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "LoanHandler.CreateAndUpdate"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var loanReq request.CreateUpdateLoanRequest
	utils.ValidatePostRequest(c, &loanReq)

	loanRes, err := l.loanService.Create(ctx, loanReq)
	if err != nil {
		panic(err)
	}
	l.ResponseCreated(c, loanRes)
}
