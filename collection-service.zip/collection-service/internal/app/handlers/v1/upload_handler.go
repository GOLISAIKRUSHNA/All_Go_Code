package handlers_v1

import (
	"collection-service/internal/app/handlers"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/app/services/loan"
	"collection-service/internal/app/services/special_offer"
	"collection-service/internal/app/services/upload"
	"collection-service/internal/dto/request"
	"collection-service/internal/dto/response"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type UploadHandler struct {
	handlers.BaseHandler
	uploadService upload.IuploadService
}

func InitUploadHandler(ctx context.Context, loanService loan.ILoanService, caseService _case.ICaseService,
	specialOfferService special_offer.ISpecialOfferService) *UploadHandler {
	handler := UploadHandler{
		uploadService: upload.InitUploadService(ctx, loanService, caseService, specialOfferService),
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *UploadHandler) UploadFile(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "UploadHandler|UploadFile"); span != nil {
		defer span.End()
	}
	// Set maximum request body size
	c.Request.Body = http.MaxBytesReader(c.Writer, c.Request.Body, 30<<20) // 20 MB

	// Parse the multipart form
	if err := c.Request.ParseMultipartForm(30 << 20); err != nil {
		fmt.Println("Failed to parse multipart form:", err.Error())
		u.ResponseError(c, "Failed to parse multipart form")
		return
	}

	ctx := utils.FetchRequestCtx(c)

	// Get file from form field
	file, err := c.FormFile("file")
	if err != nil {
		u.ResponseError(c, err.Error())
		return
	}

	bulkUpload := request.BulkUploadRequest{
		Reason:        c.PostForm("reason"),
		UploadedBy:    c.PostForm("uploaded_by"),
		Type:          c.PostForm("type"),
		TypeRefNumber: c.PostForm("type_ref_number"),
		FileName:      file.Filename,
	}
	_, errUpload := u.uploadService.UploadFile(ctx, file, bulkUpload)
	if errUpload != nil {
		u.ResponseError(c, errUpload.Error())
	}
	u.ResponseSuccess(c, nil)
}

func (u *UploadHandler) GetUploadList(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "UploadHandler|GetUploadList"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	listParams := request.BulkUploadListRequest{
		Reason:     c.Query("reason"),
		Status:     c.Query("status"),
		PageNo:     c.Query("page"),
		UploadedBy: c.Query("uploaded_by"),
	}
	list := u.uploadService.GetBulkUploadList(ctx, listParams)

	u.ResponseSuccess(c, list)
}

func (u *UploadHandler) GetUploadDetails(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "UploadHandler|GetUploadDetails"); span != nil {
		defer span.End()
	}

	ctx := utils.FetchRequestCtx(c)

	uploadRefNumber := c.Param("upload_ref_number")
	uploadDetails := u.uploadService.GetBulkUploadDetails(ctx, uploadRefNumber)
	type Upload struct {
		UploadDetails *response.BulkUploadDetails `json:"upload"`
	}
	if !utils.IsEmptyStruct(uploadDetails) {
		u.ResponseSuccess(c, Upload{UploadDetails: &uploadDetails})
	} else {
		u.ResponseSuccess(c, Upload{})
	}

}
