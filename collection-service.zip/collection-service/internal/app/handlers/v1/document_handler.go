package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/customer"
	"collection-service/internal/dto/response"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type DocumentHandler struct {
	handlers.BaseHandler
	customerDocumentService customer.ICustomerDocumentService
}

func InitDocumentHandler(ctx context.Context) *DocumentHandler {
	handler := DocumentHandler{
		customerDocumentService: customer.InitCustomerDocumentService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (u *DocumentHandler) GetDocuments(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "DocumentHandler.GetDocuments"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	documents, err := u.customerDocumentService.GetDocuments(ctx, c.Query("customer_ref_number"), c.Query("loan_ref_number"))
	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, response.CustomerDocumentResp{Documents: documents})
}
