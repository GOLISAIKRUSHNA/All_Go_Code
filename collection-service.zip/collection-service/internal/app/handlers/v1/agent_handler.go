package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/agent"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

type AgentHandler struct {
	handlers.BaseHandler
	agentService agent.IAgentService
}

func InitAgentHandler(ctx context.Context) *AgentHandler {
	handler := AgentHandler{
		agentService: agent.InitAgentService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (a *AgentHandler) AgentInfo(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentHandler.AgentInfo"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	agentInfo, err := a.agentService.GetAgentInfo(ctx, c.Param("agent_ref_number"))

	if err != nil {
		a.ResponseError(c, err.Error())
		return
	}

	a.ResponseSuccess(c, agentInfo)

}

func (a *AgentHandler) CollectionSummary(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentHandler.CollectionSummary"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	collectionSummary, err := a.agentService.GetAgentCollectionSummary(ctx, c.Param("agent_ref_number"))
	if err != nil {
		a.ResponseError(c, err.Error())
	}
	a.ResponseSuccess(c, collectionSummary)

}

func (a *AgentHandler) AutoSuggestAgents(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentHandler.AutoSuggestAgents"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	pageNo := c.Query("page_no")
	page, _ := strconv.ParseInt(pageNo, 10, 64)
	pagination := dto.PaginationData{
		CurrentPage: page,
	}
	//access the url params from context.
	req := request.AutoSuggestParams{
		Name:                     c.Query("name"),
		ServiceProviderRefNumber: c.Query("service_provider_ref_number"),
		TeamRefNumber:            c.Query("team_ref_number"),
	}
	utils.ValidateParamRequest(c, &req)

	res, err := a.agentService.GetAllTheAgentsWithMatchingName(ctx, req, pagination)

	if err != nil {
		fmt.Println(err)
		return
	}

	a.ResponseSuccess(c, res)

}

// Create agent handler
func (u *AgentHandler) Create(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentHandler.Create"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var agents request.CreateAgentReq

	utils.ValidatePostRequest(c, &agents)

	res, err := u.agentService.Create(ctx, agents)

	if err != nil {
		u.ResponseError(c, err.Error())
	} else {
		u.ResponseSuccess(c, res)
	}

}

// Update agent handler
func (u *AgentHandler) Update(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentHandler.Update"); span != nil {
		defer span.End()
	}

	ctx := utils.FetchRequestCtx(c)

	var agents request.UpdateAgentReq

	utils.ValidatePostRequest(c, &agents)
	_, err := u.agentService.Update(ctx, agents, c.Param("agent_ref_number"))

	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, nil)

}

// GetAll agent handler
func (u *AgentHandler) GetAgentList(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "AgentHandler.FindAllUnexpired"); span != nil {
		defer span.End()
	}

	ctx := utils.FetchRequestCtx(c)

	agentStatus := c.Query("status")
	pageNo := c.Query("page_no")
	agentRole := c.Query("role")

	status := enum.StringToStatus(agentStatus)
	agentRoleEnum := enum.StringToAgentRole(agentRole)

	page, _ := strconv.ParseInt(pageNo, 10, 64)

	pagination := dto.PaginationData{
		CurrentPage: page,
	}
	req := request.GetAgent{
		ServiceProviderRefNumber:  c.Query("service_provider_ref_number"),
		FirstName:                 c.Query("first_name"),
		LastName:                  c.Query("last_name"),
		MobileNumber:              c.Query("mobile_number"),
		Email:                     c.Query("email"),
		Username:                  c.Query("username"),
		ReportingManagerRefNumber: c.Query("reporting_manager_ref_number"),
		AgentRefNumber:            c.Query("agent_ref_number"),
		Visibility:                enum.StringToAgentVisibility(c.Query("visibility")),
		Status:                    status,
		Role:                      agentRoleEnum,
		Search:                    c.Query("search"),
	}
	res, err := u.agentService.FindAgentList(ctx, req, pagination)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, res)
}
