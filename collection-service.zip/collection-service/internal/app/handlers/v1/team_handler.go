package handlers_v1

import (
	"collection-service/internal/app/handlers"
	"collection-service/internal/app/services/teams"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"github.com/gin-gonic/gin"
)

type TeamHandler struct {
	handlers.BaseHandler
	teamService teams.ITeamService
}

func InitTeamHandler(ctx context.Context, teamService teams.ITeamService) *TeamHandler {
	handler := TeamHandler{teamService: teamService}
	handler.SetContext(ctx)
	return &handler
}

func (u *TeamHandler) CreateTeam(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "TeamHandler.CreateTeam"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	var req request.CreateTeamReq

	utils.ValidatePostRequest(c, &req)

	res, err := u.teamService.CreateTeam(ctx, req)

	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, res)
}

func (u *TeamHandler) AddUserToTeam(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "TeamHandler.AddUserToTeam"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	var req request.AddUserToTeamReq

	utils.ValidatePostRequest(c, &req)

	err := u.teamService.AddUserToTeam(ctx, req)

	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, nil)
}

func (u *TeamHandler) GetTeams(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "TeamHandler.GetTeams"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	object := enum.StringToTeamObject(c.Query("object"))
	req := request.GetTeamsReq{
		Object:          object,
		ObjectRefNumber: c.Query("object_ref_number"),
	}

	res, err := u.teamService.GetTeams(ctx, req)
	if err != nil {
		u.ResponseError(c, err.Error())
	}
	u.ResponseSuccess(c, res)
}

func (u *TeamHandler) RemoveUserFromTeam(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "TeamHandler.RemoveUserFromTeam"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	var req request.RemoveUserFromTeamReq

	utils.ValidatePostRequest(c, &req)

	err := u.teamService.RemoveUserFromTeam(ctx, req)

	if err != nil {
		u.ResponseError(c, err.Error())
	}

	u.ResponseSuccess(c, nil)
}
