package handlers_v1

import (
	"collection-service/internal/app/handlers"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"strconv"

	"github.com/gin-gonic/gin"
)

type CaseBlockHandler struct {
	handlers.BaseHandler
	caseBlockService _case.ICaseBlockService
}

func InitCaseBlockHandler(ctx context.Context) *CaseBlockHandler {
	handler := CaseBlockHandler{
		caseBlockService: _case.InitCaseBlockService(ctx),
	}
	handler.SetContext(ctx)

	return &handler
}

func (cb *CaseBlockHandler) GetCaseBlockListWithPaginate(c *gin.Context) {
	if span := tracing.TraceSpan(c, "CaseBlockHandler|GetCaseBlockListWithPaginate"); span != nil {
		defer span.End()
	}
	pageNo, _ := strconv.Atoi(c.Query("page"))
	caseRefNumber := c.Param("case_ref_number")
	listParams := request.CaseBlockList{
		Page:          pageNo,
		CaseRefNumber: caseRefNumber,
	}
	list := cb.caseBlockService.GetBlockListWithPagination(c, listParams)

	cb.ResponseSuccess(c, list)
}

/*
Block Case :	API will block case as per request
@request : c *gin.Context
@response : CaseBlockResponse
@Author:Tejas Surve
*/
func (cb *CaseBlockHandler) BlockCase(c *gin.Context) {
	if span := tracing.TraceSpan(c.Request.Context(), "CaseHandler.BlockCase"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)

	var blockCaseReq request.BlockCase

	utils.ValidatePostRequest(c, &blockCaseReq)

	blockCaseReq.CaseRefNumber = c.Param("case_ref_number")
	err := cb.caseBlockService.BlockCase(ctx, blockCaseReq)
	if err != nil {
		cb.ResponseError(c, err.Error())
		return
	}

	cb.ResponseSuccess(c, nil)
}

func (cb *CaseBlockHandler) GetBlockReasonMaster(c *gin.Context) {
	if span := tracing.TraceSpan(c, "TicketHandler|GetBlockReasonMaster"); span != nil {
		defer span.End()
	}
	ctx := utils.FetchRequestCtx(c)
	id, _ := strconv.Atoi(c.Query("id"))
	blockReasonRequest := request.CaseBlockReason{
		ID:          id,
		BlockSource: c.Query("source"),
	}
	list := cb.caseBlockService.GetBlockReasonMaster(ctx, blockReasonRequest)
	cb.ResponseSuccess(c, list)
}

func (cb *CaseBlockHandler) GetAllBlockedCases(c *gin.Context) {
	if span := tracing.TraceSpan(c, "CaseBlockHandler|GetAllBlockedCases"); span != nil {
		defer span.End()
	}
	pageNo, _ := strconv.Atoi(c.Query("page"))
	blockReasonId, _ := strconv.Atoi(c.Query("block_reason_id"))
	listParams := request.CaseBlockList{
		Page:          pageNo,
		CaseRefNumber: c.Query("case_ref_number"),
		BlockSource:   c.Query("block_source"),
		BlockReasonId: blockReasonId,
		BlockedBy:     c.Query("blocked_by"),
	}
	list := cb.caseBlockService.GetBlockListWithPagination(c, listParams)

	cb.ResponseSuccess(c, list)
}
