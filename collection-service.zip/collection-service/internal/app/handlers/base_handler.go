package handlers

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/dto"
	"collection-service/internal/utils/tracing"
	"context"
	"net/http"

	"github.com/gin-gonic/gin"
)

type BaseHandler struct {
	ctx context.Context
}

// All setters and getters defined here in a pair
func (h *BaseHandler) SetContext(c context.Context) *BaseHandler {
	h.ctx = c
	return h
}

func (h *BaseHandler) GetContext() context.Context {
	return h.ctx
}

func (h *BaseHandler) ResponseSuccess(c *gin.Context, data interface{}) {
	if data == nil {
		data = map[string]interface{}{}
	}
	c.JSON(http.StatusOK, dto.SuccessResponse{
		TraceId: tracing.GetTraceIdFromGinCtx(c),
		Data:    data,
	})
}

func (h *BaseHandler) ResponseCreated(c *gin.Context, data interface{}) {
	if data == nil {
		data = map[string]interface{}{}
	}
	c.JSON(http.StatusCreated, dto.SuccessResponse{
		TraceId: tracing.GetTraceIdFromGinCtx(c),
		Data:    data,
	})
}

func (h *BaseHandler) ResponseError(c *gin.Context, message string) {
	c.JSON(http.StatusInternalServerError, dto.ServerErrorResponse{
		TraceId: tracing.GetTraceIdFromGinCtx(c),
		Error: dto.RequestError{
			Code:    constants.INTERNAL_SERVER_ERROR_CODE,
			Message: "Internal Server Error",
			Details: []dto.RequestDetails{
				{
					Field:   "Not Applicable",
					Message: message,
				},
			},
		},
	})
}

func (h *BaseHandler) ResponseNotFound(c *gin.Context, errorMessage string, data []dto.RequestDetails) {
	c.JSON(http.StatusNotFound, dto.NotFoundResponse{
		TraceId: tracing.GetTraceIdFromGinCtx(c),
		Error: dto.RequestError{
			Code:    constants.NOT_FOUND_ERROR_CODE,
			Message: errorMessage,
			Details: data,
		},
	})
}
