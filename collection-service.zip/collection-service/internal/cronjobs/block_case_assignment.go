package cronjobs

import (
	"collection-service/common/logger"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/dto/request"
	"collection-service/internal/utils"
	"context"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

type BlockCaseAssignment struct {
	// Any configuration or dependencies
	caseBlockService _case.ICaseBlockService
}

func InitBlockCaseAssignment(ctx context.Context) {
	dep := &UnBlockCaseJob{
		caseBlockService: _case.InitCaseBlockService(ctx),
	}
	ginCtx := &gin.Context{}
	ginCtx.Request = &http.Request{}
	//get case block list
	const batchSize = 100 // Adjust batch size as needed
	var offset int
	currentDateTime := time.Now()
	batch := 0
	logger.Info(ginCtx.Request.Context(), "Cron|BlockCaseAssignment|Benchmark|StartJob", logger.LogFields{"startTime": currentDateTime})
	for {
		batch++
		batchStartTime := time.Now()
		// Fetch batch of case block list with limit and offset
		caseBlockList := dep.caseBlockService.GetCaseBlockList(ginCtx, request.CaseBlockList{Limit: batchSize, Offset: offset, IsResolved: true})

		// If no more records are fetched, break the loop
		if len(caseBlockList) == 0 {
			logger.Info(ginCtx.Request.Context(), "Cron|BlockCaseAssignment|loop breaked", logger.LogFields{"case_count": len(caseBlockList)})
			break
		}
		// Process the batch
		for i := range caseBlockList {
			//if caseBlockList[i].IsResolved {
			blockedUntil := utils.StringToDateTime(caseBlockList[i].BlockedUntil)
			if blockedUntil.After(currentDateTime) {
				//fmt.Println("==================== unblocked cases:=", caseBlockList[i].CaseRefNumber)
				//dep.CaseService.UpdateCase(ginCtx, caseBlockList[i].CaseRefNumber, request.CaseUpdateReq{IsBlocked: false})
			}
			//}
		}
		// Increment the offset for the next batch
		offset += batchSize
		batchEndTime := time.Now()
		logger.Info(ginCtx.Request.Context(), "Cron|BlockCaseAssignment|Benchmark|Batch", logger.LogFields{"batch": batch, "startTime": batchStartTime, "endTime": batchEndTime, "elapsedTimeSeconds": batchEndTime.Sub(batchStartTime).Seconds()})
	}
	processEndTime := time.Now()
	elapsed := processEndTime.Sub(currentDateTime)
	logger.Info(ginCtx.Request.Context(), "Cron|BlockCaseAssignment|Benchmark|EndJob", logger.LogFields{"startTime": currentDateTime, "endTime": processEndTime, "elapsedTimeSeconds": elapsed.Seconds()})

}
