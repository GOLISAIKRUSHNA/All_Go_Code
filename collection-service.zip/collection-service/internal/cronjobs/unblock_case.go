package cronjobs

import (
	"collection-service/common/logger"
	_case "collection-service/internal/app/services/case"
	"collection-service/internal/models"
	"collection-service/internal/repositories"
	repo_interfaces "collection-service/internal/repositories/repo_interface"
	"context"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

type UnBlockCaseJob struct {
	// Any configuration or dependencies
	caseBlockService  _case.ICaseBlockService
	caseRepo          repo_interfaces.ICaseRepository
	caseBlockListRepo repo_interfaces.ICaseBlockListRepository
}

func InitUnBlockCase(ctx context.Context) {
	dep := &UnBlockCaseJob{
		caseBlockService:  _case.InitCaseBlockService(ctx),
		caseRepo:          repositories.InitCaseRepository(ctx),
		caseBlockListRepo: repositories.InitCaseBlockListRepository(ctx),
	}
	ginCtx := &gin.Context{}
	ginCtx.Request = &http.Request{}
	//get case block list
	const batchSize = 2 // Adjust batch size as needed
	var offset int
	currentDateTime := time.Now()
	batch := 0
	logger.Info(ginCtx.Request.Context(), "Cron|UnBlockCases|Benchmark|StartJob", logger.LogFields{"startTime": currentDateTime})
	for {

		// case table isBlocked
		// is resolved true from case block list
		// if manul resolution =true extend again for based on days block
		//update case table

		batch++
		batchStartTime := time.Now()
		// Fetch batch of case block list with limit and offset
		caseList, _ := dep.caseRepo.GetCaseList(ginCtx, models.Case{Limit: batchSize, Offset: offset, IsBlocked: true})

		// If no more records are fetched, break the loop
		if len(caseList) == 0 {
			logger.Info(ginCtx.Request.Context(), "Cron|InitUnBlockCase|loop breaked", logger.LogFields{"case_count": len(caseList)})
			break
		}
		// Process the batch
		for i := range caseList {
			isBlocked := true
			// feth group by record for case which has max blocked untildate and manual resolution required

			blocked_data, err := dep.caseBlockListRepo.GetMaxBlockedUntil(ginCtx, models.CaseBlockList{CaseRefNumber: caseList[i].CaseRefNumber})
			if err != nil {
				logger.Error(ginCtx.Request.Context(), err, "Cron|InitUnBlockCase|fetchBlockedUntilError", logger.LogFields{"case_ref_number": caseList[i].CaseRefNumber})
			}
			if blocked_data.MaxBlockedUntil.Before(time.Now()) && blocked_data.IsResolved {
				isBlocked = false
			}

			_, updateErr := dep.caseRepo.Update(ginCtx, models.Case{IsBlocked: isBlocked}, models.Case{CaseRefNumber: blocked_data.CaseRefNumber})
			if updateErr != nil {
				logger.Error(ginCtx.Request.Context(), err, "Cron|InitUnBlockCase|unblockCase", logger.LogFields{"case_ref_number": caseList[i].CaseRefNumber})
			}

		}
		// Increment the offset for the next batch
		offset += batchSize
		batchEndTime := time.Now()
		logger.Info(ginCtx.Request.Context(), "Cron|UnBlockCases|Benchmark|Batch", logger.LogFields{"batch": batch, "startTime": batchStartTime, "endTime": batchEndTime, "elapsedTimeSeconds": batchEndTime.Sub(batchStartTime).Seconds()})
	}
	processEndTime := time.Now()
	elapsed := processEndTime.Sub(currentDateTime)
	logger.Info(ginCtx.Request.Context(), "Cron|UnBlockCases|Benchmark|EndJob", logger.LogFields{"startTime": currentDateTime, "endTime": processEndTime, "elapsedTimeSeconds": elapsed.Seconds()})

}
