package response

type GetTeamsRes struct {
	Teams []Team `json:"teams"`
}

type Team struct {
	TeamRefNumber string          `json:"team_ref_number"`
	Name          string          `json:"name"`
	CreatedAt     string          `json:"created_at"`
	ClientUsers   []ClientUserRes `json:"client_users"`
	Agents        []AgentUserRes  `json:"agents"`
}

type ClientUserRes struct {
	ClientUserRefNumber string `json:"client_user_ref_number"`
	Name                string `json:"name"`
	Email               string `json:"email"`
}
type AgentUserRes struct {
	AgentRefNumber string `json:"agent_ref_number"`
	Name           string `json:"name"`
	Email          string `json:"email"`
}
