package response

import "collection-service/internal/enum"

type AgentInfoResponse struct {
	Agent AgentInfo `json:"agent"`
}

type AgentInfo struct {
	AgentRefNumber            string               `json:"agent_ref_number"`
	ServiceProviderRefNumber  string               `json:"service_provider_ref_number"`
	ServiceProviderName       string               `json:"service_provider_name"`
	FirstName                 string               `json:"first_name"`
	LastName                  string               `json:"last_name"`
	MobileNumber              string               `json:"mobile_number"`
	Email                     string               `json:"email"`
	Status                    enum.Status          `json:"status"`
	ReportingManagerRefNumber string               `json:"reporting_manager_ref_number"`
	ReportingManagerName      string               `json:"reporting_manager_name"`
	LanguagesSupported        string               `json:"languages_supported"`
	CashCollectionLimit       float64              `json:"cash_collection_limit"`
	CashDepositByDays         int                  `json:"cash_deposit_by_days"`
	Designation               string               `json:"designation"`
	AgentRole                 enum.AgentRole       `json:"agent_role"`
	AgentVisibility           enum.AgentVisibility `json:"agent_visibility"`
	EmployeeID                string               `json:"employee_id"`
	PhotoPath                 string               `json:"photo_path"`
	IsAttendancePending       bool                 `json:"is_attendance_pending"`
	TeamRefNumber             string               `json:"team_ref_number"`
	TeamName                  string               `json:"team_name"`
}

type Agent struct {
	FirstName                 string               `json:"first_name"`
	LastName                  string               `json:"last_name"`
	MobileNumber              string               `json:"mobile_number"`
	Email                     string               `json:"email"`
	Username                  string               `json:"username"`
	HasPanelAccess            bool                 `json:"has_panel_access"`
	HasAppAccess              bool                 `json:"has_app_access"`
	CashCollectionLimit       float64              `json:"cash_collection_limit"`
	Status                    enum.Status          `json:"status"`
	Designation               string               `json:"designation"`
	CashDepositByDays         int                  `json:"cash_deposit_by_days"`
	ReportingManagerRefNumber string               `json:"reporting_manager_ref_number"`
	ReportingManagerName      string               `json:"reporting_manager_name"`
	LanguagesSupported        []string             `json:"languages_supported"`
	Role                      enum.AgentRole       `json:"role"`
	CreatedBy                 string               `json:"created_by"`
	UpdatedBy                 string               `json:"updated_by"`
	ServiceProviderRefNumber  string               `json:"service_provider_ref_number"`
	EmployeeID                string               `json:"employee_id"`
	PhotoPath                 string               `json:"photo_path"`
	AgentRefNumber            string               `json:"agent_ref_number"`
	Visibility                enum.AgentVisibility `json:"visibility"`
	TeamName                  string               `json:"team_name"`
	TeamRefNumber             string               `json:"team_ref_number"`
}

type GetAgentResp struct {
	Agents []Agent `json:"agents"`
	PaginationData
}
