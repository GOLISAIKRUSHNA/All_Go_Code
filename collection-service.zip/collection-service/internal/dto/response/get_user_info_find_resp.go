package response

import "collection-service/internal/enum"

type UserInfoResponse struct {
	User UserInfo `mapstructure:"user" json:"user"`
}

type UserInfo struct {
	FirstName    string `mapstructure:"first_name" json:"first_name"`
	LastName     string `mapstructure:"last_name" json:"last_name"`
	MobileNumber string `mapstructure:"mobile_number" json:"mobile_number"`
	Email        string `mapstructure:"email" json:"email"`

	UserRoles []string `mapstructure:"user_roles" json:"user_roles"`

	UserRefNumber   string          `mapstructure:"user_ref_number" json:"user_ref_number"`
	Object          enum.UserObject `mapstructure:"object" json:"object"`
	ObjectRefNumber string          `mapstructure:"object_ref_number" json:"object_ref_number"`
}
