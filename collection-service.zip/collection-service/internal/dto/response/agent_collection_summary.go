package response

type AgentCollectionSummaryResponse struct {
	TotalCollection     float64 `json:"total_collection"`
	TodayCollection     float64 `json:"today_collection"`
	YesterdayCollection float64 `json:"yesterday_collection"`
	PendingDeposit      float64 `json:"pending_deposit"`
	UnverifiedAmount    float64 `json:"unverified_amount"`
}
