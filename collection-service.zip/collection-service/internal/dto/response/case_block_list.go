package response

import (
	"collection-service/internal/enum"
)

type CaseBlockList struct {
	CaseRefNumber        string               `json:"case_ref_number"`
	BlockReasonMasterId  int                  `json:"block_reason_master_id"`
	OriginalBlockedUntil string               `json:"original_blocked_until"`
	BlockedUntil         string               `json:"blocked_until"`
	BlockedSource        enum.BlockSource     `json:"blocked_source"`
	BlockReason          string               `json:"block_reason"`
	BlockedAt            string               `json:"blocked_at"`
	BlockedBy            string               `json:"blocked_by"`
	BlockedByName        string               `json:"blocked_by_name"`
	BlockedByRole        enum.AgentRole       `json:"blocked_by_role"`
	BlockedByVisibility  enum.AgentVisibility `json:"blocked_by_visibility"`
	IsResolved           bool                 `json:"is_resolved"`
	TicketRefNumber      string               `json:"ticket_ref_number"`
	Issue                string               `json:"issue"`
	SubIssue             string               `json:"sub_issue"`
	Comment              string               `json:"comment"`
	ResolvedAt           string               `json:"resolved_at"`
	CreatedAt            string               `json:"created_at"`
}

type BlockListData struct {
	BlockList   []CaseBlockList `json:"block_list"`
	CurrentPage int             `json:"current_page"`
	Pages       int64           `json:"pages"`
}
