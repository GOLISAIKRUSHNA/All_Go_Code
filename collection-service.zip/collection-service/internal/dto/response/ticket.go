package response

import "collection-service/internal/enum"

type Ticket struct {
	TicketRefNumber     string               `json:"ticket_ref_number"`
	BlockedReason       string               `json:"blocked_reason"`
	BlockSource         string               `json:"blocked_source"`
	BlockedDate         string               `json:"blocked_date"`
	BlockedBy           string               `json:"blocked_by"`
	BlockedByName       string               `json:"blocked_by_name"`
	BlockedByRole       enum.AgentRole       `json:"agent_role"`
	BlockedByVisibility enum.AgentVisibility `json:"agent_visibility"`
	IssueId             int                  `json:"issue_id"`
	Action              string               `json:"action"`
	SubIssueId          int                  `json:"sub_issue_id"`
	CreatedAt           string               `json:"created_at"`
	Mood                string               `json:"mood"`
}
