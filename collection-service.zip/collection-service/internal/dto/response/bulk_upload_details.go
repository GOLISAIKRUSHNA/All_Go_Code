package response

type BulkUploadDetails struct {
	UploadRefNumber       string `json:"upload_ref_number"`
	Reason                string `json:"reason"`
	InputFileName         string `json:"input_file_name"`
	InputFilePath         string `json:"input_file_url"`
	OutputFilePath        string `json:"output_file_url"`
	TotalRecordsCount     int32  `json:"total_records_count"`
	ProcessedRecordsCount int32  `json:"processed_records_count"`
	SuccessCount          int32  `json:"success_count"`
	FailedCount           int32  `json:"failed_count"`
	Status                string `json:"status"`
	CreatedAt             string `json:"created_at"`
	UploadedBy            string `json:"uploaded_by"`
	UploadedByName        string `json:"uploaded_by_name"`
}
