package response

type AgentAutoSuggestResponse struct {
	Agents []AgentAutoSuggestedAgent `json:"agents"`
	PaginationData
}
type AgentAutoSuggestedAgent struct {
	AgentRefNumber string `json:"agent_ref_number"`
	FirstName      string `json:"first_name"`
	LastName       string `json:"last_name"`
	Email          string `json:"email"`
	TeamRefNumber  string `json:"team_ref_number"`
	TeamName       string `json:"team_name"`
}
