package response

import (
	"collection-service/internal/enum"
	"github.com/guregu/null/v5"
	"time"
)

type PostSpecialOfferResp struct {
	SpecialOfferRefNumber string                `json:"special_offer_ref_number"`
	CaseRefNumber         string                `json:"case_ref_number"`
	LoanRefNumber         string                `json:"loan_ref_number"`
	OfferType             enum.OfferType        `json:"offer_type"`
	WaiverType            enum.WaiverType       `json:"waiver_type"`
	WaiverValue           null.Float            `json:"waiver_value"`
	MinimumPaymentAmount  float64               `json:"minimum_payment_amount"`
	Status                enum.OfferStatus      `json:"status"`
	ActivationSource      enum.ActivationSource `json:"activation_source"`
	StartDatetime         time.Time             `json:"start_datetime"`
	EndDatetime           time.Time             `json:"end_datetime"`
	CreatedBy             string                `json:"created_by"`
	CreatedAt             time.Time             `json:"created_at"`
	UpdatedAt             time.Time             `json:"updated_at"`
}
