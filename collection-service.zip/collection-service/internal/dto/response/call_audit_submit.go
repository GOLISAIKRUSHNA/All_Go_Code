package response

type CallAuditFinalResponse struct {
	CallAuditSubmitResponse CallAuditSubmitResponse `json:"call_audit"`
}

type CallAuditSubmitResponse struct {
	AuditRefNumber string `json:"audit_ref_number"`
	Status         string `json:"status"`
	ResponseId     string `json:"response_id"`
}
