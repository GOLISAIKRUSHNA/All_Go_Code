package response

import "collection-service/internal/enum"

type GetCaseAllocationDetailsRes struct {
	CaseRefNumber     string        `json:"case_ref_number"`
	CustomerRefNumber string        `json:"customer_ref_number"`
	ClientRefNumber   string        `json:"client_ref_number"`
	AllocatedTo       []AllocatedTo `json:"allocated_to"`
}

type AllocatedTo struct {
	AgentRefNumber           string            `json:"agent_ref_number"`
	ServiceProviderRefNumber string            `json:"service_provider_ref_number"`
	Intervention             enum.Intervention `json:"intervention"`
}
