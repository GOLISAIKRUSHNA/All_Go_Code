package response

import "collection-service/internal/enum"

type CustomerContactListResponse struct {
	Contacts []Contacts `json:"contacts"`
}

type Contacts struct {
	ContactRefNumber string           `json:"contact_ref_number"`
	ContactNumber    string           `json:"contact_number"`
	ContactName      string           `json:"contact_name"`
	ContactOf        enum.ContactOf   `json:"contact_of"`
	ContactType      enum.ContactType `json:"contact_type"`
	IsPrimary        bool             `json:"is_primary"`
	CreatedBy        string           `json:"created_by"`
}
