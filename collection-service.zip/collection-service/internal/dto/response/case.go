package response

type Case struct {
	CaseRefNumber                   string  `json:"case_ref_number"`
	LoanRefNumber                   string  `json:"loan_ref_number"`
	ClientRefNumber                 string  `json:"client_ref_number"`
	CustomerRefNumber               string  `json:"customer_ref_number"`
	Status                          string  `json:"status"`
	TotalDue                        float64 `json:"total_due"`
	TotalPrincipalDue               float64 `json:"total_principal_due"`
	TotalInterestDue                float64 `json:"total_interest_due"`
	TotalFeesDue                    float64 `json:"total_fees_due"`
	NoOfLoansDue                    float64 `json:"no_of_loans_due"`
	NoOfEmisDue                     int     `json:"no_of_emis_due"`
	TotalOutstanding                float64 `json:"total_outstanding"`
	TotalPrincipalOutstanding       float64 `json:"total_principal_outstanding"`
	TotalFeesOutstanding            float64 `json:"total_fees_outstanding"`
	TotalInterestOutstanding        float64 `json:"total_interest_outstanding"`
	CurrentDpd                      int     `json:"current_dpd"`
	Bucket                          string  `json:"bucket"`
	MaxDpd                          int     `json:"max_dpd"`
	CollectionFor                   string  `json:"collection_for"`
	CaseType                        string  `json:"case_type"`
	LastDisposition                 string  `json:"last_disposition"`
	LastDispositionDatetime         string  `json:"last_disposition_datetime"`
	LastDispositionFollowupDate     string  `json:"last_disposition_followup_date"`
	TotalCallsAttempted             int     `json:"total_calls_attempted"`
	TotalCallsConnected             int     `json:"total_calls_connected"`
	LastCallConnectedAt             string  `json:"last_call_connected_at"`
	ClientLoanIds                   string  `json:"client_loan_ids"`
	ClientLogoUrl                   string  `json:"client_logo_url"`
	HavingMandateInprogressPayments bool    `json:"having_mandate_inprogress_payments"`
	HavingInprogressPayments        bool    `json:"having_inprogress_payments"`
	CallsLeft                       int     `json:"calls_left"`
	DistanceCheckMeters             int     `json:"distance_check_meters"`
	Product                         string  `json:"product"`
}
