package response

type AttributesResp struct {
	SegmentAttributes []Attribute `json:"attributes"`
}

type Attribute struct {
	Label   string   `json:"label"`
	Type    string   `json:"type"`
	Name    string   `json:"name"`
	Options []string `json:"options"`
}
