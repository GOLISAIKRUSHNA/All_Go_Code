package response

import "time"

type CustomerDocument struct {
	ID                uint      `json:"id"`
	DocumentRefNumber string    `json:"document_ref_number"`
	CustomerRefNumber string    `json:"customer_ref_number"`
	LoanRefNumber     string    `json:"loan_ref_number"`
	Type              string    `json:"type"`
	FileURL           string    `json:"file_url"`
	CreatedAt         time.Time `json:"created_at"`
}

type CustomerDocumentResp struct {
	Documents []CustomerDocument `json:"documents"`
}
