package response

type CallAuditResponse struct {
	TraceID string `json:"trace_id"`
	Data    struct {
		ResponseID string `json:"response_id"`
	} `json:"data"`
}
