package response

type LoanPayment struct {
	LoanPaymentRefNumber    string  `json:"loan_payment_ref_number"`
	ClientPaymentId         string  `json:"client_payment_id"`
	PaymentRefNumber        string  `json:"payment_ref_number"`
	LoanRefNumber           string  `json:"loan_ref_number"`
	PaymentDatetime         string  `json:"payment_datetime"`
	PaymentAmount           float64 `json:"payment_amount"`
	AppliedTowardsPrincipal float64 `json:"applied_towards_principal"`
	AppliedTowardsInterest  float64 `json:"applied_towards_interest"`
	AppliedTowardsFees      float64 `json:"applied_towards_fees"`
	AppliedTowardsPenalty   float64 `json:"applied_towards_penalty"`
}
