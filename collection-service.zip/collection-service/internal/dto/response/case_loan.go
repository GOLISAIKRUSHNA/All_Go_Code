package response

type CaseLoanResponse struct {
	Loans []CaseLoanRes `json:"loans"`
}

type CaseLoanRes struct {
	LoanRefNumber               string              `json:"loan_ref_number"`
	ClientLoanId                string              `json:"client_loan_id"`
	CustomerRefNumber           string              `json:"customer_ref_number"`
	ClientRefNumber             string              `json:"client_ref_number"`
	CaseRefNumber               string              `json:"case_ref_number"`
	LoanAmount                  float64             `json:"loan_amount"`
	Tenure                      int                 `json:"tenure"`
	TenureType                  string              `json:"tenure_type"`
	InterestRate                float64             `json:"interest_rate"`
	EmiAmount                   float64             `json:"emi_amount"`
	Status                      string              `json:"status"`
	Product                     string              `json:"product"`
	SubProduct                  string              `json:"sub_product"`
	ActiveFinancierRefNumber    string              `json:"active_financier_ref_number"`
	SecondaryFinancierRefNumber string              `json:"secondary_financier_ref_number"`
	DisbursementDate            string              `json:"disbursement_date"`
	DueDate                     string              `json:"due_date"`
	FirstEmiDate                string              `json:"first_emi_date"`
	LastEmiDate                 string              `json:"last_emi_date"`
	EarliestUnpaidEmiDate       string              `json:"earliest_unpaid_emi_date"`
	TotalDue                    float64             `json:"total_due"`
	TotalPrincipalDue           float64             `json:"total_principal_due"`
	TotalInterestDue            float64             `json:"total_interest_due"`
	TotalFeesDue                float64             `json:"total_fees_due"`
	TotalOutstanding            float64             `json:"total_outstanding"`
	TotalPrincipalOutstanding   float64             `json:"total_principal_outstanding"`
	TotalInterestOutstanding    float64             `json:"total_interest_outstanding"`
	TotalFeesOutstanding        float64             `json:"total_fees_outstanding"`
	TotalPrincipalPaid          float64             `json:"total_principal_paid"`
	TotalInterestPaid           float64             `json:"total_interest_paid"`
	TotalFeesPaid               float64             `json:"total_fees_paid"`
	NoOfEmisPaid                int                 `json:"no_of_emis_paid"`
	NoOfEmisUnpaid              int                 `json:"no_of_emis_unpaid"`
	CurrentDpd                  int                 `json:"current_dpd"`
	MaxDpd                      int                 `json:"max_dpd"`
	PaymentLink                 string              `json:"payment_link"`
	LoanPayment                 []LoanPaymentRes    `json:"loan_payments"`
	LoanCollateral              []LoanCollateralRes `json:"loan_collaterals"`
	LoanBorrower                []LoanBorrowerRes   `json:"loan_borrowers"`
}

type LoanPaymentRes struct {
	LoanPaymentRefNumber    string  `json:"loan_payment_ref_number"`
	PaymentRefNumber        string  `json:"payment_ref_number"`
	ClientPaymentId         string  `json:"client_payment_id"`
	PaymentGateway          string  `json:"payment_gateway"`
	PaymentAmount           float64 `json:"payment_amount"`
	PaymentDatetime         string  `json:"payment_datetime"`
	AppliedTowardsPrincipal float64 `json:"applied_towards_principal"`
	AppliedTowardsInterest  float64 `json:"applied_towards_interest"`
	AppliedTowardsFees      float64 `json:"applied_towards_fees"`
}

type LoanCollateralRes struct {
	Type                     string  `json:"type"`
	Value                    float64 `json:"value"`
	Description              string  `json:"description"`
	PrimaryIdentifierType    string  `json:"primary_identifier_type"`
	PrimaryIdentifier        string  `json:"primary_identifier"`
	AdditionalIdentifierType string  `json:"additional_identifier_type"`
	AdditionalIdentifier     string  `json:"additional_identifier"`
	MakeAndModel             string  `json:"make_and_model"`
}

type LoanBorrowerRes struct {
	LoanRefNumber             string      `json:"loan_ref_number"`
	BorrowerCustomerRefNumber string      `json:"borrower_customer_ref_number"`
	Type                      string      `json:"type"`
	RelationWithPrimary       string      `json:"relation_with_primary"`
	CreatedBy                 string      `json:"created_by"`
	Customers                 CustomerRes `json:"customer"`
}

type CustomerRes struct {
	FirstName    string `json:"first_name"`
	LastName     string `json:"last_name"`
	MobileNumber int    `json:"mobile_number"`
}
