package response

type CreateTeamRes struct {
	Team TeamDetails `json:"team"`
}

type TeamDetails struct {
	TeamRefNumber string `json:"team_ref_number"`
	Name          string `json:"name"`
}
