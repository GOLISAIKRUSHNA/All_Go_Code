package response

type CreateUserResp struct {
	User CreateUserRespNode `json:"user"`
}

type CreateUserRespNode struct {
	UserRefNumber string `json:"user_ref_number"`
}
