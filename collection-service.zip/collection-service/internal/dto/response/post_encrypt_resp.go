package response

type EncryptResp struct {
	EncryptedString string `mapstructure:"encrypted_string" json:"encrypted_string"`
}
