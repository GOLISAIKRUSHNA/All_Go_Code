package response

type BlockReasonListData struct {
	BlockReasonMasterData []BlockReasonList `json:"block_reason_master"`
}

type BlockReasonList struct {
	ID          int    `json:"id"`
	Description string `json:"description"`
	Source      string `json:"source"`
	Reason      string `json:"reason"`
	CreatedAt   string `json:"created_at"`
}
