package response

type CaseList struct {
	//Case Case `json:"case"`
	//Customer Customer        `json:"customer"`
	Address []CustomerAddress `json:"address"`
}

type CaseListResponse struct {
	Cases []CaseList `json:"cases"`
}
