package response

type UserExistsResponse struct {
	IsExists bool `json:"is_exists"`
}
