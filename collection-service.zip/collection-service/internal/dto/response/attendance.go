package response

type Attendance struct {
	AttendanceRefNumber string  `json:"attendance_ref_number"`
	AgentRefNumber      string  `json:"agent_ref_number"`
	AgentName           string  `json:"agent_name"`
	AttendanceDate      string  `json:"attendance_date" `
	Latitude            float64 `json:"latitude" `
	Longitude           float64 `json:"longitude"`
	MarkType            string  `json:"mark_type" `
	ApprovalStatus      string  `json:"approval_status"`
	MarkDateTime        string  `json:"mark_date_time"`
	ApprovalDateTime    string  `json:"approval_date_time"`
	CreatedBy           string  `json:"created_by"`
	SelfieFilePath      string  `json:"selfie_file_path"`
}

type GetAttendanceResp struct {
	Attendances []Attendance `json:"attendances"`
}
