package response

type GetActiveCasesResp struct {
	Cases []string `json:"cases"`
}
