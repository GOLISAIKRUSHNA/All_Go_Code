package response

type CreateAddressRes struct {
	Address AddressDetails `json:"address"`
}

type AddressDetails struct {
	AddressRefNumber string `json:"address_ref_number"`
}
