package response

type PaymentSummary struct {
	TotalPendingForDeposit float64 `json:"total_pending_for_deposit"`
	TotalUnverifiedDeposit float64 `json:"total_unverified_deposit"`
}
