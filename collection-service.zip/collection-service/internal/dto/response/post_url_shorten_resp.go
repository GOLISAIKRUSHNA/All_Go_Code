package response

import "time"

type CreateShortURLResp struct {
	LongURL    string    `json:"long_url"`
	ShortURL   string    `json:"short_url"`
	UniqueCode string    `json:"unique_code"`
	ExpiresAt  time.Time `json:"expires_at" time_format:"2006-01-02T15:04:05Z07:00"`
}
