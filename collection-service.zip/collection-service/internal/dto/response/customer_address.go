package response

import (
	"time"
)

type CustomerAddress struct {
	ID                uint      `json:"id"`
	AddressRefNumber  string    `json:"address_ref_number"`
	TotalDueAmount    float64   `json:"total_due_amount"`
	CustomerRefNumber string    `json:"customer_ref_number"`
	LoanRefNumber     string    `json:"loan_ref_number"`
	IsPrimary         bool      `json:"is_primary"`
	CaseRefNumber     string    `json:"case_ref_number"`
	Address           string    `json:"address"`
	Line1             string    `json:"line_1"`
	Line2             string    `json:"line_2"`
	Line3             string    `json:"line_3"`
	Label             string    `json:"label"`
	Type              string    `json:"type"`
	ResidentType      string    `json:"resident_type"`
	Source            string    `json:"source"`
	AddressMedium     string    `json:"address_medium"`
	Landmark          string    `json:"landmark"`
	Latitude          float64   `json:"lat"`
	Longitude         float64   `json:"long"`
	Pincode           int       `json:"pincode"`
	City              string    `json:"city"`
	State             string    `json:"state"`
	Country           string    `json:"country"`
	CityId            int       `json:"city_id"`
	StateId           int       `json:"state_id"`
	CreatedAt         time.Time `json:"created_at"`
	UpdatedAt         time.Time `json:"updated_at"`
}

type CustomerAddressesResp struct {
	Addresses []CustomerAddress `json:"addresses"`
}
