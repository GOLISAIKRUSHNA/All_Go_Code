package response

type TicketListData struct {
	Tickets     []TicketList `json:"tickets"`
	CurrentPage int          `json:"current_page"`
	Pages       int64        `json:"pages"`
}
type TicketList struct {
	Ticket   Ticket   `json:"ticket"`
	Customer Customer `json:"customer"`
	Case     Case     `json:"case"`
}
