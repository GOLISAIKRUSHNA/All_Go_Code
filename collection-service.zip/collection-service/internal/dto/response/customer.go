package response

type Customer struct {
	ClientCustomerId        string `json:"client_customer_id"`
	CustomerRefNumber       string `json:"customer_ref_number"`
	ClientRefNumber         string `json:"client_ref_number"`
	FirstName               string `json:"first_name"`
	LastName                string `json:"last_name"`
	MobileNumber            string `json:"mobile_number"`
	Email                   string `json:"email"`
	CustomerName            string `json:"customer_name"`
	PreferredLanguage       string `json:"preferred_language"`
	CreatedBy               string `json:"created_by"`
	Gender                  string `json:"gender"`
	Age                     int    `json:"age"`
	PrimaryContactRefNumber string `json:"primary_contact_ref_number"`
}
