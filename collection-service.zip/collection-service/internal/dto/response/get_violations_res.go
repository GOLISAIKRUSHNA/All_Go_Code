package response

type ViolationsRes struct {
	Violations []Violation `json:"violations"`
}
type Violation struct {
	ID             int    `json:"id"`
	Violation      string `json:"violation"`
	ViolationLevel string `json:"violation_level"`
	IsCaseToBlock  bool   `json:"is_case_to_block"`
	CreatedAt      string `json:"created_at"`
}
