package response

type Loan struct {
}
