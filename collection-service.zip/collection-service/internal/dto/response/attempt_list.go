package response

type AttemptListResponse struct {
	Attempts []AttemptList `json:"attempts"`
}

type AttemptList struct {
	AttemptRefNumber     string `json:"attempt_ref_number"`
	CustomerMobileNumber string `json:"customer_mobile_number"`
	AgentName            string `json:"agent_name"`
	AgentRole            string `json:"agent_role"`
	AgentRefNumber       string `json:"agent_ref_number"`
	Status               string `json:"status"`
	AgentStatus          string `json:"agent_status"`
	ConnectedStatus      string `json:"connected_status"`
	CallStartDatetime    string `json:"call_start_datetime"`
	CallEndDatetime      string `json:"call_end_datetime"`
	CallDuration         string `json:"call_duration"`
	CallRecordFileURL    string `json:"call_record_file_url"`
	CallAttemptedDate    string `json:"call_attempted_date"`
	Mood                 string `json:"mood"`
	Disposition          string `json:"disposition"`
}
