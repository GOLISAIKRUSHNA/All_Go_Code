package response

type ClientNamesInfo struct {
	ClientRefNumber string `json:"client_ref_number"`
	ClientName      string `json:"client_name"`
}

type GetClientNamesResp struct {
	ClientNamesInfo []ClientNamesInfo `json:"client_names_info"`
}
