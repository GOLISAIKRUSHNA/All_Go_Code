package response

type PincodeDetails struct {
	Pincode int    `json:"pincode"`
	CityId  int    `json:"city_id"`
	StateId int    `json:"state_id"`
	City    string `json:"city"`
	State   string `json:"state"`
}

type PincodeDetailsResponse struct {
	PincodeDetails PincodeDetails `json:"pincode_details"`
}
