package response

type PaginationData struct {
	CurrentPage int64 `json:"current_page"`
	Pages       int64 `json:"pages"`
}
