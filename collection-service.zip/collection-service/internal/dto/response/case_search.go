package response

import "collection-service/internal/enum"

type SearchCaseResponse struct {
	Cases []CaseSearch `json:"cases"`
	PaginationData
}

type CaseSearch struct {
	CaseRefNumber    string          `json:"case_ref_number"`
	LoanRefNumber    string          `json:"loan_ref_number"`
	ClientLoanId     string          `json:"client_loan_id"`
	ClientCustomerId string          `json:"client_customer_id"`
	CreatedAt        string          `json:"created_at"`
	Status           enum.CaseStatus `json:"status"`
}
