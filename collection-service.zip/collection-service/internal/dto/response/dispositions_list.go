package response

import (
	"collection-service/internal/enum"
)

type Disposition struct {
	DispositionRefNumber string      `json:"disposition_ref_number"`
	Source               enum.Source `json:"source"`
	CaseRefNumber        string      `json:"case_ref_number"`
	CustomerRefNumber    string      `json:"customer_ref_number"`
	CustomerName         string      `json:"customer_name"`
	AgentRefNumber       string      `json:"agent_ref_number"`
	AgentName            string      `json:"agent_name"`
	Disposition          string      `json:"disposition"`
	ContactNumber        string      `json:"contact_number"`
	Comment              string      `json:"comment"`
	Latitude             float64     `json:"latitude"`
	Longitude            float64     `json:"longitude"`
	FollowupDatetime     string      `json:"followup_date"`
	CreatedAt            string      `json:"created_at"`
	Address              string      `json:"address"`
	AttemptRefNumber     string      `json:"attempt_ref_number"`
}

type GetDispositionResp struct {
	Dispositions []Disposition `json:"dispositions"`
	PaginationData
}
