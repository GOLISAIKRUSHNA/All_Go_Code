package response

import (
	"collection-service/internal/enum"
)

type ClientUser struct {
	ClientUserRefNo           string                    `json:"client_user_ref_number"`
	ClientRefNo               string                    `json:"client_ref_number"`
	FirstName                 string                    `json:"first_name"`
	LastName                  string                    `json:"last_name"`
	Email                     string                    `json:"email"`
	MobileNumber              string                    `json:"mobile_number"`
	Status                    enum.Status               `json:"status"`
	Designation               string                    `json:"designation"`
	ReportingManagerRefNumber string                    `json:"reporting_manager_ref_number"`
	ReportingManagerName      string                    `json:"reporting_manager_name"`
	ClientUserRole            enum.ClientUserRole       `json:"client_user_role"`
	ClientUserVisibility      enum.ClientUserVisibility `json:"client_user_visibility"`
	PhotoPath                 string                    `json:"photo_path"`
	CreatedBy                 string                    `json:"created_by"`
	UpdatedBy                 string                    `json:"updated_by"`
	TeamName                  string                    `json:"team_name"`
	TeamRefNumber             string                    `json:"team_ref_number"`

	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}

type GetClientUsersResp struct {
	ClientUsers []ClientUser `json:"client_users"`
	PaginationData
}

type GetClientUserResp struct {
	ClientUser ClientUser `json:"client_user"`
}
