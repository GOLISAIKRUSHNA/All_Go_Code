package response

import "collection-service/internal/enum"

type ServiceProvidersResp struct {
	ServiceProviderList []ServiceProviderList `json:"service_providers"`
}
type ClientsResp struct {
	ClientList []ClientList `json:"clients"`
}

type ServiceProviderList struct {
	ServiceProviderRefNumber string                           `json:"service_provider_ref_number"`
	Name                     string                           `json:"name"`
	Intervention             string                           `json:"intervention"`
	Status                   enum.ClientServiceProviderStatus `json:"status"`
}

type ClientList struct {
	ClientRefNumber string                           `json:"client_ref_number"`
	Name            string                           `json:"name"`
	Intervention    string                           `json:"intervention"`
	Status          enum.ClientServiceProviderStatus `json:"status"`
	TotalCases      int                              `json:"total_cases"`
	ActiveCases     int                              `json:"active_cases"`
	InActiveCases   int                              `json:"inactive_cases"`
	PaidCases       int                              `json:"paid_cases"`
	WithdrawnCases  int                              `json:"withdrawn_cases"`
}
