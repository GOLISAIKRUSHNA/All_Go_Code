package response

type ClickToCallResponse struct {
	AttemptRefNumber     string `json:"attempt_ref_number"`
	CaseRefNumber        string `json:"case_ref_number"`
	ContactRefNumber     string `json:"contact_ref_number"`
	DispositionRefNumber string `json:"disposition_ref_number"`
	DialerRefNumber      string `json:"dialer_ref_number"`
	Status               string `json:"status"`
}
