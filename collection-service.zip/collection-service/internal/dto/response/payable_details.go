package response

type PayableData struct {
	PayableDetails PayableDetails `json:"payable_details"`
}

type PayableDetails struct {
	ClientRefNumber      string  `json:"client_ref_number"`
	ClientName           string  `json:"client_name"`
	LogoUrl              string  `json:"client_logo_url"`
	ClientCustomerId     string  `json:"client_customer_id"`
	CustomerName         string  `json:"customer_name"`
	CustomerMobileNumber string  `json:"customer_mobile_number"`
	CustomerEmail        string  `json:"customer_email"`
	PayableAmount        float64 `json:"payable_amount"`
	PrincipalAmount      float64 `json:"principal_amount"`
	InterestAmount       float64 `json:"interest_amount"`
	FeesAmount           float64 `json:"fees_amount"`
	Loans                []Loans `json:"loans"`
}
type Loans struct {
	ClientLoanId      string  `json:"client_loan_id"`
	LoanRefNumber     string  `json:"loan_ref_number"`
	CaseRefNumber     string  `json:"case_ref_number"`
	TotalDue          float64 `json:"total_due"`
	NoOfEmisUnpaid    int     `json:"total_emi_due"`
	TotalPrincipalDue float64 `json:"total_principal_due"`
	TotalInterestDue  float64 `json:"total_interest_due"`
	TotalFeesDue      float64 `json:"total_fees_due"`
}
