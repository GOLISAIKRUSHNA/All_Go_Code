package response

import "collection-service/internal/enum"

type SpecialOfferRespInfo struct {
	SpecialOfferRefNumber        string                `json:"special_offer_ref_number,omitempty"`
	LoanRefNumber                string                `json:"loan_ref_number"`
	OfferType                    string                `json:"offer_type"`
	TotalDue                     float64               `json:"total_due"`
	TotalPrincipalDue            float64               `json:"total_principal_due"`
	TotalInterestDue             float64               `json:"total_interest_due"`
	TotalFeesDue                 float64               `json:"total_fees_due"`
	TotalDueDiscounted           float64               `json:"total_due_discounted"`
	TotalPrincipalDueDiscounted  float64               `json:"total_principal_due_discounted"`
	TotalInterestDueDiscounted   float64               `json:"total_interest_due_discounted"`
	TotalFeesDueDiscounted       float64               `json:"total_fees_due_discounted"`
	TotalDueWaiverPercentage     float64               `json:"total_due_waiver_percentage"`
	TotalFeesDueWaiverPercentage float64               `json:"total_fees_due_waiver_percentage"`
	MinimumPaymentAmount         float64               `json:"minimum_payment_amount"`
	OfferWaiverPercentage        float64               `json:"offer_waiver_percentage"`
	ActivationSource             enum.ActivationSource `json:"activation_source"`
	Status                       enum.OfferStatus      `json:"status"`
	StartDatetime                string                `json:"start_datetime"`
	EndDatetime                  string                `json:"end_datetime"`
	CurrentlyActive              bool                  `json:"currently_active"`
	SpecialOffersMasterRefNumber string                `json:"special_offers_master_ref_number"`
}
type GetSpecialOffersResp struct {
	SpecialOffers []SpecialOfferRespInfo `json:"special_offers"`
}
