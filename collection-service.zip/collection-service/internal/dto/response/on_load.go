package response

type OnLoad struct {
	LoginMode           []string `json:"login_mode"`
	SoftUpgradeVersion  string   `json:"soft_upgrade_version"`
	ForceUpgradeVersion string   `json:"force_upgrade_version"`
}
type UploadReason struct {
	Reason        string `json:"reason"`
	SampleFileURL string `json:"sample_file_url"`
}
type PostLoginOnLoadResponse struct {
	UploadReasons    []UploadReason         `json:"upload_reasons"`
	Permissions      map[string]interface{} `json:"permissions"`
	PermissionsGroup map[string]interface{} `json:"permissions_group"`
}

type PostLogin struct {
	Client               Data                   `json:"client"`
	ServiceProvider      Data                   `json:"service_provider"`
	FieldDispositionList []interface{}          `json:"field_disposition_list"`
	CallDispositionList  []interface{}          `json:"call_disposition_list"`
	SupportedLanguages   []interface{}          `json:"supported_languages"`
	IssueList            []interface{}          `json:"issue_list"`
	Permissions          map[string]interface{} `json:"permissions"`
	PermissionsGroup     map[string]interface{} `json:"permissions_group"`
}

type Data struct {
	LogoURL string `json:"logo_url"`
	Name    string `json:"name"`
}
