package response

type HomePage struct {
	CollectionSummary CollectionSummary  `json:"collection_summary"`
	DepositSummary    DispositionSummary `json:"deposit_summary"`
}

type CollectionSummary struct {
	TotalToBeCollected  float64 `json:"total_to_be_collected"`
	TotalCollected      float64 `json:"total_collected"`
	TodayCollection     float64 `json:"today_collection"`
	YesterdayCollection float64 `json:"yesterday_collection"`
}

type DispositionSummary struct {
	TotalPendingForDeposit float64 `json:"total_pending_for_deposit"`
	TotalUnverifiedDeposit float64 `json:"total_unverified_deposit"`
}
