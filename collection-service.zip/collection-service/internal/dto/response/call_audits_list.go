package response

type CallAuditsResponse struct {
	CallAudits  []CallAudit `json:"call_audits"`
	CurrentPage int         `json:"current_page"`
	Pages       int64       `json:"pages"`
}

type CallAudit struct {
	AuditRefNumber       string `json:"audit_ref_number"`
	CaseRefNumber        string `json:"case_ref_number"`
	AttemptRefNumber     string `json:"attempt_ref_number"`
	CustomerMobileNumber string `json:"customer_mobile_number"`
	CallerName           string `json:"caller_name"`
	CallerRole           string `json:"caller_role"`
	CallerVisibility     string `json:"caller_visibility"`
	Status               string `json:"status"`
	AgentStatus          string `json:"agent_status"`
	ConnectedStatus      string `json:"connected_status"`
	CallStartDatetime    string `json:"call_start_datetime"`
	CallEndDatetime      string `json:"call_end_datetime"`
	CallDuration         string `json:"call_duration"`
	CallRecordFileURL    string `json:"call_record_file_url"`
	Disposition          string `json:"disposition"`
	CreatedAt            string `json:"created_at"`
	TemplateId           string `json:"template_id"`
}
