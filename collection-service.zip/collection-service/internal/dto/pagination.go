package dto

const RECORDS_LIMIT = 10

type PaginationData struct {
	CurrentPage int64
	Limit       int64
}

func Init(currentPage int64) PaginationData {
	return PaginationData{
		CurrentPage: currentPage,
		Limit:       RECORDS_LIMIT,
	}
}
