package events

import "collection-service/internal/enum"

type CustomerContactCreated struct {
	ContactRefNumber  string           `json:"contact_ref_number"`
	CustomerRefNumber string           `json:"customer_ref_number"`
	LoanRefNumber     string           `json:"loan_ref_number"`
	CaseRefNumber     string           `json:"case_ref_number"`
	ContactNumber     string           `json:"contact_number"`
	ContactName       string           `json:"contact_name"`
	ContactOf         enum.ContactOf   `json:"contact_of"`
	ContactType       enum.ContactType `json:"contact_type"`
	CreatedBy         string           `json:"created_by"`
	State             string           `json:"state"`
	Country           string           `json:"country"`
}
