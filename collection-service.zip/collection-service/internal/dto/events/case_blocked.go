package events

import "time"

type CaseBlocked struct {
	CaseRefNumber        string    `json:"case_ref_number"`
	BlockReasonMasterId  int       `json:"block_reason_master_id"`
	OriginalBlockedUntil time.Time `json:"original_blocked_until"`
	BlockedUntil         time.Time `json:"blocked_until"`
	BlockedAt            time.Time `json:"blocked_at"`
	BlockedBy            string    `json:"blocked_by"`
	IsResolved           bool      `json:"is_resolved"`
	TicketRefNumber      string    `json:"ticket_ref_number"`
	CreateTicket         bool      `json:"create_ticket"`
}
