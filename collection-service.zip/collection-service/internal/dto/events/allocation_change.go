package events

import "collection-service/internal/enum"

type AllocationChangedEvent struct {
	PreviousAllocation *AllocationEventNode `json:"previous_allocation"`
	NewAllocation      *AllocationEventNode `json:"new_allocation"`
}
type AllocationEventNode struct {
	CaseRefNumber                string            `json:"case_ref_number"`
	ClientRefNumber              string            `json:"client_ref_number"`
	ClientTeamRefNumber          string            `json:"client_team_ref_number"`
	ServiceProviderRefNumber     string            `json:"service_provider_ref_number"`
	ServiceProviderTeamRefNumber string            `json:"service_provider_team_ref_number"`
	AgentRefNumber               string            `json:"agent_ref_number"`
	Intervention                 enum.Intervention `json:"intervention"`
}
