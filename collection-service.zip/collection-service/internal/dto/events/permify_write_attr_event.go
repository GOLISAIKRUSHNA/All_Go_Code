package events

import "collection-service/internal/adapter/permify"

type PermifyWriteAttributesEvent struct {
	AttributeTuples []permify.AttributeTuple `json:"attribute_tuples"`
}
