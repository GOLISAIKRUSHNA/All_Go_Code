package events

type SendPaymentLinkEvent struct {
	CaseRefNumber       string `json:"case_ref_number"`
	MobileNumber        string `json:"mobile_number"`
	Email               string `json:"email"`
	WebengageCampaignID string `json:"webengage_campaign_id"`
	Attributes          string `json:"attributes"`
}
