package events

type GenerateCase struct {
	CustomerRefNumber string `json:"customer_ref_number" binding:"required"`
	LoanRefNumber     string `json:"loan_ref_number"`
	ClientRefNumber   string `json:"client_ref_number"`
	Level             string `json:"level"`
	CollectionFor     string `json:"collection_for"`
}
