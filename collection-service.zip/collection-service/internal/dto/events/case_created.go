package events

import (
	"collection-service/internal/enum"
	"time"
)

type CaseCreatedEvent struct {
	CaseRefNumber       string             `json:"case_ref_number"`
	ClientRefNumber     string             `json:"client_ref_number"`
	ClientTeamRefNumber string             `json:"client_team_ref_number"`
	CustomerRefNumber   string             `json:"customer_ref_number"`
	LoanRefNumber       string             `json:"loan_ref_number"`
	CollectionFor       enum.CollectionFor `json:"collection_for"`
	CaseLevel           string             `json:"case_level"`
	FinancierRefNumber  string             `json:"financier_ref_number"`
	Bucket              enum.Bucket        `json:"bucket"`
	TotalDue            float64            `json:"total_due"`
	Status              enum.CaseStatus    `json:"status"`
	TotalPrincipalDue   float64            `json:"total_principal_due"`
	TotalInterestDue    float64            `json:"total_interest_due"`
	TotalFeesDue        float64            `json:"total_fees_due"`
	CreatedBy           string             `json:"created_by"`
	CreatedAt           time.Time          `json:"created_at"`
}
