package events

import "collection-service/internal/adapter/permify"

type PermifyWriteRelationsEvent struct {
	RelationTuples []permify.RelationTuple `json:"relation_tuples"`
}
