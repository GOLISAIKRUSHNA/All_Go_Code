package events

import (
	"collection-service/internal/enum"
)

type Disposition struct {
	AttemptRefNumber     string      `json:"attempt_ref_number"`
	DispositionRefNumber string      `json:"disposition_ref_number"`
	Source               enum.Source `json:"source"`
	CaseRefNumber        string      `json:"case_ref_number"`
	CustomerRefNumber    string      `json:"customer_ref_number"`
	AgentRefNumber       string      `json:"agent_ref_number"`
	Disposition          string      `json:"disposition"`
	Comment              string      `json:"comment"`
	FollowupDatetime     string      `json:"followup_datetime"`
	Location             Location    `json:"location"`
	//SelfieFilePath       string      `json:"selfie_file_path"`
	AddressRefNumber string `json:"address_ref_number"`
	ContactRefNumber string `json:"contact_ref_number"`
	DispositionType  string `json:"disposition_type"`
}

type Location struct {
	Latitude  float64
	Longitude float64
}
