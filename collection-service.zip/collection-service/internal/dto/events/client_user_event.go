package events

import (
	jwt_token "collection-service/internal/app/services/token"
	"collection-service/internal/enum"
)

type CreateClientUserEvent struct {
	ClientRefNumber           string                    `json:"client_ref_number" binding:"required"`
	ClientUserRefNumber       string                    `json:"client_user_ref_number"`
	FirstName                 string                    `json:"first_name"`
	LastName                  string                    `json:"last_name"`
	MobileNumber              string                    `json:"mobile_number" binding:"required"`
	Email                     string                    `json:"email" binding:"required"`
	Username                  string                    `json:"username" binding:"required"`
	Password                  string                    `json:"password" binding:"required"`
	Designation               string                    `json:"designation"`
	ReportingManagerRefNumber string                    `json:"reporting_manager_ref_number"`
	ClientUserRole            enum.ClientUserRole       `json:"client_user_role" binding:"required"`
	ClientUserVisibility      enum.ClientUserVisibility `json:"client_user_visibility" binding:"required"`
	Claims                    *jwt_token.Claims         `json:"claims"`
	OrgID                     string                    `json:"org_id"`
}

type UpdateClientUserEvent struct {
	ClientRefNumber                   string                    `json:"client_ref_number" binding:"required"`
	ClientUserRefNumber               string                    `json:"client_user_ref_number"`
	FirstName                         string                    `json:"first_name"`
	LastName                          string                    `json:"last_name"`
	MobileNumber                      string                    `json:"mobile_number" binding:"required"`
	Email                             string                    `json:"email" binding:"required"`
	Username                          string                    `json:"username" binding:"required"`
	Password                          string                    `json:"password" binding:"required"`
	Designation                       string                    `json:"designation"`
	ReportingManagerRefNumber         string                    `json:"reporting_manager_ref_number"`
	ClientUserRole                    enum.ClientUserRole       `json:"client_user_role" binding:"required"`
	ClientUserVisibility              enum.ClientUserVisibility `json:"client_user_visibility" binding:"required"`
	Claims                            *jwt_token.Claims         `json:"claims"`
	OrgID                             string                    `json:"org_id"`
	PreviousReportingManagerRefNumber string                    `json:"previous_reporting_manager_ref_number"`
	PreviousRole                      enum.ClientUserRole       `json:"previous_role"`
}
