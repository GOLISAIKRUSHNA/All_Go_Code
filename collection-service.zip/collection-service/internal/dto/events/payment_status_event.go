package events

type PaymentStatusEvent struct {
	PaymentRefNumber    string  `json:"payment_ref_number"`
	PaymentReason       string  `json:"payment_reason"`
	Amount              float64 `json:"amount"`
	Status              string  `json:"status"`
	PaymentDatetime     string  `json:"payment_datetime"`
	FinalStatusDatetime string  `json:"final_status_datetime"`
	PaymentFor          string  `json:"payment_for"`
	PaymentForRefNumber string  `json:"payment_for_ref_number"`
	Partner             string  `json:"partner"`
	CreatedBy           string  `json:"created_by"`
}
