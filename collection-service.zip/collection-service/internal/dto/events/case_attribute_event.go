package events

import (
	"collection-service/internal/enum"
	"time"
)

type CaseAttributes struct {
	CaseRefNumber               string                  `json:"case_ref_number,omitempty"`
	CustomerRefNumber           string                  `json:"customer_ref_number,omitempty"`
	FirstName                   *string                 `json:"first_name,omitempty"`
	LastName                    *string                 `json:"last_name,omitempty"`
	MobileNumber                *string                 `json:"mobile_number,omitempty"`
	Email                       *string                 `json:"email,omitempty"`
	Gender                      *string                 `json:"gender,omitempty"`
	PreferredLanguage           *string                 `json:"preferred_language,omitempty"`
	EmploymentType              *string                 `json:"employment_type,omitempty"`
	MonthlyIncome               *float64                `json:"monthly_income,omitempty"`
	CibilScore                  *int                    `json:"cibil_score,omitempty"`
	ClientRefNumber             *string                 `json:"client_ref_number,omitempty"`
	LoanRefNumber               *string                 `json:"loan_ref_number,omitempty"`
	MaxDpd                      *int                    `json:"max_dpd,omitempty"`
	CurrentDpd                  *int                    `json:"current_dpd,omitempty"`
	Bucket                      *enum.Bucket            `json:"bucket,omitempty"`
	TotalDue                    *float64                `json:"total_due,omitempty"`
	TotalPrincipalDue           *float64                `json:"total_principal_due,omitempty"`
	TotalInterestDue            *float64                `json:"total_interest_due,omitempty"`
	TotalFeesDue                *float64                `json:"total_fees_due,omitempty"`
	NoOfLoansDue                *float64                `json:"no_of_loans_due,omitempty"`
	NoOfEmisDue                 *int                    `json:"no_of_emis_due,omitempty"`
	LastDisposition             *string                 `json:"last_disposition,omitempty"`
	LastDispositionDatetime     *time.Time              `json:"last_disposition_datetime,omitempty"`
	LastDispositionFollowupDate *time.Time              `json:"last_disposition_followup_date,omitempty"`
	Tenure                      *int                    `json:"tenure,omitempty"`
	TenureType                  *enum.LoanTenure        `json:"tenure_type,omitempty"`
	InterestRate                *float64                `json:"interest_rate,omitempty"`
	EmiAmount                   *float64                `json:"emi_amount,omitempty"`
	Product                     *string                 `json:"product,omitempty"`
	ActiveFinancierRefNumber    *string                 `json:"active_financier_ref_number,omitempty"`
	SecondaryFinancierRefNumber *string                 `json:"secondary_financier_ref_number,omitempty"`
	ActiveFinancierName         *string                 `json:"active_financier_name,omitempty"`
	SecondaryFinancierName      *string                 `json:"secondary_financier_name,omitempty"`
	DisbursementDate            *string                 `json:"disbursement_date,omitempty"`
	DueDate                     *time.Time              `json:"due_date,omitempty"`
	Status                      *enum.CaseStatus        `json:"status,omitempty"`
	CaseCreatedAt               *time.Time              `json:"case_created_at,omitempty"`
	LoanCollateralType          *string                 `json:"loan_collateral_type,omitempty"`
	LoanCollateralDescription   *string                 `json:"loan_collateral_description,omitempty"`
	CoApplicantName             *string                 `json:"co_applicant_name,omitempty"`
	CoApplicantRelation         *string                 `json:"co_applicant_relation,omitempty"`
	CoApplicantEmail            *string                 `json:"co_applicant_email,omitempty"`
	CoApplicantMobileNumber     *string                 `json:"co_applicant_mobile_number,omitempty"`
	ClientLoanId                *string                 `json:"client_loan_id,omitempty"`
	LoanAmount                  *float64                `json:"loan_amount,omitempty"`
	ShortLink                   *string                 `json:"short_link,omitempty"`
	ClientShortLink             *string                 `json:"client_short_link,omitempty"`
	IsBlocked                   *bool                   `json:"is_blocked,omitempty"`
	DuesWaiverOffer             *map[string]interface{} `json:"dues_waiver_offer,omitempty"`
	SettlementOffer             *map[string]interface{} `json:"settlement_offer,omitempty"`
}
