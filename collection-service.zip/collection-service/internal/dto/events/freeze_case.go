package events

type FreezeCase struct {
	CaseRefNumber string `json:"case_ref_number"`
	Reason        string `json:"reason"`
	Action        string `json:"action"`
	CreatedBy     string `json:"created_by"`
	CreatedAt     string `json:"created_at"`
}
