package events

type CaseWithdrawnEvent struct {
	CaseRefNumber string `json:"case_ref_number"`
}
