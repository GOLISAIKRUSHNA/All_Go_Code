package events

type CaseUnBlocked struct {
	CaseRefNumber string `json:"case_ref_number"`
}
