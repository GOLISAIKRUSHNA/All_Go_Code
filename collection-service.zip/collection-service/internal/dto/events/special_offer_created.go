package events

import (
	"collection-service/internal/enum"
	"time"
)

type SpecialOfferCreated struct {
	SpecialOfferRefNumber   string           `json:"special_offer_ref_number"`
	CaseRefNumber           string           `json:"case_ref_number"`
	LoanRefNumber           string           `json:"loan_ref_number"`
	OfferType               enum.OfferType   `json:"offer_type"`
	WaiverType              enum.WaiverType  `json:"waiver_type"`
	WaiverValue             float64          `json:"waiver_value"`
	TotalFeesDueWaiverType  enum.WaiverType  `json:"total_fees_due_waiver_type"`
	TotalFeesDueWaiverValue float64          `json:"total_fees_due_waiver_value"`
	MinimumPaymentAmount    float64          `json:"minimum_payment_amount"`
	OfferStatus             enum.OfferStatus `json:"offer_status"`
	StartDatetime           string           `json:"start_datetime"`
	EndDatetime             string           `json:"end_datetime"`
	CreatedBy               string           `json:"created_by"`
	CreatedAt               time.Time        `json:"created_at"`
	UpdatedAt               time.Time        `json:"updated_at"`
}
