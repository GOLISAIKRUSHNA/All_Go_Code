package events

type BulkUploadEvent struct {
	UploadRefNumber string
	Reason          string
	Type            string
	TypeRefNumber   string
	UploadedBy      string
}
