package events

type TicketCreated struct {
	TicketRefNumber string `json:"ticket_ref_number"`
	CaseRefNumber   string `json:"case_ref_number"`
	AgentRefNumber  string `json:"agent_ref_number"`
	Status          string `json:"status"`
	IssueId         string `json:"issue_id"`
	SubIssueId      string `json:"sub_issue_id"`
	Action          string `json:"action"`
	Comment         string `json:"comment"`
}
