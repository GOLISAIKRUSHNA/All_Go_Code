package events

type CaseAttributeEvent struct {
	CaseRefNumber string `json:"case_ref_number"`
	Payment       struct {
		HavingMandateInprogressPayments bool `json:"having_mandate_inprogress_payments"`
		HavingInprogressPayments        bool `json:"having_inprogress_payments"`
	} `json:"payment"`
}
