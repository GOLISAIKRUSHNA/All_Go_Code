package events

import "time"

type CaseAttemptReport struct {
	CaseRefNumber        string    `json:"case_ref_number"`
	TotalCallsAttempted  int       `json:"total_calls_attempted"`
	TotalCallsConnected  int       `json:"total_calls_connected"`
	TodaysCallsAttempted int       `json:"todays_calls_attempted"`
	TodaysCallsConnected int       `json:"todays_calls_connected"`
	LastCallConnectedAt  time.Time `json:"last_call_connected_at"`
	AgentRefNumber       string    `json:"agent_ref_number"`
}
