package events

import (
	jwt_token "collection-service/internal/app/services/token"
	"collection-service/internal/enum"
	"time"
)

type AgentCreatedEvent struct {
	AgentRefNumber            string               `json:"agent_ref_number"`
	ServiceProviderRefNumber  string               `json:"service_provider_ref_number"`
	FirstName                 string               `json:"first_name"`
	LastName                  string               `json:"last_name"`
	MobileNumber              string               `json:"mobile_number"`
	Status                    string               `json:"status"`
	Password                  string               `json:"password"`
	Role                      enum.AgentRole       `json:"role"`
	Visibility                enum.AgentVisibility `json:"visibility"`
	CreatedAt                 time.Time            `json:"created_at"`
	ReportingManagerRefNumber string               `json:"reporting_manager_ref_number"`

	Email           string            `json:"email" binding:"email,required"`
	Username        string            `json:"username" binding:"alphanum_plus_sym,required,max=50"`
	Object          enum.UserObject   `json:"object"`
	ObjectRefNumber string            `json:"object_ref_number"`
	Claims          *jwt_token.Claims `json:"claims"`
	OrgID           string            `json:"org_id"`
}

type AgentUpdatedEvent struct {
	AgentRefNumber            string               `json:"agent_ref_number"`
	ServiceProviderRefNumber  string               `json:"service_provider_ref_number"`
	FirstName                 string               `json:"first_name"`
	LastName                  string               `json:"last_name"`
	MobileNumber              string               `json:"mobile_number"`
	Status                    string               `json:"status"`
	Password                  string               `json:"password"`
	Role                      enum.AgentRole       `json:"role"`
	Visibility                enum.AgentVisibility `json:"visibility"`
	CreatedAt                 time.Time            `json:"created_at"`
	ReportingManagerRefNumber string               `json:"reporting_manager_ref_number"`

	Email                             string            `json:"email" binding:"email,required"`
	Username                          string            `json:"username" binding:"alphanum_plus_sym,required,max=50"`
	Claims                            *jwt_token.Claims `json:"claims"`
	OrgID                             string            `json:"org_id"`
	PreviousReportingManagerRefNumber string            `json:"previous_reporting_manager_ref_number"`
	PreviousRole                      enum.AgentRole    `json:"previous_role"`
}
