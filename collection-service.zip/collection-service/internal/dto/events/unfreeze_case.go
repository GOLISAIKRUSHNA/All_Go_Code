package events

type UnFreezeCase struct {
	CaseRefNumber string `json:"case_ref_number"`
	CreatedBy     string `json:"created_by"`
	CreatedAt     string `json:"created_at"`
}
