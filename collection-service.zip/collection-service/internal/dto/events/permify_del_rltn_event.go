package events

import "collection-service/internal/adapter/permify"

type PermifyDeleteRelationsEvent struct {
	DeleteRelationTuple permify.DeleteRelationTuple `json:"delete_relation_tuple"`
}
