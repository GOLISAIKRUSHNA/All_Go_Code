package request

type UserExistsReq struct {
	Username string `json:"username"`
}
