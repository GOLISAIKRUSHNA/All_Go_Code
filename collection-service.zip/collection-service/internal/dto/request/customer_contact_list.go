package request

type CustomerContactListFilter struct {
	CustomerRefNumber string
	CaseRefNumber     string
}
