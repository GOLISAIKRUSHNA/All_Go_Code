package request

import "collection-service/internal/enum"

type ActivateSpecialOfferReq struct {
	SpecialOffersMasterRefNumber string         `json:"special_offers_master_ref_number" binding:"required"`
	OfferType                    enum.OfferType `json:"offer_type" binding:"required"`
	QueueType                    enum.QueueType `json:"queue_type" binding:"required"`
	ClientRefNumber              string         `json:"client_ref_number"`
}
