package request

type DialerServiceClick2Call struct {
	CaseRefNumber        string `json:"case_ref_number"`
	CustomerRefNumber    string `json:"customer_ref_number"`
	CustomerName         string `json:"customer_name"`
	ContactRefNumber     string `json:"contact_ref_number"`
	CustomerMobileNumber string `json:"customer_mobile_number"`
	AgentRefNumber       string `json:"agent_ref_number"`
	AgentName            string `json:"agent_name"`
	AgentMobileNumber    string `json:"agent_mobile_number"`
	BridgeCall           bool   `json:"bridge_call"`
}
