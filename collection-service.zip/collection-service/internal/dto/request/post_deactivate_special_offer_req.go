package request

type DeactivateSpecialOfferReq struct {
	SpecialOfferRefNumber string `json:"special_offer_ref_number" binding:"required"`
}
