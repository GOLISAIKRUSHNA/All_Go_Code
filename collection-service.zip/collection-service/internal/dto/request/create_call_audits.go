package request

type CallAudits struct {
	AttemptRefNumber     string `json:"attempt_ref_number" binding:"required"`
	CaseRefNumber        string `json:"case_ref_number" binding:"required"`
	CallerAgentRefNumber string `json:"caller_agent_ref_number" binding:"required"`
	TemplateId           string `json:"template_id" binding:"required"`
	CallDuration         string `json:"call_duration" binding:"required"`
	CallDate             string `json:"call_date" binding:"required"`
}
