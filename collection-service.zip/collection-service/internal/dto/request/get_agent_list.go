package request

import "collection-service/internal/enum"

type GetAgent struct {
	FirstName                 string               `json:"first_name"`
	LastName                  string               `json:"last_name"`
	MobileNumber              string               `json:"mobile_number" binding:"mobile,required"`
	Email                     string               `json:"email" binding:"email,required"`
	Username                  string               `json:"username" binding:"alphanum_plus_sym,required,max=50"`
	HasPanelAccess            bool                 `json:"has_panel_access"`
	HasAppAccess              bool                 `json:"has_app_access"`
	CashCollectionLimit       float64              `json:"cash_collection_limit"`
	Designation               string               `json:"designation"`
	CashDepositByDays         int                  `json:"cash_deposit_by_days"`
	Status                    enum.Status          `json:"status"`
	ReportingManagerRefNumber string               `json:"reporting_manager_ref_number"`
	LanguagesSupported        []string             `json:"languages_supported" binding:"required"`
	CreatedBy                 string               `json:"created_by"`
	UpdatedBy                 string               `json:"updated_by"`
	Role                      enum.AgentRole       `json:"role"`
	Visibility                enum.AgentVisibility `json:"visibility"`
	ServiceProviderRefNumber  string               `json:"service_provider_ref_number"`
	AgentRefNumber            string               `json:"agent_ref_number"`
	Search                    string               `json:"search"`
}
