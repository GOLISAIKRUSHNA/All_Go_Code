package request

import "collection-service/internal/enum"

type AddContact struct {
	CustomerRefNumber string           `json:"customer_ref_number" binding:"required"`
	LoanRefNumber     string           `json:"loan_ref_number"`
	CaseRefNumber     string           `json:"case_ref_number"`
	ContactNumber     string           `json:"contact_number" binding:"required"`
	ContactName       string           `json:"contact_name" binding:"required"`
	ContactOf         enum.ContactOf   `json:"contact_of" binding:"required"`
	ContactType       enum.ContactType `json:"contact_type"`
	IsPrimary         bool             `json:"is_primary"`
	CreatedBy         string           `json:"created_by" binding:"required"`
}
