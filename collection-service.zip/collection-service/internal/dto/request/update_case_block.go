package request

import "time"

type UpdateBlockCase struct {
	CaseRefNumber   string    `json:"case_ref_number"`
	BlockedUntil    time.Time `json:"blocked_until"`
	IsResolved      bool      `json:"is_resolved"`
	CreatedBy       string    `json:"created_by"`
	Action          string    `json:"action"`
	TicketRefNumber string    `json:"ticket_ref_number"`
}
