package request

type AttendanceUpdateReq struct {
	AttendanceReferenceNumbers []string `json:"attendance_ref_numbers" binding:"required"`
	AgentRefNumber             string   `json:"agent_ref_number" binding:"required"`
	ApprovalStatus             string   `json:"approval_status" binding:"required"`
}
