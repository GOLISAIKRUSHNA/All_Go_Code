package request

type CreateCommentReq struct {
	CaseRefNumber        string `json:"case_ref_number" binding:"required"`
	Comment              string `json:"comment"`
	Disposition          string `json:"disposition"`
	DispositionRefNumber string `json:"disposition_ref_number"`
	CreatedBy            string `json:"created_by"`
	CreatedByName        string `json:"created_by_name"`
}
