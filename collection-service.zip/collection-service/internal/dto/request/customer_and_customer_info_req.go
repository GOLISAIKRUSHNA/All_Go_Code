package request

type CustomerAndCustomerInfoReq struct {
	Customer     CustomerReq
	CustomerInfo CustomerInfo
}
