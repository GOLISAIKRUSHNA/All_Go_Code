package request

import (
	"collection-service/internal/enum"
	"time"
)

type CreateTicket struct {
	CaseRefNumber    string            `json:"case_ref_number"`
	AgentRefNumber   string            `json:"agnet_ref_number"`
	Status           enum.TicketStatus `json:"status"`
	IssueId          int               `json:"issue_id"`
	SubIssueId       int               `json:"sub_issue_id"`
	Action           enum.TicketAction `json:"action"`
	Comment          string            `json:"comment"`
	ExtendedDatetime time.Time         `json:"extended_datetime"`
}
