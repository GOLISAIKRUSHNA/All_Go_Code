package request

import "collection-service/internal/enum"

type CaseLoanFilter struct {
	CaseRefNumber string
	Status        string

	// claims params
	ClientRefNumber          string
	ServiceProviderRefNumber string
	Object                   enum.UserObject
	ObjectRefNumber          string
	XApp                     string
}
