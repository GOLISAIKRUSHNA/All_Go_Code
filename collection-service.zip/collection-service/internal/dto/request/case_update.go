package request

type CaseUpdateReq struct {
	CaseRefNumber string `json:"case_ref_number"`
	IsBlocked     bool   `json:"is_blocked"`
}
