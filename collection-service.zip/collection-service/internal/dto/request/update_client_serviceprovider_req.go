package request

import "collection-service/internal/enum"

type UpdateClientServiceProviderReq struct {
	Status                   enum.ClientServiceProviderStatus `json:"status" binding:"required"`
	ClientRefNumber          string                           `json:"client_ref_number" `
	ServiceProviderRefNumber string                           `json:"service_provider_ref_number" `
}
