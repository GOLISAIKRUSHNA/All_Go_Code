package request

type TicketListReq struct {
	TicketRefNumber      string `json:"ticket_ref_number"`
	CaseRefNumber        string `json:"case_ref_number"`
	AgentRefNumber       string `json:"agnet_ref_number"`
	Status               string `json:"status"`
	Source               string `json:"source"`
	Reason               string `json:"reason"`
	IssueId              int    `json:"issue_id"`
	SubIssueId           int    `json:"sub_issue_id"`
	SortByBlockedDate    string `json:"sort_by_blocked_date"`
	SortByTotalDueAmount string `json:"sort_by_total_due_amount"`
	IsIssueFilled        bool   `json:"is_issue_filled"`
	IsSubIssueFilled     bool   `json:"is_sub_issue_filled"`
	PageNo               int    `json:"page_no"`
	IssueIds             string `json:"issue_ids"`
	SubIssueIds          string `json:"sub_issue_ids"`
	Default              bool   `json:"default"`
}
