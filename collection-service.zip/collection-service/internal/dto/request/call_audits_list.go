package request

type CallAuditsList struct {
	AuditAgentRefNumber string `json:"audit_agent_ref_number"`
	AuditRefNumber      string `json:"audit_ref_number"`
	Status              string `json:"status"`
	PageNo              int    `json:"page_no"`
	Search              string `json:"search"`
	Sort                string `json:"sort"`
}
