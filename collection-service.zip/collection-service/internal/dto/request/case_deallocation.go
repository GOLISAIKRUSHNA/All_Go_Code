package request

import "collection-service/internal/enum"

type CaseDeAllocationReq struct {
	ClientLoanId             string            `json:"client_loan_id"`
	CaseRefNumber            string            `json:"case_ref_number"`
	AgentRefNumber           string            `json:"agent_ref_number"`
	Intervention             enum.Intervention `json:"intervention"`
	ServiceProviderRefNumber string            `json:"service_provider_ref_number"`
	Object                   string            `json:"object"`
	ObjectRefNumber          string            `json:"object_ref_number" `
	CreatedBy                string            `json:"created_by" binding:"required"`
}
