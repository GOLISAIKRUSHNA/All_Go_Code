package request

type GetViolationsReq struct {
	ID              []string `json:"id"`
	ClientRefNumber string   `json:"client_ref_number"`
}
