package request

type Click2Call struct {
	CaseRefNumber    string `json:"case_ref_number"`
	AgentRefNumber   string `json:"agent_ref_number"`
	ContactRefNumber string `json:"contact_ref_number"`
	BridgeCall       bool   `json:"bridge_call"`
}
