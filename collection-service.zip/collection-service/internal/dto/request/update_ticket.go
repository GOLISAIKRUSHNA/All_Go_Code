package request

import (
	"collection-service/internal/enum"
	"errors"
	"strings"
)

type UpdateTicket struct {
	AgentRefNumber   string            `json:"agent_ref_number"`
	IssueId          int               `json:"issue_id"`
	SubIssueId       int               `json:"sub_issue_id"`
	Action           enum.TicketAction `json:"action"` // enum.TicketAction
	Comment          string            `json:"comment"`
	ExtendedDatetime string            `json:"extended_datetime"`
}

func (input *UpdateTicket) Validate() error {
	var errorString string
	if input.IssueId == 0 {
		errorString = errorString + "" + "required or invalid issue id, "
	}
	if input.SubIssueId == 0 {
		errorString = errorString + "" + "required or invalid sub issue id "
	}
	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}
