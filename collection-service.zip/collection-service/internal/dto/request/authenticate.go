package request

type Authenticate struct {
	LoginMode    string `json:"login_mode" binding:"required"`
	MobileNumber string `json:"mobile_number" binding:"mobile"`
	Email        string `json:"email" binding:"email"`
	Username     string `json:"username"`
	Password     string `json:"password"`
	OTP          string `json:"otp"`
}
