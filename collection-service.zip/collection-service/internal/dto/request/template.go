package request

type Template struct {
	Title           string     `json:"title"`
	Description     string     `json:"description"`
	Status          string     `json:"status"`
	CreatedBy       string     `json:"created_by"`
	ClientRefNumber string     `json:"client_ref_number"`
	IsPublished     bool       `json:"is_published"`
	Categories      []Category `json:"categories"`
	Questions       []Question `json:"questions"`
}

type Category struct {
	CategorySequence int    `json:"category_sequence"`
	Label            string `json:"label"`
	Description      string `json:"description"`
}

type Question struct {
	QuestionSequence int        `json:"question_sequence"`
	Title            string     `json:"title"`
	Description      string     `json:"description"`
	CategorySequence int        `json:"category_sequence"`
	IsMandatory      bool       `json:"is_mandatory"`
	ResponseType     string     `json:"response_type"`
	MaxScore         int        `json:"max_score"`
	ScoreIntent      string     `json:"score_intent"`
	Responses        []Response `json:"responses"`
}

type Response struct {
	Value          string `json:"value"`
	Description    string `json:"description"`
	Score          int    `json:"score"`
	ViolationId    int    `json:"violation_id"`
	Violation      string `json:"violation"`
	ViolationLevel string `json:"violation_level"`
	IsDefault      bool   `json:"is_default"`
}
