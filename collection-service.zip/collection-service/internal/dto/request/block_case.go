package request

import "collection-service/internal/enum"

type BlockCase struct {
	CaseRefNumber              string `json:"case_ref_number"`
	ClientLoanId               string `json:"client_loan_id"`
	Reason                     string `json:"reason"`
	Source                     enum.BlockSource
	BlockedUntil               string `json:"blocked_until"`
	BlockType                  string `json:"block_type"`
	IsManualResolutionRequired bool   `json:"is_manual_resolution_required"`
	ViolationId                int    `json:"violation_id"`
	CreatedBy                  string `json:"created_by"`
}
