package request

type SendPaymentLinkReq struct {
	MobileNumber   string `json:"mobile_number"`
	Email          string `json:"email"`
	AgentRefNumber string `json:"agent_ref_number"`
}
