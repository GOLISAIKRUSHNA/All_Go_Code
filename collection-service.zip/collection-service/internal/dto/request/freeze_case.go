package request

import "collection-service/internal/enum"

type FreezeCase struct {
	CaseRefNumber string            `json:"case_ref_number"`
	Action        enum.FreezeStatus `json:"action"`
	Reason        string            `json:"reason"`
	CreatedBy     string            `json:"created_by"`
	CreatedAt     string            `json:"created_at"`
}

type UnFreezeCase struct {
	CaseRefNumber string            `json:"case_ref_number"`
	Action        enum.FreezeStatus `json:"action"`
	Reason        string            `json:"reason"`
	CreatedBy     string            `json:"created_by"`
	CreatedAt     string            `json:"created_at"`
}

type DailyCallsLimitFreeze struct {
	CaseRefNumber string            `json:"case_ref_number"`
	Action        enum.FreezeStatus `json:"action"`
	Reason        string            `json:"reason"`
	CreatedBy     string            `json:"created_by"`
	Disposition   string            `json:"disposition"`
}
