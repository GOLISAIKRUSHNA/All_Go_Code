package request

import "collection-service/internal/enum"

type GetClientUserQueryParam struct {
	ClientRefNumber     string `json:"client_ref_number"`
	ClientUserRefNumber string `json:"client_user_ref_number"`
	MobileNumber        string `json:"mobile_number"`
	Email               string `json:"email"`
	Search              string `json:"search"`

	Status enum.Status `json:"status"`
}
