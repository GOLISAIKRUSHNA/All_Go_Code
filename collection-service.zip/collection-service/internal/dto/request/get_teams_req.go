package request

import "collection-service/internal/enum"

type GetTeamsReq struct {
	Object          enum.TeamObject `json:"object"`
	ObjectRefNumber string          `json:"object_ref_number"`
}
