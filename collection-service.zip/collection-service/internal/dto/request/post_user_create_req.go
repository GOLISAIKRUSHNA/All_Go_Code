package request

import (
	jwt_token "collection-service/internal/app/services/token"
	"collection-service/internal/enum"
)

type CreateUserReq struct {
	FirstName       string            `json:"first_name"`
	LastName        string            `json:"last_name"`
	MobileNumber    string            `json:"mobile_number" binding:"mobile,required"`
	Email           string            `json:"email" binding:"email,required"`
	Username        string            `json:"username" binding:"alphanum_plus_sym,required,max=50"`
	Password        string            `json:"password" binding:"required"`
	Object          enum.UserObject   `json:"object"`
	ObjectRefNumber string            `json:"object_ref_number"`
	Claims          *jwt_token.Claims `json:"claims"`
	OrgID           string            `json:"org_id"`
}
