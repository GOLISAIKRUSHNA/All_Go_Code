package request

type BulkUploadRequest struct {
	Reason        string `json:"reason" binding:"required"`
	UploadedBy    string `json:"uploaded_by"  binding:"required"`
	Type          string `json:"type"`
	TypeRefNumber string `json:"type_ref_number" binding:"required"`
	FileName      string
}
