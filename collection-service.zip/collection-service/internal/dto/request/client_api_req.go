package request

type ClientAPIReq struct {
	ClientRefNumber string `json:"client_ref_number"`
	Method          string `json:"method"`
	URL             string `json:"url"`
}
