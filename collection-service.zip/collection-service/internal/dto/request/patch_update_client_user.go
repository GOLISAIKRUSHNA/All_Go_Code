package request

import "collection-service/internal/enum"

type UpdateClientUserReq struct {
	FirstName                 string                    `json:"first_name"`
	LastName                  string                    `json:"last_name"`
	Username                  string                    `json:"username"`
	Email                     string                    `json:"email"`
	MobileNumber              string                    `json:"mobile_number"`
	Designation               string                    `json:"designation"`
	PhotoBase64String         string                    `json:"photo_base64_string"`
	ClientUserRole            enum.ClientUserRole       `json:"client_user_role"`
	ClientUserVisibility      enum.ClientUserVisibility `json:"client_user_visibility"`
	Status                    enum.Status               `json:"status"`
	TeamRefNumber             string                    `json:"team_ref_number"`
	ReportingManagerRefNumber string                    `json:"reporting_manager_ref_number"`
}
