package request

type AutoSuggestClientUserReq struct {
	Name            string
	ClientRefNumber string
	TeamRefNumber   string
}
