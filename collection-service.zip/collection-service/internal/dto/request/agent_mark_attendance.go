package request

type MarkAttendanceReq struct {
	AgentRefNumber               string  `json:"agent_ref_number" binding:"required"`
	AttendanceDate               string  `json:"attendance_date" binding:"required"`
	AttendanceSelfieBase64String string  `json:"selfie" binding:"required"`
	Latitude                     float64 `json:"latitude" binding:"required"`
	Longitude                    float64 `json:"longitude" binding:"required"`
	MarkType                     string  `json:"mark_type" binding:"required"`
}
