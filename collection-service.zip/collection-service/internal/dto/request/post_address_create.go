package request

import "collection-service/internal/enum"

type CreateAddressRequest struct {
	CustomerRefNumber string              `json:"customer_ref_number"`
	LoanRefNumber     string              `json:"loan_ref_number"`
	CaseRefNumber     string              `json:"case_ref_number"`
	Line1             string              `json:"line_1"`
	Line2             string              `json:"line_2"`
	Line3             string              `json:"line_3"`
	Landmark          string              `json:"landmark"`
	Label             enum.AddressLabel   `json:"label"`
	Type              enum.AddressType    `json:"type"`
	Source            enum.AddressSource  `json:"source"`
	AddressQuality    enum.AddressQuality `json:"address_quality"`
	AddressMedium     enum.AddressMedium  `json:"address_medium"`
	ResidentType      string              `json:"resident_type"`
	Pincode           int                 `json:"pincode"`
	City              string              `json:"city"`
	State             string              `json:"state"`
	Country           string              `json:"country"`
	CityId            int                 `json:"city_id"`
	StateId           int                 `json:"state_id"`
	Latitude          float64             `json:"latitude"`
	Longitude         float64             `json:"longitude"`
	CreatedBy         string              `json:"created_by"`
	UpdatedBy         string              `json:"updated_by"`
	IsPrimary         bool                `json:"is_primary"`
}
