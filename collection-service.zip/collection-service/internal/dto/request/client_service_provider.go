package request

type ClientServiceProviderReq struct {
	ClientRefNumber          string `json:"client_ref_number"`
	ServiceProviderRefNumber string `json:"service_provider_ref_number"`
	Status                   string `json:"status"`
}
