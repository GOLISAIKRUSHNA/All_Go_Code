package request

type CaseBlockList struct {
	IsResolved    bool   `json:"is_resolved"`
	CaseRefNumber string `json:"case_ref_number"`
	BlockReasonId int    `json:"block_reason_id"`
	BlockSource   string `json:"block_source"`
	BlockedBy     string `json:"blocked_by"`
	Limit         int    `json:"limit"`
	Offset        int    `json:"offset"`
	Page          int    `json:"page"`
}
