package request

import (
	"collection-service/internal/enum"
)

type CreateClientUserReq struct {
	ClientRefNumber           string                    `json:"client_ref_number" binding:"required"`
	FirstName                 string                    `json:"first_name"`
	LastName                  string                    `json:"last_name"`
	MobileNumber              string                    `json:"mobile_number" binding:"required"`
	Email                     string                    `json:"email" binding:"required"`
	Username                  string                    `json:"username"`
	Password                  string                    `json:"password" binding:"required"`
	Designation               string                    `json:"designation"`
	ReportingManagerRefNumber string                    `json:"reporting_manager_ref_number"`
	ClientUserRole            enum.ClientUserRole       `json:"client_user_role" binding:"required"`
	ClientUserVisibility      enum.ClientUserVisibility `json:"client_user_visibility" binding:"required"`

	CreatedBy         string `json:"created_by"`
	PhotoBase64String string `json:"photo_base64_string"`
	TeamRefNumber     string `json:"team_ref_number"`
}
