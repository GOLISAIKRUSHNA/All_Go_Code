package request

type EncryptReq struct {
	Text  string `json:"text" binding:"required"`
	KeyId string `json:"key_id" binding:"required"`
}
