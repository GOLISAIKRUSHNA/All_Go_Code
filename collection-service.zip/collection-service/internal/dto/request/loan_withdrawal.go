package request

type LoanWithdrawalReq struct {
	ClientLoanId string `json:"client_loan_id"`
	Reason       string `json:"reason"`
	OtherReason  string `json:"other_reason"`
	CreatedBy    string `json:"created_by"`
}
