package request

type AddUserToTeamReq struct {
	TeamRefNumber string   `json:"team_ref_number"`
	ClientUsers   []string `json:"client_users"`
	Agents        []string `json:"agents"`
}
