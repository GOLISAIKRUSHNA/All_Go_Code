package request

import "collection-service/internal/enum"

type PostLoginParams struct {
	AppName                  string          `json:"app_name"`
	Object                   enum.UserObject `json:"object"`
	ObjectRefNumber          string          `json:"object_ref_number"`
	ClientRefNumber          string          `json:"client_ref_number"`
	ServiceProviderRefNumber string          `json:"service_provider_ref_number"`
}
