package request

type Address struct {
	AddressRefNumber string `json:"address_ref_number"`
	Label            string `json:"label"`
	Type             string `json:"type"`
	ResidentType     string `json:"resident_type"`
	Source           string `json:"source"`
	Line1            string `json:"line_1"`
	Line2            string `json:"line_2"`
	Line3            string `json:"line_3"`
	Landmark         string `json:"landmark"`
	Pincode          int    `json:"pincode"`
	City             string `json:"city"`
	State            string `json:"state"`
	Country          string `json:"country"`
}
