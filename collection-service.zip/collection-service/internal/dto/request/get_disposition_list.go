package request

type GetDisposition struct {
	CaseRefNumber     string `json:"case_ref_number"`
	CustomerRefNumber string `json:"customer_ref_number"`
}
