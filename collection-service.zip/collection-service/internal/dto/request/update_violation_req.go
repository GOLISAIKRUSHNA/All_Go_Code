package request

type UpdateViolationReq struct {
	ID              int    `json:"id" binding:"required"`
	ClientRefNumber string `json:"client_ref_number" binding:"required"`
	Violation       string `json:"violation" binding:"required"`
	ViolationLevel  string `json:"violation_level" binding:"required"`
	IsCaseToBlock   *bool  `json:"is_case_to_block" binding:"required"`
	UpdatedBy       string `json:"updated_by"  binding:"required"`
}
