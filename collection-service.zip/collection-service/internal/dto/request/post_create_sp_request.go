package request

import (
	"collection-service/internal/enum"
)

type PostCreateSpecialOffer struct {
	ClientLoanId         string           `json:"client_loan_id" binding:"required"`
	OfferType            enum.OfferType   `json:"offer_type" binding:"required"`
	WaiverType           enum.WaiverType  `json:"waiver_type" binding:"required"`
	WaiverValue          float64          `json:"waiver_value" binding:"required"`
	MinimumPaymentAmount float64          `json:"minimum_payment_amount"`
	Status               enum.OfferStatus `json:"status"`
	StartDatetime        string           `json:"start_datetime" binding:"required"`
	EndDatetime          string           `json:"end_datetime" binding:"required"`
	CreatedBy            string           `json:"created_by"`
	ClientRefNumber      string           `json:"client_ref_number" binding:"required"`
}
