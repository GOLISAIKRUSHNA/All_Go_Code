package request

import (
	jwt_token "collection-service/internal/app/services/token"
	"collection-service/internal/enum"
)

type UpdateUserReq struct {
	Object          enum.UserObject   `json:"object"`
	ObjectRefNumber string            `json:"object_ref_number"`
	Username        string            `json:"username"`
	Password        string            `json:"password"`
	Claims          *jwt_token.Claims `json:"claims"`
	OrgID           string            `json:"org_id"`
}
