package request

type UnblockCase struct {
	CaseRefNumber string `json:"case_ref_number"`
}
