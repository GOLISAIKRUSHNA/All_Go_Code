package request

type BulkUploadListRequest struct {
	Reason     string `json:"reason"`
	Status     string `json:"status"`
	PageNo     string `json:"page"`
	UploadedBy string `json:"uploaded_by"`
}
