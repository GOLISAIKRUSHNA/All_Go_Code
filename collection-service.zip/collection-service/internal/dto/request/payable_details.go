package request

type PayableDetails struct {
	CaseRefNumber            string `json:"case_ref_number"`
	LoanRefNumber            string `json:"loan_ref_number"`
	CustomerRefNumber        string `json:"customer_ref_number"`
	ClientLoanId             string `json:"client_loan_id"`
	ClientCustomerId         string `json:"client_customer_id"`
	ServiceProviderRefNumber string `json:"service_provider_ref_number"`
}
