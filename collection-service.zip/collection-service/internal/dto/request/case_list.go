package request

import "collection-service/internal/enum"

type CaseListFilter struct {
	ClientLoanId              string
	LoanRefNumber             string
	ClientCustomerId          string
	CustomerRefNumber         string
	CurrentDPDBucket          string
	CaseRefNumber             string
	LastDisposition           string
	GetPTPCases               bool
	GetUntouchCases           bool
	SortByDue                 string
	SortByBucket              string
	SortByLastDispositionDate string
	FollowupDate              string
	Status                    string
	SearchBy                  string
	SearchKey                 string
	PageNo                    int
	// claims params
	ClientRefNumber          string
	ServiceProviderRefNumber string
	Object                   enum.UserObject
	ObjectRefNumber          string

	// db level filters
	AgentRefNumbers              *[]string
	ServiceProviderTeamRefNumber *string
	ClientTeamRefNumber          *string
	AllocatedTo                  *string
	Default                      bool
	XApp                         string
}
