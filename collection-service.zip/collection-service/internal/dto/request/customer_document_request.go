package request

type CustomerDocumentRequest struct {
	ClientCustomerId string
	ClientRefNumber  string
	DocumentType     string
	CreatedBy        string
}
