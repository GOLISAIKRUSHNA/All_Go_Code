package request

type Login struct {
	LoginMode    string `json:"login_mode" binding:"required,max=100"`
	MobileNumber string `json:"mobile_number" binding:"required,mobile"`
}
