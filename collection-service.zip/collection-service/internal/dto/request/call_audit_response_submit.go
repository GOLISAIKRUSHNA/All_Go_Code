package request

type CallAuditSubmit struct {
	Template           Template             `json:"template"`
	SubmittedResponses []SubmittedResponses `json:"submitted_responses"`
}

type SubmittedResponses struct {
	QuestionSequence int    `json:"question_sequence"`
	CategorySequence int    `json:"category_sequence"`
	Value            string `json:"value"`
	Note             string `json:"note"`
	Score            int    `json:"score"`
	ViolationId      int    `json:"violation_id"`
	Violation        string `json:"violation"`
	ViolationLevel   string `json:"violation_level"`
}

type CallAuditParam struct {
	AuditRefNumber string `json:"audit_ref_number"`
}
