package request

type AttemptListRequest struct {
	CaseRefNumber     string `json:"case_ref_number"`
	AttemptedBy       string `json:"attempted_by"`
	CustomerRefNumber string `json:"customer_ref_number"`
	For               string `json:"for"` //CSAT,AUDITOR,AGENT
}
