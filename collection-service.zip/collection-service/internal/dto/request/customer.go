package request

import "time"

type CustomerReq struct {
	ClientCustomerId  string    `json:"client_customer_id" binding:"required"`
	CustomerRefNumber string    `json:"customer_ref_number" binding:"required"`
	ClientRefNumber   string    `json:"client_ref_number" binding:"required"`
	FirstName         string    `json:"first_name"`
	LastName          string    `json:"last_name"`
	MobileNumber      string    `json:"mobile_number"`
	PreferredLanguage string    `json:"preferred_language"`
	Email             string    `json:"email"`
	Dob               time.Time `json:"dob"`
	Gender            string    `json:"gender"`
	CreatedBy         string    `json:"createdBy"  binding:"required"`
}
