package request

import (
	"collection-service/internal/enum"
	"time"
)

type CreateSpecialOffer struct {
	ClientLoanId         string                `json:"client_loan_id" binding:"required"`
	OfferType            enum.OfferType        `json:"offer_type" binding:"required"`
	WaiverType           enum.WaiverType       `json:"waiver_type" binding:"required"`
	WaiverValue          float64               `json:"waiver_value" binding:"required"`
	MinimumPaymentAmount float64               `json:"minimum_payment_amount"`
	Status               enum.OfferStatus      `json:"status"`
	StartDatetime        time.Time             `json:"start_datetime" binding:"required"`
	EndDatetime          time.Time             `json:"end_datetime" binding:"required"`
	ActivationSource     enum.ActivationSource `json:"activation_source"`
	CreatedBy            string                `json:"created_by"`
	ClientRefNumber      string                `json:"client_ref_number" binding:"required"`
}
