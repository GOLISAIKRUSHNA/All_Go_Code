package request

import "collection-service/internal/enum"

type CreateTeamReq struct {
	Object          enum.TeamObject `json:"object"`
	ObjectRefNumber string          `json:"object_ref_number"`
	Name            string          `json:"name"`
	CreatedBy       string          `json:"created_by"`
}
