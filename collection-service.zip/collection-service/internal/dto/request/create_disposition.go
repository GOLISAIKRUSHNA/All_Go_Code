package request

import (
	"collection-service/internal/enum"
)

type Disposition struct {
	AttemptRefNumber  string      `json:"attempt_ref_number"`
	Source            enum.Source `json:"source"`
	CaseRefNumber     string      `json:"case_ref_number" binding:"required"`
	CustomerRefNumber string      `json:"customer_ref_number" binding:"required"`
	AgentRefNumber    string      `json:"agent_ref_number"`
	Disposition       string      `json:"disposition"`
	Comment           string      `json:"comment"`
	FollowupDatetime  string      `json:"followup_datetime"`
	Location          Location    `json:"location"`
	SelfieFilePath    string      `json:"selfie_file_path"`
	AddressRefNumber  string      `json:"address_ref_number"`
	AgentName         string      `json:"agent_name"`
	ContactRefNumber  string      `json:"contact_ref_number"`
	PreferredLanguage string      `json:"preferred_language"`
}

type Location struct {
	Latitude  float64 `json:"latitude"`
	Longitude float64 `json:"longitude"`
}
