package request

type CallAuditCommonServiceRequest struct {
	AuditRefNumber     string               `json:"audit_ref_number"`
	AuditedBy          string               `json:"audited_by"`
	AuditedDatetime    string               `json:"audited_datetime"`
	CaseRefNumber      string               `json:"case_ref_number"`
	Template           Template             `json:"template"`
	SubmittedResponses []SubmittedResponses `json:"submitted_responses"`
}
