package request

import "collection-service/internal/enum"

type GenerateCase struct {
	CustomerRefNumber   string             `json:"customer_ref_number" binding:"required"`
	LoanRefNumber       string             `json:"loan_ref_number"`
	ClientRefNumber     string             `json:"client_ref_number"`
	Level               string             `json:"level"`
	CollectionFor       enum.CollectionFor `json:"collection_for"`
	ClientTeamRefNumber string             `json:"client_team_ref_number"`
}
