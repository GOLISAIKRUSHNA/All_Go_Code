package request

import (
	"time"
)

type CaseAttributeReq struct {
	CaseRefNumber                   string
	ClientLoanIds                   string
	LastDisposition                 string
	LastDispositionDatetime         *time.Time
	LastDispositionFollowupDate     *time.Time
	TotalCallsAttempted             int
	TotalCallsConnected             int
	TodaysCallsAttempted            int
	TodaysCallsConnected            int
	LastCallConnectedAt             *time.Time
	ContactRefNumber                string
	HavingMandateInprogressPayments bool
	HavingInprogressPayments        bool
	DispositionType                 string
}
