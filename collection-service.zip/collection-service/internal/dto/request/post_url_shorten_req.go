package request

type CreateShortUrlReq struct {
	LongURL         string `json:"long_url"`
	ClientRefNumber string `json:"client_ref_number"`
}
