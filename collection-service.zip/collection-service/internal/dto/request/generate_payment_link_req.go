package request

import (
	"collection-service/internal/enum"
)

type GeneratePaymentLinkReq struct {
	ClientRefNumber string
	Object          enum.Object
	ObjectRefNumber string
	Entity          enum.URLEntity
	EntityRefNumber string
	CaseRefNumber   string
}
