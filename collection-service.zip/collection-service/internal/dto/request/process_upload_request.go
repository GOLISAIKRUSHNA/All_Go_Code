package request

type ProcessUploadRequest struct {
	UploadRefNumber string
	Reason          string
	InputFilePath   string
	Type            string
	TypeRefNumber   string
	UploadedBy      string
}
