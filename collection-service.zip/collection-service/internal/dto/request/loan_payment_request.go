package request

type LoanPayment struct {
	ClientPaymentId         string  `json:"client_payment_id" binding:"required"`
	ClientLoanId            string  `json:"client_loan_id" binding:"required"`
	LoanRefNumber           string  `json:"loan_ref_number"`
	PaymentRefNumber        string  `json:"payment_ref_number"`
	PaymentReason           string  `json:"payment_reason"`
	PaymentGateway          string  `json:"payment_gateway" binding:"required"`
	PaymentAmount           float64 `json:"payment_amount" binding:"required" validate:"gt>0"`
	PaymentDatetime         string  `json:"payment_datetime" binding:"required"`
	AppliedTowardsPrincipal float64 `json:"applied_towards_principal"`
	AppliedTowardsInterest  float64 `json:"applied_towards_interest"`
	AppliedTowardsFees      float64 `json:"applied_towards_fees"`
	CreatedBy               string  `json:"created_by"`
	ClientRefNumber         string  `json:"client_ref_number"`
	IsWaiver                bool    `json:"is_waiver"`
}
