package request

import "collection-service/internal/enum"

type GetAttendanceReq struct {
	AgentRefNumber         string              `json:"agent_ref_number" binding:"required"`
	ApprovalStatus         string              `json:"attendance_status"`
	AttendanceRequestScope enum.HierarchyScope `json:"type"`
}
