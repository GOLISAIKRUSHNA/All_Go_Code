package request

import (
	"collection-service/internal/enum"
)

type CreateUpdateLoanRequest struct {
	CreatedBy           string `json:"created_by"  binding:"required"`
	ClientRefNumber     string `json:"client_ref_number"  binding:"required"`
	ClientTeamRefNumber string `json:"client_team_ref_number"`
	Customer            Customer
	CustomerInfo        CustomerInfo `json:"customer_info"`
	Loan                Loan
	Collaterals         []Collaterals
	Borrowers           []Borrowers
	References          []References
	Addresses           []Addresses
	Documents           []Documents
}

type Loan struct {
	ServiceProviderRefNumber    string           `json:"service_provider_ref_number"`
	ClientLoanId                string           `json:"client_loan_id" binding:"required"`
	CreditCardNo                string           `json:"credit_card_no"`
	LoanAmount                  float64          `json:"loan_amount"  binding:"required"`
	Tenure                      int              `json:"tenure"`
	TenureType                  enum.LoanTenure  `json:"tenure_type"`
	InterestRate                float64          `json:"interest_rate"`
	EmiAmount                   float64          `json:"emi_amount"`
	Product                     enum.LoanProduct `json:"product" binding:"required"`
	SubProduct                  string           `json:"sub_product"`
	ActiveFinancierName         string           `json:"active_financier_name" binding:"required"`
	SecondaryFinancierName      string           `json:"secondary_financier_name"`
	DisbursementAmount          float64          `json:"disbursement_amount"`
	DisbursementDate            string           `json:"disbursement_date"`
	DueDate                     string           `json:"due_date"`
	FirstEmiDate                string           `json:"first_emi_date"`
	LastEmiDate                 string           `json:"last_emi_date"`
	EarliestUnpaidEmiDate       string           `json:"earliest_unpaid_emi_date"`
	BillTotalPaymentDue         float64          `json:"bill_total_payment_due"`
	BillMinPaymentDue           float64          `json:"bill_min_payment_due"`
	BillStatementGenerationDate string           `json:"bill_statement_generation_date"`
	CreditLimit                 float64          `json:"credit_limit"`
	AvailableCreditLimit        float64          `json:"available_credit_limit"`
	Status                      enum.LoanStatus  `json:"status" binding:"required"`
	TotalDue                    float64          `json:"total_due" binding:"required"`
	TotalPrincipalDue           float64          `json:"total_principal_due"`
	TotalInterestDue            float64          `json:"total_interest_due"`
	TotalFeesDue                float64          `json:"total_fees_due"`
	TotalOutstanding            float64          `json:"total_outstanding"`
	TotalPrincipalOutstanding   float64          `json:"total_principal_outstanding"`
	TotalInterestOutstanding    float64          `json:"total_interest_outstanding"`
	TotalFeesOutstanding        float64          `json:"total_fees_outstanding"`
	TotalPrincipalPaid          float64          `json:"total_principal_paid"`
	TotalInterestPaid           float64          `json:"total_interest_paid"`
	TotalFeesPaid               float64          `json:"total_fees_paid"`
	NoOfEmisPaid                int              `json:"no_of_emis_paid"`
	CurrentDpd                  int              `json:"current_dpd"`
	MaxDpd                      int              `json:"max_dpd"`
	PaymentLink                 string           `json:"payment_link"`
	CreatedBy                   string           `json:"created_by"`
	UpdatedBy                   string           `json:"updated_by"`
	CollectionFor               enum.CollectionFor
	ActiveFinancierRefNumber    string
	MandateRazorpayCustomerID   string `json:"mandate_razorpay_customer_id"`
	MandateRazorpayToken        string `json:"mandate_razorpay_token"`
	BankName                    string `json:"bank_name"`
	BankAccountNo               string `json:"bank_account_no"`
}

type Customer struct {
	ClientCustomerId  string `json:"client_customer_id"  binding:"required"`
	CustomerRefNumber string `json:"customer_ref_number"`
	FirstName         string `json:"first_name"  binding:"required"`
	LastName          string `json:"last_name"`
	MobileNumber      string `json:"mobile_number" binding:"required"`
	PreferredLanguage string `json:"preferred_language"`
	Email             string `json:"email"`
	City              string `json:"city"`
	Dob               string `json:"dob"`
	Gender            string `json:"gender"  binding:"required"`
}

type CustomerInfo struct {
	EmploymentType string  `json:"employment_type"`
	EmployerName   string  `json:"employer_name"`
	MonthlyIncome  float64 `json:"monthly_income"`
	Occupation     string  `json:"occupation"`
	CibilScore     int     `json:"cibil_score"`
}

type Collaterals struct {
	Type                     string  `json:"type"`
	Value                    float64 `json:"value"`
	Description              string  `json:"description"`
	PrimaryIdentifierType    string  `json:"primary_identifier_type"`
	PrimaryIdentifier        string  `json:"primary_identifier"`
	AdditionalIdentifierType string  `json:"additional_identifier_type"`
	AdditionalIdentifier     string  `json:"additional_identifier"`
	MakeAndModel             string  `json:"make_and_model"`
}

type Borrowers struct {
	FirstName           string `json:"first_name"`
	LastName            string `json:"last_name"`
	MobileNumber        string `json:"mobile_number"`
	Type                string `json:"type"`
	RelationWithPrimary string `json:"relation_with_primary"`
}

type References struct {
	FirstName     string `json:"first_name"`
	LastName      string `json:"last_name"`
	ContactNumber int    `json:"contact_number"`
	Relation      string `json:"relation"`
}

type Addresses struct {
	Label        enum.AddressLabel   `json:"label"`
	Type         enum.AddressType    `json:"type"`
	ResidentType string              `json:"resident_type"`
	Source       enum.AddressSource  `json:"source"`
	Medium       enum.AddressMedium  `json:"address_medium"`
	Quality      enum.AddressQuality `json:"address_quality"`
	Line1        string              `json:"line_1"`
	Line2        string              `json:"line_2"`
	Line3        string              `json:"line_3"`
	Landmark     string              `json:"landmark"`
	Pincode      int                 `json:"pincode"`
	City         string              `json:"city"`
	State        string              `json:"state"`
	Country      string              `json:"country"`
	Lat          float64             `json:"lat"`
	Long         float64             `json:"long"`
	CreatedBy    string              `json:"created_by"`
}

type Documents struct {
	Photo        string `json:"photo" binding:"required"`
	Base64Encode string `json:"base64_encode"  binding:"required"`
}
