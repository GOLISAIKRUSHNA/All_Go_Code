package request

type AuditAgentAllocate struct {
	AuditRefNumbers     []string `json:"audit_ref_numbers"`
	AuditAgentRefNumber string   `json:"audit_agent_ref_number"`
}
