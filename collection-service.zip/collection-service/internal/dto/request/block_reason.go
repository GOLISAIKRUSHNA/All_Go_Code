package request

type CaseBlockReason struct {
	ID              int    `json:"id"`
	Reason          string `json:"reason"`
	BlockSource     string `json:"source`
	BlockSourceList []string
}
