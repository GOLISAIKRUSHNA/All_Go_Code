package request

type AllocateTicket struct {
	TicketRefNumber string `json:"ticket_ref_number"`
	CaseRefNumber   string `json:"case_ref_number"`
	AgentRefNumber  string `json:"agent_ref_number"`
	Status          string `json:"status"`
	AllocatedBy     string `json:"allocated_by"`
}
