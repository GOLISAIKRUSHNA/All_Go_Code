package request

type HomePageRequest struct {
	AgentRefNumber string `json:"agent_ref_number"`
}
