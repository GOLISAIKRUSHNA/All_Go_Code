package request

type Config struct {
	ConfigName string `json:"config_name"`
}
