package request

type SearchCaseReq struct {
	Query           string `json:"query"`
	ClientRefNumber string `json:"client_ref_number"`
}
