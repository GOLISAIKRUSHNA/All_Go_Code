package request

type AutoSuggestParams struct {
	Name                     string
	ServiceProviderRefNumber string
	TeamRefNumber            string
}
