package request

type TicketListFilter struct {
	SortByBlockedDate    string
	SortByTotalDueAmount string
	IsIssueFilled        bool
	IsSubIssueFilled     bool
	BlockedReason        []int
	BlockedSource        []string
	PageNo               int
	IssueIds             []int
	SubIssueIds          []int
	Default              bool
}
