package request

import "collection-service/internal/enum"

type UpdateAgentReq struct {
	FirstName                 string               `json:"first_name"`
	LastName                  string               `json:"last_name"`
	Username                  string               `json:"username"`
	LanguagesSupported        []string             `json:"languages_supported"`
	PhotoBase64String         string               `json:"photo_base64_string"`
	MobileNumber              string               `json:"mobile_number"`
	Email                     string               `json:"email"`
	ReportingManagerRefNumber string               `json:"reporting_manager_ref_number"`
	Designation               string               `json:"designation"`
	CashCollectionLimit       float64              `json:"cash_collection_limit"`
	CashDepositByDays         int                  `json:"cash_deposit_by_days"`
	AgentRole                 enum.AgentRole       `json:"agent_role"`
	AgentVisibility           enum.AgentVisibility `json:"agent_visibility"`
	Status                    enum.Status          `json:"status"`
}
