package dto

type ApplyPayment struct {
	ClientPaymentId         string  `json:"client_payment_id"`
	LoanRefNumber           string  `json:"loan_ref_number"`
	PaymentAmount           float64 `json:"payment_amount"`
	AppliedTowardsPrincipal float64 `json:"applied_towards_principal"`
	AppliedTowardsInterest  float64 `json:"applied_towards_interest"`
	AppliedTowardsFees      float64 `json:"applied_towards_fees"`
	TotalDue                float64 // adding this for future value change
	ClientRefNumber         string  `json:"client_ref_number"`
	IsSpecificApply         bool    `json:"is_specific_apply"`
}
