package dto

type RequestDetails struct {
	Field   string `json:"field,omitempty"`
	Message string `json:"message,omitempty"`
}

type RequestError struct {
	Code    string           `json:"code"`
	Message string           `json:"message"`
	Details []RequestDetails `json:"details"`
}

type SuccessResponse struct {
	TraceId string      `json:"trace_id,omitempty"`
	Data    interface{} `json:"data,omitempty"`
}

type NotFoundResponse struct {
	TraceId string       `json:"trace_id,omitempty"`
	Error   RequestError `json:"error,omitempty"`
}

type BadRequestResponse struct {
	TraceId string       `json:"trace_id,omitempty"`
	Error   RequestError `json:"error,omitempty"`
}

type ServerErrorResponse struct {
	TraceId string       `json:"trace_id,omitempty"`
	Error   RequestError `json:"error,omitempty"`
}
