package dto

import "time"

type CaseResponse struct {
	FirstName                       string    `json:"first_name"`
	LastName                        string    `json:"last_name"`
	Email                           string    `json:"email"`
	Gender                          string    `json:"gender"`
	Dob                             time.Time `json:"dob"`
	MobileNumber                    string    `json:"mobile_number"`
	ClientCustomerId                string    `json:"client_customer_id"`
	PreferredLanguage               string    `json:"preferred_language"`
	CaseRefNumber                   string    `json:"case_ref_number"`
	CustomerRefNumber               string    `json:"customer_ref_number"`
	LoanRefNumber                   string    `json:"loan_ref_number"`
	ClientRefNumber                 string    `json:"client_ref_number"`
	ServiceProviderRefNumber        string    `json:"service_provider_ref_number"`
	CaseType                        string    `json:"case_type"`
	TotalDue                        float64   `json:"total_due"`
	TotalPrincipalDue               float64   `json:"total_principal_due"`
	TotalInterestDue                float64   `json:"total_interest_due"`
	TotalFeesDue                    float64   `json:"total_fees_due"`
	NoOfLoansDue                    string    `json:"no_of_loans_due"`
	NoOfEmisDue                     string    `json:"no_of_emis_due"`
	TotalOutstanding                float64   `json:"total_outstanding"`
	TotalPrincipalOutstanding       float64   `json:"total_principal_outstanding"`
	TotalInterestOutstanding        float64   `json:"total_interest_outstanding"`
	TotalPrincipalPaid              float64   `json:"total_principal_paid"`
	TotalInterestPaid               float64   `json:"total_interest_paid"`
	TotalFeesPaid                   float64   `json:"total_fees_paid"`
	NoOfEmisPaid                    int       `json:"no_of_emis_paid"`
	CurrentDpd                      int       `json:"current_dpd"`
	Bucket                          string    `json:"bucket"`
	MaxDpd                          int       `json:"max_dpd"`
	Status                          string    `json:"status"`
	CollectionFor                   string    `json:"collection_for"`
	IsFreezed                       bool      `json:"is_freezed"`
	LastDisposition                 string    `json:"last_disposition"`
	LastDispositionDatetime         string    `json:"last_position_datetime"`
	LastDispositionFollowupDate     string    `json:"last_disposition_followup_date"`
	TotalCallsAttempted             int       `json:"total_calls_attempted"`
	TotalCallsConnected             int       `json:"total_calls_connected"`
	TodaysCallsAttempted            int       `json:"todays_calls_attempted"`
	LastCallConnectedAt             string    `json:"last_call_connected_at"`
	ContactRefNumber                string    `json:"contact_ref_number"`
	ClientLoanIds                   string    `json:"client_loan_ids"`
	LogoUrl                         string    `json:"logo_url"`
	CallsLeft                       int       `json:"calls_left"`
	AddressRefNumber                string    `json:"address_ref_number"`
	IsPrimary                       int       `json:"is_primary"`
	Label                           string    `json:"label"`
	AddressSource                   string    `json:"address_source"`
	AddressType                     string    `json:"address_type"`
	Line1                           string    `json:"line1"`
	Line2                           string    `json:"line2"`
	Line3                           string    `json:"line3"`
	Landmark                        string    `json:"landmark"`
	Pincode                         int       `json:"pincode"`
	Lat                             float64   `json:"lat"`
	Long                            float64   `json:"long"`
	HavingMandateInprogressPayments bool      `json:"having_mandate_inprogress_payments"`
	HavingInprogressPayments        bool      `json:"having_inprogress_payments"`
	AllocatedTo                     string    `json:"allocated_to"`
	AllocatedToFirstName            string    `json:"allocated_to_first_name"`
	AllocatedToLastName             string    `json:"allocated_to_last_name"`
	Product                         string    `json:"product"`
}
