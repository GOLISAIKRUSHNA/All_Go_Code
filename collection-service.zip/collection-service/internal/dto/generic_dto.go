package dto

// Define a generic struct for validation
type GenericStruct struct {
	Data interface{} `validate:"required"`
}
