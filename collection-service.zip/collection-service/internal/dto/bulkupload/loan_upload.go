package bulkupload

import (
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"errors"
	"math"
	"strconv"
	"strings"
)

type LoanUpload struct {
	ClientLoanId              string  `xlsx:"column1"`
	ClientCustomerId          string  `xlsx:"column2"`
	LoanAmount                float64 `xlsx:"column3"`
	Tenure                    int     `xlsx:"column4"`
	TenureType                string  `xlsx:"column5"`
	InterestRate              float64 `xlsx:"column6"`
	EmiAmount                 float64 `xlsx:"column7"`
	Product                   string  `xlsx:"column8"`
	SubProduct                string  `xlsx:"column9"`
	DisbursementDate          string  `xlsx:"column10"`
	DisbursementAmount        float64 `xlsx:"column11"`
	DueDate                   string  `xlsx:"column12"`
	FirstEmiDate              string  `xlsx:"column13" validate:"required"`
	LastEmiDate               string  `xlsx:"column14"`
	EarliestUnpaidEmiDate     string  `xlsx:"column15"`
	TotalDue                  float64 `xlsx:"column16" validate:"required"`
	TotalPrincipalDue         float64 `xlsx:"column17" validate:"required"`
	TotalInterestDue          float64 `xlsx:"column18" validate:"required"`
	TotalFeesDue              float64 `xlsx:"column19" validate:"required"`
	TotalOutstanding          float64 `xlsx:"column20"`
	TotalPrincipalOutstanding float64 `xlsx:"column21"`
	TotalInterestOutstanding  float64 `xlsx:"column22"`
	TotalFeesOutstanding      float64 `xlsx:"column23"`
	TotalPrincipalPaid        float64 `xlsx:"column24"`
	TotalInterestPaid         float64 `xlsx:"column25"`
	TotalFeesPaid             float64 `xlsx:"column26"`
	NoOfEmisPaid              int     `xlsx:"column27"`
	CurrentDpd                int     `xlsx:"column28"`
	MaxDpd                    int     `xlsx:"column29"`
	ActiveFinancierRefNumber  string  `xlsx:"column30"`
	MandateRazorpayCustomerID string  `xlsx:"column31"`
	MandateRazorpayToken      string  `xlsx:"column32"`
	BankName                  string  `xlsx:"column33"`
	BankAccountNo             string  `xlsx:"column34"`
	PaymentLink               string  `xlsx:"column35"`
	ClientTeamRefNumber       string  `xlsx:"column36"`
}

type ConsolodatedLoanUpload struct {
	ClientLoanId              string  `xlsx:"column1" validate:"required"`
	LoanAmount                float64 `xlsx:"column2" validate:"required,gt=0"`
	Tenure                    int     `xlsx:"column3" validate:"required,gt=0"`
	TenureType                string  `xlsx:"column4"`
	InterestRate              float64 `xlsx:"column5" validate:"required,gt=0"`
	EmiAmount                 float64 `xlsx:"column6"`
	Product                   string  `xlsx:"column7"`
	SubProduct                string  `xlsx:"column8"`
	DisbursementDate          string  `xlsx:"column9"`
	DisbursementAmount        float64 `xlsx:"column10"`
	DueDate                   string  `xlsx:"column11"`
	FirstEmiDate              string  `xlsx:"column12"`
	LastEmiDate               string  `xlsx:"column13"`
	EarliestUnpaidEmiDate     string  `xlsx:"column14"`
	TotalDue                  float64 `xlsx:"column15" validate:"required,gt=0"`
	TotalPrincipalDue         float64 `xlsx:"column16" validate:"required,gt=0"`
	TotalInterestDue          float64 `xlsx:"column17" validate:"required,gt=0"`
	TotalFeesDue              float64 `xlsx:"column18" validate:"required,gt=0"`
	CurrentDpd                int     `xlsx:"column19"`
	AssetClassification       string  `xlsx:"column20"`
	ClientCustomerId          string  `xlsx:"column21"`
	FirstName                 string  `xlsx:"column22"`
	LastName                  string  `xlsx:"column23"`
	MobileNumber              string  `xlsx:"column24" validate:"required,len=10"`
	Email                     string  `xlsx:"column25" validate:"required,email"`
	Dob                       string  `xlsx:"column26"`
	Gender                    string  `xlsx:"column27"`
	PreferredLanguage         string  `xlsx:"column28"`
	Label                     string  `xlsx:"column29"`
	Source                    string  `xlsx:"column30"`
	Line1                     string  `xlsx:"column31" validate:"lte=100,omitempty"`
	Line2                     string  `xlsx:"column32" validate:"lte=100,omitempty"`
	Line3                     string  `xlsx:"column33" validate:"lte=100,omitempty"`
	Landmark                  string  `xlsx:"column34"  validate:"lte=50,omitempty"`
	Pincode                   int     `xlsx:"column35"`
	City                      string  `xlsx:"column36"`
	State                     string  `xlsx:"column37"`
	ActiveFinancier           string  `xlsx:"column38"`
	MandateRazorpayCustomerID string  `xlsx:"column39"`
	MandateRazorpayToken      string  `xlsx:"column40"`
	BankName                  string  `xlsx:"column41"`
	BankAccountNo             string  `xlsx:"column42"`
	PaymentLink               string  `xlsx:"column43"`
	ClientTeamRefNumber       string  `xlsx:"column44"`
}

type CreditCardLoanUpload struct {
	CreditCardNo                string  `xlsx:"column1"`
	ClientLoanId                string  `xlsx:"column2"`
	InterestRate                float64 `xlsx:"column3"`
	Status                      string  `xlsx:"column4"`
	Product                     string  `xlsx:"column5"`
	SubProduct                  string  `xlsx:"column6"`
	BillStatementGenerationDate string  `xlsx:"column7"`
	BillTotalPaymentDue         float64 `xlsx:"column8"` // billed amount
	UnBilledAmount              float64 `xlsx:"column9"` //unbilled amount
	DueDate                     string  `xlsx:"column10"`
	TotalDue                    float64 `xlsx:"column11"`
	TotalInterestDue            float64 `xlsx:"column12"`
	TotalFeesDue                float64 `xlsx:"column13"`
	BillMinPaymentDue           float64 `xlsx:"column14"`
	CurrentDpd                  int     `xlsx:"column15"`
	ClientCustomerId            string  `xlsx:"column16"`
	FirstName                   string  `xlsx:"column17"`
	LastName                    string  `xlsx:"column18"`
	MobileNumber                string  `xlsx:"column19"`
	Email                       string  `xlsx:"column20"`
	Dob                         string  `xlsx:"column21"`
	Gender                      string  `xlsx:"column22"`
	PreferredLanguage           string  `xlsx:"column23"`
	Address                     string  `xlsx:"column24"`
	Landmark                    string  `xlsx:"column25"`
	Pincode                     int     `xlsx:"column26"`
	City                        string  `xlsx:"column27"`
	State                       string  `xlsx:"column28"`
	ActiveFinancier             string  `xlsx:"column29"`
	ClientTeamRefNumber         string  `xlsx:"column30"`
}

// Validate strcuts

func (l *ConsolodatedLoanUpload) ConsolidateValidate(clientConfig dto.AppConfig) error {
	var errorString string
	if len(l.ClientLoanId) < 3 {
		errorString += "invalid client loan id, "
	}
	if !isFloat(l.LoanAmount) || l.LoanAmount <= 0 {
		errorString += "invalid loan amount "
	}
	if !isInt(l.Tenure) || l.Tenure <= 0 {
		errorString += "tenure must be a greater than 0, "
	}
	tenureType, _ := enum.StringToTenureTypeEnum(l.TenureType)
	if tenureType == enum.LoanTenure(0) {
		errorString += "invalid tenure type, "
	}
	if !isFloat(l.InterestRate) || l.InterestRate < 0 {
		errorString += "interest rate must be greater than 0, "
	}
	if !isFloat(l.EmiAmount) || l.EmiAmount <= 0 {
		errorString += "emi amount must be greater than 0, "
	}
	_, productErr := enum.StringToLoanProductEnum(l.Product)
	if productErr != nil {
		errorString += "invalid product type, "
	}
	if utils.IsNotEmpty(l.DisbursementDate) && !utils.IsValidYmdDateFormat(l.DisbursementDate) {
		errorString += "invalid disbursement Date date or date  must be in valid format yyyy-mm-dd, "
	}
	if !isFloat(l.DisbursementAmount) && l.DisbursementAmount <= 0 {
		errorString += "disbursement amount must be greater than 0, "
	}
	if utils.IsEmpty(l.DueDate) || (utils.IsNotEmpty(l.DueDate) && !utils.IsValidYmdDateFormat(l.DueDate)) {
		errorString += "Invalid due date or due date must be in valid format yyyy-mm-dd,  "
	}
	if utils.IsEmpty(l.FirstEmiDate) || !utils.IsValidYmdDateFormat(l.FirstEmiDate) {
		errorString += "invalid first emi date Date date or date  must be in valid format yyyy-mm-dd, "
	}
	if utils.IsNotEmpty(l.LastEmiDate) && !utils.IsValidYmdDateFormat(l.LastEmiDate) {
		errorString += "invalid last emi date Date date or date  must be in valid format yyyy-mm-dd, "
	}
	if (l.CurrentDpd <= 0 && l.EarliestUnpaidEmiDate == "") || (utils.IsNotEmpty(l.EarliestUnpaidEmiDate) && !utils.IsValidYmdDateFormat(l.EarliestUnpaidEmiDate)) {
		errorString += "current dpd or earliest unpaid emi date must be valid & present or must be valid format yyyy-mm-dd, "
	}
	if !isFloat(l.TotalDue) || !isFloat(l.TotalPrincipalDue) || !isFloat(l.TotalInterestDue) || !isFloat(l.TotalFeesDue) {
		errorString += "total due, total principal due, total interest due must be greater than 0, "
	}
	if utils.IsEmpty(l.ClientCustomerId) || len(l.ClientCustomerId) < 3 {
		errorString += "invalid client customer id, "
	}
	if len(l.FirstName) <= 3 || !utils.ContainsOnlyChars(l.FirstName) {
		errorString += "invalid first name, "
	}
	if utils.IsEmpty(l.MobileNumber) || !utils.IsValidMobileNumber(l.MobileNumber) {
		errorString += "invalid mobile number, "
	}
	if !utils.ContainsOnlyChars(l.PreferredLanguage) {
		errorString += "invalid, add languages in comma seperated string without spaces, "
	}
	if utils.IsEmpty(l.ActiveFinancier) {
		errorString += "invalid financier, "
	}
	if utils.IsEmpty(l.Dob) {
		errorString += "DOB: " + l.Dob + " is Empty, "
	}
	if !utils.IsValidYmdDateFormat(l.Dob) {
		errorString += "DOB: " + l.Dob + " must be in valid format yyyy-mm-dd, "
	}
	if utils.IsValidFutureDate(l.Dob) {
		errorString += "DOB: " + l.Dob + " Cant be a future date, "
	}
	if utils.IsEmpty(l.Email) || !utils.IsValidEmail(l.Email) {
		errorString += "invalid email, "
	}
	addressErr := utils.ValidateAddress(request.CreateAddressRequest{Line1: l.Line1, Line2: l.Line2, Line3: l.Line3, Source: enum.StringToAddressSource(l.Source), Label: enum.StringToAddressLabel(l.Label), Country: "India"})
	if addressErr != nil {
		errorString += addressErr.Error()
	}
	if !utils.IsValidPincode(strconv.Itoa(l.Pincode)) {
		errorString += "invalid pincode, "
	}
	if clientConfig.PaymentConfig.NachEnabled {
		if utils.IsEmpty(l.BankName) || utils.IsEmpty(l.BankAccountNo) || utils.IsEmpty(l.MandateRazorpayCustomerID) || utils.IsEmpty(l.MandateRazorpayToken) {
			errorString += "bank name, bank account no, mandate customer id, mandate razorpay token are mandatory when nach enabled, "
		}
	}
	if clientConfig.PaymentConfig.PaymentConfigType == "non_native" && clientConfig.PaymentConfig.PaymentNonNative.CustomPaymentLink {
		errorString += "payment link is mandatory, "
	}
	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}

func (l *CreditCardLoanUpload) CreditValidate() error {
	var errorString string

	if utils.IsEmpty(l.DueDate) || (utils.IsNotEmpty(l.DueDate) && !utils.IsValidYmdDateFormat(l.DueDate)) {
		errorString += "Invalid due date or due date must be in valid format yyyy-mm-dd,  "
	}
	if !isFloat(l.InterestRate) || l.InterestRate <= 0 {
		errorString += "interest rate must be greater than 0, "
	}
	//customer validation
	if utils.IsNotEmpty(l.MobileNumber) && !utils.IsValidMobileNumber(l.MobileNumber) {
		errorString += "invalid mobile number, "
	}
	if len(l.FirstName) <= 3 || !utils.ContainsOnlyChars(l.FirstName) {
		errorString += "invalid first name, "
	}
	if len(l.LastName) <= 3 || !utils.ContainsOnlyChars(l.LastName) {
		errorString += "invalid last name, "
	}
	if utils.IsNotEmpty(l.Dob) || !utils.IsValidYmdDateFormat(l.Dob) || utils.IsValidFutureDate(l.Dob) {
		errorString += "invalid date of birth or date must be in valid format yyyy-mm-dd, "
	}
	if !utils.ContainsOnlyChars(l.PreferredLanguage) || !utils.ValidateLanguages(l.PreferredLanguage) {
		errorString += "invalid, add languages in comma seperated string without spaces, "
	}
	if len(l.Address) > 100 {
		errorString += "address length must be less than 100, "
	}
	if len(l.Landmark) > 50 {
		errorString += "landmark length should be less than 50 ,"
	}
	if utils.IsEmpty(l.ActiveFinancier) {
		errorString += "invalid financier, "
	}
	if utils.IsNotEmpty(l.Email) && !utils.IsValidEmail(l.Email) {
		errorString += "invalid email "
	}

	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}

func (l *LoanUpload) LoanValidate(clientConfig dto.AppConfig) error {
	var errorString string
	if len(l.ClientLoanId) < 3 {
		errorString += "invalid client loan id, "
	}
	if !isFloat(l.LoanAmount) || l.LoanAmount <= 0 {
		errorString += "invalid loan amount "
	}
	if !isInt(l.Tenure) || l.Tenure <= 0 {
		errorString += "tenure must be a greater than 0, "
	}
	_, tenureTypeErr := enum.StringToTenureTypeEnum(l.TenureType)
	if tenureTypeErr != nil {
		errorString += "invalid tenure type, "
	}
	if utils.IsEmpty(l.DueDate) || (utils.IsNotEmpty(l.DueDate) && !utils.IsValidYmdDateFormat(l.DueDate)) {
		errorString += "Invalid due date or due date must be in valid format yyyy-mm-dd,  "
	}
	_, productErr := enum.StringToLoanProductEnum(l.Product)
	if productErr != nil {
		errorString += "invalid product type, "
	}
	if !isFloat(l.InterestRate) || l.InterestRate <= 0 {
		errorString += "interest rate must be greater than 0, "
	}
	if (l.CurrentDpd <= 0 && l.EarliestUnpaidEmiDate == "") || (utils.IsNotEmpty(l.EarliestUnpaidEmiDate) && !utils.IsValidYmdDateFormat(l.EarliestUnpaidEmiDate)) {
		errorString += "current dpd or earliest unpaid emi date must be valid & present or must be valid format yyyy-mm-dd, "
	}
	if !isFloat(l.TotalDue) || !isFloat(l.TotalPrincipalDue) || !isFloat(l.TotalInterestDue) || !isFloat(l.TotalFeesDue) {
		errorString += "total due, total principal due, total interest due must be greater than 0, "
	}
	if utils.IsEmpty(l.ActiveFinancierRefNumber) {
		errorString += "invalid financier, "
	}
	if utils.IsNotEmpty(l.DisbursementDate) && !utils.IsValidYmdDateFormat(l.DisbursementDate) {
		errorString += "invalid disbursement Date date or date  must be in valid format yyyy-mm-dd, "
	}
	if !isFloat(l.DisbursementAmount) && l.DisbursementAmount <= 0 {
		errorString += "disbursement amount must be greater than 0, "
	}
	if utils.IsEmpty(l.FirstEmiDate) || !utils.IsValidYmdDateFormat(l.FirstEmiDate) {
		errorString += "invalid first emi date Date date or date  must be in valid format yyyy-mm-dd, "
	}
	if utils.IsNotEmpty(l.LastEmiDate) && !utils.IsValidYmdDateFormat(l.LastEmiDate) {
		errorString += "invalid last emi date Date date or date  must be in valid format yyyy-mm-dd, "
	}
	if clientConfig.PaymentConfig.NachEnabled {
		if utils.IsEmpty(l.BankName) || utils.IsEmpty(l.BankAccountNo) || utils.IsEmpty(l.MandateRazorpayCustomerID) || utils.IsEmpty(l.MandateRazorpayToken) {
			errorString += "bank name, bank account no, mandate customer id, mandate razorpay token are mandatory when nach enabled, "
		}
	}
	if clientConfig.PaymentConfig.PaymentConfigType == "non_native" && clientConfig.PaymentConfig.PaymentNonNative.CustomPaymentLink {
		errorString += "payment link is mandatory, "
	}
	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}

func isFloat(value interface{}) bool {
	switch v := value.(type) {
	case float32:
		return !math.IsNaN(float64(v))
	case float64:
		return !math.IsNaN(v)
	default:
		return false
	}
}

func isInt(value int) bool {
	return value == int(value)
}
