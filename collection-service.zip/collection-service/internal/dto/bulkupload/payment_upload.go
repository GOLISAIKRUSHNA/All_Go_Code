package bulkupload

import (
	"collection-service/internal/utils"
	"errors"
	"strings"
)

type PaymentUpload struct {
	ClientLoanId       string  `xlsx:"column1" validate:"required"`
	PaymentId          string  `xlsx:"column2" validate:"required"`
	PaymentReceiptDate string  `xlsx:"column3"  validate:"required,datetime=2006-01-02"`
	PaymentReceiptMode string  `xlsx:"column4" validate:"required"`
	PaymentAmount      float64 `xlsx:"column5" validate:"required"`
}

func (p *PaymentUpload) PaymentUploadValidate() error {
	var errorString string
	if len(p.ClientLoanId) < 3 || len(p.ClientLoanId) > 50 {
		errorString += "Mandatory or invalid client loan id, "
	}
	if len(p.PaymentId) < 3 || len(p.PaymentId) > 50 {
		errorString += "Mandatory field and length cannot be greater than 50, "
	}
	if utils.IsEmpty(p.PaymentReceiptDate) || !utils.IsValidYmdAndYmdHMSDateFormat(p.PaymentReceiptDate) || utils.IsValidFutureDate(p.PaymentReceiptDate) {
		errorString += "required or invalid payment receipt date or date  must be in valid format yyyy-mm-dd, "
	}
	if !isFloat(p.PaymentAmount) || p.PaymentAmount <= 0 {
		errorString += "Mandatory & TOTAL PAYMENT AMOUNT cannot be 0, "
	}
	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}
