package bulkupload

import (
	"collection-service/internal/enum"
	"errors"
	"strings"
)

type AgentAllocationUpload struct {
	CaseRefNumber  string `xlsx:"column1"`
	AgentRefNumber string `xlsx:"column2"`
}

type ServiceProviderAllocationUpload struct {
	ClientLoanId             string `xlsx:"column1"`
	Intervention             string `xlsx:"column2"`
	ServiceProviderRefNumber string `xlsx:"column3"`
}

type CaseDeallocationUpload struct {
	ClientLoanId             string `xlsx:"column1"`
	Intervention             string `xlsx:"column2"`
	ServiceProviderRefNumber string `xlsx:"column3"`
}
type AgentCaseDeallocationUpload struct {
	CaseRefNumber  string `xlsx:"column1"`
	AgentRefNumber string `xlsx:"column2"`
}

func (a *ServiceProviderAllocationUpload) SpLoanAllocationValidate() error {
	var errorString string
	if len(a.ClientLoanId) < 3 || len(a.ClientLoanId) > 50 {
		errorString += "required or invalid client loan id, "
	}
	if len(a.Intervention) < 3 || len(a.Intervention) > 10 {
		errorString += "required or invalid intervention, length should be in 3 to 10, "
	}
	_, err := enum.StringToInterventionEnum(a.Intervention)
	if err != nil {
		errorString += "invalid intervention, it should be either FIELD or CALLING, "
	}
	/*if len(a.ServiceProviderRefNumber) < 3 || len(a.ServiceProviderRefNumber) > 50 {
		errorString += "required or invalid service provider ref number, "
	}*/

	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}

func (a *AgentAllocationUpload) AgentLoanAllocationValidate() error {
	var errorString string
	if len(a.CaseRefNumber) < 3 || len(a.CaseRefNumber) > 20 {
		errorString += "required or invalid client loan id, "
	}
	if len(a.AgentRefNumber) < 3 || len(a.AgentRefNumber) > 50 {
		errorString += "required or invalid agent ref number, "
	}

	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}

func (a *AgentCaseDeallocationUpload) AgentCaseDeallocationValidate() error {
	var errorString string
	if len(a.CaseRefNumber) < 3 || len(a.CaseRefNumber) > 20 {
		errorString += "required or invalid client loan id, length should be in 3 to 20, "
	}
	if len(a.AgentRefNumber) < 3 || len(a.AgentRefNumber) > 20 {
		errorString += "required or invalid agent ref number, length should be in 3 to 20, "
	}

	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}
