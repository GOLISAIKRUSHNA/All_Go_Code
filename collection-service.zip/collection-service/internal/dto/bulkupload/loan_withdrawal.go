package bulkupload

import (
	"errors"
	"strings"
)

type LoanWithdrawal struct {
	ClientLoanId string
	Reason       string
	OtherReason  string
}

func (l *LoanWithdrawal) LoanWithdrawalValidate() error {
	var errorString string
	if len(l.ClientLoanId) < 3 || len(l.ClientLoanId) > 50 {
		errorString += "mandatory or invalid client loan id, "
	}
	if len(l.Reason) < 3 || len(l.Reason) > 150 {
		errorString += "Withdraw Reason is invalid "
	}

	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}
