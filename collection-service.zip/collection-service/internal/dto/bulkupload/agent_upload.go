package bulkupload

import (
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"errors"
	"strings"
)

type AgentUpload struct {
	ServiceProviderRefNumber  string  `xlsx:"column1" `
	FirstName                 string  `xlsx:"column2"`
	LastName                  string  `xlsx:"column3"`
	MobileNumber              string  `xlsx:"column4"`
	Email                     string  `xlsx:"column5"`
	Username                  string  `xlsx:"column6"`
	Password                  string  `xlsx:"column7"`
	CashCollectionLimit       float64 `xlsx:"column8"`
	CashDepositByDays         int     `xlsx:"column9"`
	ReportingManagerRefNumber string  `xlsx:"column10"`
	LanguagesSupported        string  `xlsx:"column11"`
	Designation               string  `xlsx:"column12"`
	Role                      string  `xlsx:"column13"`
	Visibility                string  `xlsx:"column14"`
}

func (a *AgentUpload) Validate() error {
	var errorString string
	if len(a.ServiceProviderRefNumber) < 3 || len(a.ServiceProviderRefNumber) > 20 {
		errorString += "required or invalid service provider ref number, "
	}
	if len(a.FirstName) < 3 || len(a.FirstName) > 50 || !utils.ContainsOnlyChars(a.FirstName) {
		errorString += "required or invalid first name, "
	}
	if len(a.LastName) < 3 || len(a.LastName) > 50 || !utils.ContainsOnlyChars(a.LastName) {
		errorString += "required or invalid last name, "
	}
	if len(a.MobileNumber) < 3 || len(a.MobileNumber) > 10 || !utils.IsValidMobileNumber(a.MobileNumber) {
		errorString += "required or invalid mobile number, "
	}
	if len(a.Email) < 3 || len(a.Email) > 50 || !utils.IsValidEmail(a.Email) {
		errorString += "required or invalid email, "
	}
	if utils.IsEmpty(a.Password) || !utils.IsValidPassword(a.Password) {
		errorString += "required or invalid password ,Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character AND should be at least 8 characters long "
	}
	if utils.IsEmpty(a.Designation) && len(a.Designation) > 50 {
		errorString += "designation required or invalid designation length, "
	}
	if len(a.ReportingManagerRefNumber) < 3 || len(a.ReportingManagerRefNumber) > 20 {
		errorString += "required or invalid reporting manager ref number, length should be between 3 to 20, "
	}
	if len(a.LanguagesSupported) < 3 || !utils.ValidateLanguages(a.LanguagesSupported) {
		errorString += "required or invalid languages supported, "
	}
	if utils.IsEmpty(a.Role) || a.Role != enum.StringToAgentRole(a.Role).String() {
		errorString += "required or invalid role, "
	}
	if utils.IsEmpty(a.Visibility) || a.Visibility != enum.StringToAgentVisibility(a.Visibility).String() {
		errorString += "required or invalid Visibility, "
	}
	agentRole := enum.StringToAgentRole(a.Role)
	if agentRole == enum.AGENT_ROLE_FIELD_AGENT || agentRole == enum.AGENT_ROLE_FIELD_TL || agentRole == enum.AGENT_ROLE_FIELD_MANAGER {
		// Validate CashCollectionLimit
		if a.CashCollectionLimit < 0 || !utils.IsFloat(a.CashCollectionLimit) {
			errorString += "Cash collection limit required or must be in float, "
		}
		if a.CashDepositByDays < 0 || !utils.IsInt(a.CashDepositByDays) {
			errorString += "Cash deposit by days required or must be in int, "
		}
	}

	// validate agent role enum
	/*agentRole := enum.StringToAgentRole(a.Role)
	if agentRole == enum.AgentRole(0) && a.Role != "" {
		errorString += "invalid agent role, "
	}

	// validate agent visibility enum
	agentVisibility := enum.StringToAgentVisibility(a.Visibility)
	if agentVisibility == enum.AgentVisibility(0) && a.Visibility != "" {
		errorString += "invalid agent visibility "
	}*/

	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}
