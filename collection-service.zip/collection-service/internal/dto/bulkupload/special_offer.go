package bulkupload

import (
	"collection-service/internal/enum"
	"collection-service/internal/utils"
	"errors"
	"strings"
)

type SpecialOffer struct {
	ClientLoanId         string  `xlsx:"column1" validate:"required"`
	OfferType            string  `xlsx:"column2" validate:"required"`
	WaiverType           string  `xlsx:"column3" validate:"required"`
	WaiverValue          float64 `xlsx:"column4" validate:"required"`
	MinimumPaymentAmount float64 `xlsx:"column5"`
	Status               string  `xlsx:"column6"`
	StartDateTime        string  `xlsx:"column7"`
	EndDateTime          string  `xlsx:"column8"`
}

func (l *SpecialOffer) SpecialOfferValidate() error {
	var errorString string
	if len(l.ClientLoanId) <= 3 || len(l.ClientLoanId) > 50 {
		errorString += "invalid client loan id"
	}
	if enum.StringToOfferType(l.OfferType) == enum.OfferType(0) {
		errorString += "invalid offer type, "
	}

	if enum.StringToWaiverType(l.WaiverType) == enum.WaiverType(0) {
		errorString += "invalid waiver type, "
	}

	if (!isFloat(l.WaiverValue) || l.WaiverValue < 0) ||
		(enum.StringToWaiverType(l.WaiverType) == enum.PERCENTAGE && (l.WaiverValue <= 0 || l.WaiverValue > 100)) {
		errorString += "invalid waiver value, "
	}

	if enum.StringToOfferStatus(l.Status) == enum.OfferStatus(0) {
		errorString += "invalid offer status, "
	}

	if !isFloat(l.MinimumPaymentAmount) || l.MinimumPaymentAmount < 0 {
		errorString += "invalid minimum payment amount, "
	}
	if utils.IsEmpty(l.StartDateTime) || !utils.IsValidYmdHMSDateFormat(l.StartDateTime) {
		errorString += "invalid start date or must be in valid date format yyyy-mm-dd hh:mm:ss, "
	}

	if utils.IsEmpty(l.EndDateTime) || !utils.IsValidYmdHMSDateFormat(l.EndDateTime) {
		errorString += "invalid end date or must be in valid date format yyyy-mm-dd, "
	}

	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}
