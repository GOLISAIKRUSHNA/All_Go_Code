package bulkupload

import (
	"collection-service/internal/utils"
	"errors"
	"strings"
)

type BlockCaseUpload struct {
	ClientLoanId string `xlsx:"column1"`
	BlockType    string `xlsx:"column2"`
	BlockedUntil string `xlsx:"column3" `
	Reason       string `xlsx:"column4" `
}

func (c *BlockCaseUpload) CaseBlockValidate() error {
	var errorString string
	if utils.IsEmpty(c.BlockType) || (c.BlockType != "REFER_TO_CSAT" && c.BlockType != "LIMITED_PERIOD_BLOCK") {
		errorString += "block type is required or invalid block type "
	}
	if c.BlockType == "LIMITED_PERIOD_BLOCK" {
		if utils.IsEmpty(c.BlockedUntil) || !utils.IsValidYmdDateFormat(c.BlockedUntil) {
			errorString += "blocked until date is required or invalid date format it must be yyyy-mm-dd, "
		}
	}
	if utils.IsEmpty(c.ClientLoanId) || len(c.ClientLoanId) < 3 {
		errorString += "client loan id is required or invalid client loan id "
	}
	if len(c.Reason) <= 0 || c.Reason == "" || len(c.Reason) > 200 {
		errorString += "reason should not be empty or reason should be less than 200 characters,"
	}
	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}
