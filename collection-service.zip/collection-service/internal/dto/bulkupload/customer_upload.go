package bulkupload

import (
	"collection-service/internal/utils"
	"errors"
	"strings"
)

type CustomerUpload struct {
	ClientCustomerId  string  `xlsx:"column1"`
	BorrowerType      string  `xlsx:"column2"`
	FirstName         string  `xlsx:"column3"  validate:"required,max=20"`
	LastName          string  `xlsx:"column4"  validate:"required,max=20"`
	MobileNumber      string  `xlsx:"column5"  validate:"required,len=10"`
	Email             string  `xlsx:"column6"  validate:"email"`
	Dob               string  `xlsx:"column7" binding:"dateYmd"`
	Gender            string  `xlsx:"column8"`
	PreferredLanguage string  `xlsx:"column9"  validate:"required,max=20"`
	IsPrimary         string  `xlsx:"column10"`
	MonthlyIncome     float64 `xlsx:"column11"`
	Occupation        string  `xlsx:"column12"`
	CibilScore        int     `xlsx:"column13"`
	EmploymentType    string  `xlsx:"column14"`
	EmployerName      string  `xlsx:"column15"`
}

func (c *CustomerUpload) CustomerValidate() error {
	var errorString string
	if len(c.ClientCustomerId) < 3 || len(c.ClientCustomerId) > 20 {
		errorString += "client customer id:required, or length must be in 3 to 20, "
	}
	if utils.IsEmpty(c.FirstName) || !utils.ContainsOnlyChars(c.FirstName) {
		errorString += "first name:valid first name required, "
	}
	if utils.IsEmpty(c.LastName) || !utils.ContainsOnlyChars(c.LastName) {
		errorString += "last name:valid last name required, "
	}
	if utils.IsEmpty(c.MobileNumber) || !utils.IsValidMobileNumber(c.MobileNumber) {
		errorString += "mobile number: valid mobile number is required, "
	}
	if utils.IsEmpty(c.Email) || !utils.IsValidEmail(c.Email) {
		errorString += "email:valid email is required, "
	}
	if utils.IsEmpty(c.Dob) {
		errorString += "dob : dob is required, "
	}
	if utils.IsEmpty(c.Dob) || !utils.IsValidYmdDateFormat(c.Dob) {
		errorString += "dob: dob should be in Y-m-d format, "
	}
	if utils.IsValidFutureDate(c.Dob) {
		errorString += "dob: dob should not be future date, "
	}
	if !utils.ValidateLanguages(c.PreferredLanguage) {
		errorString += "preferred language: invalid language, "
	}

	if errorString != "" {
		return errors.New(strings.TrimSpace(errorString))
	}
	return nil
}
