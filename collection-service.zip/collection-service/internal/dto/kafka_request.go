package dto

type KafkaProduceRequest struct {
	Topic     *string                 `form:"topic" binding:"omitempty"`
	Key       *string                 `form:"key" binding:"required"`
	Value     *interface{}            `form:"value" binding:"required"`
	Header    *map[string]interface{} `form:"header" binding:"omitempty,mapnotempty"`
	Partition *int32                  `form:"partition" binding:"omitempty,numeric"`
}
