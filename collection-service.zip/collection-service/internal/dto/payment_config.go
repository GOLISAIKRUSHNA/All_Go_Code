package dto

type AppConfig struct {
	PaymentConfig   PaymentConfig `mapstructure:"payment_config" json:"payment_config"`
	DailyCallsLimit int           `mapstructure:"daily_calls_limit" json:"daily_calls_limit"` // keys like "daily_calls_limit" are need to move in  product_config
}

type PaymentConfig struct {
	CustomerPaymentMethods    []PaymentMethod             `json:"customer_payment_methods" mapstructure:"customer_payment_methods"`
	BankDepositPaymentMethods []PaymentMethod             `json:"bank_deposit_payment_methods" mapstructure:"bank_deposit_payment_methods"`
	Razorpay                  []RazorpayConfig            `json:"razorpay" mapstructure:"razorpay"`
	PaymentConfigType         string                      `mapstructure:"payment_config_type" json:"payment_config_type"`
	PaymentNative             NativeSendPaymentDetails    `mapstructure:"payment_native" json:"payment_native"`
	PaymentNonNative          NonnativeSendPaymentDetails `mapstructure:"payment_nonnative" json:"payment_nonnative"`
	NachEnabled               bool                        `mapstructure:"nach_enabled" json:"nach_enabled"`
}

type PaymentMethod struct {
	Mode             string          `json:"mode" mapstructure:"mode"`
	Partner          string          `json:"partner" mapstructure:"partner"`
	SurchargePercent string          `json:"surcharge_percent" mapstructure:"surcharge_percent"`
	Mid              string          `json:"mid" mapstructure:"mid"`
	UPIApps          []string        `json:"upi_apps,omitempty" mapstructure:"upi_apps"`
	AccountDetails   *AccountDetails `json:"account_details,omitempty" mapstructure:"account_details"`
}
type AccountDetails struct {
	BankName        string `json:"bank_name" mapstructure:"bank_name"`
	BranchName      string `json:"branch_name" mapstructure:"branch_name"`
	BankAccountNo   string `json:"bank_account_no" mapstructure:"bank_account_no"`
	BeneficiaryName string `json:"beneficiary_name" mapstructure:"beneficiary_name"`
	BranchIFSCCode  string `json:"branch_ifsc_code" mapstructure:"branch_ifsc_code"`
}

type RazorpayConfig struct {
	Mid       string `json:"mid" mapstructure:"mid"`
	KeyID     string `json:"key_id" mapstructure:"key_id"`
	PayeeVPA  string `json:"payee_vpa" mapstructure:"payee_vpa"`
	KeySecret string `json:"key_secret" mapstructure:"key_secret"`
	PayeeName string `json:"payee_name" mapstructure:"payee_name"`
}

type NativeSendPaymentDetails struct {
	SendPaymentLinkType string              `mapstructure:"send_payment_link_type" json:"send_payment_link_type"`
	NativeSendPayment   SendPaymentCampaign `mapstructure:"native_send_payment" json:"native_send_payment"`
}

type NonnativeSendPaymentDetails struct {
	SendPaymentLinkType  string                    `mapstructure:"send_payment_link_type" json:"send_payment_link_type"`
	NonnativeSendPayment SendPaymentCampaign       `mapstructure:"nonnative_send_payment" json:"nonnative_send_payment"`
	SendPaymentLinkAPI   SendPaymentLinkAPIDetails `mapstructure:"send_payment_link_api" json:"send_payment_link_api"`
	CustomPaymentLink    bool                      `mapstructure:"custom_payment_link" json:"custom_payment_link"`
}

type SendPaymentLinkAPIDetails struct {
	URL        string `mapstructure:"url" json:"url"`
	Method     string `mapstructure:"method" json:"method"`
	Attributes string `json:"attributes" mapstructure:"attributes"`
}

type SendPaymentCampaign struct {
	WebengageCampaignID string `mapstructure:"webengage_campaign_id" json:"webengage_campaign_id"`
	Attributes          string `mapstructure:"attributes" json:"attributes"`
}
