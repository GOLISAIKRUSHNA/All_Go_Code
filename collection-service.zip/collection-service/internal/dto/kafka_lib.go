package dto

// Exported Kafka credentials struct
type KafkaOptions struct {
	KafkaBrokers       string
	KafkaUsername      string
	KafkaPassword      string
	KafkaConsumerTopic string
	KafkaDlqTopic      string
	KafkaConsumerGroup string
	KafkaBatchSize     int
	KafkaTls           bool
	KafkaOutputTopic   string
}
