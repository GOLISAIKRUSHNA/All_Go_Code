package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"context"

	"gorm.io/gorm"
)

type FinancierRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Financier
}

func InitFinancierRepository(ctx context.Context) *FinancierRepo {
	repo := &FinancierRepo{
		model: models.Financier{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo FinancierRepo) Create(ctx context.Context, model models.Financier) (models.Financier, error) {

	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.Financier{}, created_data.Error
}

func (repo FinancierRepo) Update(ctx context.Context, update models.Financier, where models.Financier) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("financier_ref_number=?", &where.FinancierRefNumber).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo FinancierRepo) FindByReferenceNumberOne(ctx context.Context, filter models.Financier) (*models.Financier, error) {

	financierModel := &models.Financier{}
	repo.GetReadDBConnection().Model(&models.Financier{}).Where(filter).First(&financierModel)
	return financierModel, nil
}
