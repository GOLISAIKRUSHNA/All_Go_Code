package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type PincodeMasterRepo struct {
	BaseRepo
	query *gorm.DB
	model models.PincodeMaster
}

func InitPincodeMasterRepository(ctx context.Context) *PincodeMasterRepo {
	repo := &PincodeMasterRepo{
		model: models.PincodeMaster{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo PincodeMasterRepo) FindByPincode(ctx context.Context, pincode int) (models.PincodeMaster, error) {
	var result models.PincodeMaster

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	conn := repo.GetDBConnection(dbType).Preload("City").Preload("State").Where("pincode = ?", pincode)
	err := conn.First(&result).Error
	if err != nil {
		return result, err
	}
	return result, nil
}
