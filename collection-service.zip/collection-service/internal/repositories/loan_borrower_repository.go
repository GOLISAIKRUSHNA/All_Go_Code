package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm/clause"

	"gorm.io/gorm"
)

type LoanBorrowerRepo struct {
	BaseRepo
	query *gorm.DB
	model models.LoanBorrower
}

func InitLoanBorrowerRepository(ctx context.Context) *LoanBorrowerRepo {
	repo := &LoanBorrowerRepo{
		model: models.LoanBorrower{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo LoanBorrowerRepo) Create(ctx context.Context, model models.LoanBorrower) (models.LoanBorrower, error) {

	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.LoanBorrower{}, created_data.Error
}

func (repo LoanBorrowerRepo) Update(ctx context.Context, update models.LoanBorrower, where models.LoanBorrower) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("loan_ref_number=?", &where.LoanRefNumber).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo LoanBorrowerRepo) FindByReferenceNumberOne(ctx context.Context, filter models.LoanBorrower) (*models.LoanBorrower, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	borrowerModel := &models.LoanBorrower{}

	custInfoResp := repo.GetDBConnection(connectionType).Model(&models.LoanBorrower{}).Preload(clause.Associations).Where(filter)
	custInfoResp = custInfoResp.First(&borrowerModel)
	return borrowerModel, nil
}
