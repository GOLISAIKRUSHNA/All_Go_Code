package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/dto"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"

	"gorm.io/gorm"
)

type AgentsRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Agent
}

func InitAgentRepository(ctx context.Context) *AgentsRepo {
	repo := &AgentsRepo{
		model: models.Agent{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo AgentsRepo) GetAgentsMatchingByName(ctx context.Context, filter *models.Agent, pagination dto.PaginationData) ([]models.Agent, int64, error) {
	if span := tracing.TraceSpan(ctx, "AgentsRepo.GetAgentsMatchingByName"); span != nil {
		defer span.End()
		
	}

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := repo.GetDBConnection(dbType)

	var totalRecords int64
	var result []models.Agent

	baseQuery := db.Model(&models.Agent{}).Where("service_provider_ref_number = ? AND first_name LIKE ?", filter.ServiceProviderRefNumber, "%"+filter.FirstName+"%")

	// Counting totalRecords without pagination
	err := baseQuery.Count(&totalRecords).Error
	if err != nil {
		return nil, 0, err
	}

	// Apply pagination and ordering
	query := baseQuery.Preload("TeamInfo").Scopes(utils.Paginate(ctx, int(pagination.CurrentPage), int(pagination.Limit))).
		Order("CASE WHEN service_provider_team_ref_number = '' THEN 0 ELSE 1 END")

	// Execute the query
	if err := query.Find(&result).Error; err != nil {
		return result, 0, err
	}

	// Return the result
	return result, totalRecords, nil
}

func (repo AgentsRepo) GetAgentInfo(ctx context.Context, agentRefNumber string) (models.Agent, error) {
	if span := tracing.TraceSpan(ctx, "AgentsRepo.GetAgentInfo"); span != nil {
		defer span.End()
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := repo.GetDBConnection(dbType)
	// Query to fetch agents with agent_ref_number = 1
	//agentRefNumber := ctx.Param("agent_reference_number")

	var agent models.Agent
	if err := db.Model(&models.Agent{}).Preload("ServiceProviderInfo").Preload("ReportingManagerInfo").Preload("TeamInfo").
		Where("agent_ref_number = ?", agentRefNumber).First(&agent).Error; err != nil {
		panic("Failed to fetch agent")
	}

	// Return the result
	return agent, nil
}

func (repo AgentsRepo) FindOne(c context.Context, filters *models.Agent) (*models.Agent, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(c, "AgentsRepo.FindOne"); span != nil {
		defer span.End()
	}

	var result models.Agent

	dbType := utils.ExtractDBTypeFromCtx(c)

	conn := repo.GetDBConnection(dbType).Where(filters)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo AgentsRepo) FindOneExceptAgent(c context.Context, filters *models.Agent, agentRefNumberNotIn []string) (*models.Agent, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(c, "AgentsRepo.FindOne"); span != nil {
		defer span.End()
	}

	var result models.Agent

	dbType := utils.ExtractDBTypeFromCtx(c)

	conn := repo.GetDBConnection(dbType).Where(filters).Not("agent_ref_number IN (?)", agentRefNumberNotIn)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

// Create agent
func (repo AgentsRepo) Create(ctx context.Context, model models.Agent) (models.Agent, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "AgentsRepo.Create"); span != nil {
		defer span.End()
	}

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	model.AgentRefNumber = utils.GenerateRandomString(10, "AG")
	result := repo.GetDBConnection(dbType).Create(&model)

	if result.RowsAffected > 0 {
		return model, nil
	}

	return models.Agent{}, result.Error
}

// Update agent
func (repo AgentsRepo) Update(ctx context.Context, filters *models.Agent, agent *models.Agent) (bool, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "AgentsRepo.Create"); span != nil {
		defer span.End()
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	result := repo.GetDBConnection(dbType).Where(filters).Updates(agent)

	if result.Error != nil {
		return false, result.Error
	}
	return true, nil
}

// FindAgentList finds all unexpired agents with optional search functionality.
func (repo AgentsRepo) FindAgentList(ctx context.Context, agent *models.Agent, search string, pagination dto.PaginationData) ([]models.Agent, int64, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "AgentsRepo.FindAgentList"); span != nil {
		defer span.End()
	}

	var result []models.Agent
	var totalRecords int64

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := repo.GetDBConnection(dbType).Model(&models.Agent{})

	// Apply the agent filter
	query := db.Preload("TeamInfo").Preload("ReportingManagerInfo").Where(agent)

	//  search conditions on concatenated first_name and last_name or email
	if search != "" {
		searchPattern := "%" + search + "%"
		query = query.Where("CONCAT(first_name, ' ', last_name) LIKE ? OR email LIKE ?", searchPattern, searchPattern)
	}

	// Count total records without pagination
	err := query.Count(&totalRecords).Error
	if err != nil {
		return nil, 0, err
	}

	// Apply pagination and sorting by created_at in descending order
	err = query.Scopes(utils.Paginate(ctx, int(pagination.CurrentPage), int(pagination.Limit))).
		Order("created_at DESC").Find(&result).Error
	if err != nil {
		return nil, 0, err
	}

	return result, totalRecords, nil
}

// Find Reportees of an Agent
func (repo AgentsRepo) FindReportees(ctx context.Context, reportingManagerRefNumber string) ([]models.Agent, error) {
	if span := tracing.TraceSpan(ctx, "AgentsRepo.FindReportees"); span != nil {
		defer span.End()
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := repo.GetDBConnection(dbType)
	var result []models.Agent
	err := db.Where("reporting_manager_ref_number = ?", reportingManagerRefNumber).Find(&result).Error
	if err != nil {
		logger.Error(ctx, err, "Could Not Find Reportees", nil)
		return nil, err
	}
	return result, nil
}

func (repo *AgentsRepo) GetCollectionSummary(ctx context.Context, agentRefNumber string) (response.CollectionSummary, error) {

	var collectionSummary response.CollectionSummary

	paymentCollectionQuery := `SELECT a.agent_ref_number,
        COALESCE(SUM(lp.payment_amount), 0) AS total_collected,
        COALESCE(SUM(CASE WHEN DATE(lp.payment_datetime) = CURDATE() THEN lp.payment_amount ELSE 0 END), 0) AS today_collection,
        COALESCE(SUM(CASE WHEN DATE(lp.payment_datetime) = DATE_SUB(CURDATE(), INTERVAL 1 DAY) THEN lp.payment_amount ELSE 0 END), 0) AS yesterday_collection,
        COUNT(DISTINCT c.case_ref_number) AS allocated_cases_count
    FROM allocations a
    INNER JOIN cases c ON a.case_ref_number = c.case_ref_number
    INNER JOIN loans l ON l.case_ref_number = c.case_ref_number
    LEFT JOIN loan_payments lp ON lp.loan_ref_number = l.loan_ref_number AND lp.created_at > a.created_at
    WHERE  c.status='ACTIVE' AND a.agent_ref_number = ? GROUP BY a.agent_ref_number;
    `

	err := repo.GetReadDBConnection().Raw(paymentCollectionQuery, agentRefNumber).Scan(&collectionSummary).Error

	if err != nil {
		return collectionSummary, fmt.Errorf("failed to execute query: %w", err)
	}
	caseQuery := `
    SELECT COALESCE(SUM(COALESCE(c.total_due, 0)), 0) AS total_to_be_collected
    FROM allocations a
    INNER JOIN cases c ON a.case_ref_number = c.case_ref_number
    INNER JOIN loans l ON l.case_ref_number = c.case_ref_number
    WHERE a.agent_ref_number = ?  AND c.status='ACTIVE'
    GROUP BY a.agent_ref_number;
    `
	errCaseQuery := repo.GetReadDBConnection().Raw(caseQuery, agentRefNumber).Scan(&collectionSummary.TotalToBeCollected).Error

	if errCaseQuery != nil {
		return collectionSummary, fmt.Errorf("failed to execute query: %w", errCaseQuery)
	}

	//
	var paidPayments float64
	loanPaymentQuery := `
    SELECT COALESCE(SUM(COALESCE(lp.payment_amount, 0)), 0) AS total_to_be_collected
    FROM allocations a
    INNER JOIN cases c ON a.case_ref_number = c.case_ref_number
    INNER JOIN loans l ON l.case_ref_number = c.case_ref_number
    LEFT JOIN loan_payments lp ON lp.loan_ref_number = c.loan_ref_number AND lp.created_at > a.created_at
    WHERE a.agent_ref_number = ?  AND c.status='ACTIVE'
    GROUP BY a.agent_ref_number;
    `
	errCaseLoanPaymentQuery := repo.GetReadDBConnection().Raw(loanPaymentQuery, agentRefNumber).Scan(&paidPayments).Error
	if paidPayments > 0 {
		collectionSummary.TotalToBeCollected = collectionSummary.TotalToBeCollected + paidPayments
	}
	if errCaseLoanPaymentQuery != nil {
		return collectionSummary, fmt.Errorf("failed to execute query: %w", errCaseLoanPaymentQuery)
	}
	return collectionSummary, nil
}

func (repo *AgentsRepo) GetAllAgents(ctx context.Context, where models.Agent) ([]models.Agent, error) {

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	// Counting totalRecords
	result := []models.Agent{}
	conn := repo.GetDBConnection(dbType).Table("agents").Where(where)
	err := conn.Find(&result).Error
	if err != nil {
		return result, err
	}
	return result, nil
}

func (repo *AgentsRepo) FindAgentsWithRefNumbers(ctx context.Context, agentRefNumbers []string) ([]models.Agent, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	agents := []models.Agent{}
	despositionResp := repo.GetDBConnection(connectionType).Model(&models.Agent{}).Where("agent_ref_number IN (?)", agentRefNumbers)
	if err := despositionResp.Find(&agents).Error; err != nil {
		logger.Error(ctx, err, "DispositionRepo|FindOne|dbErr", logger.LogFields{"where": agentRefNumbers})
		return agents, err
	}
	return agents, nil
}

func (repo *AgentsRepo) UpdateAgentTeamRefNumber(ctx context.Context, filters []string, teamRefNumber string) (bool, error) {
	if span := tracing.TraceSpan(ctx, "AgentsRepo.UpdateAgentTeamRefNumber"); span != nil {
		defer span.End()
	}
	result := repo.GetWriteDBConnection().Table("agents").Where("agent_ref_number IN (?)", filters).Update("service_provider_team_ref_number", teamRefNumber)
	if result.Error != nil {
		return false, result.Error
	}
	return true, nil

}
func (repo *AgentsRepo) FindAgentsByTeamRefNumbers(ctx context.Context, teamRefNumbers []string) ([]models.Agent, error) {
	if span := tracing.TraceSpan(ctx, "AgentsRepo.FindAgentsByTeamRefNumbers"); span != nil {
		defer span.End()
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	var agentUsers []models.Agent
	conn := repo.GetDBConnection(dbType).Where("service_provider_team_ref_number IN (?)", teamRefNumbers)
	err := conn.Find(&agentUsers).Error
	if err != nil {
		return nil, err
	}
	return agentUsers, nil
}

func (repo *AgentsRepo) CheckIsPresentInTeam(ctx context.Context, agentRefNumbers []string) (bool, error) {
	if span := tracing.TraceSpan(ctx, "AgentsRepo.CheckIsPresentInTeam"); span != nil {
		defer span.End()
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	var count int64
	conn := repo.GetDBConnection(dbType).Model(&models.Agent{}).
		Where("agent_ref_number IN (?) AND (service_provider_team_ref_number IS NULL OR service_provider_team_ref_number = '')", agentRefNumbers).
		Count(&count)
	if conn.Error != nil {
		return false, conn.Error
	}
	// If count is greater than 0, it means there are agents with empty or null team_ref_number
	if count > 0 {
		return false, nil
	}
	return true, nil
}
