package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type CustomerInfoRepo struct {
	BaseRepo
	query *gorm.DB
	model models.CustomerInfo
}

func InitCustomerInfoRepository(ctx context.Context) *CustomerInfoRepo {
	repo := &CustomerInfoRepo{
		model: models.CustomerInfo{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo CustomerInfoRepo) Create(ctx context.Context, model models.CustomerInfo) (models.CustomerInfo, error) {
	model.InfoRefNumber = utils.GenerateRandomString(6, "CI")
	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.CustomerInfo{}, created_data.Error
}

func (repo CustomerInfoRepo) Update(ctx context.Context, update models.CustomerInfo, where models.CustomerInfo) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("loan_ref_number=?", &where.LoanRefNumber).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo CustomerInfoRepo) FindByReferenceNumberOne(ctx context.Context, filter models.CustomerInfo) (*models.CustomerInfo, error) {

	custInfoModel := &models.CustomerInfo{}
	custInfoResp := repo.GetReadDBConnection().Model(&models.CustomerInfo{}).Where(filter)
	custInfoResp = custInfoResp.First(&custInfoModel)
	return custInfoModel, nil
}
