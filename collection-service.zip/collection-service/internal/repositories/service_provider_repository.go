package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type ServiceProviderRepo struct {
	BaseRepo
	query *gorm.DB
	model models.ServiceProvider
}

func InitServiceProviderRepository(ctx context.Context) *ServiceProviderRepo {
	repo := &ServiceProviderRepo{
		model: models.ServiceProvider{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}
func (repo ServiceProviderRepo) TxnConn(ctx context.Context) *gorm.DB {
	return repo.GetTxnConn()
}

func (repo ServiceProviderRepo) FindOne(ctx context.Context, searchFilter models.ServiceProvider) (*models.ServiceProvider, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	serviceProviderModel := &models.ServiceProvider{}
	if err := repo.GetDBConnection(connectionType).Model(models.ServiceProvider{}).Where(searchFilter).First(&serviceProviderModel); err != nil {
		return serviceProviderModel, err.Error
	}
	return serviceProviderModel, nil
}
