package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/enum"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"strings"
	"time"

	"gorm.io/gorm"
)

type CaseRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Case
}

func InitCaseRepository(ctx context.Context) *CaseRepo {
	repo := &CaseRepo{
		model: models.Case{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo CaseRepo) Create(ctx context.Context, model models.Case) (models.Case, error) {

	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.Case{}, created_data.Error
}

func (repo CaseRepo) GetCaseListWithPaginate(ctx context.Context, filter request.CaseListFilter, agentRefNumbers *[]string, serviceProviderTeamRefNumber *string, clientTeamRefNumber *string) ([]dto.CaseResponse, int64, int, error) {
	if span := tracing.TraceSpan(ctx, "CaseRepo.Get"); span != nil {
		defer span.End()
	}

	var cases []dto.CaseResponse
	var totalRecords int64
	var pageSize int = 10
	if filter.PageNo <= 0 {
		filter.PageNo = 1
	}

	selectQuery := `
	     ctx.first_name,
	     ctx.last_name,
		 ctx.gender,
		 ctx.dob,
	     ctx.email,
	     ctx.mobile_number,
	     ctx.client_customer_id,
	     ctx.preferred_language,
	     ca.case_ref_number,
		 ca.loan_ref_number,
		 ca.client_ref_number,
		 ca.customer_ref_number,
		 ca.client_ref_number,
		 ca.service_provider_ref_number,
		 ca.case_type,
	     (ca.total_principal_due + ca.total_interest_due + ca.total_fees_due ) as total_due,
		 ca.total_principal_due,
		 ca.total_interest_due,
		 ca.total_fees_due,
		 ca.no_of_loans_due,
	     ca.no_of_emis_due,
	     ca.total_outstanding,
	     ca.total_principal_outstanding,
		 ca.total_interest_outstanding,
		 ca.total_principal_paid,
		 ca.total_interest_paid,
		 ca.total_fees_paid,
		 ca.no_of_emis_paid,
		 ca.current_dpd,
		 ca.bucket,
		 ca.max_dpd,
		 ca.status,
		 ca.collection_for,
		 ca.is_freezed,
         ca.product,
		 ca2.last_disposition,
		 ca2.last_disposition_datetime,
		 ca2.last_disposition_followup_date,
		 ca2.total_calls_attempted,
		 ca2.total_calls_connected,
		 ca2.todays_calls_attempted,
		 ca2.last_call_connected_at,
		 ca2.client_loan_ids,
		 ca2.contact_ref_number, 
		ca2.having_mandate_inprogress_payments, 
		ca2.having_inprogress_payments, 
		 cl.logo_url`

	if filter.Object == enum.USER_AGENT {
		selectQuery += `,ag.first_name as allocated_to_first_name,
			ag.last_name as allocated_to_last_name,
			ag.agent_ref_number as allocated_to`
	}

	gormSelectClause := repo.GetReadDBConnection().
		Table("cases ca").
		Select(selectQuery)

	query := gormSelectClause.Joins("JOIN clients cl ON cl.client_ref_number = ca.client_ref_number").
		Joins("JOIN customers ctx ON ctx.customer_ref_number = ca.customer_ref_number").
		Joins("LEFT JOIN case_attributes ca2 ON ca2.case_ref_number = ca.case_ref_number")

	if filter.Object == enum.USER_AGENT {
		query = query.Joins("JOIN allocations a ON a.case_ref_number = ca.case_ref_number").
			Joins("INNER JOIN agents ag ON ag.agent_ref_number = a.agent_ref_number")
		if filter.XApp == constants.FIELD_APP_NAME {
			query = query.Where("a.intervention = ?", enum.INTERVENTION_FIELD)
		} else {
			query = query.Where("a.intervention = ?", enum.INTERVENTION_CALLING)
		}
		if serviceProviderTeamRefNumber != nil && agentRefNumbers != nil {
			query = query.Where("(a.service_provider_team_ref_number = ? OR a.agent_ref_number IN ?)", *serviceProviderTeamRefNumber, *agentRefNumbers)
		} else if serviceProviderTeamRefNumber != nil {
			query = query.Where("a.service_provider_team_ref_number = ?", *serviceProviderTeamRefNumber)
		} else if agentRefNumbers != nil {
			query = query.Where("a.agent_ref_number IN ?", *agentRefNumbers)
		}

		query = query.Where("(ca.is_blocked = 0 OR ca.is_blocked IS NULL)").
			Where("a.service_provider_ref_number=?", filter.ServiceProviderRefNumber)

		if filter.AllocatedTo != nil {
			query = query.Where("a.agent_ref_number = ?", *filter.AllocatedTo)
		}
	} else if filter.Object == enum.USER_CLIENT_USER {
		query = query.Where("ca.client_ref_number=?", filter.ClientRefNumber)

		if clientTeamRefNumber != nil {
			query = query.Where("ca.client_team_ref_number = ?", *clientTeamRefNumber)
		}
	}

	if strings.TrimSpace(filter.Status) != "" {
		query = query.Where("ca.status = ?", filter.Status)
	}
	if strings.TrimSpace(filter.ClientCustomerId) != "" {
		query = query.Where("ctx.client_customer_id = ?", filter.ClientCustomerId)
	}

	if strings.TrimSpace(filter.CaseRefNumber) != "" {
		query = query.Where("ca.case_ref_number = ?", filter.CaseRefNumber)
	}

	if strings.TrimSpace(filter.CustomerRefNumber) != "" {
		query = query.Where("ctx.customer_ref_number = ?", filter.CustomerRefNumber)
	}

	if strings.TrimSpace(filter.LoanRefNumber) != "" {
		query = query.Where("ca.loan_ref_number = ?", filter.LoanRefNumber)
	}

	if strings.TrimSpace(filter.ClientLoanId) != "" {
		query = query.Joins("LEFT JOIN loans l ON l.loan_ref_number = ca.loan_ref_number").
			Where("l.client_loan_id = ?", filter.ClientLoanId)
	}

	if strings.TrimSpace(filter.CurrentDPDBucket) != "" {
		buckets := strings.Split(filter.CurrentDPDBucket, ",")
		query = query.Where("ca.bucket IN (?)", buckets)
	}

	if filter.GetPTPCases {
		todayDate := time.Now().Format("2006-01-02") // Format today's date as YYYY-MM-DD
		query = query.Where("DATE(ca2.last_disposition_followup_date) = ?", todayDate)
	}

	if filter.GetUntouchCases {
		oneDayAgo := time.Now().Add(-24 * time.Hour) // Get date 24 hours ago
		formattedOneDayAgo := oneDayAgo.Format("2006-01-02 15:04:05")
		query = query.Where("ca2.last_disposition_datetime IS NULL OR ca2.last_disposition_datetime < ?", formattedOneDayAgo)
	}
	if utils.IsNotEmpty(filter.LastDisposition) {
		dispositions := strings.Split(filter.LastDisposition, ",")
		query = query.Where("ca2.last_disposition IN (?)", dispositions)
	}
	if utils.IsNotEmpty(filter.FollowupDate) {
		query = query.Where("DATE(ca2.last_disposition_followup_date) = ?", filter.FollowupDate)
	}
	//Search By
	if utils.IsNotEmpty(filter.SearchBy) {
		searchTerm := "%" + filter.SearchKey + "%"
		if filter.SearchBy == "CASE" {
			query = query.Where("ca.case_ref_number LIKE ?", searchTerm)
		} else if filter.SearchBy == "LOAN" {
			query = query.Where("ca2.client_loan_ids LIKE ?", searchTerm)
		}
	}
	if filter.Default {
		if filter.XApp == constants.FIELD_APP_NAME {
			query = query.Order(repo.customDefaultFilterQueryForApp(ctx))
		} else {
			query = query.Order(repo.customDefaultFilterQueryForCalling(ctx))
		}

	} else {
		// Sort By
		if utils.IsNotEmpty(filter.SortByDue) {
			query = query.Order("total_due " + strings.ToUpper(filter.SortByDue))
		}
		if strings.EqualFold(strings.ToLower(filter.SortByBucket), "asc") {
			query = query.Order("CASE WHEN ca.bucket = 'PRE_DEL' THEN 0 ELSE 1 END, ca.bucket ASC")
		} else if strings.EqualFold(strings.ToLower(filter.SortByBucket), "desc") {
			query = query.Order("CASE WHEN ca.bucket = 'PRE_DEL' THEN 1 ELSE 0 END, ca.bucket DESC")
		}
		if utils.IsNotEmpty(filter.SortByLastDispositionDate) {
			query = query.Order("ca2.last_disposition_datetime " + strings.ToUpper(filter.SortByLastDispositionDate))
		}
	}

	query = query.Count(&totalRecords).
		Scopes(utils.Paginate(ctx, filter.PageNo, pageSize)).
		Find(&cases)

	if query.RowsAffected == 0 {
		return cases, 0, 0, nil
	}

	if query.Error != nil {
		if query.Error == gorm.ErrRecordNotFound {
			utils.ValidationError(ctx, []dto.RequestDetails{
				{
					Field:   "bad request",
					Message: "record not found",
				},
			})
			return nil, 0, 0, query.Error
		}
		return nil, 0, 0, query.Error
	}

	totalPages := totalRecords / int64(pageSize)
	if totalRecords%int64(pageSize) > 0 {
		totalPages++
	}

	return cases, totalPages, filter.PageNo, nil
}

func (repo CaseRepo) GetCaseListWithPaginateForClientUser(ctx context.Context, filter request.CaseListFilter, teamRefNumber *string) ([]dto.CaseResponse, int64, int, error) {
	if span := tracing.TraceSpan(ctx, "CaseRepo.Get"); span != nil {
		defer span.End()
	}

	var cases []dto.CaseResponse
	var totalRecords int64
	var pageSize int = 10
	if filter.PageNo == 0 {
		filter.PageNo = 1
	}

	selectQuery := `
	     ctx.first_name,
	     ctx.last_name,
		 ctx.gender,
		 ctx.dob,
	     ctx.email,
	     ctx.mobile_number,
	     ctx.client_customer_id,
	     ctx.preferred_language,
	     ca.case_ref_number,
		 ca.loan_ref_number,
		 ca.client_ref_number,
		 ca.customer_ref_number,
		 ca.client_ref_number,
		 ca.service_provider_ref_number,
		 ca.case_type,
	     ca.total_due,
		 ca.total_principal_due,
		 ca.total_interest_due,
		 ca.total_fees_due,
		 ca.no_of_loans_due,
	     ca.no_of_emis_due,
	     ca.total_outstanding,
	     ca.total_principal_outstanding,
		 ca.total_interest_outstanding,
		 ca.total_principal_paid,
		 ca.total_interest_paid,
		 ca.total_fees_paid,
		 ca.no_of_emis_paid,
		 ca.current_dpd,
		 ca.bucket,
		 ca.max_dpd,
		 ca.status,
		 ca.collection_for,
		 ca2.last_disposition,
		 ca2.last_disposition_datetime,
		 ca2.last_disposition_followup_date,
		 ca2.total_calls_attempted,
		 ca2.total_calls_connected,
		 ca2.todays_calls_attempted,
		 ca2.last_call_connected_at,
		 ca2.client_loan_ids,
		 ca2.contact_ref_number, 
		ca2.having_mandate_inprogress_payments, 
		ca2.having_inprogress_payments, 
		 cl.logo_url`

	gormSelectClause := repo.GetReadDBConnection().
		Table("cases ca").
		Select(selectQuery)

	query := gormSelectClause.Joins("JOIN clients cl ON cl.client_ref_number = ca.client_ref_number").
		Joins("JOIN customers ctx ON ctx.customer_ref_number = ca.customer_ref_number").
		Joins("LEFT JOIN case_attributes ca2 ON ca2.case_ref_number = ca.case_ref_number")

	if teamRefNumber != nil {
		query = query.Where("ca.client_team_ref_number = ?", *teamRefNumber)
	}

	query = query.Where("ca.client_ref_number=?", filter.ClientRefNumber)

	if strings.TrimSpace(filter.Status) != "" {
		query = query.Where("ca.status = ?", filter.Status)
	}
	if strings.TrimSpace(filter.ClientCustomerId) != "" {
		query = query.Where("ctx.client_customer_id = ?", filter.ClientCustomerId)
	}

	if strings.TrimSpace(filter.CaseRefNumber) != "" {
		query = query.Where("ca.case_ref_number = ?", filter.CaseRefNumber)
	}

	if strings.TrimSpace(filter.CustomerRefNumber) != "" {
		query = query.Where("ctx.customer_ref_number = ?", filter.CustomerRefNumber)
	}

	if strings.TrimSpace(filter.LoanRefNumber) != "" {
		query = query.Where("ca.loan_ref_number = ?", filter.LoanRefNumber)
	}

	if strings.TrimSpace(filter.ClientLoanId) != "" {
		query = query.Joins("LEFT JOIN loans l ON l.loan_ref_number = ca.loan_ref_number").
			Where("l.client_loan_id = ?", filter.ClientLoanId)
	}

	if strings.TrimSpace(filter.CurrentDPDBucket) != "" {
		buckets := strings.Split(filter.CurrentDPDBucket, ",")
		query = query.Where("ca.bucket IN (?)", buckets)
	}

	if filter.GetPTPCases {
		todayDate := time.Now().Format("2006-01-02") // Format today's date as YYYY-MM-DD
		query = query.Where("DATE(ca2.last_disposition_followup_date) = ?", todayDate)
	}

	if filter.GetUntouchCases {
		oneDayAgo := time.Now().Add(-24 * time.Hour) // Get date 24 hours ago
		formattedOneDayAgo := oneDayAgo.Format("2006-01-02 15:04:05")
		query = query.Where("ca2.last_disposition_datetime IS NULL OR ca2.last_disposition_datetime < ?", formattedOneDayAgo)
	}
	if utils.IsNotEmpty(filter.LastDisposition) {
		dispositions := strings.Split(filter.LastDisposition, ",")
		query = query.Where("ca2.last_disposition IN (?)", dispositions)
	}
	if utils.IsNotEmpty(filter.FollowupDate) {
		query = query.Where("DATE(ca2.last_disposition_followup_date) = ?", filter.FollowupDate)
	}
	//Search By
	if utils.IsNotEmpty(filter.SearchBy) {
		searchTerm := "%" + filter.SearchKey + "%"
		if filter.SearchBy == "CASE" {
			query = query.Where("ca.case_ref_number LIKE ?", searchTerm)
		} else if filter.SearchBy == "LOAN" {
			query = query.Where("ca2.client_loan_ids LIKE ?", searchTerm)
		}

	}
	// Sort By
	if utils.IsNotEmpty(filter.SortByDue) {
		query = query.Order("ca.total_due " + strings.ToUpper(filter.SortByDue))
	}
	if strings.EqualFold(strings.ToLower(filter.SortByBucket), "asc") {
		query = query.Order("CASE WHEN ca.bucket = 'PRE_DEL' THEN 0 ELSE 1 END, ca.bucket ASC")
	} else if strings.EqualFold(strings.ToLower(filter.SortByBucket), "desc") {
		query = query.Order("CASE WHEN ca.bucket = 'PRE_DEL' THEN 1 ELSE 0 END, ca.bucket DESC")
	}
	if utils.IsNotEmpty(filter.SortByLastDispositionDate) {
		query = query.Order("ca2.last_disposition_datetime " + strings.ToUpper(filter.SortByLastDispositionDate))
	}
	query = query.Order(repo.customDefaultFilterQueryForCalling(ctx))
	query = query.Count(&totalRecords).
		Scopes(utils.Paginate(ctx, filter.PageNo, pageSize)).
		Find(&cases)

	if query.RowsAffected == 0 {
		return cases, 0, 0, nil
	}

	if query.Error != nil {
		if query.Error == gorm.ErrRecordNotFound {
			utils.ValidationError(ctx, []dto.RequestDetails{
				{
					Field:   "bad request",
					Message: "record not found",
				},
			})
			return nil, 0, 0, query.Error
		}
		return nil, 0, 0, query.Error
	}

	totalPages := totalRecords / int64(pageSize)
	if totalRecords%int64(pageSize) > 0 {
		totalPages++
	}

	return cases, totalPages, filter.PageNo, nil
}
func (repo CaseRepo) GetCaseLoanForAgents(ctx context.Context, filter request.CaseLoanFilter) ([]models.Loan, error) {
	if span := tracing.TraceSpan(ctx, "CaseRepo.LoanGet"); span != nil {
		defer span.End()
	}
	var caseLoans []models.Loan

	query := repo.GetReadDBConnection().
		Model(models.Loan{}).
		Preload("LoanPayment").
		Preload("LoanCollateral").
		Preload("LoanBorrower").
		Preload("LoanBorrower.Customer").
		Preload("ActiveFinancier").
		Preload("SecondaryFinancier").
		Preload("Client").
		Preload("CustomerInfo").
		Omit("GroupedLoans", "ClientLoanIds").
		Joins("JOIN allocations a ON a.case_ref_number = loans.case_ref_number").
		Where("loans.case_ref_number=?", filter.CaseRefNumber)
	//Where("a.service_provider_ref_number=?", filter.ServiceProviderRefNumber)

	if strings.TrimSpace(filter.Status) != "" {
		query = query.Where("status=?", filter.Status)
	}

	if filter.XApp == constants.FIELD_APP_NAME {
		query = query.Where("a.intervention = ?", enum.INTERVENTION_FIELD)
	}
	if filter.XApp == constants.CALLING_PANEL_NAME {
		query = query.Where("a.intervention = ?", enum.INTERVENTION_CALLING)
	}

	query = query.Find(&caseLoans)

	if query.Error != nil {
		return nil, query.Error
	}

	if query.RowsAffected == 0 {
		utils.BadRequestException(ctx, "400", "bad request", "no record found", nil)
	}

	return caseLoans, nil
}

func (repo CaseRepo) GetCaseLoanForCLientUser(ctx context.Context, filter request.CaseLoanFilter) ([]models.Loan, error) {
	if span := tracing.TraceSpan(ctx, "CaseRepo.LoanGet"); span != nil {
		defer span.End()
	}
	var caseLoans []models.Loan

	query := repo.GetReadDBConnection().
		Model(models.Loan{}).
		Preload("LoanPayment").
		Preload("LoanCollateral").
		Preload("LoanBorrower").
		Preload("LoanBorrower.Customer").
		Preload("ActiveFinancier").
		Preload("SecondaryFinancier").
		Preload("Client").
		Preload("CustomerInfo").
		Omit("GroupedLoans", "ClientLoanIds").
		Where("case_ref_number=?", filter.CaseRefNumber).
		Where("client_ref_number=?", filter.ClientRefNumber)

	if strings.TrimSpace(filter.Status) != "" {
		query = query.Where("status=?", filter.Status)
	}

	query = query.Find(&caseLoans)

	if query.Error != nil {
		return nil, query.Error
	}

	if query.RowsAffected == 0 {
		utils.BadRequestException(ctx, "400", "bad request", "no record found", nil)
	}

	return caseLoans, nil
}

func (repo CaseRepo) Update(ctx context.Context, update models.Case, where models.Case) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("case_ref_number=?", &where.CaseRefNumber).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo CaseRepo) FindByReferenceNumberOne(ctx context.Context, filter models.Case) (*models.Case, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	caseModel := &models.Case{}
	caseResp := repo.GetDBConnection(connectionType).Model(&models.Case{}).Where(filter).Preload("Customer").Preload("CaseAttribute")
	if err := caseResp.First(&caseModel).Error; err != nil {
		logger.Error(ctx, err, "CaseRepo|FindByReferenceNumberOne|dbErr", logger.LogFields{"where": filter})
		return caseModel, err
	}

	return caseModel, nil
}

func (repo CaseRepo) UpdateWithMapInterface(ctx context.Context, update map[string]interface{}, where models.Case) bool {
	isUpdated := true
	caseUpdate := repo.GetWriteDBConnection().Model(models.Case{}).Where("case_ref_number=?", &where.CaseRefNumber).Updates(update)
	if caseUpdate.Error != nil {
		isUpdated = false
		logger.Error(ctx, caseUpdate.Error, "Error while updating case record", map[string]interface{}{"case_ref_number": where})
	}
	return isUpdated
}

func (repo CaseRepo) GetCase(ctx context.Context, filter *models.Case) (*models.Case, error) {
	var result models.Case

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Preload("AllocationInfo").Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo CaseRepo) GetCaseList(ctx context.Context, filter models.Case) ([]models.Case, error) {
	var result []models.Case

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)
	if filter.Limit > 0 && filter.Offset >= 0 {
		conn.Limit(filter.Limit).Offset(filter.Offset)
	}
	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (repo CaseRepo) GetCaseListWithoutPaginate(ctx context.Context, filter request.CaseListFilter, agentRefNumbers *[]string, serviceProviderTeamRefNumber *string, clientTeamRefNumber *string) ([]dto.CaseResponse, error) {

	var cases []dto.CaseResponse

	selectQuery := `
	     ctx.first_name,
	     ctx.last_name,
		 ctx.gender,
		 ctx.dob,
	     ctx.email,
	     ctx.mobile_number,
	     ctx.client_customer_id,
	     ctx.preferred_language,
	     ca.case_ref_number,
		 ca.loan_ref_number,
		 ca.client_ref_number,
		 ca.customer_ref_number,
		 ca.client_ref_number,
		 ca.service_provider_ref_number,
		 ca.case_type,
	     ca.total_due,
		 ca.total_principal_due,
		 ca.total_interest_due,
		 ca.total_fees_due,
		 ca.no_of_loans_due,
	     ca.no_of_emis_due,
	     ca.total_outstanding,
	     ca.total_principal_outstanding,
		 ca.total_interest_outstanding,
		 ca.total_principal_paid,
		 ca.total_interest_paid,
		 ca.total_fees_paid,
		 ca.no_of_emis_paid,
		 ca.current_dpd,
		 ca.bucket,
		 ca.max_dpd,
		 ca.status,
		 ca.collection_for,
		 ca2.last_disposition,
		 ca2.last_disposition_datetime,
		 ca2.last_disposition_followup_date,
		 ca2.total_calls_attempted,
		 ca2.total_calls_connected,
		 ca2.todays_calls_attempted,
		 ca2.last_call_connected_at,
		 ca2.client_loan_ids,
		 ca2.contact_ref_number,
		cua.address_ref_number,
		cua.is_primary,
		cua.label,
		cua.source as address_source, 
		cua.type as address_type,
		cua.line_1, 
		cua.line_2, 
		cua.line_3, 
        cua.landmark,
		cua.pincode,
		cua.lat, 
		cua.long,
		cl.logo_url`

	if filter.Object == enum.USER_AGENT {
		selectQuery += `,ag.first_name as allocated_to_first_name,
			ag.last_name as allocated_to_last_name,
			ag.agent_ref_number as allocated_to`
	}

	gormSelectClause := repo.GetReadDBConnection().
		Table("cases ca").
		Select(selectQuery)

	query := gormSelectClause.Joins("JOIN clients cl ON cl.client_ref_number = ca.client_ref_number").
		Joins("JOIN customers ctx ON ctx.customer_ref_number = ca.customer_ref_number").
		Joins("LEFT JOIN case_attributes ca2 ON ca2.case_ref_number = ca.case_ref_number").
		Joins("JOIN customer_addresses cua ON cua.customer_ref_number = ca.customer_ref_number and cua.is_primary = 1")

	if filter.Object == enum.USER_AGENT {
		query = query.Joins("JOIN allocations a ON a.case_ref_number = ca.case_ref_number").
			Joins("INNER JOIN agents ag ON ag.agent_ref_number = a.agent_ref_number")
		if filter.XApp == constants.FIELD_APP_NAME {
			query = query.Where("a.intervention = ?", enum.INTERVENTION_FIELD)
		}
		if filter.XApp == constants.CALLING_PANEL_NAME {
			query = query.Where("a.intervention = ?", enum.INTERVENTION_CALLING)
		}
		if serviceProviderTeamRefNumber != nil && agentRefNumbers != nil {
			query = query.Where("(a.service_provider_team_ref_number = ? OR a.agent_ref_number IN ?)", *serviceProviderTeamRefNumber, *agentRefNumbers)
		} else if serviceProviderTeamRefNumber != nil {
			query = query.Where("a.service_provider_team_ref_number = ?", *serviceProviderTeamRefNumber)
		} else if agentRefNumbers != nil {
			query = query.Where("a.agent_ref_number IN ?", *agentRefNumbers)
		}

		query = query.Where("(ca.is_blocked = 0 OR ca.is_blocked IS NULL)").
			Where("a.service_provider_ref_number=?", filter.ServiceProviderRefNumber)

		if filter.AllocatedTo != nil {
			query = query.Where("a.agent_ref_number = ?", *filter.AllocatedTo)
		}

	} else if filter.Object == enum.USER_CLIENT_USER {
		query = query.Where("ca.client_ref_number=?", filter.ClientRefNumber)

		if clientTeamRefNumber != nil {
			query = query.Where("ca.client_team_ref_number = ?", *clientTeamRefNumber)
		}
	}

	if strings.TrimSpace(filter.Status) != "" {
		query = query.Where("ca.status = ?", filter.Status)
	}
	if strings.TrimSpace(filter.ClientCustomerId) != "" {
		query = query.Where("ctx.client_customer_id = ?", filter.ClientCustomerId)
	}

	if strings.TrimSpace(filter.CaseRefNumber) != "" {
		query = query.Where("ca.case_ref_number = ?", filter.CaseRefNumber)
	}

	if strings.TrimSpace(filter.CustomerRefNumber) != "" {
		query = query.Where("ctx.customer_ref_number = ?", filter.CustomerRefNumber)
	}

	if strings.TrimSpace(filter.LoanRefNumber) != "" {
		query = query.Where("ca.loan_ref_number = ?", filter.LoanRefNumber)
	}

	if strings.TrimSpace(filter.ClientLoanId) != "" {
		query = query.Joins("LEFT JOIN loans l ON l.loan_ref_number = ca.loan_ref_number").
			Where("l.client_loan_id = ?", filter.ClientLoanId)
	}

	if strings.TrimSpace(filter.CurrentDPDBucket) != "" {
		buckets := strings.Split(filter.CurrentDPDBucket, ",")
		query = query.Where("ca.bucket IN (?)", buckets)
	}

	if filter.GetPTPCases {
		todayDate := time.Now().Format("2006-01-02") // Format today's date as YYYY-MM-DD
		query = query.Where("DATE(ca2.last_disposition_followup_date) = ?", todayDate)
	}

	if filter.GetUntouchCases {
		oneDayAgo := time.Now().Add(-24 * time.Hour) // Get date 24 hours ago
		formattedOneDayAgo := oneDayAgo.Format("2006-01-02 15:04:05")
		query = query.Where("ca2.last_disposition_datetime IS NULL OR ca2.last_disposition_datetime < ?", formattedOneDayAgo)
	}
	if utils.IsNotEmpty(filter.LastDisposition) {
		dispositions := strings.Split(filter.LastDisposition, ",")
		query = query.Where("ca2.last_disposition IN (?)", dispositions)
	}
	if utils.IsNotEmpty(filter.FollowupDate) {
		query = query.Where("DATE(ca2.last_disposition_followup_date) = ?", filter.FollowupDate)
	}

	//Search By
	if utils.IsNotEmpty(filter.SearchBy) {
		searchTerm := "%" + filter.SearchKey + "%"
		if filter.SearchBy == "CASE" {
			query = query.Where("ca.case_ref_number LIKE ?", searchTerm)
		} else if filter.SearchBy == "LOAN" {
			query = query.Where("ca2.client_loan_ids LIKE ?", searchTerm)
		}

	}
	// Sort By
	if utils.IsNotEmpty(filter.SortByDue) {
		query = query.Order("ca.total_due " + strings.ToUpper(filter.SortByDue))
	}
	if utils.IsNotEmpty(filter.SortByBucket) {
		query = query.Order("ca.bucket " + strings.ToUpper(filter.SortByBucket))
	}
	if utils.IsNotEmpty(filter.SortByLastDispositionDate) {
		query = query.Order("ca2.last_disposition_datetime " + strings.ToUpper(filter.SortByLastDispositionDate))
	}
	query = query.Find(&cases)

	if query.Error != nil {
		return cases, query.Error
	}

	return cases, nil
}

func (repo *CaseRepo) SearchCaseOnQueryString(ctx context.Context, query string, filter models.Case, pagination dto.PaginationData) ([]models.Case, int64, error) {
	var cases []models.Case
	var totalRecords int64

	db := repo.GetReadDBConnection()

	// Define the base query
	baseQuery := `
        SELECT case_ref_number, loan_ref_number, status, created_at
        FROM cases
        WHERE case_ref_number LIKE CONCAT('%', ?, '%') AND client_ref_number = ?
        UNION 
        SELECT cases.case_ref_number, cases.loan_ref_number, cases.status, cases.created_at
        FROM cases 
        JOIN loans ON cases.loan_ref_number = loans.loan_ref_number 
        WHERE (loans.loan_ref_number LIKE CONCAT('%', ?, '%') OR loans.client_loan_id LIKE CONCAT('%', ?, '%')) AND cases.client_ref_number = ?
        UNION 
        SELECT cases.case_ref_number, cases.loan_ref_number, cases.status, cases.created_at
        FROM cases 
        JOIN loans ON cases.loan_ref_number = loans.loan_ref_number 
        JOIN customers ON loans.customer_ref_number = customers.customer_ref_number 
        WHERE customers.client_customer_id LIKE CONCAT('%', ?, '%') AND cases.client_ref_number = ?
    `

	// Count the total records
	countQuery := `
        SELECT COUNT(*) FROM (
            ` + baseQuery + `
        ) AS total
    `
	err := db.Raw(countQuery, query, filter.ClientRefNumber, query, query, filter.ClientRefNumber, query, filter.ClientRefNumber).Count(&totalRecords).Error
	if err != nil {
		return nil, 0, err
	}

	// Apply pagination
	paginatedQuery := baseQuery + `
        LIMIT ? OFFSET ?
    `
	offset := (pagination.CurrentPage - 1) * pagination.Limit

	// Fetch the paginated records
	err = db.Raw(paginatedQuery, query, filter.ClientRefNumber, query, query, filter.ClientRefNumber, query, filter.ClientRefNumber, pagination.Limit, offset).Scan(&cases).Error
	if err != nil {
		return nil, 0, err
	}

	return cases, totalRecords, nil
}

func (repo *CaseRepo) customDefaultFilterQueryForApp(ctx context.Context) string {
	logger.Info(ctx, "caseRepo|customDefaultFilterQueryForApp", nil)
	query := `CASE 
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition IN ('PTP', 'CB') AND DATE(ca2.last_disposition_followup_date) = CURDATE() THEN 1
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition = 'BPTP' THEN 2
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition = 'FPTP' THEN 3
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition = 'PARTIAL_PAID' THEN 4
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition IN ('PTP', 'CB') AND DATE(ca2.last_disposition_followup_date) > CURDATE() THEN 5
			-- WHEN ca.is_freezed != 1 and ca2.last_disposition_datetime != '0000-00-00 00:00:00' and ca2.last_disposition_datetime IS NOT NULL and ca2.last_disposition_datetime > DATE_SUB(NOW(), INTERVAL 2 DAY) THEN 6
			WHEN
			(ca.is_freezed != 1 and (ca2.last_disposition_datetime IS NULL OR ca2.last_disposition_datetime = '0000-00-00 00:00:00')) or
			(ca.is_freezed != 1 and ca2.last_disposition_datetime != '0000-00-00 00:00:00' and ca2.last_disposition_datetime IS NOT NULL and ca2.last_disposition_datetime < DATE_SUB(NOW(), INTERVAL 2 DAY)) THEN 7
			WHEN ca.is_freezed = 1 THEN 9
			ELSE 8
			END, ca.total_due desc, ca2.last_disposition_datetime asc`
	return query
}
func (repo *CaseRepo) customDefaultFilterQueryForCalling(ctx context.Context) string {
	logger.Info(ctx, "caseRepo|customDefaultFilterQueryForCalling", nil)
	query := `CASE 
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition IN ('PTP', 'CB') AND DATE(ca2.last_disposition_followup_date) = CURDATE() THEN 1
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition = 'BPTP' THEN 2
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition = 'FPTP' THEN 3
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition = 'PARTIAL_PAID' THEN 4
			WHEN ca.is_freezed != 1 and ca2.disposition_type = 'POSITIVE' and ca2.last_disposition IN ('PTP', 'CB') AND DATE(ca2.last_disposition_followup_date) > CURDATE() THEN 5
			-- WHEN ca.is_freezed != 1 and ca2.last_disposition_datetime != '0000-00-00 00:00:00' and ca2.last_disposition_datetime IS NOT NULL and ca2.last_disposition_datetime > DATE_SUB(NOW(), INTERVAL 2 DAY) THEN 6
			WHEN
			(ca.is_freezed != 1 and (ca2.last_disposition_datetime IS NULL OR ca2.last_disposition_datetime = '0000-00-00 00:00:00')) or
			(ca.is_freezed != 1 and ca2.last_disposition_datetime != '0000-00-00 00:00:00' and ca2.last_disposition_datetime IS NOT NULL and ca2.last_disposition_datetime < DATE_SUB(NOW(), INTERVAL 2 DAY)) THEN 7
			WHEN ca.is_freezed = 1 THEN 9
			ELSE 8
			END, ca.total_due desc, ca2.last_disposition_datetime asc`
	return query
}

func (repo *CaseRepo) GetClientActiveCases(ctx context.Context, clientRefNumber string) ([]string, error) {
	var caseRefNumbers []string
	db := repo.GetReadDBConnection()
	err := db.Table("cases").Where("client_ref_number = ? AND status = ?", clientRefNumber, enum.CASE_ACTIVE.String()).Pluck("case_ref_number", &caseRefNumbers).Error
	if err != nil {
		logger.Error(ctx, err, "CaseRepo|GetClientActiveCases|dbErr", logger.LogFields{"clientRefNumber": clientRefNumber})
		return nil, err
	}
	return caseRefNumbers, nil
}
