package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"
	"gorm.io/gorm"
)

type CaseBlockListRepo struct {
	BaseRepo
	query *gorm.DB
	model models.CaseBlockList
}

func InitCaseBlockListRepository(ctx context.Context) *CaseBlockListRepo {
	repo := &CaseBlockListRepo{
		model: models.CaseBlockList{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo CaseBlockListRepo) Create(ctx context.Context, model models.CaseBlockList) (*models.CaseBlockList, error) {

	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.Error != nil {
		logger.Error(ctx, created_data.Error, "CaseBlockListRepo|Create", logger.LogFields{"blockListParams": model})
		return &model, created_data.Error
	}
	return &model, nil
}

func (repo CaseBlockListRepo) Update(ctx context.Context, update models.CaseBlockList, where models.CaseBlockList) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where(where).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo CaseBlockListRepo) FindOne(ctx context.Context, filter models.CaseBlockList) (*models.CaseBlockList, error) {
	var result models.CaseBlockList

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo CaseBlockListRepo) Get(ctx context.Context, filter models.CaseBlockList) (*[]models.CaseBlockList, error) {
	var result []models.CaseBlockList

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)
	if filter.Limit > 0 && filter.Offset >= 0 {
		conn.Limit(filter.Limit).Offset(filter.Offset)
	} else {
		conn.Limit(20)
	}
	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo CaseBlockListRepo) GetMaxBlockedUntil(ctx context.Context, filter models.CaseBlockList) (models.MaxBlockedUntil, error) {

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	var result models.MaxBlockedUntil
	err := repo.GetDBConnection(dbType).Model(&models.CaseBlockList{}).
		Joins("JOIN block_reason_master ON case_block_list.block_reason_master_id = block_reason_master.id").
		Where(filter).
		Select("MAX(case_block_list.blocked_until) AS max_blocked_until, block_reason_master.days_to_block, case_block_list.case_ref_number, case_block_list.is_resolved, case_block_list.id").
		Group("case_block_list.case_ref_number").
		Scan(&result).Error

	if err != nil {
		return result, err
	}

	return result, nil
}

func (repo CaseBlockListRepo) GetBlockListWithPaginate(c context.Context, filter models.CaseBlockList, pageNo int) ([]models.CaseBlockList, int64, error) {
	connectionType := utils.ExtractDBTypeFromCtx(c)
	pageSize := constants.DEFAULT_PAGE_SIZE
	if pageNo == 0 {
		pageNo = 1
	}
	offset := (pageNo - 1) * pageSize
	var totalItemsCount int64
	caseBlockList := []models.CaseBlockList{}
	db := repo.GetDBConnection(connectionType).Model(models.CaseBlockList{}).Preload("BlockedByData").Preload("BlockReasonMaster").Preload("Tickets")

	// Modify Where condition to include case_reference_number, source, and reason
	if filter.CaseRefNumber != "" {
		db = db.Where("case_ref_number = ?", filter.CaseRefNumber)
	}
	if filter.BlockedBy != "" {
		db = db.Where("blocked_by = ?", filter.BlockedBy)
	}
	if filter.BlockReasonMasterId > 0 {
		db = db.Where("block_reason_master_id = ?", filter.BlockReasonMasterId)
	}
	if filter.BlockSource.String() != "" {
		db = db.Joins("JOIN block_reason_master ON case_block_list.block_reason_master_id = block_reason_master.id").Where("block_reason_master.source = ?", filter.BlockSource)
	}
	blockList := db.Count(&totalItemsCount)

	// Calculate total pages
	totalPages := (totalItemsCount + int64(pageSize) - 1) / int64(pageSize)

	blockList = blockList.Order("id desc").Limit(pageSize).Offset(offset).Find(&caseBlockList)
	return caseBlockList, totalPages, nil
}

func (repo CaseBlockListRepo) FindOneBlockedCase(ctx context.Context, filter models.CaseBlockList) (*models.CaseBlockList, error) {
	var result models.CaseBlockList

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter).Where("ticket_ref_number IS NULL OR ticket_ref_number = ?", "")

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}
