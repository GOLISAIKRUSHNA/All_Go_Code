package repositories

import (
	"collection-service/internal/app/services/storage/cacheservice"
	"collection-service/internal/models"
	"context"
	"encoding/json"
	"time"
)

type OtpRepo struct {
	cache *cacheservice.BaseCacheService
}

const OTP = "OTP"
const SET = "set"
const OTP_EXPIRY_SECONDS = 30
const OTP_LIFECYCLE_WINDOW = 60
const OTP_DEFAULT_RESEND_ATTEMPTS_LIMIT = 3
const OTP_DEFAULT_WRONG_ATTEMPTS_LIMIT = 3

func InitOtpRepo(ctx context.Context) OtpRepo {
	return OtpRepo{cache: cacheservice.GetInstance()}
}

func (repo OtpRepo) Create(ctx context.Context, phone string, otpEntity models.OTP) error {
	cachedOtpValue, err := repo.Get(ctx, phone)
	if err != nil {
		return err
	}

	ttl := OTP_LIFECYCLE_WINDOW * time.Second

	if cachedOtpValue != "" {
		var cacheOtpEntity models.OTP
		err = json.Unmarshal([]byte(cachedOtpValue), &cacheOtpEntity)
		if err != nil {
			return err
		}

		ttl = cacheOtpEntity.FirstIssuedAt.Add(ttl).Sub(time.Now())

	}

	otpBody, err := json.Marshal(otpEntity)
	if err != nil {
		return err
	}
	repo.cache.Create(OTP+phone, otpBody, SET, ttl)
	return nil

}

func (repo OtpRepo) Get(ctx context.Context, phone string) (string, error) {
	cacheValString, err := repo.cache.Read(OTP+phone, SET)
	if err != nil {
		return "", err
	}

	return cacheValString, nil
}
