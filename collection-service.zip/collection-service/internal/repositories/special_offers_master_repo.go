package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"
)

type SpecialOffersMasterRepo struct {
	BaseRepo
	model *models.SpecialOffersMaster
}

func (repo SpecialOffersMasterRepo) GetSpecialOfferMaster(ctx context.Context, filter *models.SpecialOffersMaster) (*models.SpecialOffersMaster, error) {
	var result models.SpecialOffersMaster

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		logger.Error(ctx, err, "error while fetching special offers master", logger.LogFields{"client_ref_number": filter.ClientRefNumber})
		return nil, err
	}
	return &result, nil
}

func InitSpecialOffersMasterRepo(ctx context.Context) *SpecialOffersMasterRepo {
	repo := &SpecialOffersMasterRepo{
		model: &models.SpecialOffersMaster{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)

	return repo
}
func (repo SpecialOffersMasterRepo) GetSpecialOffersMaster(ctx context.Context, filter *models.SpecialOffersMaster) ([]models.SpecialOffersMaster, error) {
	var result []models.SpecialOffersMaster

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.Find(&result).Error
	if err != nil {
		logger.Error(ctx, err, "error while fetching special offers master", logger.LogFields{"client_ref_number": filter.ClientRefNumber})
		return nil, err
	}
	return result, nil
}
