package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"
	"gorm.io/gorm"
)

type CaseFreezeRepo struct {
	BaseRepo
	query *gorm.DB
	model models.CaseFreezeHistory
}

func InitCaseFreezeRepository(ctx context.Context) *CaseFreezeRepo {
	repo := &CaseFreezeRepo{
		model: models.CaseFreezeHistory{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo CaseFreezeRepo) Create(ctx context.Context, model models.CaseFreezeHistory) error {

	insertData := repo.GetWriteDBConnection().Create(&model)
	if insertData.Error != nil {
		logger.Error(ctx, insertData.Error, "FreezeCaseRepo|Create", logger.LogFields{"freezeData": model})
		return insertData.Error
	}
	return nil
}

func (repo CaseFreezeRepo) Update(ctx context.Context, update models.CaseFreezeHistory, where models.CaseFreezeHistory) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where(where).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo CaseFreezeRepo) FindOne(ctx context.Context, filter models.CaseFreezeHistory) (*models.CaseFreezeHistory, error) {
	var result models.CaseFreezeHistory

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

/*
func (repo CaseFreezeRepo) GetBlockListWithPaginate(c context.Context, filter models.CaseBlockList, pageNo int) ([]models.CaseBlockList, int64, error) {
	connectionType := utils.ExtractDBTypeFromCtx(c)
	pageSize := constants.DEFAULT_PAGE_SIZE
	if pageNo == 0 {
		pageNo = 1
	}
	offset := (pageNo - 1) * pageSize
	var totalItemsCount int64
	caseBlockList := []models.CaseBlockList{}
	db := repo.GetDBConnection(connectionType).Model(models.CaseBlockList{}).Preload("BlockedByData").Preload("BlockReasonMaster")

	// Modify Where condition to include case_reference_number, source, and reason
	if filter.CaseRefNumber != "" {
		db = db.Where("case_ref_number = ?", filter.CaseRefNumber)
	}
	if filter.BlockedBy != "" {
		db = db.Where("blocked_by = ?", filter.BlockedBy)
	}
	if filter.BlockReasonMasterId > 0 {
		db = db.Where("block_reason_master_id = ?", filter.BlockReasonMasterId)
	}
	if filter.BlockSource.String() != "" {
		db = db.Joins("JOIN block_reason_master ON case_block_list.block_reason_master_id = block_reason_master.id").Where("block_reason_master.source = ?", filter.BlockSource)
	}
	blockList := db.Count(&totalItemsCount)

	// Calculate total pages
	totalPages := (totalItemsCount + int64(pageSize) - 1) / int64(pageSize)

	blockList = blockList.Order("id desc").Limit(pageSize).Offset(offset).Find(&caseBlockList)
	return caseBlockList, totalPages, nil
}*/
