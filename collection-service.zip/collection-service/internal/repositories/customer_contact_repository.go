package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/dto/request"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"gorm.io/gorm"
)

type CustomerContactRepo struct {
	BaseRepo
	query *gorm.DB
	model models.CustomerContacts
}

func (repo CustomerContactRepo) GetTextColumnName() []string {
	columns := []string{
		"first_name", "last_name", "middle_name", "email",
	}
	return columns
}
func InitCustomerContactRepository(ctx context.Context) *CustomerContactRepo {
	repo := &CustomerContactRepo{
		model: models.CustomerContacts{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)

	return repo
}

func (repo CustomerContactRepo) AddCustomerContact(ctx context.Context, model models.CustomerContacts) (models.CustomerContacts, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "CustomerContactRepo.AddCustomerContact"); span != nil {
		defer span.End()
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	result := repo.GetDBConnection(dbType).Create(&model)
	if result.RowsAffected > 0 {
		return model, nil
	}

	return models.CustomerContacts{}, result.Error
}

func (repo CustomerContactRepo) FindOne(ctx context.Context, filters *models.CustomerContacts) (*models.CustomerContacts, error) {

	var result models.CustomerContacts

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filters)
	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}

	return &result, nil
}

// this function is returning list of customer contacts
func (repo CustomerContactRepo) CustomerContactList(ctx context.Context, filter request.CustomerContactListFilter) ([]models.CustomerContacts, error) {
	// implementing sentry traceSpan to track errors
	if span := tracing.TraceSpan(ctx, "CustomerContactRepo.List"); span != nil {
		defer span.End()
	}
	connectionType := utils.ExtractDBTypeFromCtx(ctx)

	var customerContactResponse []models.CustomerContacts

	query := repo.GetDBConnection(connectionType).Model(&models.CustomerContacts{})

	if filter.CustomerRefNumber != "" {
		query = query.Where("customer_ref_number = ?", filter.CustomerRefNumber)
	}
	if filter.CaseRefNumber != "" {
		query = query.Where("case_ref_number = ?", filter.CaseRefNumber)
	}

	query = query.Find(&customerContactResponse)

	if query.Error != nil {
		return customerContactResponse, query.Error
	}

	return customerContactResponse, nil
}

func (repo CustomerContactRepo) UpdateCustomerContact(ctx context.Context, updateCustomerContact map[string]interface{}, where models.CustomerContacts) error {
	if span := tracing.TraceSpan(ctx, "CustomerContactRepo.UpdateCustomerContact"); span != nil {
		defer span.End()
	}

	err := repo.GetWriteDBConnection().Model(models.CustomerContacts{}).Where("customer_ref_number=?", &where.CustomerRefNumber).Updates(updateCustomerContact)
	if err != nil {
		return err.Error
	}

	return nil
}
