package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/dto/request"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"
	"gorm.io/gorm"
)

type TicketRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Tickets
}

func InitTicketRepository(ctx context.Context) *TicketRepo {
	repo := &TicketRepo{
		model: models.Tickets{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo TicketRepo) Create(ctx context.Context, model *models.Tickets) (*models.Tickets, error) {
	model.TicketRefNumber = utils.GenerateRandomString(6, "TI")
	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.Error != nil {
		logger.Error(ctx, created_data.Error, "TicketRepo|Create", logger.LogFields{"err": created_data.Error})
		return model, nil
	}
	return model, nil
}

func (repo TicketRepo) Update(ctx context.Context, update *models.Tickets, where models.Tickets) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where(where).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo TicketRepo) FindOne(ctx context.Context, filter models.Tickets) (*models.Tickets, error) {
	var result models.Tickets

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo TicketRepo) GetTicketListWithPaginate(ctx context.Context, filter models.Tickets, extraFilter request.TicketListFilter) ([]models.Tickets, int64, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	pageSize := constants.DEFAULT_PAGE_SIZE
	pageNo := 1
	if extraFilter.PageNo > 0 {
		pageNo = extraFilter.PageNo
	}
	offset := (pageNo - 1) * pageSize
	var totalItemsCount int64
	ticketList := []models.Tickets{}
	tickets := repo.GetDBConnection(connectionType).Model(models.Tickets{}).Preload("Case").Preload("Agent").Preload("Case.Customer").Preload("Case.CaseAttribute").Preload("Case.Client").Preload("CaseBlockList", func(db *gorm.DB) *gorm.DB {
		// Add WHERE condition based on reason and source
		return db.Where("ticket_ref_number IS NULL OR ticket_ref_number=''").Order("blocked_until DESC").Preload("BlockedByData").Preload("BlockReasonMaster")

	}).Where(filter)

	tickets = tickets.Joins("JOIN case_block_list ON case_block_list.case_ref_number = tickets.case_ref_number").Joins("JOIN block_reason_master ON block_reason_master.id = case_block_list.block_reason_master_id")

	if len(extraFilter.BlockedReason) > 0 {
		tickets.Where("block_reason_master.id IN  (?)", extraFilter.BlockedReason)
	}
	if len(extraFilter.BlockedSource) > 0 {
		tickets = tickets.Where("block_reason_master.source IN (?)", extraFilter.BlockedSource)
	}
	if extraFilter.SortByTotalDueAmount != "" {
		tickets.Joins("JOIN cases ON cases.case_ref_number = tickets.case_ref_number")
		tickets = tickets.Order("cases.total_due " + extraFilter.SortByTotalDueAmount)
	}
	if len(extraFilter.SubIssueIds) > 0 {
		tickets = tickets.Where("sub_issue_id IN (?)", extraFilter.SubIssueIds)
	}
	if len(extraFilter.IssueIds) > 0 {
		tickets = tickets.Where("issue_id IN (?)", extraFilter.IssueIds)
	}
	tickets = tickets.Where("case_block_list.ticket_ref_number IS NULL OR case_block_list.ticket_ref_number = ''").Group("tickets.ticket_ref_number")
	tickets.Count(&totalItemsCount)
	if extraFilter.Default {
		tickets = tickets.Joins("JOIN case_attributes ON tickets.case_ref_number = case_attributes.case_ref_number")
		tickets = tickets.Order(repo.getDefaultOrderQuery())
	} else {
		if extraFilter.SortByBlockedDate != "" {
			tickets = tickets.Order("case_block_list.blocked_at " + extraFilter.SortByBlockedDate)
		}
		//Condition to filter based on IsSubIssueFilled and sub_issue_id
		if extraFilter.IsSubIssueFilled {
			tickets = tickets.Order("sub_issue_id DESC")
		}
		if extraFilter.IsIssueFilled {
			tickets = tickets.Order("issue_id DESC")
		}
		if !extraFilter.IsSubIssueFilled {
			tickets = tickets.Order("sub_issue_id ASC")
		}
		if !extraFilter.IsIssueFilled {
			tickets = tickets.Order("issue_id ASC")
		}
		tickets = tickets.Order("tickets.created_at ASC")
	}

	// Calculate total pages
	totalPages := (totalItemsCount + int64(pageSize) - 1) / int64(pageSize)
	tickets = tickets.Limit(pageSize).Offset(offset).Find(&ticketList)
	return ticketList, totalPages, nil
}

// GetTicketCountForAgent returns the count of tickets assigned to the agent
func (repo TicketRepo) GetTicketCountForAgent(ctx context.Context, where models.Tickets) (int64, error) {
	// Extract the database type from the context
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	// Define a variable to store the count
	var count int64

	// Perform the query to get the count of tickets assigned to the agent
	err := repo.GetDBConnection(dbType).Model(models.Tickets{}).Where(where).Count(&count).Error
	if err != nil {
		return 0, err
	}
	// Return the count of tickets assigned to the agent
	return count, nil
}

func (repo TicketRepo) getDefaultOrderQuery() string {
	return `
       CASE
        WHEN (tickets.sub_issue_id IS NULL AND tickets.issue_id IS NULL ) 
            OR (tickets.issue_id <= 0 AND tickets.sub_issue_id <= 0) 
            OR (tickets.action IS NULL AND tickets.action = '') 
        THEN 0
        ELSE 1
    END,
    CASE
        WHEN case_attributes.disposition_type = 'positive' THEN 
            CASE
                WHEN case_attributes.last_disposition = 'PTP' 
                    AND case_attributes.last_disposition_followup_date != '0000-00-00 00:00:00' 
                    AND case_attributes.last_disposition_followup_date = CURRENT_DATE 
                THEN 0
                WHEN case_attributes.last_disposition = 'CB' 
                    AND case_attributes.last_disposition_followup_date != '0000-00-00 00:00:00' 
                    AND case_attributes.last_disposition_followup_date = CURRENT_DATE 
                THEN 1
                ELSE 2
            END
        ELSE 
            CASE
                WHEN case_attributes.last_disposition IN ('BPTP', 'FPTP', 'PARTIAL_PAID') THEN 0
                WHEN case_attributes.last_disposition_followup_date > CURRENT_DATE THEN 1
                ELSE 2
            END
    END,
    case_block_list.blocked_at DESC
    `
}
