package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"gorm.io/gorm"
)

type CustomerDocsRepo struct {
	BaseRepo
	query *gorm.DB
	model models.CustomerDocument
}

func InitCustomerDocsRepository(ctx context.Context) *CustomerDocsRepo {
	repo := &CustomerDocsRepo{
		model: models.CustomerDocument{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo CustomerDocsRepo) FindMany(ctx context.Context, filters *models.CustomerDocument) ([]models.CustomerDocument, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "CustomerDocsRepo.FindMany"); span != nil {
		defer span.End()
	}

	var result []models.CustomerDocument

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	//conn, _ := repo.setQuery(ctx, filters, db_type)
	conn := repo.GetDBConnection(dbType).Where(filters)
	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (repo CustomerDocsRepo) Create(ctx context.Context, model models.CustomerDocument) (models.CustomerDocument, error) {
	model.DocumentRefNumber = utils.GenerateRandomString(6, "DOC")
	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.CustomerDocument{}, created_data.Error
}

func (repo CustomerDocsRepo) Update(ctx context.Context, update models.CustomerDocument, where models.CustomerDocument) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("document_ref_number=?", &where.DocumentRefNumber).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo CustomerDocsRepo) FindCustomerDocument(ctx context.Context, filter models.CustomerDocument) (models.CustomerDocument, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	document := models.CustomerDocument{}
	err := repo.GetDBConnection(connectionType).Model(&models.CustomerDocument{}).Where(filter).First(&document).Error
	if err != nil {
		return document, err
	}
	return document, nil
}
