package repositories

import (
	//"bytes"

	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type AllocationRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Allocation
}

func InitAllocationRepository(ctx context.Context) *AllocationRepo {
	repo := &AllocationRepo{
		model: models.Allocation{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo AllocationRepo) Create(ctx context.Context, model *models.Allocation, dbConn *gorm.DB) error {

	created_data := dbConn.Create(&model)
	if created_data.RowsAffected > 0 {
		return nil
	}
	return created_data.Error
}

func (repo AllocationRepo) Update(ctx context.Context, update models.Allocation, where models.Allocation) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("case_ref_number=?", &where.CaseRefNumber).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo AllocationRepo) FindByReferenceNumberOne(ctx context.Context, filter models.Allocation) (*models.Allocation, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	allocationModel := &models.Allocation{}
	allocationResp := repo.GetDBConnection(connectionType).Model(&models.Allocation{}).Where(filter)
	if err := allocationResp.First(&allocationModel).Error; err != nil {
		return allocationModel, err
	}
	return allocationModel, nil
}

//	func (repo AllocationRepo) DeleteCaseAllocation(ctx context.Context, caseRefNumber, serviceProviderRefNumber string, dbConn *gorm.DB) error {
//		allocationModel := &models.Allocation{}
//		if err := dbConn.Unscoped().Where("case_ref_number = ? and service_provider_ref_number = ?", caseRefNumber, serviceProviderRefNumber).Delete(&allocationModel).Error; err != nil {
//			return err
//		}
//		return nil
//	}
func (repo AllocationRepo) DeleteCaseAllocation(ctx context.Context, deleteReq models.Allocation, dbConn *gorm.DB) error {
	allocationModel := &models.Allocation{}
	if err := dbConn.Unscoped().Where(deleteReq).Delete(&allocationModel).Error; err != nil {
		return err
	}
	return nil
}

func (repo AllocationRepo) GetAllocationDetails(ctx context.Context, model models.Allocation) (models.Allocation, error) {
	var allocation models.Allocation
	query := repo.GetReadDBConnection().
		Model(models.Allocation{}).
		Preload("Agent").
		Where("case_ref_number=? AND agent_ref_number=?", model.CaseRefNumber, model.AgentRefNumber).
		First(&allocation)

	if query.Error != nil {
		return allocation, query.Error
	}

	return allocation, nil
}
