package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"context"

	"gorm.io/gorm"
)

type AgentRolesRepo struct {
	BaseRepo
	query *gorm.DB
	model models.AgentRole
}

func InitAgentRoleRepository(ctx context.Context) *AgentRolesRepo {
	repo := &AgentRolesRepo{
		model: models.AgentRole{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo AgentRolesRepo) GetAgentRoleById(ctx context.Context, roleId int) (*models.AgentRole, error) {
	roleResp := models.AgentRole{}
	role := repo.GetReadDBConnection().Model(&models.AgentRole{}).Where("id=?", roleId)
	// checking if the role is empty or not
	result := role.First(&roleResp)
	if result.Error != nil {
		return nil, result.Error
	}
	return &roleResp, nil
}
