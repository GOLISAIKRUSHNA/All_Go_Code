package repo_interfaces

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"context"
)

type ILoanRepository interface {
	IBaseRepository

	FindById(ctx context.Context, loanRefNo string, db_type ...constants.DatabaseType) (map[string]interface{}, error)
	FindOne(ctx context.Context, filters *models.SearchFilters, db_type ...constants.DatabaseType) (*models.Loan, error)
	Create(ctx context.Context, model models.Loan) (models.Loan, error)
	Update(ctx context.Context, model models.Loan, whereBlock models.Loan) (bool, error)
	UpdateWithMap(ctx context.Context, updateParams map[string]interface{}, whereBlock models.Loan) bool
	FindByReferenceNumberOne(ctx context.Context, filters models.Loan) (*models.Loan, error)
	GetSumOfColumns(ctx context.Context, filter models.Loan) ([]models.Loan, error)
	Get(ctx context.Context, filter models.Loan) ([]models.Loan, error)
	GetLoan(ctx context.Context, filter *models.Loan) (*models.Loan, error)
	FindLoansByCaseRefNumberHavingPayLinks(ctx context.Context, caseRefNumber string) ([]models.Loan, error)
	GetAllActiveLoansWhereCaseRefNumbersIN(ctx context.Context, caseRefNumbers []string) ([]models.Loan, error)
}
