package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ICaseFreezeRepository interface {
	Create(ctx context.Context, model models.CaseFreezeHistory) error
}
