package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ILoanReferenceRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.LoanReference) (models.LoanReference, error)
	Update(ctx context.Context, model models.LoanReference, whereBlock models.LoanReference) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.LoanReference) (*models.LoanReference, error)
}
