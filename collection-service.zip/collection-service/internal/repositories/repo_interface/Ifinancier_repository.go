package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IFinancierRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.Financier) (models.Financier, error)
	Update(ctx context.Context, model models.Financier, whereBlock models.Financier) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.Financier) (*models.Financier, error)
}
