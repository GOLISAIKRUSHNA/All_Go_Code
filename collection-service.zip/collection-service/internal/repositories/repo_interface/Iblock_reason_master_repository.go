package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IBlockReasonMasterRepository interface {
	IBaseRepository
	Create(ctx context.Context, model map[string]interface{}) (*models.BlockReasonMaster, error)
	Update(ctx context.Context, model map[string]interface{}, whereBlock models.BlockReasonMaster) (bool, error)
	FindOne(ctx context.Context, filter models.BlockReasonMaster) (*models.BlockReasonMaster, error)
	Get(ctx context.Context, filter models.BlockReasonMaster, source []string) (*[]models.BlockReasonMaster, error)
}
