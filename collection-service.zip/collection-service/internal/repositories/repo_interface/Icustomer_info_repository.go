package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ICustomerInfoRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.CustomerInfo) (models.CustomerInfo, error)
	Update(ctx context.Context, model models.CustomerInfo, whereBlock models.CustomerInfo) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.CustomerInfo) (*models.CustomerInfo, error)
}
