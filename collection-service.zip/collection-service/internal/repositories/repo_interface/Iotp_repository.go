package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IOtpRepo interface {
	Create(ctx context.Context, phone string, otpEntity models.OTP) error
	Get(ctx context.Context, phone string) (string, error)
}
