package repo_interfaces

import (
	"collection-service/internal/models"
	"context"

	"gorm.io/gorm"
)

type IAllocationRepository interface {
	IBaseRepository
	Create(ctx context.Context, model *models.Allocation, dbConn *gorm.DB) error
	Update(ctx context.Context, model models.Allocation, whereBlock models.Allocation) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.Allocation) (*models.Allocation, error)
	//DeleteCaseAllocation(ctx context.Context, caseRefNumber, serviceProviderRefNumber string, dbConn *gorm.DB) error
	DeleteCaseAllocation(ctx context.Context, deleteReq models.Allocation, dbConn *gorm.DB) error
	GetAllocationDetails(ctx context.Context, model models.Allocation) (models.Allocation, error)
}
