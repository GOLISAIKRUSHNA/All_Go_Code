package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ICustomerDocsRepository interface {
	IBaseRepository
	FindMany(ctx context.Context, filters *models.CustomerDocument) ([]models.CustomerDocument, error)
	FindCustomerDocument(ctx context.Context, filters models.CustomerDocument) (models.CustomerDocument, error)
	Create(ctx context.Context, model models.CustomerDocument) (models.CustomerDocument, error)
	Update(ctx context.Context, model models.CustomerDocument, whereBlock models.CustomerDocument) (bool, error)
}
