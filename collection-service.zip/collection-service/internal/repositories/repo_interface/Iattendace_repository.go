package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IAttendanceRepository interface {
	IBaseRepository

	Create(ctx context.Context, attendance *models.Attendance) (bool, error)
	UpdateApprovalStatus(ctx context.Context, attendances []string, approvalStatus string, agentName string) (bool, error)
	FindMany(ctx context.Context, filters *models.Attendance) ([]models.Attendance, error)
	FindManyByAgentRefNumbers(ctx context.Context, agentRefNumbers []string, approvalStatus string) ([]models.Attendance, error)
	FindManyByAttendanceRefNumbers(ctx context.Context, attendanceRefNumbers []string) ([]models.Attendance, error)
}
