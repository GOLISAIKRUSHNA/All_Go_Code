package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ILoanCollateralRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.LoanCollateral) (models.LoanCollateral, error)
	Update(ctx context.Context, model models.LoanCollateral, whereBlock models.LoanCollateral) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.LoanCollateral) (*models.LoanCollateral, error)
}
