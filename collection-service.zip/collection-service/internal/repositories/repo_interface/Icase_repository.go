package repo_interfaces

import (
	"collection-service/internal/dto"
	"collection-service/internal/dto/request"
	"collection-service/internal/models"
	"context"
)

type ICaseRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.Case) (models.Case, error)
	Update(ctx context.Context, model models.Case, whereBlock models.Case) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.Case) (*models.Case, error)
	GetCaseListWithPaginate(ctx context.Context, filter request.CaseListFilter, agentRefNumbers *[]string, teamRefNumber *string, clientTeamRefNumber *string) ([]dto.CaseResponse, int64, int, error)
	GetCaseListWithPaginateForClientUser(ctx context.Context, filter request.CaseListFilter, teamRefNumber *string) ([]dto.CaseResponse, int64, int, error)
	GetCaseLoanForAgents(ctx context.Context, filter request.CaseLoanFilter) ([]models.Loan, error)
	GetCaseLoanForCLientUser(ctx context.Context, filter request.CaseLoanFilter) ([]models.Loan, error)
	UpdateWithMapInterface(ctx context.Context, updateParams map[string]interface{}, whereBlock models.Case) bool
	GetCase(ctx context.Context, filter *models.Case) (*models.Case, error)
	GetCaseList(ctx context.Context, filter models.Case) ([]models.Case, error)
	GetCaseListWithoutPaginate(ctx context.Context, filter request.CaseListFilter, agentRefNumbers *[]string, teamRefNumber *string, clientTeamRefNumber *string) ([]dto.CaseResponse, error)
	SearchCaseOnQueryString(ctx context.Context, query string, filter models.Case, pagination dto.PaginationData) ([]models.Case, int64, error)
	GetClientActiveCases(ctx context.Context, clientRefNumber string) ([]string, error)
}
