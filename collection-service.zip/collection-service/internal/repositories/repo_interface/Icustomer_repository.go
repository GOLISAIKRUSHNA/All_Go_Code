package repo_interfaces

import (
	"collection-service/internal/models"
	"context"

	"gorm.io/gorm"
)

type ICustomerRepository interface {
	IBaseRepository

	Create(ctx context.Context, model models.Customer) (models.Customer, error)
	Update(ctx context.Context, model models.Customer, whereBlock models.CustomerWhereParams) (models.Customer, error)
	FindOne(ctx context.Context, filter models.CustomerWhereParams) (*models.Customer, error)
	TxnConn(ctx context.Context) *gorm.DB
	GetCustomer(ctx context.Context, filter *models.Customer) (*models.Customer, error)
}
