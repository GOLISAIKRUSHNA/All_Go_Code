package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IClientRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.Client) (models.Client, error)
	Update(ctx context.Context, model models.Client, whereBlock models.Client) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter *models.Client) (*models.Client, error)
	FindAllByClientRefNumbers(ctx context.Context, clientRefNumbers []string) ([]models.Client, error)
	UpdateClientConfig(ctx context.Context, clientRefNumber string, config string) error
}
