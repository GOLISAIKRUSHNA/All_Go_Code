package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IAgentRoleMappingRepo interface {
	IBaseRepository

	FindOne(ctx context.Context, filters *models.AgentRoleMapping) (*models.AgentRoleMapping, error)
	CreateRoleMappings(ctx context.Context, agentRolesMappingData []models.AgentRoleMapping) error
	FindAll(ctx context.Context, filters *models.AgentRoleMapping) ([]models.AgentRoleMapping, error)
	DeleteAgentRoleMappings(ctx context.Context, agentRoleIDs []int) error
	//Exists(ctx context.Context, filters *models.SearchFilters, db_type constants.DatabaseType) (bool, error)
}
