package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IPincodeMasterRepository interface {
	IBaseRepository
	FindByPincode(ctx context.Context, pincode int) (models.PincodeMaster, error)
}
