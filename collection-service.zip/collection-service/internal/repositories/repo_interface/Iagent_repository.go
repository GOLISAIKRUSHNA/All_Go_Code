package repo_interfaces

import (
	"collection-service/internal/dto"
	"collection-service/internal/dto/response"
	"collection-service/internal/models"
	"context"
)

type IAgentRepository interface {
	IBaseRepository

	FindOne(ctx context.Context, filters *models.Agent) (*models.Agent, error)
	FindOneExceptAgent(c context.Context, filters *models.Agent, agentRefNumberNotIn []string) (*models.Agent, error)

	Create(ctx context.Context, filters models.Agent) (models.Agent, error)
	Update(ctx context.Context, filters *models.Agent, agent *models.Agent) (bool, error)
	FindAgentList(ctx context.Context, agent *models.Agent, search string, pagination dto.PaginationData) ([]models.Agent, int64, error)
	// Exists(ctx context.Context, filters *models.SearchFilters, db_type constants.DatabaseType) (bool, error)
	GetAgentsMatchingByName(ctx context.Context, filter *models.Agent, pagination dto.PaginationData) ([]models.Agent, int64, error)
	GetAgentInfo(ctx context.Context, agentRefNumber string) (models.Agent, error)

	GetAllAgents(ctx context.Context, filter models.Agent) ([]models.Agent, error)
	FindReportees(ctx context.Context, agentRefNumber string) ([]models.Agent, error)
	GetCollectionSummary(ctx context.Context, agentRefNumber string) (response.CollectionSummary, error)
	FindAgentsWithRefNumbers(ctx context.Context, agentRefNumbers []string) ([]models.Agent, error)
	UpdateAgentTeamRefNumber(ctx context.Context, filters []string, teamRefNumber string) (bool, error)
	CheckIsPresentInTeam(ctx context.Context, agentRefNumbers []string) (bool, error)
	FindAgentsByTeamRefNumbers(ctx context.Context, teamRefNumbers []string) ([]models.Agent, error)
}
