package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ICaseAttributeRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.CaseAttribute) (models.CaseAttribute, error)
	Update(ctx context.Context, model models.CaseAttribute, caseRefNumber string) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.CaseAttribute) (*models.CaseAttribute, error)
	UpdateWithMapInterface(ctx context.Context, updateParams map[string]interface{}, whereBlock models.CaseAttribute) bool
}
