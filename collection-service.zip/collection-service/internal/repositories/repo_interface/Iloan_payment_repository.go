package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ILoanPaymentRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.LoanPayment) (models.LoanPayment, error)
	Update(ctx context.Context, model models.LoanPayment, whereBlock models.LoanPaymentWhereParams) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filters *models.LoanPayment) (*models.LoanPayment, error)
}
