package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ICaseStatusHistoryRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.CaseStatusHistory) (models.CaseStatusHistory, error)
	FindByReferenceNumberOne(ctx context.Context, filter *models.CaseStatusHistory) (*models.CaseStatusHistory, error)
}
