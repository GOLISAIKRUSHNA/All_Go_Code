package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IClientServiceProviderRepository interface {
	IBaseRepository
	FindAll(ctx context.Context, filter models.ClientServiceProviders) ([]models.ClientServiceProviders, error)
	FindOne(ctx context.Context, filter models.ClientServiceProviders) (*models.ClientServiceProviders, error)
	UpdateClientServiceProvider(ctx context.Context, filter *models.ClientServiceProviders, model *models.ClientServiceProviders) error
}
