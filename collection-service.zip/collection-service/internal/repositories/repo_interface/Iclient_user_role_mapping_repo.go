package repo_interfaces

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"context"
)

type IClientUserRoleMappingRepo interface {
	IBaseRepository

	FindOne(ctx context.Context, filters *models.ClientUserRoleMapping, db_type constants.DatabaseType) (*models.ClientUserRoleMapping, error)
}
