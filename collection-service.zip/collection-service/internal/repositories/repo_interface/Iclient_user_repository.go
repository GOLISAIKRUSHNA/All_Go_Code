package repo_interfaces

import (
	"collection-service/internal/dto"
	"collection-service/internal/models"
	"context"
)

type IClientUserRepository interface {
	IBaseRepository
	FindOne(ctx context.Context, filters *models.ClientUser) (*models.ClientUser, error)
	Create(ctx context.Context, model *models.ClientUser) (*models.ClientUser, error)
	FindClientUserPage(ctx context.Context, filter *models.ClientUser, search string, pagination dto.PaginationData) ([]models.ClientUser, int64, error)
	FindClientUser(ctx context.Context, filters *models.ClientUser) (*models.ClientUser, error)
	FindOneExceptClientUsers(ctx context.Context, filters *models.ClientUser, clientUserRefNumberNotIn []string) (*models.ClientUser, error)
	Update(ctx context.Context, filters *models.ClientUser, agent *models.ClientUser) (bool, error)
	UpdateClientUserTeamRefNumber(ctx context.Context, filters []string, teamRefNumber string) (bool, error)
	CheckIsPresentInTeam(ctx context.Context, clientUserRefNumbers []string) (bool, error)
	FindClientUsersByTeamRefNumbers(ctx context.Context, teamRefNumbers []string) ([]models.ClientUser, error)
	GetClientUserMatchingByName(ctx context.Context, filter *models.ClientUser, pagination dto.PaginationData) ([]models.ClientUser, int64, error)
}
