package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ILoanBorrowerRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.LoanBorrower) (models.LoanBorrower, error)
	Update(ctx context.Context, model models.LoanBorrower, whereBlock models.LoanBorrower) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.LoanBorrower) (*models.LoanBorrower, error)
}
