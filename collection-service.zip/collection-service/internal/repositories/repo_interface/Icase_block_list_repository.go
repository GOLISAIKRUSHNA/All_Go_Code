package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ICaseBlockListRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.CaseBlockList) (*models.CaseBlockList, error)
	Update(ctx context.Context, model models.CaseBlockList, whereBlock models.CaseBlockList) (bool, error)
	FindOne(ctx context.Context, filter models.CaseBlockList) (*models.CaseBlockList, error)
	Get(ctx context.Context, filter models.CaseBlockList) (*[]models.CaseBlockList, error)
	GetMaxBlockedUntil(ctx context.Context, filter models.CaseBlockList) (models.MaxBlockedUntil, error)
	GetBlockListWithPaginate(ctx context.Context, filter models.CaseBlockList, pageNo int) ([]models.CaseBlockList, int64, error)
	FindOneBlockedCase(ctx context.Context, filter models.CaseBlockList) (*models.CaseBlockList, error)
}
