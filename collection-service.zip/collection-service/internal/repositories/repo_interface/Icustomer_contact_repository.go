package repo_interfaces

import (
	"collection-service/internal/dto/request"
	"collection-service/internal/models"
	"context"
)

type ICustomerContactRepository interface {
	IBaseRepository
	AddCustomerContact(ctx context.Context, model models.CustomerContacts) (models.CustomerContacts, error)
	FindOne(ctx context.Context, filters *models.CustomerContacts) (*models.CustomerContacts, error)
	CustomerContactList(context.Context, request.CustomerContactListFilter) ([]models.CustomerContacts, error)
	UpdateCustomerContact(ctx context.Context, updateCustomerContact map[string]interface{}, where models.CustomerContacts) error
}
