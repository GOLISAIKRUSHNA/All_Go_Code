package repo_interfaces

import (
	"collection-service/internal/dto"
	"collection-service/internal/models"
	"context"
)

type IDispositionRepository interface {
	IBaseRepository
	FindOne(ctx context.Context, filters models.Disposition) (*models.Disposition, error)
	CreateDispositionRecord(ctx context.Context, data *models.Disposition) error
	FindDispositionList(ctx context.Context, filters models.Disposition, pagination dto.PaginationData) ([]models.Disposition, int64, error)
	FindDispositionsFromAttemptRef(ctx context.Context, attemptRef []string) ([]models.Disposition, error)
}
