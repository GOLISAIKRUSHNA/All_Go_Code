package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type IAgentRoleRepository interface {
	IBaseRepository
	GetAgentRoleById(ctx context.Context, roleId int) (*models.AgentRole, error)
}
