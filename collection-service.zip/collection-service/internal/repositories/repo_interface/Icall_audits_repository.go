package repo_interfaces

import (
	"collection-service/internal/dto/request"
	"collection-service/internal/models"
	"context"
)

type ICallAuditsRepository interface {
	IBaseRepository
	CreateCallAudits(ctx context.Context, model models.CallAudits) error
	CallAuditsList(ctx context.Context, queryRequest request.CallAuditsList) ([]models.CallAudits, int64, int, error)
	FindOne(ctx context.Context, filter models.CallAudits) (models.CallAudits, error)
	UpdateOne(ctx context.Context, where models.CallAudits, update models.CallAudits) error
	FindByAuditRefNumbers(ctx context.Context, filter request.AuditAgentAllocate) ([]models.CallAudits, error)
	UpdateAuditAgentRefNumber(ctx context.Context, filter request.AuditAgentAllocate) error
}
