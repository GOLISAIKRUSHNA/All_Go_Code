package repo_interfaces

import (
	"collection-service/internal/models"
	"context"

	"gorm.io/gorm"
)

type IAllocationHistoryRepository interface {
	IBaseRepository
	Create(ctx context.Context, model models.AllocationHistory, dbConn *gorm.DB) (models.AllocationHistory, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.AllocationHistory) (*models.AllocationHistory, error)
}
