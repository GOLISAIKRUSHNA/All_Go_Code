package repo_interfaces

import (
	"collection-service/internal/models"
	"context"
)

type ICustomerAddressRepository interface {
	IBaseRepository
	Create(ctx context.Context, model *models.CustomerAddress) (*models.CustomerAddress, error)
	Update(ctx context.Context, model models.CustomerAddress, whereBlock models.CustomerAddress) (bool, error)
	FindByReferenceNumberOne(ctx context.Context, filter models.CustomerAddress) (*models.CustomerAddress, error)
	FindMany(ctx context.Context, filters *models.CustomerAddress) ([]models.CustomerAddress, error)
	UpdateWithMapInterface(ctx context.Context, updateParams map[string]interface{}, whereBlock models.CustomerAddress) error
}
