package repositories

import (
	//"bytes"

	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	//"encoding/gob"

	"gorm.io/gorm"
)

type AllocationHistoryRepo struct {
	BaseRepo
	query *gorm.DB
	model models.AllocationHistory
}

func InitAllocationHistoryRepository(ctx context.Context) *AllocationHistoryRepo {
	repo := &AllocationHistoryRepo{
		model: models.AllocationHistory{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo AllocationHistoryRepo) Create(ctx context.Context, model models.AllocationHistory, dbConn *gorm.DB) (models.AllocationHistory, error) {

	created_data := dbConn.Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.AllocationHistory{}, created_data.Error
}

func (repo AllocationHistoryRepo) FindByReferenceNumberOne(ctx context.Context, filter models.AllocationHistory) (*models.AllocationHistory, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	allocationHistoryModel := &models.AllocationHistory{}
	allocationResp := repo.GetDBConnection(connectionType).Model(&models.AllocationHistory{}).Where(filter)
	if err := allocationResp.First(&allocationHistoryModel).Error; err != nil {
		return allocationHistoryModel, err
	}
	return allocationHistoryModel, nil
}
