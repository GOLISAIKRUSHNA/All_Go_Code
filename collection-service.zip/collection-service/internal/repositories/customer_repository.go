package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type CustomerRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Customer
}

func InitCustomerRepository(ctx context.Context) *CustomerRepo {
	repo := &CustomerRepo{
		model: models.Customer{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}
func (repo CustomerRepo) TxnConn(ctx context.Context) *gorm.DB {
	return repo.GetTxnConn()
}

func (repo CustomerRepo) Create(ctx context.Context, model models.Customer) (models.Customer, error) {
	model.CustomerRefNumber = utils.GenerateRandomString(6, "CR")
	created_data := repo.GetWriteDBConnection().Create(&model)
	repo.GetWriteDBConnection()
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.Customer{}, created_data.Error
}

func (repo CustomerRepo) Update(ctx context.Context, update models.Customer, where models.CustomerWhereParams) (models.Customer, error) {
	custModel := models.Customer{}
	customer, err := repo.FindOne(ctx, where)
	if err != nil {
		return custModel, err
	}
	if len(customer.MobileNumber) > 0 {
		customer := repo.GetWriteDBConnection().Where("customer_ref_number=?", &customer.CustomerRefNumber).Updates(update)
		if customer.RowsAffected > 0 {
			return custModel, err
		}
	}
	return custModel, nil
}

func (repo CustomerRepo) FindOne(ctx context.Context, searchFilter models.CustomerWhereParams) (*models.Customer, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	customerModel := &models.Customer{}
	if err := repo.GetDBConnection(connectionType).Model(models.Customer{}).Where(searchFilter).First(&customerModel); err != nil {
		return customerModel, err.Error
	}
	return customerModel, nil
}

func (repo CustomerRepo) GetCustomer(ctx context.Context, filter *models.Customer) (*models.Customer, error) {
	var result models.Customer

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}
