package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/dto"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type DispositionRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Disposition
}

func InitDispositionRepository(ctx context.Context) *DispositionRepo {
	repo := &DispositionRepo{
		model: models.Disposition{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo DispositionRepo) CreateDispositionRecord(ctx context.Context, data *models.Disposition) error {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "DispositionRepo.CreateDispositionRecord"); span != nil {
		defer span.End()
	}
	data.DispositionRefNumber = utils.GenerateRandomString(6, "DRN")

	res := repo.GetWriteDBConnection().Create(&data)
	if res.Error != nil {
		return res.Error
	}

	return nil
}

func (repo DispositionRepo) FindDispositionList(ctx context.Context, filters models.Disposition, pagination dto.PaginationData) ([]models.Disposition, int64, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "DispositionRepo.FindDispositionList"); span != nil {
		defer span.End()
	}

	var result []models.Disposition
	var totalRecords int64

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := repo.GetDBConnection(dbType)

	// Preloading of CustomerInfo, AgentInfo, AddressInfo, ContactInfo
	conn := db.Table("dispositions").Model(&models.Disposition{}).Preload(clause.Associations).Where(filters).Order("id DESC")

	// Count total records before applying pagination
	err := conn.Count(&totalRecords).Error
	if err != nil {
		return nil, 0, err
	}

	// Apply pagination
	conn = conn.Scopes(utils.Paginate(ctx, int(pagination.CurrentPage), int(pagination.Limit)))

	// Fetch paginated records
	err = conn.Find(&result).Error
	if err != nil {
		return nil, 0, err
	}
	return result, totalRecords, nil
}

func (repo DispositionRepo) FindOne(ctx context.Context, filter models.Disposition) (*models.Disposition, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	disposition := &models.Disposition{}
	despositionResp := repo.GetDBConnection(connectionType).Model(&models.Disposition{}).Where(filter)
	if err := despositionResp.First(&disposition).Error; err != nil {
		logger.Error(ctx, err, "DispositionRepo|FindOne|dbErr", logger.LogFields{"where": filter})
		return disposition, err
	}

	return disposition, nil
}

func (repo DispositionRepo) FindDispositionsFromAttemptRef(ctx context.Context, attemptRefNumbers []string) ([]models.Disposition, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	dispositions := []models.Disposition{}
	despositionResp := repo.GetDBConnection(connectionType).Model(&models.Disposition{}).Where("attempt_ref_number IN (?)", attemptRefNumbers)
	if err := despositionResp.Find(&dispositions).Error; err != nil {
		logger.Error(ctx, err, "DispositionRepo|FindOne|dbErr", logger.LogFields{"where": attemptRefNumbers})
		return dispositions, err
	}
	return dispositions, nil
}
