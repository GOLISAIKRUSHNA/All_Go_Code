package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/app/services/storage/sqlservice"
	"context"

	"gorm.io/gorm"
)

type BaseRepo struct {
	ctx     context.Context
	readDB  sqlservice.ISqlService
	writeDB sqlservice.ISqlService
}

func (r *BaseRepo) SetContext(ctx context.Context) *BaseRepo {
	r.ctx = ctx
	return r
}

func (r *BaseRepo) SetDBConnection(db_type constants.DatabaseType) *BaseRepo {
	switch db_type {
	case "READ":
		r.readDB = sqlservice.GetReadInstance()
	case "WRITE":
		r.writeDB = sqlservice.GetWriteInstance()
	}
	return r
}

func (r *BaseRepo) GetContext() context.Context {
	if r.ctx == nil {
		panic(constants.MODEL_NOT_FOUND)
	}
	return r.ctx
}

func (r *BaseRepo) GetDBConnection(db_type constants.DatabaseType) *gorm.DB {
	var db sqlservice.ISqlService
	switch db_type {
	case "READ":
		db = r.readDB
	case "WRITE":
		db = r.writeDB
	}
	if db != nil && db.GetConnection() != nil {
		return db.GetConnection()
	}
	panic("DB Connection not found or not initialized")
}

func (r *BaseRepo) GetReadDBConnection() *gorm.DB {
	return r.GetDBConnection(constants.READ_DATABASE_TYPE)
}

func (r *BaseRepo) GetWriteDBConnection() *gorm.DB {
	return r.GetDBConnection(constants.WRITE_DATABASE_TYPE)
}

func (r *BaseRepo) GetTxnConn() *gorm.DB {
	return r.GetDBConnection(constants.WRITE_DATABASE_TYPE)
}
