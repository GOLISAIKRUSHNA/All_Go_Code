package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type ClientRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Client
}

func InitClientRepository(ctx context.Context) *ClientRepo {
	repo := &ClientRepo{
		model: models.Client{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo ClientRepo) Create(ctx context.Context, model models.Client) (models.Client, error) {

	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.Client{}, created_data.Error
}

func (repo ClientRepo) Update(ctx context.Context, update models.Client, where models.Client) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("client_ref_number=?", &where.ClientRefNumber).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo ClientRepo) FindByReferenceNumberOne(ctx context.Context, filter *models.Client) (*models.Client, error) {
	var result models.Client

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo ClientRepo) FindAllByClientRefNumbers(ctx context.Context, clientRefNumbers []string) ([]models.Client, error) {
	var result []models.Client

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where("client_ref_number IN ?", clientRefNumbers)

	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (repo ClientRepo) UpdateClientConfig(ctx context.Context, clientRefNumber string, config string) error {
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	result := repo.GetDBConnection(dbType).Model(&models.Client{}).Where("client_ref_number=?", clientRefNumber).Update("configuration", config)
	if result.Error != nil {
		return result.Error
	}
	return nil
}
