package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type LoanPaymentRepo struct {
	BaseRepo
	query *gorm.DB
	model models.LoanPayment
}

func InitLoanPaymentRepository(ctx context.Context) *LoanPaymentRepo {
	repo := &LoanPaymentRepo{
		model: models.LoanPayment{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo LoanPaymentRepo) Create(ctx context.Context, model models.LoanPayment) (models.LoanPayment, error) {
	model.LoanPaymentRefNumber = utils.GenerateRandomString(10, "LP")
	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.LoanPayment{}, created_data.Error
}

func (repo LoanPaymentRepo) Update(ctx context.Context, update models.LoanPayment, where models.LoanPaymentWhereParams) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("client_payment_id=?", &where.ClientPaymentId).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo LoanPaymentRepo) FindByReferenceNumberOne(ctx context.Context, filter *models.LoanPayment) (*models.LoanPayment, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	loanPaymentResp := &models.LoanPayment{}
	LoanPayment := repo.GetDBConnection(connectionType).Model(models.LoanPayment{}).Where(filter)
	LoanPayment = LoanPayment.First(&loanPaymentResp)
	if LoanPayment.Error != nil {
		return loanPaymentResp, LoanPayment.Error
	}
	return loanPaymentResp, nil
}
