package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/dto"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/viper"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type LoanRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Loan
}

func InitLoanRepository(ctx context.Context) *LoanRepo {
	repo := &LoanRepo{
		model: models.Loan{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo LoanRepo) Create(ctx context.Context, model models.Loan) (models.Loan, error) {

	created_data := repo.GetWriteDBConnection().Omit("GroupedLoans", "ClientLoanIds").Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.Loan{}, created_data.Error
}

func (repo LoanRepo) FindById(ctx context.Context, loanRefNo string, db_type ...constants.DatabaseType) (map[string]interface{}, error) {

	var result models.Loan

	filters := models.SearchFilters{
		Filters: map[string]interface{}{
			"loan_reference_number": loanRefNo,
		},
	}

	database_type := constants.READ_DATABASE_TYPE

	if len(db_type) > 0 {
		database_type = db_type[0]
	}

	conn, _ := repo.setQuery(ctx, &filters, database_type)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}

	var resMap map[string]interface{}
	inrec, _ := json.Marshal(result)
	json.Unmarshal(inrec, &resMap)

	return resMap, nil
}

func (repo LoanRepo) GetTextColumnName() []string {
	columns := []string{
		"first_name", "last_name", "middle_name", "email",
	}
	return columns
}

func (repo LoanRepo) setQuery(ctx context.Context, mo *models.SearchFilters, db_type constants.DatabaseType) (*gorm.DB, dto.Pagination) {

	conn := repo.GetDBConnection(db_type)

	pagination := dto.Pagination{}

	// Setting default values
	default_limit := viper.GetInt("MYSQL_DB_DEFAULT_LIMIT")
	conn = conn.Clauses(clause.Limit{Limit: &default_limit})
	pagination.Limit = default_limit

	if mo != nil && !utils.IsEmptyStruct(mo) {
		if mo.QueryString != nil {
			// Get the columns of the `User` model.
			columns := repo.GetTextColumnName()
			var query string
			for i, column := range columns {
				if i > 0 {
					query += " OR "
				}
				query += column + " LIKE " + "'%" + *mo.QueryString + "%'"
			}
			conn = conn.Where(query)
		}

		if mo.Offset != nil {
			conn = conn.Offset(*mo.Offset)
			pagination.Offset = *mo.Offset
		}

		if mo.Limit != nil {
			conn = conn.Limit(*mo.Limit)
			pagination.Limit = *mo.Limit
		}

		if mo.AscOrder != nil {
			for _, column := range mo.AscOrder {
				conn = conn.Order(column + " ASC")
			}
		}

		if mo.DescOrder != nil {
			for _, column := range mo.DescOrder {
				conn = conn.Order(column + " DESC")
			}
		}

		if len(mo.Filters) > 0 {
			conn = conn.Or(mo.Filters)
		}
	}

	return conn, pagination
}

func (repo LoanRepo) FindOne(ctx context.Context, filters *models.SearchFilters, db_type ...constants.DatabaseType) (*models.Loan, error) {

	var result models.Loan
	database_type := constants.READ_DATABASE_TYPE

	if len(db_type) > 0 {
		database_type = db_type[0]
	}

	conn, _ := repo.setQuery(ctx, filters, database_type)

	repo.GetReadDBConnection()
	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo LoanRepo) Update(ctx context.Context, update models.Loan, where models.Loan) (bool, error) {
	isUpdated := true
	loanUpdate := repo.GetWriteDBConnection()
	if utils.IsNotEmpty(where.ClientLoanId) {
		loanUpdate = loanUpdate.Where("client_loan_id=?", &where.ClientLoanId).Updates(update)
	}
	if utils.IsNotEmpty(where.LoanRefNumber) {
		loanUpdate = loanUpdate.Where("loan_ref_number=?", &where.LoanRefNumber).Updates(update)
	}
	if loanUpdate.Error != nil {
		isUpdated = false
		return false, loanUpdate.Error
	}
	return isUpdated, nil
}

// gorm not update 0 values so for alternat solution using map will update
func (repo LoanRepo) UpdateWithMap(ctx context.Context, update map[string]interface{}, where models.Loan) bool {
	isUpdated := true
	loanUpdate := repo.GetWriteDBConnection().Model(models.Loan{})
	if utils.IsNotEmpty(where.ClientLoanId) {
		loanUpdate = loanUpdate.Where("client_loan_id=?", &where.ClientLoanId).Updates(update)
	}
	if utils.IsNotEmpty(where.LoanRefNumber) {
		loanUpdate = loanUpdate.Where("loan_ref_number=?", &where.LoanRefNumber).Updates(update)
	}
	if loanUpdate.Error != nil {
		isUpdated = false
		logger.Error(ctx, loanUpdate.Error, "Error while updating loan record", map[string]interface{}{"loan_ref_number": where})
	}
	return isUpdated
}

func (repo LoanRepo) FindByReferenceNumberOne(ctx context.Context, filter models.Loan) (*models.Loan, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	loanResp := &models.Loan{}
	loan := repo.GetDBConnection(connectionType).Model(&models.Loan{}).Where(filter)
	loan = loan.First(&loanResp)
	if loan.Error != nil {
		return loanResp, loan.Error
	}
	return loanResp, nil
}

func (repo LoanRepo) GetSumOfColumns(ctx context.Context, filter models.Loan) ([]models.Loan, error) {
	result := []models.Loan{}
	groupBy := "client_ref_number, customer_ref_number, status"
	switch filter.Level {
	case "CLIENT":
		groupBy = "client_ref_number,customer_ref_number"
	case "LOAN":
		groupBy = "loan_ref_number"
	case "PRODUCT":
		groupBy = "client_ref_number, customer_ref_number, product"
	case "FINANCIER":
		groupBy = "client_ref_number, customer_ref_number, active_financier_ref_number"
	case "PRODUCT_AND_FINANCIER":
		groupBy = "client_ref_number, customer_ref_number, product, active_financier_ref_number"
	default:
		groupBy = "client_ref_number, customer_ref_number"
	}
	sql := buildLoanUnionGroupByQuery(groupBy)
	if err := repo.GetReadDBConnection().Raw(sql, filter.CustomerRefNumber, filter.ClientRefNumber, filter.CustomerRefNumber, filter.ClientRefNumber).Scan(&result).Error; err != nil {
		return result, err
	}
	return result, nil
}

/*
This functon return union records with CC product & non CC product with group by condition
@author Tejas Surve
*/
func buildLoanUnionGroupByQuery(groupByColumn string) string {
	return fmt.Sprintf("(SELECT customer_ref_number, loan_ref_number, client_ref_number, product, active_financier_ref_number,no_of_emis_unpaid, sum(total_due) as total_due, sum(total_principal_due) as total_principal_due, sum(total_interest_due) as total_interest_due, sum(total_fees_due) as total_fees_due, sum(total_principal_outstanding) as total_principal_outstanding,  sum(total_outstanding) as total_outstanding, sum(total_interest_outstanding) as total_interest_outstanding, sum(total_fees_outstanding) as total_fees_outstanding, sum(total_principal_paid) as total_principal_paid, sum(total_interest_paid) as total_interest_paid, sum(total_fees_paid) as total_fees_paid, sum(no_of_emis_paid) as no_of_emis_paid,  max(current_dpd) as current_dpd, max(max_dpd) as max_dpd,  GROUP_CONCAT(loan_ref_number ORDER BY loan_ref_number SEPARATOR ',') AS grouped_loans, GROUP_CONCAT(client_loan_id ORDER BY client_loan_id SEPARATOR ',') AS client_loan_ids, created_by, updated_by FROM loans WHERE customer_ref_number=? AND  client_ref_number=? AND product !='CC' GROUP BY %s ) UNION (SELECT customer_ref_number, loan_ref_number, client_ref_number, product, active_financier_ref_number, no_of_emis_unpaid, sum(total_due) as total_due, sum(total_principal_due) as total_principal_due, sum(total_interest_due) as total_interest_due, sum(total_fees_due) as total_fees_due, sum(total_principal_outstanding) as total_principal_outstanding,  sum(total_outstanding) as total_outstanding, sum(total_interest_outstanding) as total_interest_outstanding, sum(total_fees_outstanding) as total_fees_outstanding, sum(total_principal_paid) as total_principal_paid, sum(total_interest_paid) as total_interest_paid, sum(total_fees_paid) as total_fees_paid, sum(no_of_emis_paid) as no_of_emis_paid,  max(current_dpd) as current_dpd, max(max_dpd) as max_dpd,  GROUP_CONCAT(loan_ref_number ORDER BY loan_ref_number SEPARATOR ',') AS grouped_loans,GROUP_CONCAT(client_loan_id ORDER BY client_loan_id SEPARATOR ',') AS client_loan_ids, created_by, updated_by FROM loans WHERE customer_ref_number=? AND  client_ref_number=? AND product='CC' GROUP BY loan_ref_number)", groupByColumn)
}

/*
Get : return loans slice based on filter
@return []models.Loan, error
@Author Tejas Surve
*/
func (repo LoanRepo) Get(ctx context.Context, filter models.Loan) ([]models.Loan, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	loanResp := []models.Loan{}
	loan := repo.GetDBConnection(connectionType).Model(&models.Loan{})
	if utils.IsNotEmpty(filter.ClientRefNumber) {
		loan = loan.Where("client_ref_number=?", filter.ClientRefNumber)
	}
	if utils.IsNotEmpty(filter.ClientLoanId) {
		loan = loan.Where("client_loan_id=?", filter.ClientLoanId)
	}
	if utils.IsNotEmpty(filter.CustomerRefNumber) {
		loan = loan.Where("customer_ref_number=?", filter.CustomerRefNumber)
	}
	if utils.IsNotEmpty(filter.LoanRefNumber) {
		loan = loan.Where("loan_ref_number=?", filter.LoanRefNumber)
	}
	if utils.IsNotEmpty(filter.CaseRefNumber) {
		loan = loan.Where("case_ref_number=?", filter.CaseRefNumber)
	}
	loan = loan.Find(&loanResp)
	if loan.Error != nil {
		return loanResp, loan.Error
	}
	return loanResp, nil
}

func (repo LoanRepo) FindLoansByCaseRefNumberHavingPayLinks(ctx context.Context, caseRefNumber string) ([]models.Loan, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)

	var userURLModels []models.Loan
	res := repo.GetDBConnection(connectionType).Model(&models.Loan{}).Where("case_ref_number=? and payment_link is not null and payment_link != ''", caseRefNumber)

	res = res.Find(&userURLModels)
	if res.Error != nil {
		return nil, res.Error
	}
	return userURLModels, nil
}

func (repo LoanRepo) GetLoan(ctx context.Context, filter *models.Loan) (*models.Loan, error) {
	var result models.Loan

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Model(&models.Loan{}).Preload(clause.Associations).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo LoanRepo) GetAllActiveLoansWhereCaseRefNumbersIN(ctx context.Context, caseRefNumbers []string) ([]models.Loan, error) {
	var result []models.Loan

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Model(&models.Loan{}).Where("case_ref_number IN (?) AND status='ACTIVE'", caseRefNumbers)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}
