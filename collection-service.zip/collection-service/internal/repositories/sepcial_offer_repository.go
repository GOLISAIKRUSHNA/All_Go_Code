package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
)

type SpecialOfferRepo struct {
	BaseRepo
	model *models.SpecialOffer
}

func InitSpecialOfferRepo(ctx context.Context) *SpecialOfferRepo {
	repo := &SpecialOfferRepo{
		model: &models.SpecialOffer{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)

	return repo
}

func (repo SpecialOfferRepo) Get(ctx context.Context, filter *models.SpecialOffer) (*models.SpecialOffer, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "SpecialOfferRepo.Get"); span != nil {
		defer span.End()
	}

	var result models.SpecialOffer

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo SpecialOfferRepo) GetUnexpired(ctx context.Context, filter *models.SpecialOffer) (*models.SpecialOffer, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "SpecialOfferRepo.GetUnexpired"); span != nil {
		defer span.End()
	}
	var result models.SpecialOffer

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter).Where("end_datetime>NOW()")

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo SpecialOfferRepo) Update(ctx context.Context, filter *models.SpecialOffer, model *models.SpecialOffer) error {
	result := repo.GetWriteDBConnection().Where(filter).Updates(model)
	if result.Error != nil {
		return result.Error
	}
	return nil
}

func (repo SpecialOfferRepo) Create(ctx context.Context, model *models.SpecialOffer) error {
	model.SpecialOfferRefNumber = utils.GenerateRandomString(6, "OFR")
	created_data := repo.GetWriteDBConnection().Create(&model)
	repo.GetWriteDBConnection()
	if created_data.RowsAffected > 0 {
		return nil
	}
	return created_data.Error
}

func (repo SpecialOfferRepo) FindAllUnexpired(ctx context.Context, filter *models.SpecialOffer) ([]models.SpecialOffer, error) {
	var result []models.SpecialOffer

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter).Where("end_datetime>NOW()")

	err := conn.Find(&result).Error
	if err != nil {
		logger.Error(ctx, err, "error while fetching special offers", logger.LogFields{"case_ref_number": filter.CaseRefNumber})
		return nil, err
	}
	return result, nil
}
