package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"
)

type TeamRepository struct {
	BaseRepo
}

func InitTeamRepository(ctx context.Context) *TeamRepository {
	repo := &TeamRepository{}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)

	return repo
}

func (repo *TeamRepository) CreateTeam(ctx context.Context, team *models.Teams) (*models.Teams, error) {
	team.TeamRefNumber = utils.GenerateRandomString(6, "TMR")
	created_data := repo.GetWriteDBConnection().Create(&team)
	if created_data.Error != nil {
		return nil, created_data.Error
	}
	return team, nil
}

func (repo *TeamRepository) GetTeams(ctx context.Context, filters *models.Teams) ([]models.Teams, error) {
	var result []models.Teams
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	conn := repo.GetDBConnection(dbType).Where(filters)
	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}
