package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"gorm.io/gorm"
)

type ClientServiceProviderRepo struct {
	BaseRepo
	query *gorm.DB
	model models.ClientServiceProviders
}

func InitClientServiceProviderRepository(ctx context.Context) *ClientServiceProviderRepo {
	repo := &ClientServiceProviderRepo{
		model: models.ClientServiceProviders{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo ClientServiceProviderRepo) FindAll(ctx context.Context, filter models.ClientServiceProviders) ([]models.ClientServiceProviders, error) {
	var result []models.ClientServiceProviders
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Preload("Client").Preload("ServiceProvider").Where(filter)

	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}
func (repo ClientServiceProviderRepo) FindOne(ctx context.Context, providers models.ClientServiceProviders) (*models.ClientServiceProviders, error) {
	if span := tracing.TraceSpan(ctx, "AgentsRepo.GetAgentInfo"); span != nil {
		defer span.End()
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	var clietServiceProvider *models.ClientServiceProviders
	if err := repo.GetDBConnection(dbType).Model(&models.ClientServiceProviders{}).Preload("Client").Preload("ServiceProvider").Where(providers).First(&clietServiceProvider).Error; err != nil {
		logger.Error(ctx, err, "ClientServiceProviderRepo|FindOne|Error while fetching client service provider details", logger.LogFields{})
		return nil, err
	}
	return clietServiceProvider, nil
}

func (repo ClientServiceProviderRepo) UpdateClientServiceProvider(ctx context.Context, filter *models.ClientServiceProviders, model *models.ClientServiceProviders) error {
	// update client_service_provider table
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	conn := repo.GetDBConnection(dbType).Model(&models.ClientServiceProviders{}).Where(filter).Updates(model)
	if conn.Error != nil {
		return conn.Error
	}
	return nil
}
