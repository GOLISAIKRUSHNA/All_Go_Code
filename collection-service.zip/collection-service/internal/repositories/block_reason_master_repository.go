package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type BlockReasonRepo struct {
	BaseRepo
	query *gorm.DB
	model models.BlockReasonMaster
}

func InitBlockReasonRepository(ctx context.Context) *BlockReasonRepo {
	repo := &BlockReasonRepo{
		model: models.BlockReasonMaster{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo BlockReasonRepo) Create(ctx context.Context, model map[string]interface{}) (*models.BlockReasonMaster, error) {
	modelData := &models.BlockReasonMaster{}
	created_data := repo.GetWriteDBConnection().Model(modelData).Create(&model)
	if created_data.RowsAffected > 0 {
		return modelData, nil
	}
	return &models.BlockReasonMaster{}, created_data.Error
}

func (repo BlockReasonRepo) Update(ctx context.Context, update map[string]interface{}, where models.BlockReasonMaster) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("id=?", &where.ID).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo BlockReasonRepo) FindOne(ctx context.Context, filter models.BlockReasonMaster) (*models.BlockReasonMaster, error) {
	var result models.BlockReasonMaster

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Preload("Violation").Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo BlockReasonRepo) Get(ctx context.Context, filter models.BlockReasonMaster, source []string) (*[]models.BlockReasonMaster, error) {
	var result []models.BlockReasonMaster
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)
	if len(source) > 0 {
		conn = conn.Where("source IN (?)", source)
	}
	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}
