package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"

	"gorm.io/gorm"
)

type UploadRepo struct {
	BaseRepo
	query *gorm.DB
	model models.Upload
}

func InitUploadRepository(ctx context.Context) *UploadRepo {
	repo := &UploadRepo{
		model: models.Upload{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo UploadRepo) Create(ctx context.Context, model models.Upload) (models.Upload, error) {
	model.UploadRefNumber = utils.GenerateRandomString(6, "BULK")
	created_data := repo.GetWriteDBConnection().Create(&model)
	repo.GetWriteDBConnection()
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.Upload{}, created_data.Error
}

func (repo UploadRepo) Update(ctx context.Context, update models.Upload, where models.Upload) (models.Upload, error) {
	uploadModel := models.Upload{}
	uploadData, err := repo.FindByReferenceNumberOne(ctx, where)
	if err != nil {
		return uploadModel, err
	}
	if uploadData.UploadRefNumber != "" {
		customer := repo.GetWriteDBConnection().Where("upload_ref_number=?", &where.UploadRefNumber).Updates(update)
		if customer.RowsAffected > 0 {
			return uploadModel, err
		}
	}
	return uploadModel, nil
}

func (repo UploadRepo) FindByReferenceNumberOne(ctx context.Context, searchFilter models.Upload) (*models.Upload, error) {
	uploadModel := &models.Upload{}
	repo.GetReadDBConnection().Model(models.Upload{}).Preload("UploadedByInfo").Preload("UploadedByClientUser").Where(searchFilter).First(&uploadModel)
	return uploadModel, nil
}

func (repo UploadRepo) GetUploadList(ctx context.Context, searchFilter models.Upload, pageNo int) ([]models.Upload, int64, error) {
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	pageSize := 20
	if pageNo == 0 {
		pageNo = 1
	}
	offset := (pageNo - 1) * pageSize
	var totalItemsCount int64
	uploadModel := []models.Upload{}
	customer := repo.GetDBConnection(connectionType).Model(models.Upload{}).Preload("UploadedByInfo").Preload("UploadedByClientUser").Where(searchFilter).Count(&totalItemsCount)
	// Calculate total pages
	totalPages := (totalItemsCount + int64(pageSize) - 1) / int64(pageSize)

	customer = customer.Order("id desc").Limit(20).Offset(offset).Find(&uploadModel)
	return uploadModel, totalPages, nil
}
