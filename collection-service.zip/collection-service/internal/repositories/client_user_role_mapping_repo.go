package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils/tracing"
	"context"
)

type ClientUserRoleMappingRepo struct {
	BaseRepo
	model models.ClientUserRoleMapping
}

func InitClientUserRoleMappingRepo(ctx context.Context) *ClientUserRoleMappingRepo {
	repo := &ClientUserRoleMappingRepo{
		model: models.ClientUserRoleMapping{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo ClientUserRoleMappingRepo) FindOne(ctx context.Context, filters *models.ClientUserRoleMapping, db_type constants.DatabaseType) (*models.ClientUserRoleMapping, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "ClientUserRoleMappingRepo.FindOne"); span != nil {
		defer span.End()
	}

	var result models.ClientUserRoleMapping

	if db_type == "" {
		db_type = constants.READ_DATABASE_TYPE
	}

	conn := repo.GetReadDBConnection().Where(filters)
	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}
