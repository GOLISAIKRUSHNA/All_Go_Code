package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"

	"gorm.io/gorm"
)

type CustomerAddrRepo struct {
	BaseRepo
	query *gorm.DB
	model models.CustomerAddress
}

func InitCustomerAddressRepository(ctx context.Context) *CustomerAddrRepo {
	repo := &CustomerAddrRepo{
		model: models.CustomerAddress{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo CustomerAddrRepo) Create(ctx context.Context, model *models.CustomerAddress) (*models.CustomerAddress, error) {
	//model.Location = "11"
	model.AddressRefNumber = utils.GenerateRandomString(6, "AD")
	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return &models.CustomerAddress{}, created_data.Error
}

func (repo CustomerAddrRepo) Update(ctx context.Context, update models.CustomerAddress, where models.CustomerAddress) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("address_ref_number=?", &where.AddressRefNumber).Updates(update)
	if result.Error != nil {
		logger.Error(ctx, result.Error, "CustomerAddressRepo|Update", logger.LogFields{"address": update, "Where": where})
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo CustomerAddrRepo) FindByReferenceNumberOne(ctx context.Context, filter models.CustomerAddress) (*models.CustomerAddress, error) {

	custAddrModel := &models.CustomerAddress{}
	custAddResp := repo.GetReadDBConnection().Model(&models.CustomerAddress{}).Where(filter)
	custAddResp = custAddResp.First(&custAddrModel)
	return custAddrModel, nil
}

func (repo CustomerAddrRepo) FindMany(ctx context.Context, filters *models.CustomerAddress) ([]models.CustomerAddress, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "CustomerAddressRepo.FindMany"); span != nil {
		defer span.End()
	}

	var result []models.CustomerAddress

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	//conn, _ := repo.setQuery(ctx, filters, db_type)
	conn := repo.GetDBConnection(dbType).Where(filters)
	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (repo CustomerAddrRepo) UpdateWithMapInterface(ctx context.Context, update map[string]interface{}, where models.CustomerAddress) error {
	caseUpdate := repo.GetWriteDBConnection().Model(models.CustomerAddress{}).Where(where).Updates(update)
	if caseUpdate.Error != nil {
		logger.Error(ctx, caseUpdate.Error, "Error while updating case record", map[string]interface{}{"case_ref_number": where})
		return caseUpdate.Error
	}
	return nil
}
