package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/dto"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
)

type ClientUserRepo struct {
	BaseRepo
	model *models.ClientUser
}

func InitClientUserRepository(ctx context.Context) *ClientUserRepo {
	repo := &ClientUserRepo{
		model: &models.ClientUser{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo ClientUserRepo) FindOne(ctx context.Context, filters *models.ClientUser) (*models.ClientUser, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.FindOne"); span != nil {
		defer span.End()
	}

	var result models.ClientUser

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filters)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo ClientUserRepo) FindOneExceptClientUsers(ctx context.Context, filters *models.ClientUser, clientUserRefNumberNotIn []string) (*models.ClientUser, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.FindOneExceptClientUsers"); span != nil {
		defer span.End()
	}

	var result models.ClientUser

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filters).Not("client_user_ref_number IN (?)", clientUserRefNumberNotIn)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

// Update agent
func (repo ClientUserRepo) Update(ctx context.Context, filters *models.ClientUser, clientUser *models.ClientUser) (bool, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.Create"); span != nil {
		defer span.End()
	}

	result := repo.GetWriteDBConnection().Where(filters).Updates(clientUser)

	if result.Error != nil {
		return false, result.Error
	}
	return true, nil
}

// Create agent
func (repo ClientUserRepo) Create(ctx context.Context, model *models.ClientUser) (*models.ClientUser, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.Create"); span != nil {
		defer span.End()
	}

	model.ClientUserRefNo = utils.GenerateRandomString(10, "CU")
	result := repo.GetWriteDBConnection().Create(&model)

	if result.RowsAffected > 0 {
		return model, nil
	}
	logger.Error(ctx, result.Error, "db error while creating client user",
		logger.LogFields{
			"client user model": model,
		})

	return nil, result.Error
}

func (repo ClientUserRepo) FindClientUserPage(ctx context.Context, filter *models.ClientUser, search string, pagination dto.PaginationData) ([]models.ClientUser, int64, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.FindClientUserPage"); span != nil {
		defer span.End()
	}

	var result []models.ClientUser
	var totalRecords int64

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := repo.GetDBConnection(dbType).Model(&models.ClientUser{})

	// Apply the client user filter
	query := db.Preload("TeamInfo").Preload("ReportingManagerInfo").Where(filter)

	// Search conditions on concatenated first_name and last_name or email
	if search != "" {
		searchPattern := "%" + search + "%"
		query = query.Where("CONCAT(first_name, ' ', last_name) LIKE ? OR email LIKE ?", searchPattern, searchPattern)
	}

	// Count total records without pagination
	err := query.Count(&totalRecords).Error
	if err != nil {
		return nil, 0, err
	}

	// Apply pagination and sorting by created_at in descending order
	query = query.Scopes(utils.Paginate(ctx, int(pagination.CurrentPage), int(pagination.Limit))).
		Order("created_at DESC")

	// Execute the query
	err = query.Find(&result).Error
	if err != nil {
		return nil, 0, err
	}

	// Return the result
	return result, totalRecords, nil
}

func (repo ClientUserRepo) FindClientUser(ctx context.Context, filters *models.ClientUser) (*models.ClientUser, error) {
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	var clientUserModel models.ClientUser
	db := repo.GetDBConnection(dbType)
	conn := db.Model(&models.ClientUser{}).Preload("TeamInfo").Where(filters)

	err := conn.First(&clientUserModel).Error
	if err != nil {
		logger.Error(ctx, err, "db error while fetching client user entry",
			map[string]interface{}{"client_user_ref_number": filters.ClientUserRefNo})
		return nil, err
	}

	return &clientUserModel, nil
}

func (repo ClientUserRepo) UpdateClientUserTeamRefNumber(ctx context.Context, filters []string, teamRefNumber string) (bool, error) {
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.UpdateClientUserTeamRefNumber"); span != nil {
		defer span.End()
	}
	result := repo.GetWriteDBConnection().Table("client_users").Where("client_user_ref_number IN (?)", filters).Update("client_team_ref_number", teamRefNumber)
	if result.Error != nil {
		return false, result.Error
	}
	return true, nil

}

func (repo ClientUserRepo) FindClientUsersByTeamRefNumbers(ctx context.Context, teamRefNumbers []string) ([]models.ClientUser, error) {
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.FindClientUsersByTeamRefNumbers"); span != nil {
		defer span.End()
	}

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	var clientUsers []models.ClientUser
	conn := repo.GetDBConnection(dbType).Where("client_team_ref_number IN (?)", teamRefNumbers)
	err := conn.Find(&clientUsers).Error
	if err != nil {
		return nil, err
	}
	return clientUsers, nil
}

func (repo ClientUserRepo) GetClientUserMatchingByName(ctx context.Context, filter *models.ClientUser, pagination dto.PaginationData) ([]models.ClientUser, int64, error) {
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.GetClientUserMatchingByName"); span != nil {
		defer span.End()
	}

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := repo.GetDBConnection(dbType)

	var totalRecords int64
	var result []models.ClientUser

	// Construct the base query with filtering
	baseQuery := db.Model(&models.ClientUser{}).Preload("TeamInfo").Where("client_ref_number = ? AND first_name LIKE ?", filter.ClientRefNumber, "%"+filter.FirstName+"%")

	// Counting totalRecords without pagination
	err := baseQuery.Count(&totalRecords).Error
	if err != nil {
		return nil, 0, err
	}

	// Apply pagination and ordering
	query := baseQuery.Scopes(utils.Paginate(ctx, int(pagination.CurrentPage), int(pagination.Limit))).
		Order("CASE WHEN client_team_ref_number = '' THEN 0 ELSE 1 END")

	// Execute the query
	if err := query.Find(&result).Error; err != nil {
		return result, 0, err
	}

	// Return the result
	return result, totalRecords, nil
}

func (repo ClientUserRepo) CheckIsPresentInTeam(ctx context.Context, clientUserRefNumbers []string) (bool, error) {
	if span := tracing.TraceSpan(ctx, "ClientUserRepo.CheckIsPresentInTeam"); span != nil {
		defer span.End()
	}

	dbType := utils.ExtractDBTypeFromCtx(ctx)
	var count int64
	conn := repo.GetDBConnection(dbType).Model(&models.ClientUser{}).
		Where("client_user_ref_number IN (?) AND (client_team_ref_number IS NULL OR client_team_ref_number = '')", clientUserRefNumbers).
		Count(&count)
	if conn.Error != nil {
		return false, conn.Error
	}
	// If count is greater than 0, it means there are client users with empty or null client_team_ref_number
	if count > 0 {
		return false, nil
	}
	return true, nil
}
