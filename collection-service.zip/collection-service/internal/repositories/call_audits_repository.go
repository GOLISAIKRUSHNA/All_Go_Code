package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/dto/request"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"gorm.io/gorm"
)

type CallAuditsRepo struct {
	BaseRepo
	query *gorm.DB
	model models.CallAudits
}

func InitCallAuditRepository(ctx context.Context) *CallAuditsRepo {
	repo := &CallAuditsRepo{
		model: models.CallAudits{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo CallAuditsRepo) CreateCallAudits(ctx context.Context, model models.CallAudits) error {
	if span := tracing.TraceSpan(ctx, "CallAuditRepository.reateCallAudits"); span != nil {
		defer span.End()
	}
	model.AuditRefNumber = utils.GenerateRandomString(16, "AURN")
	query := repo.GetWriteDBConnection().Create(&model)
	if query.Error != nil {
		return query.Error
	}
	return nil
}

func (repo CallAuditsRepo) CallAuditsList(ctx context.Context, queryRequest request.CallAuditsList) ([]models.CallAudits, int64, int, error) {
	if span := tracing.TraceSpan(ctx, "CallAuditRepository.CallAuditsList"); span != nil {
		defer span.End()
	}
	var callAudits []models.CallAudits
	var totalRecords int64
	var pageSize int = 10

	if queryRequest.PageNo == 0 {
		queryRequest.PageNo = 1
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	query := repo.GetDBConnection(dbType).
		Model(models.CallAudits{}).
		Preload("Agent").
		Preload("Disposition")

	// Add condition for audit_agent_ref_number if provided
	if queryRequest.AuditAgentRefNumber != "" {
		query = query.Where("audit_agent_ref_number = ?", queryRequest.AuditAgentRefNumber)
	}

	if queryRequest.AuditRefNumber != "" {
		query = query.Where("audit_ref_number = ?", queryRequest.AuditRefNumber)
	}

	// Add condition for search query if provided
	if queryRequest.Search != "" {
		searchPattern := "%" + queryRequest.Search + "%"
		query = query.Where("audit_ref_number LIKE ? OR case_ref_number LIKE ?", searchPattern, searchPattern)
	}

	if queryRequest.Status != "" {
		query = query.Where("status = ?", queryRequest.Status)
	}

	// Apply sorting by CreatedAt if provided
	if queryRequest.Sort == "call_date" {
		query = query.Order("call_date ASC")
	} else if queryRequest.Sort == "-call_date" {
		query = query.Order("call_date DESC")
	} else if queryRequest.Sort == "call_duration" {
		query = query.Order("call_duration ASC")
	} else if queryRequest.Sort == "-call_duration" {
		query = query.Order("call_duration DESC")
	} else {
		query = query.Order("created_at DESC")
	}

	query = query.Count(&totalRecords).
		Scopes(utils.Paginate(ctx, queryRequest.PageNo, pageSize)).
		Find(&callAudits)

	if query.Error != nil {
		return nil, 0, 0, query.Error
	}

	totalPages := totalRecords / int64(pageSize)
	if totalRecords%int64(pageSize) > 0 {
		totalPages++
	}

	return callAudits, totalPages, queryRequest.PageNo, nil
}

func (repo CallAuditsRepo) FindOne(ctx context.Context, filter models.CallAudits) (models.CallAudits, error) {
	if span := tracing.TraceSpan(ctx, "CallAuditRepository.FindOne"); span != nil {
		defer span.End()
	}
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	var callAudits models.CallAudits
	query := repo.GetDBConnection(connectionType).
		Model(models.CallAudits{}).
		Where(filter).
		First(&callAudits)
	if query.Error != nil {
		return callAudits, query.Error
	}
	return callAudits, nil
}

func (repo CallAuditsRepo) UpdateOne(ctx context.Context, where models.CallAudits, update models.CallAudits) error {
	if span := tracing.TraceSpan(ctx, "CallAuditRepository.UpdateOne"); span != nil {
		defer span.End()
	}

	query := repo.GetWriteDBConnection().Where(where).Updates(update)
	if query.Error != nil {
		return query.Error
	}
	return nil
}

func (repo CallAuditsRepo) FindByAuditRefNumbers(ctx context.Context, filter request.AuditAgentAllocate) ([]models.CallAudits, error) {
	if span := tracing.TraceSpan(ctx, "CallAuditRepository.FindByAuditRefNumbers"); span != nil {
		defer span.End()
	}
	connectionType := utils.ExtractDBTypeFromCtx(ctx)
	var callAudits []models.CallAudits
	query := repo.GetDBConnection(connectionType).
		Model(models.CallAudits{}).
		Where("audit_ref_number IN (?)", filter.AuditRefNumbers).
		Where("audit_agent_ref_number IS NULL OR audit_agent_ref_number = ''").
		Find(&callAudits)
	if query.Error != nil {
		return callAudits, query.Error
	}
	return callAudits, nil
}

func (repo CallAuditsRepo) UpdateAuditAgentRefNumber(ctx context.Context, filter request.AuditAgentAllocate) error {
	if span := tracing.TraceSpan(ctx, "CallAuditRepository.UpdateAuditAgentRefNumber"); span != nil {
		defer span.End()
	}
	query := repo.GetWriteDBConnection().Model(&models.CallAudits{}).
		Where("audit_ref_number IN (?)", filter.AuditRefNumbers). // Use IN clause for multiple values
		Update("audit_agent_ref_number", filter.AuditAgentRefNumber)
	if query.Error != nil {
		return query.Error
	}
	return nil
}
