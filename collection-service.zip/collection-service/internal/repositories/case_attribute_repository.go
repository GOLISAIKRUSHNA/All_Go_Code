package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"context"
	"fmt"

	"gorm.io/gorm"
)

type CaseAttributeRepo struct {
	BaseRepo
	query *gorm.DB
	model models.CaseAttribute
}

func InitCaseAttributeRepository(ctx context.Context) *CaseAttributeRepo {
	repo := &CaseAttributeRepo{
		model: models.CaseAttribute{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo CaseAttributeRepo) Create(ctx context.Context, model models.CaseAttribute) (models.CaseAttribute, error) {
	fmt.Println("------------------repo-interface-create------------------", model)
	created_data := repo.GetWriteDBConnection().Create(&model)
	if created_data.RowsAffected > 0 {
		return model, nil
	}
	return models.CaseAttribute{}, created_data.Error
}

func (repo CaseAttributeRepo) Update(ctx context.Context, update models.CaseAttribute, caseRefNumber string) (bool, error) {
	isUpdated := true
	result := repo.GetWriteDBConnection().Where("case_ref_number=?", caseRefNumber).Updates(update)
	if result.Error != nil {
		isUpdated = false
		return isUpdated, result.Error
	}
	return isUpdated, nil
}

func (repo CaseAttributeRepo) FindByReferenceNumberOne(ctx context.Context, filter models.CaseAttribute) (*models.CaseAttribute, error) {
	var result models.CaseAttribute

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filter)

	err := conn.First(&result).Error
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func (repo CaseAttributeRepo) UpdateWithMapInterface(ctx context.Context, update map[string]interface{}, where models.CaseAttribute) bool {
	isUpdated := true
	caseUpdate := repo.GetWriteDBConnection().Model(models.CaseAttribute{}).Where("case_ref_number=?", &where.CaseRefNumber).Updates(update)
	if caseUpdate.Error != nil {
		isUpdated = false
		logger.Error(ctx, caseUpdate.Error, "Error while updating case record", logger.LogFields{"case_ref_number": where})
	}
	return isUpdated
}
