package repositories

import (
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"time"
)

type ViolationsRepo struct {
	BaseRepo
}

func InitViolationsRepo(ctx context.Context) *ViolationsRepo {
	repo := &ViolationsRepo{}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo ViolationsRepo) GetViolations(ctx context.Context, clientRefNumber string, ids []string) ([]*models.Violations, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "ViolationsRepo.GetViolations"); span != nil {
		defer span.End()
	}

	var result []*models.Violations
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := repo.GetDBConnection(dbType)

	conn := db.Where("client_ref_number = ? OR id IN ?", clientRefNumber, ids).Where("deleted_at IS NULL").Find(&result)
	if conn.Error != nil {
		return nil, conn.Error

	}
	return result, nil
}

func (repo ViolationsRepo) CreateViolation(ctx context.Context, violation map[string]interface{}) (*models.Violations, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "ViolationsRepo.CreateViolation"); span != nil {
		defer span.End()
	}
	violationModel := &models.Violations{}
	result := repo.GetWriteDBConnection().Model(violationModel).Create(&violation)
	if result.Error != nil {
		return violationModel, result.Error
	}
	// Retrieve the created record to populate violationModel
	if err := repo.GetWriteDBConnection().Order("id desc").Where("violation = ?", violation["violation"]).Where("client_ref_number = ?", violation["client_ref_number"]).First(violationModel).Error; err != nil {
		return nil, err
	}
	return violationModel, nil
}

func (repo ViolationsRepo) UpdateViolation(ctx context.Context, id int, violation map[string]interface{}) (bool, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "ViolationsRepo.UpdateViolation"); span != nil {
		defer span.End()
	}

	result := repo.GetWriteDBConnection().Table("violations").Where("id = ?", id).Updates(violation)
	if result.Error != nil {
		return false, result.Error
	}

	return true, nil
}
func (repo ViolationsRepo) DeleteViolation(ctx context.Context, filter models.Violations) (bool, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "ViolationsRepo.DeleteViolation"); span != nil {
		defer span.End()
	}

	// Update the "deleted_at" field to mark the record as deleted
	result := repo.GetWriteDBConnection().Model(&models.Violations{}).Where("id = ?", filter.ID).Update("deleted_at", time.Now())
	if result.Error != nil {
		return false, result.Error
	}

	return true, nil
}

func (rep ViolationsRepo) GetViolationByID(ctx context.Context, id int) (*models.Violations, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "ViolationsRepo.GetViolationByID"); span != nil {
		defer span.End()
	}
	var result models.Violations
	dbType := utils.ExtractDBTypeFromCtx(ctx)
	db := rep.GetDBConnection(dbType)

	conn := db.Where("id = ?", id).Find(&result)
	if conn.Error != nil {
		return nil, conn.Error

	}
	return &result, nil
}
