package repositories

import (
	"collection-service/common/logger"
	"collection-service/internal/app/constants"
	"collection-service/internal/models"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"time"

	"gorm.io/gorm"
)

type AttendanceRepo struct {
	BaseRepo
	query *gorm.DB
	model *models.Attendance
}

func InitAttendanceRepository(ctx context.Context) *AttendanceRepo {
	repo := &AttendanceRepo{
		model: &models.Attendance{},
	}
	repo.SetContext(ctx).SetDBConnection(constants.READ_DATABASE_TYPE).SetDBConnection(constants.WRITE_DATABASE_TYPE)
	return repo
}

func (repo AttendanceRepo) FindMany(ctx context.Context, filters *models.Attendance) ([]models.Attendance, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "AttendanceRepo.FindMany"); span != nil {
		defer span.End()
	}

	var result []models.Attendance

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where(filters)
	err := conn.Find(&result).Error
	if err != nil {
		logger.Error(ctx, err, "Could Not FindMany Attendances", nil)
		return nil, err
	}
	return result, nil
}

// Find many attendances by attendance reference numbers
func (repo AttendanceRepo) FindManyByAttendanceRefNumbers(ctx context.Context, attendanceRefNumbers []string) ([]models.Attendance, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "AttendanceRepo.FindManyByAttendanceRefNumbers"); span != nil {
		defer span.End()
	}

	var result []models.Attendance

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Where("attendance_ref_number IN (?)", attendanceRefNumbers)
	err := conn.Find(&result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}

// find all attendances belonging to a string of agent ref numbers and in a particular approval status
func (repo AttendanceRepo) FindManyByAgentRefNumbers(ctx context.Context, agentRefNumbers []string, approvalStatus string) ([]models.Attendance, error) {
	// API tracing enabling
	if span := tracing.TraceSpan(ctx, "AttendanceRepo.FindManyByAgentRefNumbers"); span != nil {
		defer span.End()
	}

	var result []models.Attendance

	dbType := utils.ExtractDBTypeFromCtx(ctx)

	conn := repo.GetDBConnection(dbType).Preload("AgentInfo").Where("agent_ref_number IN (?) AND approval_status = ?", agentRefNumbers, approvalStatus)
	err := conn.Find(&result).Error
	if err != nil {
		logger.Error(ctx, err, "Could Not Find Attendances", nil)
		return nil, err
	}
	return result, nil
}

// Create Attendance
func (repo AttendanceRepo) Create(ctx context.Context, model *models.Attendance) (bool, error) {

	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "AttendanceRepo.Create"); span != nil {
		defer span.End()
	}

	model.AttendanceRefNumber = utils.GenerateRandomString(10, "AT")
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	result := repo.GetDBConnection(dbType).Create(model)

	if result.RowsAffected > 0 {
		return true, nil
	}

	return false, result.Error
}

// Update Attedance Approval Status
func (repo AttendanceRepo) UpdateApprovalStatus(ctx context.Context, attendanceRefNumbers []string, approvalStatus string, agentName string) (bool, error) {
	// Api tracing enabling
	if span := tracing.TraceSpan(ctx, "AttendanceRepo.UpdateApprovalStatus"); span != nil {
		defer span.End()
	}
	dbType := utils.ExtractDBTypeFromCtx(ctx)

	result := repo.GetDBConnection(dbType).Where("attendance_ref_number IN (?) ", attendanceRefNumbers).Updates(models.Attendance{ApprovalStatus: approvalStatus, ApprovalDatetime: time.Now(), ApprovedBy: agentName})

	if result.Error != nil {

		logger.Error(ctx, result.Error, "Unable to get Attendances", nil)
		return false, result.Error
	}
	return true, nil
}
