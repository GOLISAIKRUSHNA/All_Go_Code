package threadservice

import (
	"errors"
	"sync"
)

// Task is a function that performs some work and returns a result
type Task func()

// ThreadPool is a ThreadPool of workers that can execute tasks concurrently
type ThreadPool struct {
	tasks      chan Task
	wg         *sync.WaitGroup
	numWorkers int
}

// NewPool creates a new ThreadPool with the given number of workers
func Execute(numWorkers int, data []func()) (*ThreadPool, error) {

	if numWorkers <= 0 {
		return nil, errors.New("Number of Workers must be greater than 0")
	}
	wp := &ThreadPool{
		tasks:      make(chan Task),
		numWorkers: numWorkers,
		wg:         &sync.WaitGroup{},
	}
	wp.wg.Add(len(data))

	go wp.addToChannel(data)

	for i := 0; i < numWorkers; i++ {
		go wp.worker()
	}
	return wp, nil
}

func (wp *ThreadPool) addToChannel(data []func()) {
	defer close(wp.tasks)
	for _, t := range data {
		wp.tasks <- t
	}
}

// worker is a goroutine that listens for tasks on the tasks channel,
// executes them, and sends the result on the results channel
func (wp *ThreadPool) worker() {
	for task := range wp.tasks {
		task()
		wp.wg.Done()
	}
}

// // Submit submits a task to the worker ThreadPool
// func (wp *ThreadPool) Submit(task Task) {
// 	wp.tasks <- task
// }

// // Close shuts down the worker ThreadPool and waits for all workers to finish
// func (wp *ThreadPool) Close() {
// 	close(wp.tasks)
// }

// Waits for all workers to finish
func (wp *ThreadPool) Wait() {
	wp.wg.Wait()
}

// // Results returns a channel that you can use to read the results of completed tasks
// func (wp *ThreadPool) Results() <-chan interface{} {
// 	return wp.results
// }
