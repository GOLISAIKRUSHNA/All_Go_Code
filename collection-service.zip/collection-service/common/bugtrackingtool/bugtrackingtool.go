package bugtrackingtool

import (
	"collection-service/internal/utils"
	"errors"
	"fmt"

	"net"
	"strings"

	"github.com/spf13/viper"
)

var BugTrackingObj *BugTrackingTool
var HostIPs *string = nil

type BugTrackingTool struct {
	trackingtool string
}

func GetNewBugTool() *BugTrackingTool {
	BugTrackingObj = &BugTrackingTool{trackingtool: viper.GetString("BUG_TRACKING_TOOL")}
	return BugTrackingObj
}

func (bs *BugTrackingTool) Initialize() {
	// getting the ip_addresses of the host machines
	getIPAddress()

	switch bs.trackingtool {
	case "SENTRY":
		utils.InitializeSentry(HostIPs)
	default:
		err := errors.New("no tool selected")
		panic(err)
	}
}

func getIPAddress() {
	//Getting the address of the host machine
	addrs, err := net.InterfaceAddrs()
	if err == nil {
		ip_addresses := strings.Trim(fmt.Sprint(addrs[:]), "[]")
		HostIPs = &ip_addresses
	}
}

func (bs *BugTrackingTool) CaptureException(err error) {

	switch bs.trackingtool {
	case "SENTRY":
		utils.SentryCaptureException(err)
	}
}
