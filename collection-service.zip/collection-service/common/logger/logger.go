// Package logger provides custom logging functionalities using Zap and integration with OpenTelemetry and Sentry.
package logger

import (
	"collection-service/common/bugtrackingtool"
	"collection-service/internal/app/constants"
	"collection-service/internal/utils"
	"collection-service/internal/utils/tracing"
	"context"
	"fmt"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"strings"

	"github.com/spf13/viper"
	"github.com/uptrace/opentelemetry-go-extra/otelzap"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/sdk/resource"
	"go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.17.0"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

func Initialize(ctx context.Context) {
	lOption := loggerOptions{
		ServiceName: viper.GetString("SERVICE_NAME"),
		Env:         viper.GetString("APP_ENV"),
		Level:       viper.GetString("LOG_LEVEL"),
	}

	configureLogger(lOption)
}

type LogField map[string]interface{}

// customLogger is a custom logger type that encapsulates the Zap logger and additional metadata.
type customLogger struct {
	zl          *otelzap.Logger // Zap logger
	env         string          // Environment
	serviceName string          // Service name
	commitID    string          // Commit ID
}

var logger *customLogger

// LoggerOptions are the properties that will be used to initialize the customLogger
type loggerOptions struct {
	ServiceName string
	Env         string
	Level       string
}

// Configure initializes the customLogger based on the provided LoggerOptions.
func configureLogger(cfg loggerOptions) {
	logger = &customLogger{
		zl:          newZapLogger(cfg),
		env:         cfg.Env,
		serviceName: cfg.ServiceName,
		// getting commit id from build vcs profile
		commitID: func() string {
			if info, ok := debug.ReadBuildInfo(); ok {
				for _, setting := range info.Settings {
					if setting.Key == "vcs.revision" {
						return setting.Value
					}
				}
			}

			return ""
		}(),
	}
}

// setLogLevel sets the Zap log level based on the provided string.
func setLogLevel(l string) zapcore.Level {
	var level zapcore.Level
	switch l {
	case "DEBUG":
		level = zap.DebugLevel
	default:
		level = zap.InfoLevel
	}

	return level
}

// Info logs an informational message.
func Info(ctx context.Context, msg string, fields map[string]interface{}) {
	logger.zl.Ctx(ctx).Info(msg, fieldsToZapFields(enhanceFields(ctx, fields))...)
}

// Warn logs a warning message.
func Warn(ctx context.Context, msg string, fields map[string]interface{}) {
	logger.zl.Ctx(ctx).Warn(msg, fieldsToZapFields(enhanceFields(ctx, fields))...)
}

// Debug logs a debug message.
func Debug(ctx context.Context, msg string, fields map[string]interface{}) {
	logger.zl.Ctx(ctx).Debug(msg, fieldsToZapFields(enhanceFields(ctx, fields))...)
}

// Error logs an error message.
func Error(ctx context.Context, err error, msg string, fields map[string]interface{}) {
	if err != nil {
		msg = msg + " : " + err.Error()
	}
	zapfields := []zap.Field{zap.Error(err)}
	zapfields = append(zapfields, fieldsToZapFields(enhanceFields(ctx, fields))...)
	logger.zl.Ctx(ctx).Error(msg, zapfields...)

	if bugtrackingtool.BugTrackingObj != nil {
		bugtrackingtool.BugTrackingObj.CaptureException(err)
	}
}

// Error logs an error message.
func Fatal(ctx context.Context, err error, msg string, fields map[string]interface{}) {
	if err != nil {
		msg = msg + " : " + err.Error()
	}
	zapfields := []zap.Field{zap.Error(err)}
	zapfields = append(zapfields, fieldsToZapFields(enhanceFields(ctx, fields))...)
	logger.zl.Ctx(ctx).Fatal(msg, zapfields...)
	bugtrackingtool.BugTrackingObj.CaptureException(err)
}

func CreateLogMsg(message ...string) string {
	otrMessage := strings.Join(message, " | ")
	return fmt.Sprintf("%s | %s", strings.ToUpper(viper.GetString("APP_ENV")), otrMessage)
}

// fieldsToZapFields converts a map of fields to Zap fields.
func fieldsToZapFields(fields map[string]any) []zap.Field {
	zapFields := make([]zap.Field, 0, len(fields))
	for k, v := range fields {
		zapFields = append(zapFields, zap.Any(k, v))
	}
	return zapFields
}

// enhanceFields enhances the provided fields with additional metadata.
func enhanceFields(ctx context.Context, fields map[string]interface{}) map[string]interface{} {
	customFields := make(map[string]interface{})
	if fields == nil {
		fields = make(map[string]interface{})
	}

	customFields["data"] = fields
	customFields["service_name"] = logger.serviceName
	customFields["env"] = logger.env
	customFields["revision"] = logger.commitID
	customFields["log_type"] = "app-log"

	traceID, spanID, _ := tracing.GetTraceInfoFromContext(ctx)
	customFields[constants.TRACE_ID] = traceID
	customFields[constants.SPAN_ID] = spanID

	// modify log type if log_type field is present.
	if logType, ok := fields["log_type"]; ok {
		if logTypeStr, ok := logType.(string); ok && (logTypeStr == "http-log" || logTypeStr == "scheduler-log") {
			customFields["log_type"] = logTypeStr
		}
		delete(fields, "log_type")
	}

	// set http log fields
	customFields["status"], _ = fields["status"].(string)
	customFields["latency"], _ = fields["latency"].(string)
	customFields["request_method"], _ = fields["request_method"].(string)
	customFields["uri"], _ = fields["uri"].(string)
	customFields["body_size"], _ = fields["body_size"].(string)
	customFields["headers"], _ = fields["headers"]

	// delete http log fields
	delete(fields, "status")
	delete(fields, "latency")
	delete(fields, "request_method")
	delete(fields, "uri")
	delete(fields, "body_size")
	delete(fields, "headers")

	// Add origin data
	origin := getOrigin(3)
	customFields["origin"] = origin

	return customFields
}

func getOrigin(skip int) LogFields {
	pc, file, line, _ := runtime.Caller(skip)
	filename := filepath.Base(file)
	funcName := runtime.FuncForPC(pc).Name()
	return LogFields{
		"file_name": filename,
		"file_line": line,
		"function":  funcName,
	}
}

// newZapLogger creates a new Zap logger based on the provided LoggerOptions.
func newZapLogger(opts loggerOptions) *otelzap.Logger {
	// Modify Zap logger initialization based on your requirements
	config := zap.NewProductionConfig()
	config.Level.SetLevel(setLogLevel(opts.Level))
	config.DisableCaller = true
	config.EncoderConfig.EncodeLevel = zapcore.CapitalLevelEncoder
	config.EncoderConfig.TimeKey = "log_time"
	config.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder
	logger, _ := config.Build()

	// Attach OpenTelemetry
	tracedLogger := otelzap.New(logger)

	return tracedLogger
}

func InitializeTelemetry(ctx context.Context) (*trace.TracerProvider, error) {

	var httpclient otlptrace.Client
	tempoUrl := viper.GetString("TEMPO_HTTP_URL")

	if strings.EqualFold(viper.GetString("APP_ENV"), "local") ||
		strings.EqualFold(viper.GetString("APP_ENV"), "development") {
		httpclient = otlptracehttp.NewClient(
			otlptracehttp.WithInsecure(),
			otlptracehttp.WithEndpoint(tempoUrl),
		)
	} else {
		httpclient = otlptracehttp.NewClient(
			otlptracehttp.WithEndpoint(tempoUrl),
		)
	}

	exporter, err := otlptrace.New(ctx, httpclient)

	if err != nil {
		return nil, err
	}

	res, err := resource.New(ctx, resource.WithAttributes(
		// the service name used to display traces in backends
		semconv.ServiceName(viper.GetString("SERVICE_NAME")),
	))
	if err != nil {
		Fatal(ctx, err, "Failed to create resource", nil)
	}

	// Login a TracerProvider with the OTLP exporter
	tp := trace.NewTracerProvider(
		trace.WithBatcher(exporter),
		trace.WithSampler(trace.AlwaysSample()), // adjust the sampling strategy as needed
		trace.WithResource(res),
	)
	otel.SetTextMapPropagator(utils.CustomPropagator{})
	otel.SetTracerProvider(tp)

	return tp, nil
}

type LogFields map[string]interface{}
