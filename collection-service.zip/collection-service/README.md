# Collection Service

A micro-service build using go.

--------
## Requirements

- [Go](https://go.dev/)
- Redis
- RabbitMQ

or
- [Docker](https://www.docker.com/)

--------

## How to run via docker?

The following are basic instructions to run the service via docker. 

### Step 1 - Get the code

Clone the code:

```shell
$ git clone git@bitbucket.org:ramp-ai-tech/collection-service.git
Cloning into 'app'...
```


### Step 2 - Create .env.docker file
- create `.env.docker` file in project root, and copy `.env.example` file content to .env.docker
- write necessary values to each key in .`env.docker` file.

### Step 3 - Run the containers
`$ docker compose up`
